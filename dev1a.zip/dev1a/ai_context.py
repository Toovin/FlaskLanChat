"""
AI Context Module - Inference-only message storage and context management
"""

from typing import List, Dict, Optional, Any
from ai_database import ai_database


class ContextManager:
    """
    Manages AI conversation context (inference-only storage)
    """

    def __init__(self):
        self.db = ai_database

    def save_message(self, conversation_key: str, role: str, content: str) -> bool:
        """Save a message to context (for inference only)"""
        return self.db.save_context_message(conversation_key, role, content)

    def get_context(self, conversation_key: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Get conversation context for AI inference"""
        return self.db.get_context_messages(conversation_key, limit)

    def build_openai_messages(self, conversation_key: str, limit: int = 50) -> List[Dict[str, str]]:
        """Build OpenAI-compatible message format from context"""
        messages = self.get_context(conversation_key, limit)

        # Convert to OpenAI format
        openai_messages = []
        for msg in messages:
            openai_messages.append({
                "role": msg["role"],
                "content": msg["content"]
            })

        return openai_messages

    def build_enhanced_context_messages(self, conversation_key: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Build enhanced message format with conversation flow awareness"""
        messages = self.get_context(conversation_key, limit)

        enhanced_messages = []
        for i, msg in enumerate(messages):
            enhanced_msg = {
                "role": msg["role"],
                "content": msg["content"],
                "timestamp": msg.get("timestamp"),
                "sequence_id": i,
                "conversation_flow": self._analyze_conversation_flow(messages, i)
            }
            enhanced_messages.append(enhanced_msg)

        return enhanced_messages

    def _analyze_conversation_flow(self, messages: List[Dict], current_index: int) -> str:
        """Analyze the conversation flow for a message"""
        if current_index == 0:
            return "conversation_start"

        prev_msg = messages[current_index - 1]

        if prev_msg["role"] == messages[current_index]["role"]:
            return "same_speaker_continuation"
        else:
            return "speaker_change_response"

    def prune_old_messages(self, conversation_key: str, max_messages: int = 100):
        """Prune old context messages to manage database size"""
        self.db.prune_old_context(conversation_key, max_messages)

    def get_conversation_key(self, user_uuid: str, conversation_type: str,
                           channel_id: str = None, character_name: str = None) -> str:
        """Generate a unique conversation key"""
        if conversation_type == "channel" and channel_id:
            return f"channel:{channel_id}:{character_name or 'default'}"
        elif conversation_type == "dm":
            return f"dm:{user_uuid}:ai"
        elif conversation_type == "modal":
            return f"modal:{user_uuid}:{character_name or 'default'}"
        else:
            return f"unknown:{user_uuid}"

    def add_user_message(self, conversation_key: str, content: str) -> bool:
        """Add a user message to context"""
        return self.save_message(conversation_key, "user", content)

    def add_assistant_message(self, conversation_key: str, content: str) -> bool:
        """Add an assistant message to context"""
        return self.save_message(conversation_key, "assistant", content)

    def get_recent_context(self, conversation_key: str, max_messages: int = 20) -> List[Dict[str, str]]:
        """Get recent context for AI inference (most common use case)"""
        return self.build_openai_messages(conversation_key, max_messages)

    def clear_context(self, conversation_key: str) -> bool:
        """Clear all context for a conversation (hard reset)"""
        try:
            # This would need to be added to the database layer
            # For now, we'll prune to 0 messages
            self.prune_old_messages(conversation_key, 0)
            return True
        except Exception:
            return False

    def clear_all_contexts(self, user_uuid: str) -> bool:
        """Clear all conversation contexts for a user"""
        return self.db.delete_all_user_conversations(user_uuid)


# Global context manager instance
context_manager = ContextManager()