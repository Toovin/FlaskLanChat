from flask import Blueprint, request, jsonify, send_from_directory, make_response, send_file, session
from werkzeug.utils import secure_filename
from lc_config import UPLOAD_DIR, THUMBNAILS_DIR, AVATAR_DIR, DEFAULT_AVATAR_DIR, MEDIA_DOWNLOAD_DIR, THUMBNAILS_MEDIA_DOWNLOADED_DIR, MAX_FILE_SIZE, MAX_TOTAL_UPLOAD_SIZE
import os
from datetime import datetime
import sqlite3
import uuid
import json
import yt_dlp
from PIL import Image
try:
    import cv2
    import numpy as np
    OPENCV_AVAILABLE = True
except ImportError:
    OPENCV_AVAILABLE = False

import re
import time
import mimetypes
from urllib.parse import quote

file_routes = Blueprint('file_routes', __name__)

@file_routes.route('/files', methods=['GET'])
def list_files():
    storage_dir = request.args.get('storage_dir', 'uploads')
    if storage_dir == 'uploads':
        upload_path = UPLOAD_DIR
    elif storage_dir == 'media_downloaded':
        upload_path = MEDIA_DOWNLOAD_DIR
    else:
        upload_path = os.path.join('static', storage_dir)
    try:
        files = []
        for filename in os.listdir(upload_path):
            filepath = os.path.join(upload_path, filename)
            if os.path.isfile(filepath):
                stat = os.stat(filepath)
                lazy_url = f'/lazy-file/{storage_dir}/{filename}'
                file_info = {
                    'name': filename,
                    'size': stat.st_size,
                    'lazy_url': lazy_url,
                    'modified': datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
                }
                files.append(file_info)
        print(f"Listed {len(files)} files from {upload_path} with lazy URLs")
        return jsonify({'files': files}), 200
    except FileNotFoundError:
        print(f"Directory {upload_path} not found, returning empty list")
        return jsonify({'files': []}), 200
    except Exception as e:
        print(f"File list failed: {str(e)}")
        return jsonify({'error': f'Failed to list files: {str(e)}'}), 500

@file_routes.route('/lazy-file/<path:filepath>')
def serve_lazy_file(filepath):
    """Serve files with proper headers - inline for viewing, attachment for downloads"""
    print(f"[DEBUG] Serving lazy file: {filepath}, download={request.args.get('download', 'false')}, "
          f"client_ip={request.remote_addr}, user_agent={request.headers.get('User-Agent')}")

    is_download = request.args.get('download', 'false').lower() == 'true'

    try:
        filepath = filepath.replace('/', os.sep)
        full_path = os.path.join('static', filepath)
        if not os.path.exists(full_path):
            print(f"[ERROR] File not found at {full_path}")
            return jsonify({'error': f'File not found: {filepath}'}), 404

        file_stats = os.stat(full_path)
        file_size = file_stats.st_size
        filename = os.path.basename(filepath)
        encoded_filename = quote(filename, safe='')

        content_type, _ = mimetypes.guess_type(full_path)
        if not content_type:
            content_type = 'application/octet-stream'

        response = send_file(
            full_path,
            mimetype=content_type,
            as_attachment=is_download,
            download_name=encoded_filename
        )
        response.headers['Access-Control-Allow-Origin'] = '*'
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
        response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        response.headers['Accept-Ranges'] = 'bytes'

        print(f"[INFO] File served: {filepath}, Content-Type: {content_type}, Size: {file_size}, "
              f"Disposition: {response.headers.get('Content-Disposition', 'Not set')}")

        return response

    except Exception as e:
        print(f"[ERROR] Failed to serve file {filepath}: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Failed to serve file: {str(e)}'}), 500

@file_routes.route('/static/<path:path>')
def serve_static(path):
    print(f"Serving static file: {path}")
    try:
        full_path = os.path.join('static', path)
        if not os.path.exists(full_path):
            print(f"File not found: {full_path}")
            return jsonify({'error': 'File not found'}), 404
        return send_from_directory('static', path)
    except Exception as e:
        print(f"Error serving static file {path}: {str(e)}")
        return jsonify({'error': f'File not found: {str(e)}'}), 404

@file_routes.route('/')
def index():
    return send_from_directory('static', 'index.html')

@file_routes.route('/check-thumbnail/<path:filename>')
def check_thumbnail(filename):
    thumbnail_path = os.path.join('static', 'thumbnails', filename)
    if os.path.exists(thumbnail_path):
        return jsonify({'exists': True, 'url': f'/static/thumbnails/{filename}'}), 200
    return jsonify({'exists': False}), 404

@file_routes.route('/list-default-avatars')
def list_default_avatars():
    try:
        avatars = []
        for filename in os.listdir(DEFAULT_AVATAR_DIR):
            filepath = os.path.join(DEFAULT_AVATAR_DIR, filename)
            if os.path.isfile(filepath):
                url = f'/static/default_avatars/{filename}'.replace('\\', '/')
                avatars.append({'name': filename, 'url': url})
        return jsonify({'avatars': avatars}), 200
    except FileNotFoundError:
        return jsonify({'avatars': []}), 200
    except Exception as e:
        return jsonify({'error': f'Failed to list default avatars: {str(e)}'}), 500