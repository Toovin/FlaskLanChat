from flask import Blueprint, request, jsonify, send_from_directory, make_response, send_file, session
from werkzeug.utils import secure_filename
from lc_config import UPLOAD_DIR, THUMBNAILS_DIR, AVATAR_DIR, DEFAULT_AVATAR_DIR, MEDIA_DOWNLOAD_DIR, THUMBNAILS_MEDIA_DOWNLOADED_DIR, MAX_FILE_SIZE, MAX_TOTAL_UPLOAD_SIZE
from database import create_folder, get_folder_structure, get_folder_by_id, get_folder_by_path, get_user_folder_structure, get_public_folder_structure, get_system_folder_structure, delete_folder, rename_folder, get_files_in_folder, add_file_to_folder, delete_file_from_folder, update_file_visibility
from lc_socket_handlers_refactor.utility_functions import validate_media_response
import os
from datetime import datetime
import sqlite3
import uuid
import json
import yt_dlp
from PIL import Image
try:
    import cv2
    import numpy as np
    OPENCV_AVAILABLE = True
except ImportError:
    OPENCV_AVAILABLE = False

import re
import time
import mimetypes
from urllib.parse import quote

from .utility_functions import get_current_user, path_to_url, generate_thumbnail

# Global socketio instance - will be set by register_routes
socketio = None

media_routes = Blueprint('media_routes', __name__)

@media_routes.route('/download-media', methods=['POST'])
def download_media():
    with open('logs/serverlog.txt', 'a') as f:
        f.write(f"Media download request received from {request.remote_addr} at {datetime.now()}\n")
        f.flush()
    print(f"Media download request received from {request.remote_addr} at {datetime.now()}")
    data = request.get_json()
    with open('logs/serverlog.txt', 'a') as f:
        f.write(f"Request data: {data}\n")
        f.flush()
    url = data.get('url')
    channel = data.get('channel', 'general')
    sender = data.get('sender', 'Anonymous')
    if not url:
        with open('logs/serverlog.txt', 'a') as f:
            f.write("Media download failed: No URL provided\n")
            f.flush()
        print("Media download failed: No URL provided")
        return jsonify({'error': 'No URL provided'}), 400

    output_name = data.get('output_name', '')
    storage_dir = 'media_downloaded'
    upload_path = MEDIA_DOWNLOAD_DIR
    os.makedirs(upload_path, exist_ok=True)
    download_id = str(uuid.uuid4())

    def progress_hook(d):
        if d['status'] == 'downloading':
            total_bytes = d.get('total_bytes') or d.get('total_bytes_estimate', 0)
            downloaded_bytes = d.get('downloaded_bytes', 0)
            if total_bytes > 0:
                progress = (downloaded_bytes / total_bytes) * 100
                socketio.emit('download_progress', {
                    'download_id': download_id,
                    'progress': progress,
                    'speed': d.get('speed', 0),
                    'eta': d.get('eta', 0)
                }, room=channel)
        elif d['status'] == 'finished':
            socketio.emit('download_progress', {
                'download_id': download_id,
                'progress': 100,
                'status': 'finished'
            }, room=channel)

    # Sanitize output name if provided
    if output_name:
        output_name = re.sub(r'[^\w\s\-_]', '', str(output_name)).replace(' ', '_').strip('_')
        if not output_name:
            output_name = f"download_{int(time.time())}"

    ydl_opts = {
        'outtmpl': os.path.join(upload_path, '%(title)s.%(ext)s') if not output_name else os.path.join(upload_path, f'{output_name}.%(ext)s'),
        'format': 'best[ext=jpg]/best[ext=png]/best[ext=gif]/best[ext=webp]/best[ext=mp4]/best[ext=webm]',
        'noplaylist': True,
        'quiet': True,
        'progress_hooks': [progress_hook],
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            filename = ydl.prepare_filename(info)
            socketio.emit('download_progress', {
                'download_id': download_id,
                'progress': 0,
                'status': 'started',
                'filename': os.path.basename(filename)
            }, room=channel)
            ydl.download([url])

        downloaded_url = f'/static/{storage_dir}/{os.path.basename(filename)}'.replace('\\', '/')
        thumbnail_url = None
        file_ext = os.path.splitext(filename)[1].lower()
        is_media = file_ext in ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.mp4', '.webm', '.avi', '.mov']
        if is_media and file_ext in ['.png', '.jpg', '.jpeg', '.gif', '.webp']:
            thumbnails_path = THUMBNAILS_MEDIA_DOWNLOADED_DIR
            os.makedirs(thumbnails_path, exist_ok=True)
            base_name = os.path.splitext(os.path.basename(filename))[0]
            thumbnail_filename = f"{base_name}_thumb.jpg"
            thumbnail_filepath = os.path.join(thumbnails_path, thumbnail_filename)
            if generate_thumbnail(filename, thumbnail_filepath):
                thumbnail_url = f'/static/thumbnails/{storage_dir}/{thumbnail_filename}'.replace('\\', '/')
            else:
                print(f"Thumbnail generation failed for {filename}")
                thumbnail_url = downloaded_url  # Fallback to full image

        response = {
            'message': f"Media downloaded: {os.path.basename(filename)}",
            'is_media': is_media,
            'image_url': downloaded_url if is_media else None,
            'thumbnail_url': thumbnail_url if is_media and thumbnail_url else downloaded_url if is_media else None,
            'sender': sender
        }

        if not validate_media_response(response):
            print(f"Invalid media response for download: {response}")
            return jsonify({'error': 'Invalid media data'}), 400

        try:
            # Get system display name for media downloads
            from database import get_system_display_name
            system_sender = get_system_display_name('media_download')

            # Check if user wants to toast on media download
            user_uuid = None
            if 'user_uuid' in session:
                user_uuid = session['user_uuid']
            should_toast = True
            if user_uuid:
                from database import get_user_settings
                settings = get_user_settings(user_uuid)
                if settings:
                    should_toast = settings.get('toast_on_media_download', True)

            # Save to database
            conn = sqlite3.connect('devchat.db')
            c = conn.cursor()
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            c.execute(
                "INSERT INTO messages (channel, sender, message, is_media, timestamp, replied_to, image_url, thumbnail_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (channel, system_sender, response['message'], response['is_media'], timestamp, None, response.get('image_url'), response.get('thumbnail_url'))
            )
            message_id = c.lastrowid
            conn.commit()
            conn.close()

            # Send toast to channel if enabled
            if should_toast:
                socketio.emit('receive_message', {
                    'id': message_id,
                    'channel': channel,
                    'sender': system_sender,
                    'message': response['message'],
                    'is_media': response['is_media'],
                    'image_url': response.get('image_url'),
                    'thumbnail_url': response.get('thumbnail_url'),
                    'timestamp': timestamp,
                    'replied_to': None,
                    'replies_count': 0,
                    'reactions': []
                }, room=channel)

            print(f"Media downloaded: {filename}, URL: {downloaded_url}, Thumbnail: {thumbnail_url}, Toast: {should_toast}")
            return jsonify({'url': downloaded_url, 'thumbnail_url': thumbnail_url, 'download_id': download_id}), 200
        except Exception as e:
            print(f"Error saving downloaded media to database: {e}")
            return jsonify({'error': f"Error saving media: {str(e)}"}), 500

    except Exception as e:
        print(f"Media download failed: {str(e)}")
        socketio.emit('download_progress', {
            'download_id': download_id,
            'status': 'error',
            'error': str(e)
        }, room=channel)
        return jsonify({'error': f'Download failed: {str(e)}'}), 400

@media_routes.route('/upload-avatar', methods=['POST'])
def upload_avatar():
    print(f"[DEBUG] Avatar upload request from {request.remote_addr}")
    if 'avatar' not in request.files:
        print("[DEBUG] Avatar upload failed: No avatar file provided")
        return jsonify({'error': 'No avatar file provided'}), 400
    file = request.files['avatar']
    if file.filename == '':
        print("[DEBUG] Avatar upload failed: No selected file")
        return jsonify({'error': 'No selected file'}), 400

    # Get type and id from form data
    avatar_type = request.form.get('type', 'user')  # user or ai
    avatar_id = request.form.get('id', '')  # uuid for user, character_name for ai

    if file:
        # Generate timestamp for uniqueness
        import time
        timestamp = str(int(time.time()))

        # Generate filename based on type
        if avatar_type == 'user':
            filename = f"avatar_user_{avatar_id}_{timestamp}{os.path.splitext(file.filename)[1]}"
        elif avatar_type == 'ai':
            filename = f"avatar_ai_{request.form.get('user_uuid', 'unknown')}_{avatar_id}_{timestamp}{os.path.splitext(file.filename)[1]}"
        else:
            filename = f"avatar_{avatar_type}_{avatar_id}_{timestamp}{os.path.splitext(file.filename)[1]}"

        filepath = os.path.join(AVATAR_DIR, filename)
        print(f"[DEBUG] Generated filename: {filename}, filepath: {filepath}")
        try:
            os.makedirs(AVATAR_DIR, exist_ok=True)  # Ensure directory exists
            print(f"[DEBUG] Saving file to {filepath}")
            file.save(filepath)
            print(f"[DEBUG] Avatar saved successfully: {filepath}")
            url = f'/static/uploads/avatars/{filename}'
            print(f"[DEBUG] Returning URL: {url}")
            return jsonify({'url': url}), 200
        except Exception as e:
            print(f"[DEBUG] Avatar upload failed: {str(e)}")
            return jsonify({'error': f'File upload failed: {str(e)}'}), 400
    print("[DEBUG] Avatar upload failed: File save error")
    return jsonify({'error': 'File upload failed'}), 400

@media_routes.route('/upload-media', methods=['POST'])
def upload_media():
    print(f"Media upload request from {request.remote_addr}")
    if 'file' not in request.files:
        print("Media upload failed: No file provided")
        return jsonify({'error': 'No file provided'}), 400
    file = request.files['file']
    if file.filename == '':
        print("Media upload failed: No selected file")
        return jsonify({'error': 'No selected file'}), 400
    if file:
        # Validate file type
        allowed_extensions = {'mp4', 'webm', 'avi', 'mov', 'mp3', 'wav', 'ogg'}
        if '.' not in file.filename or file.filename.rsplit('.', 1)[1].lower() not in allowed_extensions:
            return jsonify({'error': 'Invalid file type. Only video and audio files are allowed.'}), 400

        filename = secure_filename(file.filename)
        filepath = os.path.join(MEDIA_DOWNLOAD_DIR, filename)
        try:
            os.makedirs(MEDIA_DOWNLOAD_DIR, exist_ok=True)
            file.save(filepath)
            print(f"Media file saved: {filepath}")
            return jsonify({'filename': filename}), 200
        except Exception as e:
            print(f"Media upload failed: {str(e)}")
            return jsonify({'error': f'File upload failed: {str(e)}'}), 400
    print("Media upload failed: File save error")
    return jsonify({'error': 'File upload failed'}), 400

@media_routes.route('/upload-file', methods=['POST'])
def upload_file():
    print(f"DEBUG: upload_file route called from {request.remote_addr} at {datetime.now()}")
    if 'file' not in request.files:
        print("File upload failed: No file provided")
        return jsonify({'error': 'No file provided'}), 400
    files = request.files.getlist('file')
    folder_id = request.form.get('folder_id')
    upload_type = request.form.get('upload_type')
    visibility = request.form.get('visibility', 'private')
    print(f"[FileShare] Uploading {len([f for f in files if f.filename])} files to folder {folder_id}, type: {upload_type}, visibility: {visibility}")
    if not files or all(f.filename == '' for f in files):
        print("File upload failed: No selected files")
        return jsonify({'error': 'No selected files'}), 400

    # Validate file sizes (if limits are enabled) - skip for public uploads
    if upload_type != 'public':
        total_size = 0
        for file in files:
            if file.filename == '':
                continue
            file.seek(0, 2)  # Seek to end to get file size
            file_size = file.tell()
            file.seek(0)  # Reset file pointer

            # Check individual file size limit (if enabled)
            if MAX_FILE_SIZE and MAX_FILE_SIZE > 0 and file_size > MAX_FILE_SIZE:
                return jsonify({'error': f'File "{file.filename}" exceeds maximum size limit of {MAX_FILE_SIZE // (1024*1024)}MB'}), 400
            total_size += file_size

        # Check total upload size limit (if enabled)
        if MAX_TOTAL_UPLOAD_SIZE and MAX_TOTAL_UPLOAD_SIZE > 0 and total_size > MAX_TOTAL_UPLOAD_SIZE:
            return jsonify({'error': f'Total upload size exceeds limit of {MAX_TOTAL_UPLOAD_SIZE // (1024*1024)}MB'}), 400

    # Get folder information
    folder_path = None
    if upload_type == 'public':
        folder_path = 'file_share_system/Public_Folder'
        public_folder = get_folder_by_path(folder_path)
        if not public_folder:
            folder_id = create_folder('Public', folder_path, 'system')
        else:
            folder_id = public_folder['id']
    elif folder_id:
        try:
            folder_info = get_folder_by_id(int(folder_id))
            if folder_info:
                folder_path = folder_info['path']
                # For private uploads to 'Share' folder, redirect to user folder
                if visibility == 'private' and folder_info['name'] == 'Share':
                    current_user = get_current_user()
                    user_upload_path = f'file_share_system/{current_user}'
                    user_folder = get_folder_by_path(user_upload_path)
                    if not user_folder:
                        folder_id = create_folder(current_user, None, current_user)
                        user_folder = get_folder_by_id(folder_id)
                    folder_path = user_upload_path
                    folder_id = user_folder['id']
            else:
                return jsonify({'error': 'Invalid folder selected'}), 400
        except ValueError:
            return jsonify({'error': 'Invalid folder ID'}), 400

    storage_dir = request.form.get('storage_dir', 'uploads')
    if storage_dir == 'uploads':
        upload_path = UPLOAD_DIR
        thumbnails_path = THUMBNAILS_DIR
        url_prefix = 'uploads'
    elif storage_dir == 'media_downloaded':
        upload_path = MEDIA_DOWNLOAD_DIR
        thumbnails_path = THUMBNAILS_MEDIA_DOWNLOADED_DIR
        url_prefix = 'media_downloaded'
    elif storage_dir == 'file_share_system':
        # Handle folder-based uploads for file sharing
        current_user = get_current_user()
        if folder_path:
            # For folder uploads, use the existing folder path
            upload_path = os.path.join('static', folder_path)
            thumbnails_path = os.path.join('static', 'thumbnails', folder_path)
            url_prefix = folder_path
        else:
            # For direct uploads, save to user-specific folder
            user_upload_path = f'file_share_system/{current_user}'
            # Ensure the user's folder exists in database
            user_folder = get_folder_by_path(user_upload_path)
            if not user_folder:
                folder_id = create_folder(current_user, None, current_user)
                if folder_id:
                    user_folder = get_folder_by_id(folder_id)
            upload_path = os.path.join('static', user_upload_path)
            thumbnails_path = os.path.join('static', 'thumbnails', user_upload_path)
            url_prefix = user_upload_path
    else:
        upload_path = os.path.join('static', storage_dir)
        thumbnails_path = os.path.join('static', 'thumbnails', storage_dir)
        url_prefix = storage_dir

    os.makedirs(upload_path, exist_ok=True)
    os.makedirs(thumbnails_path, exist_ok=True)

    responses = []
    for file in files:
        original_name = secure_filename(file.filename)
        base, ext = os.path.splitext(original_name)

        # Check for existing files with same base name and append (1), (2), etc. for duplicates
        filename = original_name
        filepath = os.path.join(upload_path, filename)
        counter = 1
        while os.path.exists(filepath):
            filename = f"{base} ({counter}){ext}"
            filepath = os.path.join(upload_path, filename)
            counter += 1

        try:
            # Save file to disk
            file.save(filepath)
            print(f"File saved to disk: {filepath}")

            url = path_to_url(f'/static/{url_prefix}/{filename}')
            thumbnail_url = None
            is_media = ext.lower() in ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.jfif', '.mp4', '.webm', '.avi', '.mov']
            should_generate_thumb = is_media and ext.lower() in ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.jfif']
            print(f"DEBUG: File {filename}, ext='{ext}', is_media={is_media}, should_generate_thumb={should_generate_thumb}")

            # Generate thumbnails if needed
            if should_generate_thumb:
                # Generate thumbnails for images
                thumbnail_filename = f"{os.path.splitext(filename)[0]}_thumb.jpg"
                thumbnail_filepath = os.path.join(thumbnails_path, thumbnail_filename)
                print(f"DEBUG: Attempting thumbnail generation: {filepath} -> {thumbnail_filepath}")
                try:
                    thumb_result = generate_thumbnail(filepath, thumbnail_filepath)
                    print(f"DEBUG: generate_thumbnail returned: {thumb_result}")
                    if thumb_result:
                        if os.path.exists(thumbnail_filepath) and os.path.getsize(thumbnail_filepath) > 0:
                            thumbnail_url = path_to_url(f'/static/thumbnails/{url_prefix}/{thumbnail_filename}')
                            print(f"Thumbnail generated successfully: {thumbnail_url}")
                            # Validate the thumbnail URL by checking if file exists at expected path
                            full_thumbnail_path = os.path.join('static', 'thumbnails', url_prefix, thumbnail_filename)
                            if not os.path.exists(full_thumbnail_path):
                                print(f"WARNING: Thumbnail URL constructed but file not found at: {full_thumbnail_path}")
                                thumbnail_url = url
                        else:
                            print(f"Thumbnail file missing or empty after generation: {thumbnail_filepath}")
                            thumbnail_url = url
                    else:
                        print(f"Thumbnail generation failed for {filename}")
                        thumbnail_url = url
                except Exception as e:
                    print(f"DEBUG: Exception during thumbnail generation: {e}")
                    import traceback
                    traceback.print_exc()
                    thumbnail_url = url
            elif is_media and ext.lower() in ['.mp4', '.webm', '.avi', '.mov']:
                # For videos, don't set thumbnail_url - let client show video icon
                thumbnail_url = None

            # Get file size
            file_size = os.path.getsize(filepath) if os.path.exists(filepath) else 0

            # Transactional approach: DB first, then cleanup on failure
            file_id = None
            db_insert_success = False

            # Save to database for file sharing FIRST (transactional)
            if storage_dir == 'file_share_system':
                # Get current user (fallback to admin)
                current_user = get_current_user()
                # Store relative path from static/ directory (always use forward slashes)
                relative_filepath = path_to_url(os.path.relpath(filepath, 'static'))

                # Set ownership and visibility based on upload type
                if upload_type == 'public':
                    ownership = 'system'
                    visibility = 'public'
                    created_by_param = 'system'
                else:
                    ownership = 'user'
                    visibility = 'private'
                    created_by_param = current_user

                file_id = add_file_to_folder(filename, folder_id, relative_filepath, file_size, ownership, thumbnail_url, visibility, created_by_param)
                if file_id:
                    print(f"[FileShare] File '{filename}' uploaded to folder {folder_id} by user '{current_user}' with ID {file_id}")
                    db_insert_success = True
                else:
                    print(f"Failed to save file to database: {filename}")
                    # DB insert failed - remove the file that was already saved
                    if os.path.exists(filepath):
                        os.remove(filepath)
                        print(f"Cleaned up orphaned file: {filepath}")
                    continue  # Skip this file, don't add to responses

            # Success - add to responses
            responses.append({'url': url, 'thumbnail_url': thumbnail_url, 'size': file_size})
            print(f"File upload successful: {filepath}, URL: {url}, Thumbnail: {thumbnail_url}")

        except OSError as e:
            # Disk space, permissions, or filesystem errors
            error_msg = f"File upload failed for {original_name}: Storage error - {str(e)}"
            print(error_msg)
            responses.append({'error': error_msg})
            # Clean up partial file if it exists
            if os.path.exists(filepath):
                try:
                    os.remove(filepath)
                    print(f"Cleaned up partial file after error: {filepath}")
                except:
                    pass

        except Exception as e:
            # General errors (thumbnail generation, etc.)
            error_msg = f"File upload failed for {original_name}: {str(e)}"
            print(error_msg)
            responses.append({'error': error_msg})
            # Clean up file if DB insert didn't happen
            if storage_dir == 'file_share_system' and not db_insert_success and os.path.exists(filepath):
                try:
                    os.remove(filepath)
                    print(f"Cleaned up file after general error: {filepath}")
                except:
                    pass

    if all('error' in r for r in responses):
        return jsonify({'error': 'All file uploads failed', 'details': responses}), 400
    return jsonify({'urls': responses}), 200

@media_routes.route('/rename-media', methods=['POST'])
def rename_media():
    print(f"Media rename request received from {request.remote_addr}")
    data = request.get_json()
    old_name = data.get('old_name')
    new_name = data.get('new_name')
    storage_dir = data.get('storage_dir', 'media_downloaded')
    if not old_name or not new_name:
        print("Media rename failed: Missing old_name or new_name")
        return jsonify({'error': 'Missing old_name or new_name'}), 400
    upload_path = os.path.join('static', storage_dir)
    old_path = os.path.join(upload_path, old_name)
    new_path = os.path.join(upload_path, new_name)
    if not os.path.exists(old_path):
        print(f"Media rename failed: File {old_name} not found")
        return jsonify({'error': f'File {old_name} not found'}), 404
    if os.path.exists(new_path):
        print(f"Media rename failed: File {new_name} already exists")
        return jsonify({'error': f'File {new_name} already exists'}), 400
    try:
        os.rename(old_path, new_path)
        new_url = f'/static/{storage_dir}/{new_name}'.replace('\\', '/')
        print(f"File renamed: {old_name} -> {new_name}, URL: {new_url}")
        return jsonify({'success': True, 'new_url': new_url}), 200
    except Exception as e:
        print(f"Media rename failed: {str(e)}")
        return jsonify({'error': f'Rename failed: {str(e)}'}), 500

@media_routes.route('/delete-media', methods=['POST'])
def delete_media():
    print(f"Media delete request received from {request.remote_addr}")
    data = request.get_json()
    filename = data.get('filename')
    storage_dir = data.get('storage_dir', 'media_downloaded')
    if not filename:
        print("Media delete failed: Missing filename")
        return jsonify({'error': 'Missing filename'}), 400
    upload_path = os.path.join('static', storage_dir)
    file_path = os.path.join(upload_path, filename)
    if not os.path.exists(file_path):
        print(f"Media delete failed: File {filename} not found")
        return jsonify({'error': f'File {filename} not found'}), 404
    try:
        os.remove(file_path)
        print(f"File deleted: {filename}")
        return jsonify({'success': True}), 200
    except Exception as e:
        print(f"Media delete failed: {str(e)}")
        return jsonify({'error': f'Delete failed: {str(e)}'}), 500