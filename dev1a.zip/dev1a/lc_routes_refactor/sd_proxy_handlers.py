from flask import Blueprint, request, jsonify, send_from_directory, make_response, send_file, session
import requests
import os
import json

sd_proxy_routes = Blueprint('sd_proxy_routes', __name__)

@sd_proxy_routes.route('/sdapi/v1/samplers')
def proxy_sd_samplers():
    """Proxy SD API samplers endpoint to avoid mixed content issues"""
    try:
        import requests
        import os
        import json

        # Load config directly
        config_path = os.path.join(os.path.dirname(__file__), 'sd_config.json')
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
            base_api_url = config.get('sd_api_url', 'http://127.0.0.1:7860')
        except (FileNotFoundError, json.JSONDecodeError):
            base_api_url = 'http://127.0.0.1:7860'

        response = requests.get(f"{base_api_url.rstrip('/')}/sdapi/v1/samplers", timeout=10)
        response.raise_for_status()
        return jsonify(response.json()), response.status_code
    except requests.RequestException as e:
        print(f"Failed to proxy SD samplers: {str(e)}")
        return jsonify({'error': f'Failed to fetch samplers: {str(e)}'}), 500

@sd_proxy_routes.route('/sdapi/v1/schedulers')
def proxy_sd_schedulers():
    """Proxy SD API schedulers endpoint to avoid mixed content issues"""
    try:
        import requests
        import os
        import json

        # Load config directly
        config_path = os.path.join(os.path.dirname(__file__), 'sd_config.json')
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
            base_api_url = config.get('sd_api_url', 'http://127.0.0.1:7860')
        except (FileNotFoundError, json.JSONDecodeError):
            base_api_url = 'http://127.0.0.1:7860'

        response = requests.get(f"{base_api_url.rstrip('/')}/sdapi/v1/schedulers", timeout=10)
        response.raise_for_status()
        return jsonify(response.json()), response.status_code
    except requests.RequestException as e:
        print(f"Failed to proxy SD schedulers: {str(e)}")
        return jsonify({'error': f'Failed to fetch schedulers: {str(e)}'}), 500

@sd_proxy_routes.route('/sdapi/v1/sd-models')
def proxy_sd_models():
    """Proxy SD API models endpoint to avoid mixed content issues"""
    try:
        import requests
        import os
        import json

        # Load config directly
        config_path = os.path.join(os.path.dirname(__file__), 'sd_config.json')
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
            base_api_url = config.get('sd_api_url', 'http://127.0.0.1:7860')
        except (FileNotFoundError, json.JSONDecodeError):
            base_api_url = 'http://127.0.0.1:7860'

        response = requests.get(f"{base_api_url.rstrip('/')}/sdapi/v1/sd-models", timeout=10)
        response.raise_for_status()
        return jsonify(response.json()), response.status_code
    except requests.RequestException as e:
        print(f"Failed to proxy SD models: {str(e)}")
        return jsonify({'error': f'Failed to fetch models: {str(e)}'}), 500