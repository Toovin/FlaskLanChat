from flask import Blueprint, request, jsonify, send_from_directory, make_response, send_file, session
from werkzeug.utils import secure_filename
from lc_config import UPLOAD_DIR, THUMBNAILS_DIR, AVATAR_DIR, DEFAULT_AVATAR_DIR, MEDIA_DOWNLOAD_DIR, THUMBNAILS_MEDIA_DOWNLOADED_DIR, MAX_FILE_SIZE, MAX_TOTAL_UPLOAD_SIZE
from database import get_public_files, get_server_files, add_file_to_public, delete_file_from_public, rename_file_in_public
import os
from datetime import datetime
import sqlite3
import uuid
import json
import yt_dlp
from PIL import Image
try:
    import cv2
    import numpy as np
    OPENCV_AVAILABLE = True
except ImportError:
    OPENCV_AVAILABLE = False

import re
import time
import mimetypes
from urllib.parse import quote

from .utility_functions import get_current_user, path_to_url, generate_thumbnail

folder_routes = Blueprint('folder_routes', __name__)

# ============================================================================
# Simplified File Share Routes - Public and Server Sections
# ============================================================================

@folder_routes.route('/files/<section>', methods=['GET'])
def get_files(section):
    """Get files for Public or Server section"""
    print(f"Get {section} files request from {request.remote_addr}")

    try:
        if section not in ['public', 'server']:
            return jsonify({'error': 'Invalid section'}), 400

        current_user = get_current_user()
        print(f"Current user: {current_user}")

        if section == 'public':
            files = get_public_files(current_user)
        else:  # server
            files = get_server_files()

        print(f"Found {len(files)} files for section {section}")

        # Convert filepaths to URLs
        for file in files:
            file['url'] = f"/static/{file['filepath']}"
            file['filepath'] = f"/static/{file['filepath']}"

        return jsonify({'files': files}), 200
    except Exception as e:
        print(f"Get {section} files failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Failed to get {section} files: {str(e)}'}), 500

@folder_routes.route('/upload/<section>', methods=['POST'])
def upload_file(section):
    """Upload file to Public section only"""
    print(f"Upload to {section} request from {request.remote_addr}")
    print(f"Request files: {list(request.files.keys())}")
    print(f"Request form: {dict(request.form)}")
    print(f"Request headers: {dict(request.headers)}")

    if section != 'public':
        return jsonify({'error': 'Cannot upload to server section'}), 403

    try:
        if 'file' not in request.files:
            print("ERROR: 'file' not in request.files")
            return jsonify({'error': 'No file provided'}), 400

        file = request.files['file']
        print(f"File object: {file}, filename: '{file.filename}'")
        if file.filename == '':
            print("ERROR: file.filename is empty")
            return jsonify({'error': 'No file selected'}), 400

        # Validate file size
        file.seek(0, os.SEEK_END)
        file_size = file.tell()
        file.seek(0)
        print(f"File size: {file_size}, MAX_FILE_SIZE: {MAX_FILE_SIZE}")

        if MAX_FILE_SIZE > 0 and file_size > MAX_FILE_SIZE:
            print(f"ERROR: File too large: {file_size} > {MAX_FILE_SIZE}")
            return jsonify({'error': f'File too large. Maximum size: {MAX_FILE_SIZE} bytes'}), 400

        # Secure filename
        filename = secure_filename(file.filename)
        print(f"Secure filename: '{filename}'")
        current_user = get_current_user()
        print(f"Current user: '{current_user}'")

        if not current_user:
            print(f"Upload failed: No authenticated user")
            return jsonify({'error': 'User not authenticated'}), 401

        # Save to Public_Folder
        public_dir = os.path.join('static', 'file_share_system', 'Public_Folder')
        os.makedirs(public_dir, exist_ok=True)

        filepath = os.path.join(public_dir, filename)
        file.save(filepath)

        # Generate thumbnail if it's an image
        thumbnail_url = None
        if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.webp')):
            try:
                thumb_result = generate_thumbnail(filepath, os.path.join('static', 'thumbnails', 'file_share_system', 'Public_Folder', f"{os.path.splitext(filename)[0]}_thumb.jpg"))
                if thumb_result:
                    thumbnail_url = f'/static/thumbnails/file_share_system/Public_Folder/{os.path.splitext(filename)[0]}_thumb.jpg'
            except Exception as e:
                print(f"Thumbnail generation failed for {filename}: {e}")

        # Add to database
        print(f"[FileShare] Adding file to database: filename={filename}, user={current_user}, size={file_size}")
        file_id = add_file_to_public(filename, f'file_share_system/Public_Folder/{filename}', file_size, current_user, thumbnail_url)

        if file_id:
            print(f"[FileShare] File '{filename}' uploaded to Public section by {current_user}, ID: {file_id}")
            return jsonify({'success': True, 'file_id': file_id}), 200
        else:
            print(f"[FileShare] Database insert failed for file '{filename}'")
            # Clean up file if database insert failed
            if os.path.exists(filepath):
                os.remove(filepath)
            return jsonify({'error': 'Failed to save file to database'}), 500

    except Exception as e:
        print(f"Upload to {section} failed: {str(e)}")
        return jsonify({'error': f'Failed to upload file: {str(e)}'}), 500

@folder_routes.route('/delete-file/<section>/<filename>', methods=['DELETE'])
def delete_file(section, filename):
    """Delete file from Public section only"""
    print(f"Delete {filename} from {section} request from {request.remote_addr}")

    if section != 'public':
        return jsonify({'error': 'Cannot delete from server section'}), 403

    try:
        current_user = get_current_user()

        # Check if user owns the file
        files = get_public_files(current_user)
        file_info = next((f for f in files if f['filename'] == filename), None)

        if not file_info:
            return jsonify({'error': 'File not found or access denied'}), 404

        # Delete from filesystem
        file_path = os.path.join('static', 'file_share_system', 'Public_Folder', filename)
        if os.path.exists(file_path):
            os.remove(file_path)

        # Delete thumbnail if exists
        thumbnail_filename = f"{os.path.splitext(filename)[0]}_thumb.jpg"
        thumbnail_path = os.path.join('static', 'thumbnails', 'file_share_system', 'Public_Folder', thumbnail_filename)
        if os.path.exists(thumbnail_path):
            os.remove(thumbnail_path)

        # Delete from database
        success = delete_file_from_public(filename, current_user)
        if success:
            print(f"[FileShare] File '{filename}' deleted from Public section by {current_user}")
            return jsonify({'success': True}), 200
        else:
            return jsonify({'error': 'Failed to delete file from database'}), 500

    except Exception as e:
        print(f"Delete {filename} from {section} failed: {str(e)}")
        return jsonify({'error': f'Failed to delete file: {str(e)}'}), 500

@folder_routes.route('/rename-file/<section>/<filename>', methods=['PUT'])
def rename_file(section, filename):
    """Rename file in Public section only"""
    print(f"Rename {filename} in {section} request from {request.remote_addr}")

    if section != 'public':
        return jsonify({'error': 'Cannot rename files in server section'}), 403

    try:
        data = request.get_json()
        new_filename = data.get('new_filename')

        if not new_filename:
            return jsonify({'error': 'Missing new filename'}), 400

        # Validate new filename
        if any(char in new_filename for char in ['/', '\\', ':', '*', '?', '"', '<', '>', '|']):
            return jsonify({'error': 'Filename contains invalid characters'}), 400

        current_user = get_current_user()

        # Check if user owns the file
        files = get_public_files(current_user)
        file_info = next((f for f in files if f['filename'] == filename), None)

        if not file_info:
            return jsonify({'error': 'File not found or access denied'}), 404

        # Rename in filesystem
        public_dir = os.path.join('static', 'file_share_system', 'Public_Folder')
        old_path = os.path.join(public_dir, filename)
        new_path = os.path.join(public_dir, secure_filename(new_filename))

        if os.path.exists(old_path):
            os.rename(old_path, new_path)

        # Rename thumbnail if exists
        old_thumb = os.path.join('static', 'thumbnails', 'file_share_system', 'Public_Folder', f"{os.path.splitext(filename)[0]}_thumb.jpg")
        new_thumb = os.path.join('static', 'thumbnails', 'file_share_system', 'Public_Folder', f"{os.path.splitext(new_filename)[0]}_thumb.jpg")
        if os.path.exists(old_thumb):
            os.rename(old_thumb, new_thumb)

        # Update database
        success = rename_file_in_public(filename, secure_filename(new_filename), current_user)
        if success:
            print(f"[FileShare] File '{filename}' renamed to '{new_filename}' in Public section by {current_user}")
            return jsonify({'success': True}), 200
        else:
            return jsonify({'error': 'Failed to rename file in database'}), 500

    except Exception as e:
        print(f"Rename {filename} in {section} failed: {str(e)}")
        return jsonify({'error': f'Failed to rename file: {str(e)}'}), 500