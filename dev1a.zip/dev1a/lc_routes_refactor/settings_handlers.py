# settings_handlers.py - Centralized settings API handlers
from flask import request, jsonify
from database import database_users, database_channels
from database import get_user_ai_settings, update_user_ai_settings
from ai_database import ai_database
from lc_config import CHAT_DB_NAME
import sqlite3

def get_user_settings(user_uuid):
    """Get all user settings (AI, channels, etc.)"""
    try:
        # Get AI settings
        ai_settings = get_user_ai_settings(user_uuid) or {}

        # Get user channels and their settings
        channels = get_user_channels(user_uuid)

        # Get global system settings (if any)
        system_settings = get_system_settings()

        return {
            'ai_settings': ai_settings,
            'channel_settings': channels,
            'system_settings': system_settings
        }
    except Exception as e:
        print(f"Error getting user settings: {str(e)}")
        return {}

def save_user_settings(user_uuid, settings):
    """Save user settings"""
    try:
        print(f"[DEBUG] save_user_settings called for user_uuid: {user_uuid}, settings keys: {list(settings.keys())}")

        success = True

        # Save AI settings
        if 'ai_settings' in settings:
            print(f"[DEBUG] Saving AI settings: {settings['ai_settings']}")
            try:
                ai_result = update_user_ai_settings(user_uuid, settings['ai_settings'])
                print(f"[DEBUG] AI settings save result: {ai_result}")
                if not ai_result:
                    success = False
            except Exception as e:
                print(f"[DEBUG] Error saving AI settings: {e}")
                success = False

        # Save channel settings
        if 'channel_settings' in settings:
            try:
                channel_result = save_channel_settings(user_uuid, settings['channel_settings'])
                print(f"[DEBUG] Channel settings save result: {channel_result}")
                if not channel_result:
                    success = False
            except Exception as e:
                print(f"[DEBUG] Error saving channel settings: {e}")
                success = False

        # Save system settings (all users can modify on LAN)
        if 'system_settings' in settings:
            try:
                system_result = save_system_settings(settings['system_settings'])
                print(f"[DEBUG] System settings save result: {system_result}")
                if not system_result:
                    success = False
            except Exception as e:
                print(f"[DEBUG] Error saving system settings: {e}")
                success = False

        print(f"[DEBUG] save_user_settings completed with success: {success}")
        return success
    except Exception as e:
        print(f"Error saving user settings: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def get_user_channels(user_uuid):
    """Get user's channels with settings"""
    try:
        conn = sqlite3.connect(CHAT_DB_NAME)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        # Get all channels (assuming all users have access to all channels)
        cursor.execute("""
            SELECT c.id, c.name, c.ai_enabled, c.ai_memory_limit, c.ai_model, c.ai_temperature
            FROM channels c
        """)

        channels = []
        for row in cursor.fetchall():
            channels.append({
                'id': row['id'],
                'name': row['name'],
                'ai_enabled': bool(row['ai_enabled']),
                'ai_memory_limit': row['ai_memory_limit'] or 10,
                'ai_model': row['ai_model'] or 'default',
                'ai_temperature': row['ai_temperature'] or 0.7
            })

        conn.close()
        return channels
    except Exception as e:
        print(f"Error getting user channels: {str(e)}")
        return []

def save_channel_settings(user_uuid, channel_settings):
    """Save channel settings"""
    try:
        conn = sqlite3.connect(CHAT_DB_NAME)
        cursor = conn.cursor()

        for channel in channel_settings:
            cursor.execute("""
                UPDATE channels
                SET ai_enabled = ?, ai_memory_limit = ?, ai_model = ?, ai_temperature = ?
                WHERE id = ?
            """, (
                1 if channel.get('ai_enabled') else 0,
                channel.get('ai_memory_limit', 10),
                channel.get('ai_model', 'default'),
                channel.get('ai_temperature', 0.7),
                channel['id']
            ))

        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error saving channel settings: {str(e)}")
        return False

def get_system_settings():
    """Get global system settings"""
    try:
        conn = sqlite3.connect(CHAT_DB_NAME)
        cursor = conn.cursor()

        cursor.execute("SELECT key, value FROM system_settings")
        rows = cursor.fetchall()
        conn.close()

        # Start with defaults
        settings = {
            'debug_mode': False,
            'max_users': 100,
            'ai_endpoint_url': 'http://localhost:1234'
        }

        # Override with stored values
        for key, value in rows:
            if key == 'debug_mode':
                settings[key] = value.lower() == 'true'
            elif key == 'max_users':
                settings[key] = int(value)
            else:
                settings[key] = value

        return settings
    except Exception as e:
        print(f"Error getting system settings: {str(e)}")
        return {
            'debug_mode': False,
            'max_users': 100,
            'ai_endpoint_url': 'http://localhost:1234'
        }

def save_system_settings(settings):
    """Save global system settings"""
    try:
        conn = sqlite3.connect(CHAT_DB_NAME)
        cursor = conn.cursor()

        for key, value in settings.items():
            cursor.execute("""
                INSERT OR REPLACE INTO system_settings (key, value)
                VALUES (?, ?)
            """, (key, str(value)))

        conn.commit()
        conn.close()
        print(f"Saving system settings: {settings}")
        return True
    except Exception as e:
        print(f"Error saving system settings: {str(e)}")
        return False

def register_settings_routes(app, users_db):
    """Register settings routes"""

    @app.route('/api/settings', methods=['GET'])
    def api_get_settings():
        try:
            user_uuid = request.args.get('user_uuid')  # From query or session
            if not user_uuid:
                # Get from session or auth
                from flask import session
                user_uuid = session.get('user_uuid')
                # For local LAN development, allow anonymous access
                if not user_uuid:
                    user_uuid = 'anonymous_user'
                    print("WARNING: Using anonymous user for settings - authentication bypassed")

            settings = get_user_settings(user_uuid)
            return jsonify(settings)
        except Exception as e:
            print(f"Error in api_get_settings: {str(e)}")
            return jsonify({'error': 'Internal server error'}), 500

    @app.route('/api/settings', methods=['POST'])
    def api_save_settings():
        try:
            user_uuid = request.args.get('user_uuid')
            if not user_uuid:
                from flask import session
                user_uuid = session.get('user_uuid')
                # For local LAN development, allow anonymous access
                if not user_uuid:
                    # Use a default user UUID for anonymous settings
                    user_uuid = 'anonymous_user'
                    print("WARNING: Using anonymous user for settings - authentication bypassed")

            print(f"[DEBUG] api_save_settings called for user_uuid: {user_uuid}")
            data = request.get_json()
            print(f"[DEBUG] Received data: {data}")
            if not data:
                return jsonify({'error': 'No data provided'}), 400

            success = save_user_settings(user_uuid, data)
            print(f"[DEBUG] save_user_settings returned: {success}")
            if success:
                return jsonify({'success': True})
            else:
                return jsonify({'error': 'Failed to save settings'}), 500
        except Exception as e:
            print(f"Error in api_save_settings: {str(e)}")
            import traceback
            traceback.print_exc()
            return jsonify({'error': 'Internal server error'}), 500

    @app.route('/api/ai/characters', methods=['GET'])
    def api_get_characters():
        """Get all available AI characters for testing"""
        try:
            # Get characters from all users (for testing purposes)
            characters = []
            # Get built-in characters
            builtin_chars = ai_database.get_user_characters('system-builtin-characters')
            characters.extend(builtin_chars)

            # Get user characters (we'll get from a few known users)
            # This is a simplified approach for testing
            # Note: In production, this should be more efficient
            all_characters = ai_database.get_user_characters(None)  # Get all characters
            user_uuids = set()
            for char in all_characters:
                if char.get('user_uuid') and char['user_uuid'] != 'system-builtin-characters':
                    user_uuids.add(char['user_uuid'])

            for user_uuid in list(user_uuids)[:5]:  # Limit to first 5 users to avoid too many
                user_chars = ai_database.get_user_characters(user_uuid)
                characters.extend(user_chars)

            return jsonify({'characters': characters})
        except Exception as e:
            print(f"Error getting characters: {str(e)}")
            return jsonify({'error': 'Failed to load characters'}), 500

    @app.route('/api/test-llm', methods=['POST'])
    def api_test_llm():
        """Test LLM API with various configurations"""
        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'No data provided'}), 400

            message = data.get('message', '')
            mode = data.get('mode', 'basic')

            # Import AI agent
            from ai_agent import ai_agent

            # Prepare user settings based on mode
            user_settings = {}

            if mode == 'character':
                character_name = data.get('character_name')
                if character_name:
                    # Try to get character (will search globally now)
                    character = ai_database.get_character('dummy_user', character_name)
                    if character:
                        user_settings.update(character)
                        user_settings['name'] = character_name
                    else:
                        return jsonify({'error': f'Character {character_name} not found'}), 404

            elif mode == 'advanced':
                # Use provided settings
                user_settings.update({
                    'ai_model': data.get('model', 'default'),
                    'ai_temperature': data.get('temperature', 0.7),
                    'ai_max_tokens': data.get('max_tokens', 2048),
                    'ai_system_prompt': data.get('system_prompt', ''),
                    'ai_custom_instructions': data.get('custom_instructions', '')
                })

            # Generate response
            response = ai_agent.generate_response(
                message,
                user_id='test-user',
                user_settings=user_settings,
                mode="chat"
            )

            if response:
                return jsonify({
                    'response': response,
                    'settings_used': user_settings,
                    'mode': mode
                })
            else:
                return jsonify({'error': 'AI generation failed'}), 500

        except Exception as e:
            print(f"Error in api_test_llm: {str(e)}")
            import traceback
            traceback.print_exc()
            return jsonify({'error': 'Internal server error'}), 500