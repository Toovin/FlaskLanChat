from flask import session, g
import os
from datetime import datetime
import sqlite3
try:
    import cv2
    import numpy as np
    OPENCV_AVAILABLE = True
except ImportError:
    OPENCV_AVAILABLE = False

def get_current_user():
    """Get current user with consistent fallback to admin."""
    # First check if g.current_user is set
    current_user = getattr(g, 'current_user', None)
    if current_user:
        return current_user

    # Check if user_uuid is in session (from SocketIO login)
    user_uuid = session.get('user_uuid')
    if user_uuid:
        from database import get_username_by_uuid
        username = get_username_by_uuid(user_uuid)
        if username:
            return username

    # Fallback to old method
    return session.get('username', 'admin')

def path_to_url(path):
    """Convert a filesystem path to URL format (forward slashes)"""
    return path.replace('\\', '/')

def cleanup_orphaned_files():
    """Clean up files that exist on disk but not in database"""
    try:
        print("Starting orphaned file cleanup...")
        from database import get_files_in_folder, get_folder_structure

        # Get all file records from database
        db_files = set()
        folders = get_folder_structure()
        for folder in folders:
            files = get_files_in_folder(folder['id'])
            for file in files:
                db_files.add(file['filepath'])

        # Check filesystem for files not in database
        static_dir = 'static'
        file_share_dir = os.path.join(static_dir, 'file_share_system')

        if os.path.exists(file_share_dir):
            orphaned_count = 0
            for root, dirs, files in os.walk(file_share_dir):
                for filename in files:
                    # Skip thumbnail files - they're handled separately
                    if '_thumb.' in filename:
                        continue

                    filepath = os.path.join(root, filename)
                    relative_path = os.path.relpath(filepath, static_dir)
                    relative_path = path_to_url(relative_path)

                    if relative_path not in db_files:
                        try:
                            os.remove(filepath)
                            print(f"Removed orphaned file: {filepath}")
                            orphaned_count += 1
                        except Exception as e:
                            print(f"Failed to remove orphaned file {filepath}: {e}")

            if orphaned_count > 0:
                print(f"Cleanup complete: removed {orphaned_count} orphaned files")
            else:
                print("Cleanup complete: no orphaned files found")

    except Exception as e:
        print(f"Error during orphaned file cleanup: {e}")

def generate_thumbnail(image_path, thumbnail_path, size=(200, 200)):
    """Generate a thumbnail for an image using OpenCV or PIL as fallback"""
    try:
        os.makedirs(os.path.dirname(thumbnail_path), exist_ok=True)
        print(f"Attempting to generate thumbnail for {image_path} at {thumbnail_path}")

        if not os.path.exists(image_path):
            print(f"Error: Source image {image_path} does not exist")
            return False

        if OPENCV_AVAILABLE and cv2 is not None and np is not None:
            img = cv2.imread(image_path)
            if img is None:
                print(f"OpenCV failed to load image: {image_path}, trying PIL")
            else:
                height, width = img.shape[:2]
                if height == 0 or width == 0:
                    print(f"Error: Invalid image dimensions for {image_path}")
                    return False

                aspect_ratio = width / height
                if width > height:
                    new_width = size[0]
                    new_height = int(size[0] / aspect_ratio)
                else:
                    new_height = size[1]
                    new_width = int(size[1] * aspect_ratio)

                resized = cv2.resize(img, (new_width, new_height), interpolation=cv2.INTER_LANCZOS4)
                canvas = np.full((size[1], size[0], 3), 255, dtype=np.uint8)
                x_offset = (size[0] - new_width) // 2
                y_offset = (size[1] - new_height) // 2
                canvas[y_offset:y_offset+new_height, x_offset:x_offset+new_width] = resized

                success = cv2.imwrite(thumbnail_path, canvas, [cv2.IMWRITE_JPEG_QUALITY, 85])
                if success:
                    print(f"Thumbnail generated (OpenCV): {thumbnail_path}")
                    return True
                else:
                    print(f"Error: Failed to save thumbnail at {thumbnail_path}")
                    return False

        # Fallback to PIL
        print(f"Using PIL fallback for thumbnail generation: {image_path}")
        try:
            from PIL import Image
            with Image.open(image_path) as pil_img:
                if pil_img.mode in ('RGBA', 'LA'):
                    pil_img = pil_img.convert('RGB')
                pil_img.thumbnail(size, Image.Resampling.LANCZOS)
                pil_img.save(thumbnail_path, 'JPEG', quality=85)
            print(f"Thumbnail generated (PIL): {thumbnail_path}")
            return True
        except Exception as pil_error:
            print(f"PIL failed to process image {image_path}: {str(pil_error)}")
            return False

    except Exception as e:
        print(f"Error generating thumbnail for {image_path}: {str(e)}")
        return False