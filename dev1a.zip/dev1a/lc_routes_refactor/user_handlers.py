from flask import Blueprint, request, jsonify, send_from_directory, make_response, send_file, session
from werkzeug.security import check_password_hash
from database import get_user_by_username, check_username_available

user_routes = Blueprint('user_routes', __name__)

@user_routes.route('/user-image-preferences')
def get_user_image_preferences():
    """Get user's image generation preferences"""
    username = request.args.get('username')

    if not username:
        # Return default preferences if no username
        return jsonify({
            'model_name': 'pixelArtDiffusionXL',
            'width': 1024,
            'height': 1024,
            'steps': 33,
            'cfg_scale': 7.0,
            'clip_skip': 2,
            'negative_prompt': '',
            'sampler_name': 'DPM++ 3M SDE',
            'scheduler_name': 'exponential',
            'batch_size': 1,
            'uploaded_image': None
        }), 200

    try:
        from database import get_user_by_username, get_user_image_preferences
        user_info = get_user_by_username(username)
        if user_info:
            preferences = get_user_image_preferences(user_info['uuid'])
            return jsonify(preferences), 200
        else:
            # User not found, return defaults
            return jsonify({
                'model_name': 'pixelArtDiffusionXL',
                'width': 1024,
                'height': 1024,
                'steps': 33,
                'cfg_scale': 7.0,
                'clip_skip': 2,
                'negative_prompt': '',
                'sampler_name': 'DPM++ 3M SDE',
                'scheduler_name': 'exponential',
                'batch_size': 1,
                'uploaded_image': None
            }), 200
    except Exception as e:
        print(f"Failed to get user image preferences: {str(e)}")
        return jsonify({'error': f'Failed to get preferences: {str(e)}'}), 500

@user_routes.route('/api/login', methods=['POST'])
def http_login():
    """HTTP fallback login endpoint for when Socket.IO is unavailable"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No data provided'}), 400

        username = data.get('username', '').strip()
        password = data.get('password', '').strip()

        if not username or not password:
            return jsonify({'success': False, 'error': 'Username and password are required'}), 400

        user = get_user_by_username(username)
        if not user or not check_password_hash(user['password_hash'], password):
            return jsonify({'success': False, 'error': 'Invalid username or password'}), 401

        # Set session for HTTP fallback
        session['user_uuid'] = user['uuid']
        session.modified = True

        return jsonify({
            'success': True,
            'user': {
                'uuid': user['uuid'],
                'username': user['username'],
                'is_admin': user.get('is_admin', False)
            }
        }), 200

    except Exception as e:
        print(f"HTTP login error: {str(e)}")
        return jsonify({'success': False, 'error': 'Login failed'}), 500

@user_routes.route('/api/register', methods=['POST'])
def http_register():
    """HTTP fallback registration endpoint for when Socket.IO is unavailable"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No data provided'}), 400

        username = data.get('username', '').strip()
        password = data.get('password', '').strip()
        avatar_url = data.get('avatar_url')
        display_name = data.get('display_name')
        custom_status = data.get('custom_status')

        if not username or not password:
            return jsonify({'success': False, 'error': 'Username and password are required'}), 400

        if len(username) < 3 or len(password) < 6:
            return jsonify({'success': False, 'error': 'Username must be at least 3 characters and password at least 6 characters'}), 400

        # Check if username already exists
        existing = get_user_by_username(username)
        if existing:
            return jsonify({'success': False, 'error': 'Username already taken'}), 409

        # Create user
        import uuid
        from database import save_user, is_user_admin
        user_uuid = str(uuid.uuid4())
        password_hash = save_user(user_uuid, username, password, avatar_url, display_name, custom_status)

        # Set session for HTTP fallback
        session['user_uuid'] = user_uuid
        session.modified = True

        return jsonify({
            'success': True,
            'user': {
                'uuid': user_uuid,
                'username': username,
                'is_admin': is_user_admin(user_uuid)
            }
        }), 201

    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 400
    except Exception as e:
        print(f"HTTP registration error: {str(e)}")
        return jsonify({'success': False, 'error': 'Registration failed'}), 500

@user_routes.route('/api/check-username', methods=['GET'])
def http_check_username():
    """HTTP fallback username availability check"""
    username = request.args.get('username', '').strip()
    if not username:
        return jsonify({'available': False, 'message': 'Username is required'}), 400

    try:
        available = check_username_available(username)
        return jsonify({
            'available': available,
            'message': 'Username is available' if available else 'Username is already taken'
        }), 200
    except Exception as e:
        print(f"HTTP username check error: {str(e)}")
        return jsonify({'available': False, 'message': 'Error checking availability'}), 500