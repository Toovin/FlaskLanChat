from flask import Blueprint, request, jsonify, send_from_directory, make_response, send_file, session

session_routes = Blueprint('session_routes', __name__)

# Global users_db instance - will be set by register_routes
users_db = None

@session_routes.route('/session_check')
def session_check():
    user_uuid = session.get('user_uuid')
    if not user_uuid:
        return jsonify({'authenticated': False})

    # Check if user exists in database
    user_data = users_db.get(user_uuid)
    if user_data:
        return jsonify({
            'authenticated': True,
            'username': user_data['username'],
            'user_id': user_uuid
        })
    else:
        print(f"Session check: User UUID {user_uuid} not found in database")
        return jsonify({'authenticated': False})