# lc_routes_refactor package
from . import media_handlers, file_handlers, folder_handlers, asset_handlers, session_handlers, theme_handlers, sd_proxy_handlers, user_handlers, settings_handlers

def register_routes(app, socketio, users_db):
    """Register all routes with the Flask app"""

    # Set global instances for handlers that need them
    media_handlers.socketio = socketio
    session_handlers.users_db = users_db
    theme_handlers.users_db = users_db

    # Register all blueprints
    app.register_blueprint(media_handlers.media_routes)
    app.register_blueprint(file_handlers.file_routes)
    app.register_blueprint(folder_handlers.folder_routes)
    print("Registered folder_routes blueprint")
    app.register_blueprint(asset_handlers.asset_routes)
    app.register_blueprint(session_handlers.session_routes)
    app.register_blueprint(theme_handlers.theme_routes)
    app.register_blueprint(sd_proxy_handlers.sd_proxy_routes)
    app.register_blueprint(user_handlers.user_routes)

    # Register settings routes
    settings_handlers.register_settings_routes(app, users_db)