from flask import Blueprint, request, jsonify, send_from_directory, make_response, send_file, session
import os
from datetime import datetime
import json
import re

theme_routes = Blueprint('theme_routes', __name__)

# Global users_db instance - will be set by register_routes
users_db = None

@theme_routes.route('/save-custom-theme', methods=['POST'])
def save_custom_theme():
    # Try to get user_uuid from session first
    user_uuid = session.get('user_uuid')

    # If not in session, try to get from request args (temporary workaround)
    if not user_uuid:
        username = request.args.get('username')
        if username:
            from database import get_user_by_username
            user_info = get_user_by_username(username)
            if user_info:
                user_uuid = user_info['uuid']

    if not user_uuid:
        return jsonify({'error': 'Not authenticated'}), 401

    user_data = users_db.get(user_uuid)
    if not user_data:
        return jsonify({'error': 'User not found'}), 404

    data = request.get_json()
    if not data or 'theme' not in data:
        return jsonify({'error': 'Invalid theme data'}), 400

    theme_data = data['theme']
    theme_name = theme_data.get('name', '').strip()
    if not theme_name:
        return jsonify({'error': 'Theme name is required'}), 400

    # Create user-custom-themes directory if it doesn't exist
    themes_dir = os.path.join('user-custom-themes')
    os.makedirs(themes_dir, exist_ok=True)

    # Generate filename: username-date-time-themename.json
    username = user_data['username']
    timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
    safe_theme_name = re.sub(r'[^\w\-_]', '_', theme_name)
    filename = f"{username}-{timestamp}-{safe_theme_name}.json"
    filepath = os.path.join(themes_dir, filename)

    try:
        # Save theme data to file
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(theme_data, f, indent=2, ensure_ascii=False)

        return jsonify({
            'success': True,
            'filename': filename,
            'message': f'Theme "{theme_name}" saved successfully'
        })

    except Exception as e:
        print(f"Error saving custom theme: {e}")
        return jsonify({'error': f'Failed to save theme: {str(e)}'}), 500

@theme_routes.route('/load-custom-themes', methods=['GET'])
def load_custom_themes():
    # Try to get user_uuid from session first
    user_uuid = session.get('user_uuid')

    # If not in session, try to get from request args (temporary workaround)
    if not user_uuid:
        username = request.args.get('username')
        if username:
            from database import get_user_by_username
            user_info = get_user_by_username(username)
            if user_info:
                user_uuid = user_info['uuid']

    if not user_uuid:
        return jsonify({'error': 'Not authenticated'}), 401

    user_data = users_db.get(user_uuid)
    if not user_data:
        return jsonify({'error': 'User not found'}), 404

    themes_dir = os.path.join('user-custom-themes')
    themes = []

    if os.path.exists(themes_dir):
        try:
            for filename in os.listdir(themes_dir):
                if filename.endswith('.json') and filename.startswith(user_data['username'] + '-'):
                    filepath = os.path.join(themes_dir, filename)
                    try:
                        with open(filepath, 'r', encoding='utf-8') as f:
                            theme_data = json.load(f)
                            themes.append(theme_data)
                    except Exception as e:
                        print(f"Error loading theme {filename}: {e}")
                        continue
        except Exception as e:
            print(f"Error reading themes directory: {e}")
            return jsonify({'error': f'Failed to load themes: {str(e)}'}), 500

    return jsonify({'themes': themes})

@theme_routes.route('/delete-custom-theme', methods=['POST'])
def delete_custom_theme():
    # Try to get user_uuid from session first
    user_uuid = session.get('user_uuid')

    # If not in session, try to get from request args (temporary workaround)
    if not user_uuid:
        username = request.args.get('username')
        if username:
            from database import get_user_by_username
            user_info = get_user_by_username(username)
            if user_info:
                user_uuid = user_info['uuid']

    if not user_uuid:
        return jsonify({'error': 'Not authenticated'}), 401

    user_data = users_db.get(user_uuid)
    if not user_data:
        return jsonify({'error': 'User not found'}), 404

    data = request.get_json()
    if not data or 'theme_name' not in data:
        return jsonify({'error': 'Theme name is required'}), 400

    theme_name = data['theme_name'].strip()
    safe_theme_name = re.sub(r'[^\w\-_]', '_', theme_name)
    themes_dir = os.path.join('user-custom-themes')

    if not os.path.exists(themes_dir):
        return jsonify({'error': 'Themes directory not found'}), 404

    # Find and delete the theme file based on filename match
    deleted = False
    for filename in os.listdir(themes_dir):
        if filename.startswith(user_data['username'] + '-') and filename.endswith(f"-{safe_theme_name}.json"):
            filepath = os.path.join(themes_dir, filename)
            try:
                os.remove(filepath)
                deleted = True
                break
            except Exception as e:
                print(f"Error deleting theme {filename}: {e}")
                continue

    if deleted:
        return jsonify({'success': True, 'message': f'Theme "{theme_name}" deleted successfully'})
    else:
        return jsonify({'error': f'Theme "{theme_name}" not found'}), 404