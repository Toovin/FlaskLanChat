from flask import Blueprint, request, jsonify, send_from_directory, make_response, send_file, session
import os

asset_routes = Blueprint('asset_routes', __name__)

@asset_routes.route('/list-cursor-files', methods=['GET'])
def list_cursor_files():
    try:
        cursor_files = []

        # Get files from static/images/default_cursors directory (shipped with program)
        default_cursors_path = os.path.join('static', 'images', 'default_cursors')
        if os.path.exists(default_cursors_path):
            for filename in os.listdir(default_cursors_path):
                filepath = os.path.join(default_cursors_path, filename)
                if os.path.isfile(filepath):
                    # Filter for image/cursor types
                    if filename.lower().endswith(('.png', '.webp', '.ico', '.cur', '.gif', '.jpg', '.jpeg', '.svg')):
                        cursor_files.append({
                            'name': filename,
                            'path': f'/static/images/default_cursors/{filename}',
                            'type': 'default'
                        })

        # Get files from static/images/custom_cursors directory (user uploaded)
        custom_cursors_path = os.path.join('static', 'images', 'custom_cursors')
        if os.path.exists(custom_cursors_path):
            for filename in os.listdir(custom_cursors_path):
                filepath = os.path.join(custom_cursors_path, filename)
                if os.path.isfile(filepath):
                    # Filter for image/cursor types
                    if filename.lower().endswith(('.png', '.webp', '.ico', '.cur', '.gif', '.jpg', '.jpeg', '.svg')):
                        cursor_files.append({
                            'name': filename,
                            'path': f'/static/images/custom_cursors/{filename}',
                            'type': 'custom'
                        })

        return jsonify({'files': cursor_files}), 200
    except Exception as e:
        print(f"Failed to list cursor files: {str(e)}")
        return jsonify({'error': f'Failed to list cursor files: {str(e)}'}), 500

@asset_routes.route('/list-particle-files', methods=['GET'])
def list_particle_files():
    try:
        particle_files = []

        # Get files from static/images/default_particles directory (shipped with program)
        default_particles_path = os.path.join('static', 'images', 'default_particles')
        if os.path.exists(default_particles_path):
            for filename in os.listdir(default_particles_path):
                filepath = os.path.join(default_particles_path, filename)
                if os.path.isfile(filepath):
                    # Filter for image/particle types
                    if filename.lower().endswith(('.png', '.webp', '.gif', '.jpg', '.jpeg', '.svg')):
                        particle_files.append({
                            'name': filename,
                            'path': f'/static/images/default_particles/{filename}',
                            'type': 'default'
                        })

        # Get files from static/images/custom_particles directory (user uploaded)
        custom_particles_path = os.path.join('static', 'images', 'custom_particles')
        if os.path.exists(custom_particles_path):
            for filename in os.listdir(custom_particles_path):
                filepath = os.path.join(custom_particles_path, filename)
                if os.path.isfile(filepath):
                    # Filter for image/particle types
                    if filename.lower().endswith(('.png', '.webp', '.gif', '.jpg', '.jpeg', '.svg')):
                        particle_files.append({
                            'name': filename,
                            'path': f'/static/images/custom_particles/{filename}',
                            'type': 'custom'
                        })

        return jsonify({'files': particle_files}), 200
    except Exception as e:
        print(f"Failed to list particle files: {str(e)}")
        return jsonify({'error': f'Failed to list particle files: {str(e)}'}), 500

@asset_routes.route('/list-sticker-files', methods=['GET'])
def list_sticker_files():
    try:
        sticker_files = []

        # Get files from static/stickers/default directory
        stickers_path = os.path.join('static', 'stickers', 'default')
        if os.path.exists(stickers_path):
            for filename in os.listdir(stickers_path):
                filepath = os.path.join(stickers_path, filename)
                if os.path.isfile(filepath):
                    # Filter for supported sticker types
                    if filename.lower().endswith(('.png', '.webp', '.jpg', '.jpeg', '.svg', '.webm')):
                        sticker_files.append({
                            'name': filename,
                            'path': f'/static/stickers/default/{filename}',
                            'type': 'sticker'
                        })

        return jsonify({'files': sticker_files}), 200
    except Exception as e:
        print(f"Failed to list sticker files: {str(e)}")
        return jsonify({'error': f'Failed to list sticker files: {str(e)}'}), 500