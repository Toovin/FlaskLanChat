#!/usr/bin/env python3
import sqlite3

conn = sqlite3.connect('devchat.db')
cursor = conn.cursor()

# Check if table exists
cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='ai_characters'")
table_exists = cursor.fetchone()
print('ai_characters table exists:', table_exists is not None)

if table_exists:
    # Count characters
    cursor.execute('SELECT COUNT(*) FROM ai_characters')
    count = cursor.fetchone()[0]
    print('Number of characters:', count)

    if count > 0:
        # Get sample characters
        cursor.execute('SELECT user_uuid, character_name FROM ai_characters LIMIT 10')
        rows = cursor.fetchall()
        print('Sample characters:')
        for row in rows:
            print(f'  {row[0]}: {row[1]}')

conn.close()