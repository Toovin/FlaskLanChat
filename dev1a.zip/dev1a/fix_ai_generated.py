#!/usr/bin/env python3
"""
ARCHIVED: Fix completed - AI messages now properly flagged in new system
Fix ai_generated flag for existing AI messages.
This script updates all messages from "AI Assistant" to have ai_generated = 1.

Status: ✅ COMPLETED - AI message flagging now handled automatically in new system
Keep for reference only - do not run again.
"""

import sqlite3
import os

def fix_ai_generated_flags():
    """Update ai_generated flag for existing AI messages"""
    try:
        # Check if database exists
        if not os.path.exists('devchat.db'):
            print("Database file not found")
            return

        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        # Check if ai_generated column exists
        c.execute("PRAGMA table_info(messages)")
        columns = [col[1] for col in c.fetchall()]

        if 'ai_generated' not in columns:
            print("ai_generated column does not exist. Running database initialization...")
            from database.database_init import init_db
            init_db()
            print("Database initialized. Please run this script again.")
            return

        # Count AI messages that need fixing
        c.execute("SELECT COUNT(*) FROM messages WHERE sender = 'AI Assistant' AND (ai_generated IS NULL OR ai_generated = 0)")
        count = c.fetchone()[0]

        if count == 0:
            print("No AI messages need fixing.")
            conn.close()
            return

        print(f"Found {count} AI messages that need ai_generated flag set to 1")

        # Update the messages
        c.execute("UPDATE messages SET ai_generated = 1 WHERE sender = 'AI Assistant' AND (ai_generated IS NULL OR ai_generated = 0)")
        updated_count = c.rowcount

        conn.commit()
        conn.close()

        print(f"Successfully updated {updated_count} AI messages with ai_generated = 1")

    except Exception as e:
        print(f"Error fixing AI generated flags: {str(e)}")

if __name__ == "__main__":
    fix_ai_generated_flags()