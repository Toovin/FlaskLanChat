#!/usr/bin/env python3
"""
Simple demo of creating GIFs from PNG layers with alpha transparency
"""

from PIL import Image
import os

def create_simple_gif_from_pngs():
    """
    Create a simple animated GIF from PNG files with transparency
    """
    # Create some sample frames (you would replace these with your actual PNGs)
    frames = []

    # Frame 1: Red circle
    frame1 = Image.new('RGBA', (100, 100), (0, 0, 0, 0))  # Transparent background
    # Draw a red circle (simplified - you'd use drawing functions)
    frames.append(frame1)

    # Frame 2: Blue circle
    frame2 = Image.new('RGBA', (100, 100), (0, 0, 0, 0))  # Transparent background
    # Draw a blue circle
    frames.append(frame2)

    # Save as animated GIF
    frames[0].save(
        'demo.gif',
        save_all=True,
        append_images=frames[1:],
        duration=500,  # 500ms per frame
        loop=0,        # Infinite loop
        transparency=0 # Transparent color index
    )

    print("Created demo.gif")

def create_colored_gif_from_existing():
    """
    Take an existing GIF and create colored variants
    """
    if not os.path.exists('music_notes_1.gif'):
        print("music_notes_1.gif not found - skipping demo")
        return

    # Load original GIF
    with Image.open('music_notes_1.gif') as gif:
        frames = []
        durations = []

        # Extract frames
        try:
            while True:
                frame = gif.copy()
                if frame.mode != 'RGBA':
                    frame = frame.convert('RGBA')
                frames.append(frame)

                duration = gif.info.get('duration', 100)
                durations.append(duration)

                gif.seek(gif.tell() + 1)
        except EOFError:
            pass

        print(f"Extracted {len(frames)} frames")

        # Apply color tint to each frame
        tinted_frames = []
        tint_color = (255, 100, 100, 128)  # Semi-transparent red

        for frame in frames:
            # Create tinted overlay
            overlay = Image.new('RGBA', frame.size, tint_color)
            # Composite with original (preserves transparency)
            tinted = Image.composite(frame, overlay, frame)
            tinted_frames.append(tinted)

        # Save colored version
        tinted_frames[0].save(
            'music_notes_1_red.gif',
            save_all=True,
            append_images=tinted_frames[1:],
            duration=durations,
            loop=0,
            transparency=0
        )

        print("Created music_notes_1_red.gif")

if __name__ == '__main__':
    print("GIF Colorization Demo")
    print("====================")

    # Demo 1: Simple GIF creation
    print("\n1. Creating simple demo GIF...")
    create_simple_gif_from_pngs()

    # Demo 2: Colorizing existing GIF
    print("\n2. Creating colored variant...")
    create_colored_gif_from_existing()

    print("\nDone! Check the generated GIF files.")
