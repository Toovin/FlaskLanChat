# CSS Borders Tool

This tool provides a complete setup for creating and testing custom CSS border images. It's a one-stop-shop for generating templates, editing them, and previewing in a live playground.

## Features

- **Template Generation**: Create 64x64 PNG templates for each border part (corners, edges, center) with basic fills for painting.
- **Composite Image**: Automatically generates a 3x3 composite PNG for CSS border-image use.
- **Live Playground**: Interactive HTML tool to adjust dimensions, slices, repeat modes, and effects in real-time.
- **Effects Panel**: Apply CSS filters like brightness, contrast, hue-rotate, etc., to make borders pop.

## Usage

### Generating Templates

Run the Python script to create templates:

```bash
python generate_border_templates.py
```

This creates `tools/cssborders/generation_1/` with individual PNGs and a composite.png.

### Editing Templates

- Open the PNGs in an image editor (e.g., GIMP, Photoshop).
- Paint over the white areas to design your border.
- Regenerate composite if needed.

### Testing/Previewing

Open `test_border.html` in a browser. Adjust controls to see live changes.

### Adding Effects

In the playground, use the Effects section to apply filters for visual pop:
- Brightness/Contrast for intensity.
- Hue-rotate for color shifts.
- Blur for softness.
- Drop-shadow for depth.

### Creating New Generations

- Copy `generation_1` to `generation_2`, etc.
- Edit the templates.
- Update the folder select in `test_border.html`.

## Visual Effects for Border Images

To make borders pop:
- **Colorize**: Use hue-rotate filter or edit images with vibrant colors.
- **Gradients/Shaders**: Paint gradients in templates (e.g., bright to dark lines).
- **Patterns**: Add textures, stripes, or custom designs.
- **Animations**: CSS animations on the element (e.g., pulsing borders).
- **Shadows**: Apply drop-shadow for 3D effect.
- **Filters**: Brightness, saturation, invert for dramatic looks.
- **Combinations**: Layer with background images or use multiple borders.

Experiment in the playground to find 'oOoOoOO' effects!