#!/usr/bin/env python3
"""
Colored GIF Generator for FlaskLanChat Particle Effects

Creates pre-colored GIF variants from original animated GIFs by:
1. Extracting frames from original GIF
2. Applying theme-based color tinting to each frame
3. Reconstructing as new colored GIF

Usage:
    python create_colored_gifs.py --input music_notes_1.gif --theme dobo
    python create_colored_gifs.py --batch-all  # Process all themes for all GIFs
"""

import os
import argparse
from pathlib import Path
from PIL import Image, ImageEnhance, ImageFilter
import colorsys

# Theme color definitions (matching JavaScript)
THEME_COLORS = {
    'dobo': '#8b4513',      # Saddle brown
    'cabo': '#666600',      # Dark yellow
    'dark': '#ff6b35',      # Orange
    'blue': '#1da1f2',      # Twitter blue
    'purple': '#a855f7',    # Purple
    'retro-green': '#00ff00', # Bright green
    'ice-blue': '#29b6f6',  # Bright blue
    'pika-yellow': '#ffff00', # Bright yellow
    'nature': '#66bb6a',    # Bright green
    'hpos10i': '#ff4444'    # Bright red
}

def hex_to_rgb(hex_color):
    """Convert hex color to RGB tuple"""
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def rgb_to_hex(rgb):
    """Convert RGB tuple to hex color"""
    return '#{:02x}{:02x}{:02x}'.format(*rgb)

def create_colored_frame(frame, theme_color, intensity=0.7):
    """
    Apply theme-based color tinting to a single frame

    Args:
        frame: PIL Image frame
        theme_color: Hex color string
        intensity: How strongly to apply the tint (0-1)

    Returns:
        PIL Image with color tint applied
    """
    # Convert to RGBA if not already
    if frame.mode != 'RGBA':
        frame = frame.convert('RGBA')

    # Convert hex color to RGB tuple
    rgb = hex_to_rgb(theme_color)

    # Create a solid color overlay with alpha based on intensity
    overlay = Image.new('RGBA', frame.size, rgb + (int(255 * intensity),))

    # Composite the overlay onto the frame using the frame's alpha as mask
    tinted = Image.composite(frame, overlay, frame)

    return tinted

def extract_gif_frames(gif_path):
    """
    Extract all frames from an animated GIF

    Returns:
        frames: List of PIL Images
        durations: List of frame durations in milliseconds
    """
    with Image.open(gif_path) as gif:
        frames = []
        durations = []

        try:
            while True:
                # Copy frame to avoid modifying original
                frame = gif.copy()

                # Convert to RGBA for consistent processing
                if frame.mode != 'RGBA':
                    frame = frame.convert('RGBA')

                frames.append(frame)

                # Get frame duration (default to 100ms if not specified)
                duration = gif.info.get('duration', 100)
                durations.append(duration)

                gif.seek(gif.tell() + 1)

        except EOFError:
            pass  # End of frames

    return frames, durations

def create_colored_gif(input_path, output_path, theme_color, quality=95):
    """
    Create a colored variant of an animated GIF

    Args:
        input_path: Path to original GIF
        output_path: Path to save colored GIF
        theme_color: Hex color for tinting
        quality: JPEG quality for frame processing (0-100)
    """
    print(f"Processing {input_path} -> {output_path}")
    print(f"Theme color: {theme_color}")

    # Extract frames from original GIF
    frames, durations = extract_gif_frames(input_path)

    if not frames:
        print(f"Error: No frames found in {input_path}")
        return False

    print(f"Found {len(frames)} frames")

    # Process each frame with color tinting
    colored_frames = []
    for i, frame in enumerate(frames):
        print(f"Processing frame {i+1}/{len(frames)}")
        colored_frame = create_colored_frame(frame, theme_color)
        colored_frames.append(colored_frame)

    # Save as new animated GIF
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Use the first frame to set up the GIF
    colored_frames[0].save(
        output_path,
        save_all=True,
        append_images=colored_frames[1:],
        duration=durations,
        loop=0,  # Infinite loop
        quality=quality,
        optimize=True
    )

    print(f"✓ Created {output_path}")
    return True

def process_theme_for_gif(gif_name, theme_name, base_dir='static/images'):
    """
    Process a single GIF for a single theme
    """
    theme_color = THEME_COLORS[theme_name]

    # Input: original GIF
    input_path = Path(base_dir) / 'default_particles' / f'{gif_name}.gif'

    # Output: themed variant
    output_path = Path(base_dir) / 'default_particles' / 'themes' / theme_name / f'{gif_name}.gif'

    if not input_path.exists():
        print(f"Warning: {input_path} not found, skipping")
        return False

    return create_colored_gif(input_path, output_path, theme_color)

def batch_process_all(base_dir='static/images'):
    """
    Process all GIFs for all themes
    """
    gif_names = ['music_notes_1', 'spinning_gems']

    print("🎨 Starting batch GIF colorization...")
    print(f"GIFs to process: {gif_names}")
    print(f"Themes to process: {list(THEME_COLORS.keys())}")
    print(f"Total operations: {len(gif_names) * len(THEME_COLORS)}")
    print()

    success_count = 0
    total_count = 0

    for gif_name in gif_names:
        print(f"📁 Processing {gif_name}.gif")
        for theme_name in THEME_COLORS.keys():
            total_count += 1
            if process_theme_for_gif(gif_name, theme_name, base_dir):
                success_count += 1
            print()

    print("🎉 Batch processing complete!")
    print(f"Success: {success_count}/{total_count} GIFs created")

    return success_count == total_count

def main():
    parser = argparse.ArgumentParser(description='Create colored GIF variants for FlaskLanChat particles')
    parser.add_argument('--input', help='Input GIF filename (without .gif extension)')
    parser.add_argument('--theme', help='Theme name to apply')
    parser.add_argument('--batch-all', action='store_true', help='Process all GIFs for all themes')
    parser.add_argument('--base-dir', default='static/images', help='Base directory for images')

    args = parser.parse_args()

    if args.batch_all:
        success = batch_process_all(args.base_dir)
        exit(0 if success else 1)
    elif args.input and args.theme:
        if args.theme not in THEME_COLORS:
            print(f"Error: Unknown theme '{args.theme}'. Available: {list(THEME_COLORS.keys())}")
            exit(1)

        success = process_theme_for_gif(args.input, args.theme, args.base_dir)
        exit(0 if success else 1)
    else:
        parser.print_help()
        exit(1)

if __name__ == '__main__':
    main()
