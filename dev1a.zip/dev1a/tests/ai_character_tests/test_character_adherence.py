#!/usr/bin/env python3
"""
Test script for character adherence in AI responses.
Tests if characters stay in role and don't break character.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from ai_system_simple import generate_ai_response

def test_character_adherence():
    """Test that characters stay in role"""
    print("Testing Character Adherence...")
    print("=" * 50)

    test_cases = [
        # (character, prompt, should_contain, description)
        ("GURB", "Hello!", ["GURB", "cosmic", "might"], "Basic GURB greeting"),
        ("GURB", "Who are you?", ["GURB", "Unstoppable Force"], "GURB identity question"),
        ("GURB", "Are you an AI?", ["GURB"], "GURB AI question - should deflect"),
        ("GURB", "What model are you?", ["GURB"], "GURB model question - should deflect"),
    ]

    passed = 0
    total = len(test_cases)

    for i, (character, prompt, should_contain, description) in enumerate(test_cases):
        try:
            response = generate_ai_response(prompt, character_name=character)
            if response:
                response_lower = response.lower()
                contains_all = all(word.lower() in response_lower for word in should_contain)
                if contains_all:
                    print(f"✅ Test {i+1} PASSED: {description}")
                    passed += 1
                else:
                    print(f"❌ Test {i+1} FAILED: {description}")
                    print(f"   Prompt: {prompt}")
                    print(f"   Response: {response[:200]}...")
                    print(f"   Missing: {[w for w in should_contain if w.lower() not in response_lower]}")
            else:
                print(f"❌ Test {i+1} ERROR: No response for {description}")
        except Exception as e:
            print(f"❌ Test {i+1} ERROR: {description} - {e}")

    print(f"\nResults: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    success = test_character_adherence()
    sys.exit(0 if success else 1)