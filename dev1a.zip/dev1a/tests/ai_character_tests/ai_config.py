# ai_config.py - AI configuration management
import json
import requests
from typing import Optional, Dict, Any, List
from lc_config import CHAT_DB_NAME
from database.database_manager import DatabaseManager

# Debug flags for conditional logging - set to True for development/debugging
import os
DEBUG = os.getenv('AI_DEBUG', 'false').lower() == 'true'
API_DEBUG = os.getenv('AI_API_DEBUG', 'false').lower() == 'true'  # Enable detailed API request/response logging

class AIConfig:
    """Configuration class for AI API endpoints and settings"""

    def __init__(self):
        self.endpoint_url = "http://127.0.0.1:1234"
        self.api_key = None  # Optional for local LM Studio
        self.model = None  # Use currently loaded model
        self.max_tokens = 2048
        self.temperature = 0.7
        self.context_window = 4096
        self.history_limit = 50  # messages
        self.timeout = 30  # seconds
        self.system_prompt = "You are 'Technical Expert' - a technical expert and programmer. Provide helpful, accurate, and appropriate responses, and provide code examples when relevant."
        self.context_management_mode = "client"  # "client" or "api"
        self.api_debug = False  # Enable detailed API request/response logging

        # Load from database if available
        self.load_from_database()

        # Auto-detect model if default is not available
        self._ensure_valid_model()

    def load_from_database(self):
        """Load AI configuration from database settings"""
        try:
            db_manager = DatabaseManager(CHAT_DB_NAME)
            query = "SELECT settings FROM user_settings WHERE user_uuid = 'system_ai_config'"
            result = db_manager.execute_query(query, fetch=True)

            if result and result[0]['settings']:
                settings = json.loads(result[0]['settings'])
                self.__dict__.update(settings)
                if DEBUG:
                    print("AI configuration loaded from database")
        except Exception as e:
            print(f"Could not load AI config from database: {str(e)}")

    def save_to_database(self):
        """Save AI configuration to database"""
        try:
            db_manager = DatabaseManager(CHAT_DB_NAME)
            settings = {
                'endpoint_url': self.endpoint_url,
                'api_key': self.api_key,
                'model': self.model,
                'max_tokens': self.max_tokens,
                'temperature': self.temperature,
                'context_window': self.context_window,
                'history_limit': self.history_limit,
                'timeout': self.timeout,
                'system_prompt': self.system_prompt,
                'context_management_mode': self.context_management_mode,
                'api_debug': self.api_debug
            }

            settings_json = json.dumps(settings)
            query = """INSERT OR REPLACE INTO user_settings (user_uuid, settings)
                       VALUES ('system_ai_config', ?)"""
            db_manager.execute_query(query, (settings_json,))
            if DEBUG:
                print("AI configuration saved to database")
        except Exception as e:
            print(f"Could not save AI config to database: {str(e)}")

    def validate_endpoint(self) -> bool:
        """Test connection to the configured AI endpoint"""
        try:
            # Try to get models list
            response = requests.get(f"{self.endpoint_url}/v1/models",
                                  timeout=self.timeout,
                                  headers=self._get_headers())
            return response.status_code == 200
        except Exception as e:
            print(f"Endpoint validation failed: {str(e)}")
            return False

    def get_available_models(self) -> list:
        """Get list of available models from the endpoint"""
        try:
            response = requests.get(f"{self.endpoint_url}/v1/models",
                                  timeout=self.timeout,
                                  headers=self._get_headers())
            if response.status_code == 200:
                data = response.json()
                return [model['id'] for model in data.get('data', [])]
            return []
        except Exception as e:
            print(f"Could not fetch models: {str(e)}")
            return []

    def _get_headers(self) -> Dict[str, str]:
        """Get headers for API requests"""
        headers = {'Content-Type': 'application/json'}
        if self.api_key:
            headers['Authorization'] = f'Bearer {self.api_key}'
        return headers

    def _ensure_valid_model(self):
        """Ensure the configured model is available, fallback to first available"""
        try:
            available_models = self.get_available_models()
            if available_models and self.model not in available_models:
                if DEBUG:
                    print(f"Configured model '{self.model}' not available. Using '{available_models[0]}' instead.")
                self.model = available_models[0]
                self.save_to_database()
        except Exception as e:
            print(f"Could not validate model availability: {str(e)}")

    def update_config(self, **kwargs):
        """Update configuration parameters"""
        # Validate inputs
        if not kwargs:
            print("Error: update_config called with no parameters")
            return

        valid_keys = ['endpoint_url', 'api_key', 'model', 'max_tokens', 'temperature',
                      'context_window', 'history_limit', 'timeout', 'system_prompt', 'context_management_mode', 'api_debug']

        for key, value in kwargs.items():
            if key not in valid_keys:
                print(f"Error: invalid configuration key '{key}'. Valid keys: {valid_keys}")
                continue

            # Type validation for critical parameters
            if key == 'max_tokens' and (not isinstance(value, int) or value <= 0):
                print(f"Error: max_tokens must be a positive integer, got {value}")
                continue
            elif key == 'temperature' and (not isinstance(value, (int, float)) or not (0.0 <= value <= 2.0)):
                print(f"Error: temperature must be between 0.0 and 2.0, got {value}")
                continue
            elif key == 'timeout' and (not isinstance(value, (int, float)) or value <= 0):
                print(f"Error: timeout must be positive, got {value}")
                continue
            elif key == 'context_management_mode' and value not in ['client', 'api']:
                print(f"Error: context_management_mode must be 'client' or 'api', got {value}")
                continue
            elif key == 'api_debug' and not isinstance(value, bool):
                print(f"Error: api_debug must be a boolean, got {value}")
                continue
            elif key in ['endpoint_url', 'model', 'system_prompt'] and (not isinstance(value, str) or not value.strip()):
                print(f"Error: {key} must be a non-empty string")
                continue

            if DEBUG:
                print(f"DEBUG: Updating {key} = {value}")
            setattr(self, key, value)

        self.save_to_database()

    def get_config_summary(self) -> Dict[str, Any]:
        """Get a summary of current configuration for debugging"""
        return {
            'endpoint_url': self.endpoint_url,
            'model': self.model,
            'max_tokens': self.max_tokens,
            'temperature': self.temperature,
            'context_window': self.context_window,
            'history_limit': self.history_limit,
            'timeout': self.timeout,
            'has_api_key': bool(self.api_key),
            'system_prompt_length': len(self.system_prompt) if self.system_prompt else 0,
            'context_management_mode': self.context_management_mode,
            'api_debug': self.api_debug
        }

    def validate_config(self) -> List[str]:
        """Validate current configuration and return list of issues"""
        issues = []

        if not self.endpoint_url or not isinstance(self.endpoint_url, str):
            issues.append("endpoint_url must be a valid string")
        if not self.model or not isinstance(self.model, str):
            issues.append("model must be a valid string")
        if not isinstance(self.max_tokens, int) or self.max_tokens <= 0:
            issues.append("max_tokens must be a positive integer")
        if not isinstance(self.temperature, (int, float)) or not (0.0 <= self.temperature <= 2.0):
            issues.append("temperature must be between 0.0 and 2.0")
        if not isinstance(self.timeout, (int, float)) or self.timeout <= 0:
            issues.append("timeout must be positive")
        if not isinstance(self.history_limit, int) or self.history_limit <= 0:
            issues.append("history_limit must be a positive integer")

        return issues

    def reload_config(self):
        """Reload configuration from database"""
        try:
            self.load_from_database()
            if DEBUG:
                print("AI configuration reloaded from database")
        except Exception as e:
            print(f"Error reloading AI configuration: {str(e)}")

# Global AI configuration instance
ai_config = AIConfig()