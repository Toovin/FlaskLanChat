# ai_agent.py - AI agent for generating responses
import requests
import json
from typing import List, Dict, Any, Optional
from ai_config import ai_config, DEBUG, API_DEBUG
from database import database_ai

# Debug flags imported from ai_config


def extract_message_text(raw_message: str) -> str:
    """
    Extract readable text content from a message, handling both plain text and JSON-formatted messages.

    For JSON messages (like image generation messages), extracts the 'message' field.
    For plain text messages, returns as-is.

    Args:
        raw_message: Raw message content from database

    Returns:
        Extracted text content suitable for AI context
    """
    if not raw_message or not isinstance(raw_message, str):
        return ""

    try:
        import json
        parsed = json.loads(raw_message)
        if isinstance(parsed, dict) and 'message' in parsed:
            # JSON message format - extract the text content
            return parsed['message']
    except (json.JSONDecodeError, KeyError, TypeError):
        # Not JSON or doesn't have expected structure - treat as plain text
        pass

    # Return as plain text
    return raw_message


class AIAgent:
    """AI agent for handling chat completions and context management"""

    def __init__(self, config=None):
        self.config = config or ai_config

    def generate_response(self, prompt: str, user_id: str, context: List[Dict] = None,
                          conversation_id: int = None, mode: str = "chat",
                          image_data: str = None, user_settings: Dict = None) -> Optional[str]:
        """
        Generate AI response based on prompt and context

        Args:
            prompt: User input prompt
            user_id: User UUID
            context: List of previous messages for context
            conversation_id: AI conversation ID for history tracking
            mode: Generation mode ('chat', 'completion', 'embedding')
            image_data: Base64 encoded image data for vision models

        Returns:
            Generated response text or None if failed
        """
        # Validate required inputs
        if not prompt or not isinstance(prompt, str) or not prompt.strip():
            print("Error: prompt is required and cannot be empty")
            return None

        if not user_id or not isinstance(user_id, str):
            print("Error: user_id is required and must be a valid string")
            return None

        if mode not in ["chat", "completion", "embedding"]:
            print(f"Error: unsupported mode '{mode}'. Supported modes: chat, completion, embedding")
            return None

        try:
            if mode == "chat":
                return self._generate_chat_completion(prompt, context, conversation_id, image_data, user_settings)
            elif mode == "completion":
                return self._generate_completion(prompt)
            else:
                # This should not be reached due to validation above, but kept for safety
                print(f"Unsupported mode: {mode}")
                return None
        except Exception as e:
            print(f"Error generating AI response: {str(e)}")
            return None

    def _make_api_request(self, endpoint: str, payload: Dict, user_settings: Dict = None) -> Optional[Dict]:
        """Make API request and return full response data"""
        try:
            # Use user settings for timeout if available, otherwise config default
            timeout = user_settings.get('ai_timeout') if user_settings else self.config.timeout

            # Check if API debug logging is enabled (user setting overrides config)
            api_debug_enabled = user_settings.get('ai_api_debug') if user_settings else self.config.api_debug
            api_debug_enabled = api_debug_enabled or DEBUG or API_DEBUG or self.config.api_debug

            if api_debug_enabled:
                print(f"[AI_AGENT] API Request to {endpoint}:")
                print(f"[AI_AGENT] Payload: {payload}")

            response = requests.post(
                f"{self.config.endpoint_url}{endpoint}",
                json=payload,
                headers=self.config._get_headers(),
                timeout=timeout
            )

            if api_debug_enabled:
                print(f"[AI_AGENT] API Response status: {response.status_code}")

            if response.status_code == 200:
                response_data = response.json()
                if api_debug_enabled:
                    print(f"[AI_AGENT] API Response: {response_data}")
                return response_data
            else:
                print(f"API error: {response.status_code} - {response.text}")
                return None

        except Exception as e:
            print(f"Error in API request to {endpoint}: {str(e)}")
            return None

    def _extract_response_content(self, response_data: Dict) -> Optional[str]:
        """Extract text content from API response"""
        try:
            # Handle /v1/responses format
            if 'output' in response_data:
                for item in response_data['output']:
                    if item.get('type') == 'message' and item.get('content'):
                        for content_item in item['content']:
                            if content_item.get('type') == 'output_text':
                                return content_item['text']

            # Handle /v1/chat/completions format
            if 'choices' in response_data and response_data['choices']:
                choice = response_data['choices'][0]
                if 'message' in choice:  # Chat completion format
                    return choice['message']['content']
                elif 'text' in choice:  # Completion format
                    return choice['text']

            print(f"Unexpected API response format: {response_data}")
            return None
        except Exception as e:
            print(f"Error extracting response content: {str(e)}")
            return None

    def _extract_response_id(self, response_data: Dict) -> Optional[str]:
        """Extract response ID from API response"""
        try:
            return response_data.get('id')
        except Exception as e:
            print(f"Error extracting response ID: {str(e)}")
            return None

    def _generate_chat_completion(self, prompt: str, context: List[Dict] = None,
                                 conversation_id: int = None, image_data: str = None,
                                 user_settings: Dict = None) -> Optional[str]:
        """Generate response using chat completions or responses API based on context management mode"""

        # Check context management mode (user setting overrides global config)
        context_mode = user_settings.get('ai_context_management_mode') if user_settings else self.config.context_management_mode
        context_mode = context_mode or self.config.context_management_mode  # fallback to config

        if DEBUG or API_DEBUG:
            print(f"[AI_AGENT] Context management mode: {context_mode} (conversation_id: {conversation_id})")
            if user_settings:
                print(f"[AI_AGENT] User settings available: {list(user_settings.keys())}")
                if 'ai_context_management_mode' in user_settings:
                    print(f"[AI_AGENT] Using user setting: {user_settings['ai_context_management_mode']}")
                else:
                    print(f"[AI_AGENT] No user context mode setting, using config default: {self.config.context_management_mode}")
            else:
                print(f"[AI_AGENT] No user settings, using config default: {self.config.context_management_mode}")

        if context_mode == "api":
            return self._generate_api_side_response(prompt, conversation_id, image_data, user_settings)
        else:
            return self._generate_client_side_response(prompt, context, conversation_id, image_data, user_settings)

    def _generate_client_side_response(self, prompt: str, context: List[Dict] = None,
                                     conversation_id: int = None, image_data: str = None,
                                     user_settings: Dict = None) -> Optional[str]:
        """Generate response using client-side context management (original method)"""
        # Build messages array
        messages = []

        # Build structured system message with character and user context
        system_parts = []

        # Get user and character info
        user_name = user_settings.get('user_name') if user_settings else None
        character_name = user_settings.get('name') if user_settings else None
        character_description = user_settings.get('description') if user_settings else None

        # Build character-aware system prompt
        if character_name:
            # When a character is selected, use the character's system prompt as primary
            system_prompt = user_settings.get('ai_system_prompt') if user_settings else None
            if system_prompt:
                system_parts.append(system_prompt)
            else:
                # Fallback if no character system prompt
                system_parts.append(f"You are {character_name}.")

            # Add character description if available
            if character_description:
                system_parts.append(f"Character Description: {character_description}")

            # Add custom instructions
            custom_instructions = user_settings.get('ai_custom_instructions') if user_settings else None
            if custom_instructions:
                system_parts.append(f"Additional Instructions: {custom_instructions}")

        else:
            system_prompt = user_settings.get('ai_system_prompt') if user_settings else self.config.system_prompt
            if system_prompt:
                system_parts.append(f"System Prompt: {system_prompt}")
            if not (system_prompt and system_prompt.startswith("You are")):
                if user_name:
                    system_parts.append(f"You are an AI assistant and are talking to '{user_name}'.")
            custom_instructions = user_settings.get('ai_custom_instructions') if user_settings else None
            if custom_instructions:
                system_parts.append(f"Additional Instructions: {custom_instructions}")

        # Add response focus instruction
        system_parts.append("Respond specifically to the current user input.")

        # Combine system parts
        instructions = "\n\n".join(system_parts) if system_parts else None

        # Get the previous response ID for this conversation
        previous_response_id = None
        if conversation_id:
            from database import database_ai
            # API-side response ID tracking removed in new system
            previous_response_id = None
            if DEBUG:
                print(f"[AI_AGENT] Previous response ID: {previous_response_id}")

        # Prepare user input (current message)
        user_content = prompt

        # Replace @ai mentions with character name in current message for API consistency
        if character_name and '@ai' in user_content:
            user_content = user_content.replace('@ai', f'@{character_name}')

        # Handle image data for vision models
        if image_data:
            if image_data.startswith('data:'):
                image_url = image_data
                # Handle @ai replacement in text part for vision messages
                text_content = user_content if isinstance(user_content, str) else user_content[0]['text']
                if character_name and '@ai' in text_content:
                    text_content = text_content.replace('@ai', f'@{character_name}')
                    if isinstance(user_content, list):
                        user_content[0]['text'] = text_content
                    else:
                        user_content = text_content

                user_content = [
                    {"type": "text", "text": text_content},
                    {"type": "image_url", "image_url": {"url": image_url}}
                ]
            else:
                print(f"Error: image_data must be a complete data URL, received: {image_data[:50]}...")
                # Continue without image

        # Prepare API request payload
        model = user_settings.get('ai_model') if user_settings else self.config.model
        max_tokens = user_settings.get('ai_max_tokens') if user_settings else self.config.max_tokens
        temperature = user_settings.get('ai_temperature') if user_settings else self.config.temperature

        payload = {
            "input": user_content,
            "max_output_tokens": max_tokens,
            "temperature": temperature
        }

        # Add instructions if present
        if instructions:
            payload["instructions"] = instructions

        # Add previous response ID for context
        if previous_response_id:
            payload["previous_response_id"] = previous_response_id

        # Always specify model (required by LM Studio API)
        payload["model"] = model

        if DEBUG:
            print(f"DEBUG: API-side response payload: {payload}")

        # Make API call
        response_data = self._make_api_request("/v1/responses", payload, user_settings)
        ai_response = self._extract_response_content(response_data) if response_data else None
        response_id = self._extract_response_id(response_data) if response_data else None

        # Handle response and store response ID
        if ai_response and conversation_id:
            try:
from ai_database import ai_database
from database.database_ai import get_channel_context_for_ai

                # Store user message
                ai_database.save_conversation_message(conversation_id, "user", prompt)

                # Store AI response with response ID
                ai_database.save_conversation_message(conversation_id, "assistant", ai_response)

                # Update conversation's last response ID
                if response_id:
                    # API-side response ID tracking removed in new system
                    pass

            except Exception as e:
                print(f"Error storing API-side conversation history: {str(e)}")

        return ai_response

    def _generate_completion(self, prompt: str) -> Optional[str]:
        """Generate response using completions API (legacy)"""
        payload = {
            "model": self.config.model,
            "prompt": prompt,
            "max_tokens": self.config.max_tokens,
            "temperature": self.config.temperature
        }

        response_data = self._make_api_request("/v1/completions", payload)
        return self._extract_response_content(response_data) if response_data else None

    def build_channel_context(self, channel_id: str, message_limit: int = 20, include_ai_messages: bool = False, character_name: str = None, user_name: str = None) -> List[Dict]:
        """Build context from recent channel messages"""
        try:
            messages = get_channel_context_for_ai(channel_id, message_limit, include_ai_messages)

            if DEBUG:
                print(f"DEBUG: Retrieved {len(messages)} messages from channel {channel_id} (include_ai={include_ai_messages})")
            context = []
            for msg in messages:
                # Mark AI messages differently in context for clarity
                if msg.get('is_ai'):
                    role = "assistant"
                    content = extract_message_text(msg['message'])
                    if character_name:
                        content = f"{character_name}: {content}"
                else:
                    role = "user"  # Use standard role for user messages
                    content = extract_message_text(msg['message'])
                    if user_name:
                        content = f"{user_name}: {content}"
                context.append({
                    "role": role,
                    "content": content
                })
                if DEBUG:
                    print(f"DEBUG: Channel context: [{role}] {content[:100]}{'...' if len(content) > 100 else ''}")

            return context
        except Exception as e:
            print(f"Error building channel context: {str(e)}")
            return []

    def build_dm_context(self, user_uuid: str, ai_uuid: str, message_limit: int = 50) -> List[Dict]:
        """Build context from DM conversation with AI"""
        try:
            import sqlite3
            from lc_config import CHAT_DB_NAME
            # Use direct connection like other database functions
            conn = sqlite3.connect(CHAT_DB_NAME)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            # Get user display name for personalization
            from database import database_users
            user_name = database_users.get_display_name_by_uuid(user_uuid)

            # Query DM messages between user and AI, ordered by timestamp
            query = """SELECT sender_uuid, message, timestamp, is_media
                       FROM dm_messages
                       WHERE ((sender_uuid = ? AND recipient_uuid = ?) OR (sender_uuid = ? AND recipient_uuid = ?))
                       AND is_media = 0
                       ORDER BY timestamp ASC
                       LIMIT ?"""
            params = (user_uuid, ai_uuid, ai_uuid, user_uuid, message_limit)
            cursor.execute(query, params)
            result = cursor.fetchall()

            # Convert to dict format
            context = []
            for row in result:
                # Determine role based on sender
                if row['sender_uuid'] == ai_uuid:
                    role = "assistant"
                else:
                    role = "user"  # Use standard role for API compatibility
                content = extract_message_text(row['message'])
                context.append({
                    "role": role,
                    "content": content
                })

            conn.close()

            if DEBUG:
                print(f"DEBUG: Built DM context with {len(context)} messages")
            return context
        except Exception as e:
            print(f"Error building DM context: {str(e)}")
            return []

    def create_conversation(self, user_uuid: str, conversation_type: str,
                           channel_id: str = None, title: str = None, character_name: str = None) -> Optional[int]:
        """Create a new AI conversation or return existing"""
        if character_name and not title:
            title = f"Character: {character_name}"
        elif character_name and title:
            title = f"{title} - {character_name}"

        # Check if conversation already exists
        existing_conversations = ai_database.get_user_conversations(user_uuid, conversation_type)
        for conv in existing_conversations:
            if conv['channel_id'] == channel_id and conv['title'] == title:
                return conv['id']

        # Create new conversation
        return ai_database.create_conversation(user_uuid, conversation_type, channel_id, title)

    def get_conversation_history(self, conversation_id: int, limit: int = 50) -> List[Dict]:
        """Get conversation history for context"""
        return ai_database.get_conversation_messages(conversation_id, limit)


# Global AI agent instance
ai_agent = AIAgent()