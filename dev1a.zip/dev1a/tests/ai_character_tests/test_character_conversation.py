#!/usr/bin/env python3
"""
Test script for character conversation mixing - simulate characters bouncing back and forth.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from ai_system_simple import generate_ai_response

def simulate_character_conversation():
    """Simulate a conversation between GURB and Anabelle with shared context"""
    print("Simulating Character Conversation...")
    print("=" * 50)

    # Initialize conversation history
    conversation_history = []

    # Characters to alternate between
    characters = ["GURB", "Anabelle"]
    char_index = 0

    # Starting prompts
    prompts = [
        "Hello there! What brings you to this cosmic realm?",
        "Oh, what a fascinating place this is! Tell me more about yourself.",
        "What do you think about the mysteries of the universe?",
        "Mysteries? I love a good mystery! What kind of adventures have you had?",
        "Adventures beyond imagination! What about you, what excites you most?"
    ]

    for i, prompt in enumerate(prompts):
        current_char = characters[char_index % len(characters)]
        print(f"\n--- Turn {i+1}: {current_char} ---")
        print(f"Prompt: {prompt}")

        # Generate response with current character and full conversation history
        response = generate_ai_response(
            prompt=prompt,
            character_name=current_char,
            context_messages=conversation_history.copy()  # Pass current history
        )

        if response:
            print(f"Response: {response[:200]}...")

            # Add this exchange to history
            conversation_history.append({"role": "user", "content": prompt})
            conversation_history.append({"role": "assistant", "content": response})

            # Keep only last 10 messages to avoid token limits
            if len(conversation_history) > 20:
                conversation_history = conversation_history[-20:]
        else:
            print("❌ Failed to generate response")
            break

        char_index += 1

    print(f"\nFinal conversation history has {len(conversation_history)} messages")

def test_shared_context_with_different_characters():
    """Test using shared context but switching characters mid-conversation"""
    print("\nTesting Shared Context with Character Switching...")
    print("=" * 50)

    # Start with GURB
    context = []
    response1 = generate_ai_response("Tell me about your powers!", character_name="GURB")
    if response1:
        print(f"GURB: {response1[:150]}...")
        context.extend([
            {"role": "user", "content": "Tell me about your powers!"},
            {"role": "assistant", "content": response1}
        ])

        # Now Anabelle responds in the same conversation
        response2 = generate_ai_response("What do you think of that?", character_name="Anabelle", context_messages=context)
        if response2:
            print(f"Anabelle (responding to GURB): {response2[:150]}...")
            context.extend([
                {"role": "user", "content": "What do you think of that?"},
                {"role": "assistant", "content": response2}
            ])

            # GURB responds to Anabelle
            response3 = generate_ai_response("Interesting perspective! What else?", character_name="GURB", context_messages=context)
            if response3:
                print(f"GURB (responding to Anabelle): {response3[:150]}...")

if __name__ == "__main__":
    simulate_character_conversation()
    test_shared_context_with_different_characters()