#!/usr/bin/env python3
"""
Test script for characters asking questions to each other naturally.
Tests if characters can engage in back-and-forth questioning.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from ai_system_simple import generate_ai_response

def test_natural_question_exchange():
    """Test if characters naturally ask questions back and forth"""
    print("Testing Natural Question Exchange Between Characters...")
    print("=" * 60)

    # Start with a simple greeting that should elicit questions
    conversation_history = []

    # GURB starts
    prompt1 = "Hello! Who are you?"
    print(f"\n--- GURB asks: {prompt1} ---")

    response1 = generate_ai_response(prompt1, character_name="GURB")
    if response1:
        print(f"GURB: {response1}")
        conversation_history.extend([
            {"role": "user", "content": prompt1},
            {"role": "assistant", "content": response1}
        ])

        # Check if GURB asked a question
        has_question = any(q in response1.lower() for q in ['?', 'what', 'who', 'how', 'why', 'when', 'where'])
        print(f"❓ GURB asked a question: {has_question}")

        # Anabelle responds
        prompt2 = "That's interesting! Tell me more about yourself."
        print(f"\n--- Anabelle asks: {prompt2} ---")

        response2 = generate_ai_response(prompt2, character_name="Anabelle", context_messages=conversation_history)
        if response2:
            print(f"Anabelle: {response2}")
            conversation_history.extend([
                {"role": "user", "content": prompt2},
                {"role": "assistant", "content": response2}
            ])

            # Check if Anabelle asked a question
            has_question = any(q in response2.lower() for q in ['?', 'what', 'who', 'how', 'why', 'when', 'where'])
            print(f"❓ Anabelle asked a question: {has_question}")

            # GURB responds to Anabelle
            prompt3 = "What do you find most fascinating?"
            print(f"\n--- GURB asks: {prompt3} ---")

            response3 = generate_ai_response(prompt3, character_name="GURB", context_messages=conversation_history)
            if response3:
                print(f"GURB: {response3}")

                # Check if GURB asked a question
                has_question = any(q in response3.lower() for q in ['?', 'what', 'who', 'how', 'why', 'when', 'where'])
                print(f"❓ GURB asked a question: {has_question}")

def test_question_driven_conversation():
    """Test a conversation driven purely by character responses (no predetermined prompts)"""
    print("\nTesting Question-Driven Conversation...")
    print("=" * 60)

    conversation_history = []

    # Start with GURB asking Anabelle a question
    initial_prompt = "Anabelle, what is your favorite thing about the universe?"
    print(f"\n--- Initial: {initial_prompt} ---")

    # Anabelle responds
    response1 = generate_ai_response(initial_prompt, character_name="Anabelle")
    if response1:
        print(f"Anabelle: {response1}")
        conversation_history.extend([
            {"role": "user", "content": initial_prompt},
            {"role": "assistant", "content": response1}
        ])

        # Now let GURB respond to Anabelle's answer
        follow_up_prompt = "That's fascinating! What else interests you?"
        print(f"\n--- GURB follows up: {follow_up_prompt} ---")

        response2 = generate_ai_response(follow_up_prompt, character_name="GURB", context_messages=conversation_history)
        if response2:
            print(f"GURB: {response2}")

if __name__ == "__main__":
    test_natural_question_exchange()
    test_question_driven_conversation()