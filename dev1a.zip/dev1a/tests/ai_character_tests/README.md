# AI Character Tests

This folder contains tests for AI character functionality in FlaskLanChat.

## Test Files

### `test_character_adherence.py`
Tests that AI characters stay in character and don't break role-playing.
- Verifies characters respond consistently with their personality
- Tests identity deflection (characters don't admit being AI)
- Checks that characters maintain their defined traits

### `test_character_conversation.py`
Tests character conversation mixing and shared context.
- Simulates conversations between multiple characters (GURB, Anabelle)
- Verifies characters can bounce back and forth with shared history
- Tests that each character maintains personality while referencing previous messages

### `test_character_questions.py`
Tests natural question exchange between characters.
- Verifies characters naturally ask questions to each other during conversation
- Tests question-driven dialogue flow
- Checks that both characters engage in back-and-forth questioning

## Running Tests

```bash
# Run individual tests
python tests/ai_character_tests/test_character_adherence.py
python tests/ai_character_tests/test_character_conversation.py

# Run all AI character tests
python -m pytest tests/ai_character_tests/ -v

# Run individual question test
python tests/ai_character_tests/test_character_questions.py
```

## Dependencies

These tests require:
- `ai_system_simple.py` - The simplified AI system (imported from project root)
- `ai_config.py` - AI configuration (imported from project root)
- LM Studio server running with Qwen model
- Database connection (for character loading, falls back to hardcoded prompts if unavailable)

## Notes

- Tests use hardcoded character prompts when database is unavailable
- Full responses may be truncated in console output
- Check server logs for complete AI responses and debugging info