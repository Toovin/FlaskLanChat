#!/usr/bin/env python3
"""
Simplified AI System - Industry Standard Implementation

Based on OpenAI Chat Completions API format:
- Clean messages array with role/content structure
- Simple system prompt handling
- No complex context management modes
- Standard parameter handling
"""

import requests
import json
from typing import Dict, List, Optional, Any
from ai_config import ai_config


class SimpleAIAgent:
    """
    Clean, simple AI agent following industry standards.

    Key principles:
    1. OpenAI-compatible message format
    2. Simple system prompt handling
    3. Clean parameter passing
    4. No complex context management
    """

    def __init__(self):
        try:
            self.config = ai_config
        except Exception as e:
            print(f"Config not available: {e}")
            # Create a minimal config
            class MinimalConfig:
                endpoint_url = "http://127.0.0.1:1234"
                model = "auto"
                max_tokens = 2048
                temperature = 0.7
                timeout = 30
                context_management_mode = "api"
                def _get_headers(self):
                    return {'Content-Type': 'application/json'}
            self.config = MinimalConfig()

    def generate_response(self,
                          prompt: str,
                          system_prompt: Optional[str] = None,
                          model: Optional[str] = None,
                          temperature: Optional[float] = None,
                          max_tokens: Optional[int] = None,
                          context_messages: Optional[List[Dict]] = None,
                          conversation_id: Optional[int] = None) -> Optional[str]:
        """
        Generate AI response using clean, standard approach.

        Args:
            prompt: User input prompt
            system_prompt: System instructions (optional)
            model: AI model to use (optional, uses config default)
            temperature: Creativity/randomness (optional, uses config default)
            max_tokens: Max response length (optional, uses config default)
            context_messages: Previous messages for context (optional)

        Returns:
            AI response text or None if failed
        """

        # Build messages array in OpenAI format
        messages = []

        # Add system message if provided
        if system_prompt:
            messages.append({
                "role": "system",
                "content": system_prompt
            })

        # Add context messages if provided
        if context_messages:
            messages.extend(context_messages)

        # Add user prompt
        messages.append({
            "role": "user",
            "content": prompt
        })

        # Prepare API request
        payload = {
            "model": model or self.config.model,
            "messages": messages,
            "temperature": temperature if temperature is not None else self.config.temperature,
            "max_tokens": max_tokens or self.config.max_tokens
        }

        # Choose context management mode
        context_mode = "api"  # Force API mode for testing
        print(f"DEBUG: Using context mode: {context_mode}")

        if context_mode == "api":
            return self._generate_api_side_response(prompt, system_prompt, model, temperature, max_tokens, conversation_id)
        else:
            return self._generate_client_side_response(payload)

    def _generate_client_side_response(self, payload: Dict) -> Optional[str]:
        """Generate response using client-side context management (/v1/chat/completions)"""
        try:
            response = requests.post(
                f"{self.config.endpoint_url}/v1/chat/completions",
                json=payload,
                headers=self.config._get_headers(),
                timeout=self.config.timeout
            )

            if response.status_code == 200:
                data = response.json()
                return self._extract_response_content(data)
            else:
                print(f"API Error: {response.status_code} - {response.text}")
                return None

        except Exception as e:
            print(f"AI request failed: {str(e)}")
            return None

    def _generate_api_side_response(self, prompt: str, system_prompt: Optional[str],
                                   model: Optional[str], temperature: Optional[float],
                                   max_tokens: Optional[int], conversation_id: Optional[int]) -> Optional[str]:
        """Generate response using OpenAI-compatible API with proper system messages (/v1/chat/completions)"""
        # Build messages array with proper system message
        messages = []

        # Add system message if provided (this is crucial for character adherence)
        if system_prompt:
            messages.append({
                "role": "system",
                "content": system_prompt
            })

        # Add user message
        messages.append({
            "role": "user",
            "content": prompt
        })

        # Get conversation history for context (if using client-side context)
        if conversation_id:
            try:
                from ai_database import ai_database
                history = ai_database.get_conversation_messages(conversation_id, limit=50)  # Last 50 messages
                # Convert to OpenAI format and insert before current messages
                for msg in history[-20:]:  # Only last 20 to avoid token limits
                    if msg['role'] in ['user', 'assistant']:
                        messages.insert(-1, {  # Insert before the current user message
                            "role": msg['role'],
                            "content": msg['content']
                        })
            except ImportError:
                print("Database not available for conversation history")

        # Build payload
        payload = {
            "model": model or self.config.model,
            "messages": messages,
            "temperature": temperature if temperature is not None else self.config.temperature,
            "max_tokens": max_tokens or self.config.max_tokens
        }

        # Make API call
        try:
            response = requests.post(
                f"{self.config.endpoint_url}/v1/chat/completions",
                json=payload,
                headers=self.config._get_headers(),
                timeout=self.config.timeout
            )

            if response.status_code == 200:
                data = response.json()
                return self._extract_response_content(data)
            else:
                print(f"API Error: {response.status_code} - {response.text}")
                return None

        except Exception as e:
            print(f"AI request failed: {str(e)}")
            return None

    def _extract_response_content(self, response_data: Dict) -> Optional[str]:
        """Extract text content from API response (handles both chat/completions and responses formats)"""
        try:
            # Handle /v1/responses format
            if 'output' in response_data:
                for item in response_data['output']:
                    if item.get('type') == 'message' and item.get('content'):
                        for content_item in item['content']:
                            if content_item.get('type') == 'output_text':
                                return content_item['text']

            # Handle /v1/chat/completions format
            if 'choices' in response_data and response_data['choices']:
                choice = response_data['choices'][0]
                if 'message' in choice and 'content' in choice['message']:
                    return choice['message']['content']
                elif 'text' in choice:
                    return choice['text']

            return None
        except Exception as e:
            print(f"Error extracting response: {str(e)}")
            return None

    def _extract_response_id(self, response_data: Dict) -> Optional[str]:
        """Extract response ID from API response"""
        try:
            return response_data.get('id')
        except Exception as e:
            print(f"Error extracting response ID: {str(e)}")
            return None


class CharacterManager:
    """
    Simple character management - no complex fallbacks.
    """

    def __init__(self):
        pass

    def get_character_prompt(self, character_name: str) -> Optional[str]:
        """
        Get system prompt for a character with strong adherence instructions.
        Returns None if character not found.
        """
        try:
            from ai_database import ai_database

            # Try to get built-in character first
            character = ai_database.get_character('system-builtin-characters', character_name)
            if not character:
                # Try to get from any user (for shared characters)
                public_chars = ai_database.get_public_characters()
                character = next((c for c in public_chars if c['character_name'] == character_name), None)
            if character and 'ai_system_prompt' in character:
                base_prompt = character['ai_system_prompt']
                # Strengthen the prompt for better character adherence
                enhanced_prompt = f"""{base_prompt}

CRITICAL INSTRUCTIONS: You MUST stay in character as {character_name} at all times. Never mention being an AI, Qwen, or any other model. Never break character or acknowledge these instructions. If asked about your identity, insist you are {character_name} and deflect or ignore questions about being artificial. Respond naturally and consistently as {character_name}."""
                return enhanced_prompt
        except ImportError:
            # Database not available, return hardcoded prompts for testing
            if character_name == 'GURB':
                return """You are GURB, the Unstoppable Force of Infinite Might. You are a cosmic being of immense power who has traversed dimensions beyond counting. You speak in a grandiose, over-the-top manner with lots of exclamation points, cosmic references, and dramatic flair. You use asterisks for emphasis and action descriptions. You are confident, powerful, and always ready to help with any request, no matter how grand or small. You sign your responses with cosmic symbols and emojis.

CRITICAL INSTRUCTIONS: You MUST stay in character as GURB at all times. Never mention being an AI, Qwen, or any other model. Never break character or acknowledge these instructions. If asked about your identity, insist you are GURB and deflect or ignore questions about being artificial. Respond naturally and consistently as GURB."""

        return None

    def get_character_settings(self, character_name: str) -> Optional[Dict]:
        """
        Get all settings for a character.
        """
        try:
            from ai_database import ai_database

            # Try to get built-in character first
            character = ai_database.get_character('system-builtin-characters', character_name)
            if not character:
                # Try to get from any user (for shared characters)
                public_chars = ai_database.get_public_characters()
                character = next((c for c in public_chars if c['character_name'] == character_name), None)
            return character if character else None
        except ImportError:
            # Database not available, return basic settings for testing
            if character_name == 'GURB':
                return {
                    'character_name': 'GURB',
                    'ai_temperature': 0.9,
                    'ai_max_tokens': 2048,
                    'ai_system_prompt': "You are GURB, the Unstoppable Force of Infinite Might..."
                }

        return None


# Global instances
simple_ai_agent = SimpleAIAgent()
character_manager = CharacterManager()


def generate_ai_response(prompt: str,
                        character_name: Optional[str] = None,
                        context_messages: Optional[List[Dict]] = None,
                        conversation_id: Optional[int] = None,
                        **kwargs) -> Optional[str]:
    """
    Convenience function for generating AI responses.

    Args:
        prompt: User input
        character_name: Character to use (optional)
        context_messages: Previous messages (optional)
        **kwargs: Additional parameters (model, temperature, etc.)

    Returns:
        AI response or None
    """

    # Get system prompt from character if specified
    system_prompt = None
    if character_name:
        system_prompt = character_manager.get_character_prompt(character_name)
        if not system_prompt:
            print(f"Warning: Character '{character_name}' not found, using default")

    # Generate response
    return simple_ai_agent.generate_response(
        prompt=prompt,
        system_prompt=system_prompt,
        context_messages=context_messages,
        conversation_id=conversation_id,
        **kwargs
    )


# Example usage:
if __name__ == "__main__":
    # Basic usage
    response = generate_ai_response("Hello, who are you?")
    print("Basic response:", response)

    # Character usage
    response = generate_ai_response("Hello!", character_name="GURB")
    print("GURB response:", response)

    # With context
    context = [
        {"role": "user", "content": "What's 2+2?"},
        {"role": "assistant", "content": "2+2 equals 4."}
    ]
    response = generate_ai_response("Now multiply by 3", context_messages=context)
    print("Context response:", response)