#!/usr/bin/env python3
"""
Test script for API-side context management
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# from ai_agent import ai_agent  # Removed - API-side context deprecated
from ai_config import ai_config
from ai_database import ai_database

def test_context_modes():
    """Test both context management modes"""

    print("Testing API-side context management...")

    # Test configuration
    print(f"Current context management mode: {ai_config.context_management_mode}")

    # Change to API mode
    ai_config.update_config(context_management_mode='api')
    print(f"Updated to API mode: {ai_config.context_management_mode}")

    # Test conversation creation
    print("Initializing AI database...")
    ai_database.init_tables()
    conversation_id = ai_database.create_conversation("test_user", "modal", title="API Context Test")
    print(f"Created conversation ID: {conversation_id}")

    if conversation_id:
        # Test conversation retrieval
        conversation = ai_database.get_conversation(conversation_id)
        print(f"Retrieved conversation: {conversation}")

        # Test conversation messages (should be empty)
        messages = ai_database.get_conversation_messages(conversation_id)
        print(f"Conversation messages count: {len(messages)}")

    # API-side context management methods removed in new system
    print("API-side context management deprecated - using client-side only")

    print("API-side context management test completed!")

if __name__ == "__main__":
    test_context_modes()