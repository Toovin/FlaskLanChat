#!/usr/bin/env python3
"""
Test script to verify AI context embedding is working by calling the standalone handler
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

# Mock socketio and users_db for testing
class MockSocketIO:
    def emit(self, event, data, room=None):
        print(f"EMIT: {event} -> {data}")

class MockUsersDB:
    pass

def test_channel_ai_with_context():
    """Test channel AI with context embedding"""

    # Import the handler
    from lc_socket_handlers_refactor.ai_handlers import handle_ai_channel_mention_standalone

    # Mock data
    mock_socketio = MockSocketIO()
    mock_users_db = MockUsersDB()
    mock_users = {}

    test_data = {
        'user_uuid': 'adc86468-56dc-4cdd-8a9d-2bab480f6fc0',
        'channel': 'general',
        'message': '@ai hello, do you remember our previous conversation?',
        'character_name': 'BUKA'
    }

    print("Testing channel AI with context embedding...")
    print(f"Test data: {test_data}")

    try:
        result = handle_ai_channel_mention_standalone(
            mock_socketio, mock_users_db, mock_users, test_data
        )
        print("Handler completed successfully")
        return True
    except Exception as e:
        print(f"Error in handler: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_channel_ai_with_context()
    print(f"\nTest result: {'PASS' if success else 'FAIL'}")
    print("\nCheck the server logs and LLM API logs to verify context embedding is working.")