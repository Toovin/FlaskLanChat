#!/usr/bin/env python3
"""
Test script for AI modal integration
"""

import sys
import os
import requests
import json

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_ai_modal_direct():
    """Test AI modal functionality directly"""
    print("Testing AI modal integration...")

    try:
        from ai_modal import ai_modal

        # Test character retrieval
        print("Testing character retrieval...")
        characters = ai_modal.get_characters("test_user")
        print(f"✓ Retrieved {len(characters)} characters")

        # Test character creation
        print("Testing character creation...")
        test_character = {
            'character_name': 'IntegrationTestBot',
            'character_description': 'Bot for integration testing',
            'ai_temperature': 0.8,
            'ai_system_prompt': 'You are a test bot for integration testing.'
        }

        success = ai_modal.create_character("test_user", test_character)
        if success:
            print("✓ Character created successfully")
        else:
            print("✗ Character creation failed")
            return False

        # Test sending a message (without LM Studio for now)
        print("Testing message sending structure...")
        # This will fail without LM Studio running, but we can test the structure
        try:
            result = ai_modal.send_message(
                user_uuid="test_user",
                message="Hello, test message",
                character_name="IntegrationTestBot",
                conversation_key="test:modal:123"
            )
            print(f"Message send result: {result}")
        except Exception as e:
            print(f"Expected error (LM Studio not running): {str(e)}")

        return True

    except Exception as e:
        print(f"✗ AI modal test failed: {str(e)}")
        return False

def test_socket_handlers():
    """Test socket handler imports"""
    print("\nTesting socket handler imports...")

    try:
        from ai_socket_handlers import register_new_ai_handlers
        print("✓ Socket handlers imported successfully")

        # Test that the function exists
        if callable(register_new_ai_handlers):
            print("✓ register_new_ai_handlers is callable")
        else:
            print("✗ register_new_ai_handlers is not callable")
            return False

        return True

    except Exception as e:
        print(f"✗ Socket handler test failed: {str(e)}")
        return False

def main():
    """Run integration tests"""
    print("🧪 AI Modal Integration Test")
    print("=" * 50)

    tests = [
        ("AI Modal Direct", test_ai_modal_direct),
        ("Socket Handlers", test_socket_handlers),
    ]

    passed = 0
    total = len(tests)

    for test_name, test_func in tests:
        try:
            if test_func():
                passed += 1
                print(f"✅ {test_name}: PASSED")
            else:
                print(f"❌ {test_name}: FAILED")
        except Exception as e:
            print(f"❌ {test_name}: ERROR - {str(e)}")

    print("\n" + "=" * 50)
    print(f"📊 Integration Test Results: {passed}/{total} tests passed")

    if passed == total:
        print("🎉 All integration tests passed!")
        return True
    else:
        print("⚠️  Some integration tests failed.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)