#!/usr/bin/env python3
"""
Test script to verify image generation flow works
"""
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

def test_sd_integration_import():
    """Test if SD integration can be imported without IndentationError"""
    try:
        # Test the specific problematic import
        import ast
        with open('extensions/sd_integration.py', 'r') as f:
            source = f.read()

        # Parse the AST to check for syntax errors
        ast.parse(source)
        print("✅ SD integration syntax is valid")

        # Try to import the setup function
        from extensions.sd_integration import setup
        print("✅ SD integration setup function imports successfully")

        return True
    except IndentationError as e:
        print(f"❌ IndentationError still present: {e}")
        return False
    except Exception as e:
        print(f"⚠️  Other import error (expected for relative imports): {e}")
        return True  # This is expected due to relative imports

def test_config_exists():
    """Test if SD config exists"""
    if os.path.exists('sd_config.json'):
        print("✅ sd_config.json exists")
        return True
    else:
        print("❌ sd_config.json missing")
        return False

def test_server_imports():
    """Test if server can import without errors"""
    try:
        # Test basic imports
        from lc_command_processor import CommandProcessor
        print("✅ Command processor imports successfully")

        # Test socket handlers
        from lc_socket_handlers_refactor.messaging_handlers import register_messaging_handlers
        print("✅ Messaging handlers import successfully")

        return True
    except Exception as e:
        print(f"❌ Server import error: {e}")
        return False

if __name__ == "__main__":
    print("Testing image generation setup...")
    print("=" * 50)

    results = []
    results.append(("SD Integration Syntax", test_sd_integration_import()))
    results.append(("SD Config Exists", test_config_exists()))
    results.append(("Server Imports", test_server_imports()))

    print("\n" + "=" * 50)
    print("SUMMARY:")
    for test_name, passed in results:
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status}: {test_name}")

    all_passed = all(passed for _, passed in results)
    if all_passed:
        print("\n🎉 All tests passed! Image generation should work.")
        print("\nNext steps:")
        print("1. Start your SD API server (e.g., Automatic1111) on http://127.0.0.1:7860")
        print("2. Start the FlaskLanChat server: python server_v1_a.py")
        print("3. Login and type '!image test prompt' in chat")
        print("4. Check browser console and server logs for DEBUG messages")
    else:
        print("\n❌ Some tests failed. Fix the issues above before testing image generation.")