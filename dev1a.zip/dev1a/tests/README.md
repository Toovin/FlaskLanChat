# FlaskLanChat Test Suite
NOT ALL FILES HERE ARE USEFUL ANYMORE. 
This directory contains all test files for the FlaskLanChat project, organized by type and purpose.

## Directory Structure

```
tests/
├── python/           # Python unit and integration tests
├── javascript/       # JavaScript client-side tests
├── integration/      # Full integration tests with UI components
└── README.md         # This file
```

## Test Categories

### Python Tests (`python/`)
Unit tests and backend functionality tests written in Python:
- Database operations
- Command processing
- File handling
- API endpoints
- Data validation

### JavaScript Tests (`javascript/`)
Client-side JavaScript tests:
- UI component tests
- Client-side validation
- Socket.IO communication tests

### Integration Tests (`integration/`)
Full integration tests that test complete workflows:
- End-to-end user interactions
- UI rendering and functionality
- Cross-component communication

## Running Tests

### Python Tests
```bash
# Run all Python tests
python -m pytest tests/python/

# Run specific test
python tests/python/test_specific_feature.py
```

### JavaScript Tests
```bash
# Run JavaScript tests (if using a test runner like Jest)
npm test tests/javascript/
```

### Integration Tests
```bash
# Run integration tests
python tests/integration/test_name/
```

## Adding New Tests

- Place Python test files in `tests/python/`
- Place JavaScript test files in `tests/javascript/`
- Place integration test directories in `tests/integration/`
- Follow naming convention: `test_*.py` or `test_*.js`

## Test Coverage

Tests should cover:
- Core functionality
- Error handling
- Edge cases
- User workflows
- API endpoints
- Database operations