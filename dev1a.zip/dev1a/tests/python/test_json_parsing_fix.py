#!/usr/bin/env python3
"""
Test script to verify the JSON parsing fix works correctly.
Tests both JSON and plain text message handling.
"""

import json

def simulate_add_message_logic(text, is_media, image_url=None, thumbnail_url=None):
    """Simulate the fixed addMessage logic from messageUtils.js"""

    parsed_text = text
    attachments = []

    if is_media:
        if isinstance(text, str):
            # Check if text looks like JSON (starts with '{' or '[')
            if text.strip().startswith('{') or text.strip().startswith('['):
                try:
                    parsed = json.loads(text)
                    parsed_text = parsed.get('text', '')
                    attachments = parsed.get('attachments', []) if isinstance(parsed.get('attachments'), list) else []
                    # Filter and map attachments
                    attachments = [
                        att for att in attachments
                        if att and att.get('url') and isinstance(att['url'], str) and
                        (att.get('thumbnail_url') is None or isinstance(att.get('thumbnail_url'), str))
                    ]
                    attachments = [
                        {
                            'url': att['url'],
                            'thumbnail_url': att.get('thumbnail_url') or None,
                            'size': att.get('size', 0)
                        }
                        for att in attachments
                    ]
                    print("✅ Successfully parsed JSON message")
                except json.JSONDecodeError as e:
                    print(f"❌ Failed to parse JSON message: {e}, Text: {text}")
                    # Fall back to treating as plain text
                    parsed_text = text or ''
                    if image_url and isinstance(image_url, str):
                        attachments = [{'url': image_url, 'thumbnail_url': thumbnail_url or None, 'size': 0}]
                    else:
                        print("⚠️  No valid image_url or thumbnail_url, treating as text message")
                        is_media = False
            else:
                # Plain text message (like "Media downloaded: filename.mp4")
                print(f"📝 Treating media message as plain text: {text}")
                parsed_text = text or ''
                if image_url and isinstance(image_url, str):
                    attachments = [{'url': image_url, 'thumbnail_url': thumbnail_url or None, 'size': 0}]
                else:
                    print("⚠️  No valid image_url or thumbnail_url for plain text media message")
                    is_media = False
        elif isinstance(text, dict) and text.get('image_url') and isinstance(text['image_url'], str):
            parsed_text = text.get('message', '')
            attachments = [{'url': text['image_url'], 'thumbnail_url': text.get('thumbnail_url') or None, 'size': 0}]

    return {
        'parsed_text': parsed_text,
        'attachments': attachments,
        'is_media': is_media
    }

def test_scenarios():
    """Test different message scenarios"""
    print("🧪 Testing JSON Parsing Fix Scenarios")
    print("=" * 60)

    # Test 1: Valid JSON message
    print("\n📄 Test 1: Valid JSON Message")
    json_message = '{"text": "Hello world", "attachments": [{"url": "/static/test.jpg", "thumbnail_url": "/static/thumb.jpg", "size": 1024}]}'
    result = simulate_add_message_logic(json_message, True, "/static/fallback.jpg", "/static/fallback_thumb.jpg")
    print(f"Parsed text: '{result['parsed_text']}'")
    print(f"Attachments: {len(result['attachments'])}")
    print(f"Is media: {result['is_media']}")

    # Test 2: Plain text message (the problematic case)
    print("\n📝 Test 2: Plain Text Media Message (The Problem Case)")
    plain_text = "Media downloaded: funny_cat_video.mp4"
    result = simulate_add_message_logic(plain_text, True, "/static/media/funny_cat_video.mp4", "/static/thumbnails/funny_cat_video_thumb.jpg")
    print(f"Parsed text: '{result['parsed_text']}'")
    print(f"Attachments: {len(result['attachments'])}")
    print(f"Is media: {result['is_media']}")

    # Test 3: Invalid JSON that looks like JSON
    print("\n❌ Test 3: Invalid JSON")
    invalid_json = '{"text": "Hello world", "attachments": [{"url": "/static/test.jpg", invalid}'
    result = simulate_add_message_logic(invalid_json, True, "/static/fallback.jpg", "/static/fallback_thumb.jpg")
    print(f"Parsed text: '{result['parsed_text']}'")
    print(f"Attachments: {len(result['attachments'])}")
    print(f"Is media: {result['is_media']}")

    # Test 4: Non-media message
    print("\n💬 Test 4: Regular Text Message")
    regular_text = "This is just a regular message"
    result = simulate_add_message_logic(regular_text, False)
    print(f"Parsed text: '{result['parsed_text']}'")
    print(f"Attachments: {len(result['attachments'])}")
    print(f"Is media: {result['is_media']}")

    # Test 5: Object message
    print("\n📦 Test 5: Object Message")
    object_message = {"message": "Object text", "image_url": "/static/test.jpg", "thumbnail_url": "/static/thumb.jpg"}
    result = simulate_add_message_logic(object_message, True)
    print(f"Parsed text: '{result['parsed_text']}'")
    print(f"Attachments: {len(result['attachments'])}")
    print(f"Is media: {result['is_media']}")

def main():
    print("🚀 JSON Parsing Fix Verification Test")
    print("=" * 60)

    print("\n📋 What This Fix Does:")
    print("✅ Detects JSON vs plain text messages automatically")
    print("✅ Handles 'Media downloaded: filename.mp4' style messages")
    print("✅ Falls back gracefully when JSON parsing fails")
    print("✅ Maintains backward compatibility with existing JSON messages")
    print("✅ Prevents the 'Unexpected token' JSON parsing errors")

    print("\n🔧 How It Works:")
    print("- Checks if message starts with '{' or '[' (JSON indicator)")
    print("- If JSON: parses normally with error handling")
    print("- If plain text: treats as regular message with attachments")
    print("- Always provides fallback for image_url/thumbnail_url")

    test_scenarios()

    print("\n" + "=" * 60)
    print("✨ JSON PARSING ERROR SHOULD BE FIXED!")
    print("\n🎯 Expected Results:")
    print("- ✅ No more 'Unexpected token' errors")
    print("- ✅ Plain text media messages display correctly")
    print("- ✅ JSON messages still work as before")
    print("- ✅ Chat loads without JavaScript errors")

if __name__ == '__main__':
    main()