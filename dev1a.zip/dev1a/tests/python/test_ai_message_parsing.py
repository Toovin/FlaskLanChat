#!/usr/bin/env python3
"""
Test script for AI message parsing functionality.
Tests the extract_message_text function and AI context building with JSON messages.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from ai_agent import extract_message_text, AIAgent


def test_extract_message_text():
    """Test the extract_message_text function with various inputs"""
    print("Testing extract_message_text function...")
    print("=" * 50)

    test_cases = [
        # (input, expected_output, description)
        ('Plain text message', 'Plain text message', 'Plain text'),
        ('{"message": "Generated 1 image", "attachments": []}', 'Generated 1 image', 'Image generation message'),
        ('{"message": "Generated 3 images", "attachments": [{"url": "/static/test.jpg"}]}', 'Generated 3 images', 'Multiple images'),
        ('{"message": "", "attachments": []}', '', 'Empty message in JSON'),
        ('{"attachments": []}', '{"attachments": []}', 'JSON without message field'),
        ('Invalid json {message: "test"}', 'Invalid json {message: "test"}', 'Invalid JSON'),
        ('', '', 'Empty string'),
        (None, '', 'None input'),
        ('123', '123', 'Numeric string'),
    ]

    passed = 0
    total = len(test_cases)

    for i, (input_val, expected, description) in enumerate(test_cases):
        try:
            result = extract_message_text(input_val)
            if result == expected:
                print(f"✅ Test {i+1} PASSED: {description}")
                passed += 1
            else:
                print(f"❌ Test {i+1} FAILED: {description}")
                print(f"   Input: {repr(input_val)}")
                print(f"   Expected: {repr(expected)}")
                print(f"   Got: {repr(result)}")
        except Exception as e:
            print(f"❌ Test {i+1} ERROR: {description} - {e}")

    print(f"\nResults: {passed}/{total} tests passed")
    return passed == total


def test_ai_context_with_json_messages():
    """Test that AI context building properly parses JSON messages"""
    print("\nTesting AI context building with JSON messages...")
    print("=" * 50)

    # Mock message data that would come from database
    mock_messages = [
        {
            'sender': 'user1',
            'message': 'Hello AI!',
            'timestamp': '2024-01-01 12:00:00',
            'display_name': 'User One',
            'username': 'user1',
            'is_ai': False
        },
        {
            'sender': 'ai_user',
            'message': '{"message": "Generated 2 images", "attachments": [{"url": "/static/img1.jpg"}, {"url": "/static/img2.jpg"}], "metadata": {"model": "test"}}',
            'timestamp': '2024-01-01 12:01:00',
            'display_name': 'AI Assistant',
            'username': 'ai',
            'is_ai': True
        },
        {
            'sender': 'user2',
            'message': 'Nice images!',
            'timestamp': '2024-01-01 12:02:00',
            'display_name': 'User Two',
            'username': 'user2',
            'is_ai': False
        }
    ]

    # Test the context building logic directly (simulating what build_channel_context does)
    try:
        context = []
        for msg in mock_messages:
            if msg.get('is_ai'):
                role = "assistant"
                content = extract_message_text(msg['message'])
            else:
                role = "user"
                content = extract_message_text(msg['message'])
            context.append({"role": role, "content": content})

        print("✅ Context building test PASSED")
        print("Generated context:")
        for i, msg in enumerate(context):
            print(f"  {i+1}. [{msg['role']}] {msg['content']}")

        # Verify the image generation message was parsed correctly
        image_msg = next((msg for msg in context if msg['role'] == 'assistant'), None)
        if image_msg and image_msg['content'] == 'Generated 2 images':
            print("✅ Image generation message correctly parsed")
            return True
        else:
            print("❌ Image generation message not parsed correctly")
            print(f"   Expected: 'Generated 2 images'")
            print(f"   Got: '{image_msg['content'] if image_msg else 'None'}'")
            return False

    except Exception as e:
        print(f"❌ Context building test ERROR: {e}")
        return False


def main():
    """Run all tests"""
    print("AI Message Parsing Tests")
    print("=" * 50)

    test1_passed = test_extract_message_text()
    test2_passed = test_ai_context_with_json_messages()

    print("\n" + "=" * 50)
    if test1_passed and test2_passed:
        print("🎉 All tests PASSED!")
        return 0
    else:
        print("❌ Some tests FAILED!")
        return 1


if __name__ == "__main__":
    sys.exit(main())