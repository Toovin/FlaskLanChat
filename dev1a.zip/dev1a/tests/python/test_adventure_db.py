#!/usr/bin/env python3
"""
Test script to verify adventure database functionality.
"""

import sys
import os
from pathlib import Path

# Add the project root to sys.path
project_root = Path(__file__).parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

def test_adventure_database():
    """Test that the adventure database is properly initialized and accessible."""
    print("Testing adventure database...")

    try:
        # Import the database functions
        # from lc_database import get_city_data, get_adventure_conn  # Commented out - functions not in current modular database

        # Test database connection
        conn = get_adventure_conn()
        cursor = conn.cursor()

        # Check if cities table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='cities'")
        if cursor.fetchone():
            print("✓ Cities table exists")
        else:
            print("✗ Cities table missing")
            return False

        # Check if other required tables exist
        required_tables = ['resources', 'villagers', 'adventurers', 'guards', 'adventurer_classes']
        for table in required_tables:
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,))
            if cursor.fetchone():
                print(f"✓ {table} table exists")
            else:
                print(f"✗ {table} table missing")
                return False

        conn.close()

        # Test get_city_data function with a dummy user ID
        print("\nTesting get_city_data function...")
        try:
            # This should create a new city for the dummy user
            city_data = get_city_data("test-user-123")
            print("✓ get_city_data function works")
            print(f"  Created city with ID: {city_data['id']}")
            print(f"  City name: {city_data['name']}")
            print(f"  Resources: {city_data['resources']}")
            print(f"  Villagers: {len(city_data['villagers'])}")
        except Exception as e:
            print(f"✗ get_city_data function failed: {str(e)}")
            return False

        print("\n✓ All adventure database tests passed!")
        return True

    except ImportError as e:
        print(f"✗ Import error: {str(e)}")
        return False
    except Exception as e:
        print(f"✗ Unexpected error: {str(e)}")
        return False

if __name__ == '__main__':
    success = test_adventure_database()
    sys.exit(0 if success else 1)