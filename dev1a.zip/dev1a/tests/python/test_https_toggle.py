#!/usr/bin/env python3
"""
Test script to demonstrate HTTPS/HTTP toggle functionality.
"""

import os
import sys
from pathlib import Path

# Add the project root to sys.path
project_root = Path(__file__).parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

def test_config():
    """Test the configuration loading."""
    print("Testing HTTPS/HTTP configuration...")

    # Test default values
    print("\n1. Testing default configuration:")
    from lc_config import USE_HTTPS, SERVER_PORT
    print(f"   USE_HTTPS: {USE_HTTPS}")
    print(f"   SERVER_PORT: {SERVER_PORT}")

    # Test with environment variables
    print("\n2. Testing with environment variables:")

    # Set environment variables
    os.environ['FLASKLANCHAT_HTTPS'] = 'false'
    os.environ['FLASKLANCHAT_PORT'] = '8080'

    # Reload the module to pick up new env vars
    import importlib
    import lc_config
    importlib.reload(lc_config)

    print(f"   USE_HTTPS: {lc_config.USE_HTTPS}")
    print(f"   SERVER_PORT: {lc_config.SERVER_PORT}")

    # Test HTTPS enabled
    print("\n3. Testing HTTPS enabled:")
    os.environ['FLASKLANCHAT_HTTPS'] = 'true'
    os.environ['FLASKLANCHAT_PORT'] = '6969'
    importlib.reload(lc_config)

    print(f"   USE_HTTPS: {lc_config.USE_HTTPS}")
    print(f"   SERVER_PORT: {lc_config.SERVER_PORT}")

    print("\n✅ Configuration test completed!")
    print("\nUsage examples:")
    print("  # Run with HTTP on port 8080:")
    print("  FLASKLANCHAT_HTTPS=false FLASKLANCHAT_PORT=8080 python server_v5.py")
    print("")
    print("  # Run with HTTPS on port 6969 (default):")
    print("  python server_v5.py")
    print("")
    print("  # Run with HTTPS on custom port:")
    print("  FLASKLANCHAT_HTTPS=true FLASKLANCHAT_PORT=8443 python server_v5.py")

if __name__ == '__main__':
    test_config()