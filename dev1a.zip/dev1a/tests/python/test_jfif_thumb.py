#!/usr/bin/env python3
"""
Test script to manually test thumbnail generation on JFIF files
"""

import sys
import os
from pathlib import Path
from PIL import Image
from lc_routes_refactor.utility_functions import generate_thumbnail



def test_jfif_thumbnail():
    """Test thumbnail generation on a JFIF file"""

    # Test on one of the problematic JFIF files
    source_file = "static/uploads/GujXii3WAAEDY1p_20250912_005223.jfif"
    thumb_file = "static/thumbnails/uploads/test_thumb.jpg"

    print(f"Testing thumbnail generation:")
    print(f"Source: {source_file}")
    print(f"Thumbnail: {thumb_file}")

    if not os.path.exists(source_file):
        print(f"ERROR: Source file does not exist: {source_file}")
        return False

    print(f"Source file exists, size: {os.path.getsize(source_file)} bytes")

    try:
        result = generate_thumbnail(source_file, thumb_file)
        print(f"generate_thumbnail returned: {result}")

        if result and os.path.exists(thumb_file):
            size = os.path.getsize(thumb_file)
            print(f"Thumbnail created successfully, size: {size} bytes")
            return True
        else:
            print("Thumbnail generation failed or file not created")
            return False

    except Exception as e:
        print(f"Exception during thumbnail generation: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_jfif_thumbnail()
    print(f"\nTest result: {'PASS' if success else 'FAIL'}")