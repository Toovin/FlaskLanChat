#!/usr/bin/env python3
"""
Test script to verify the database manager separation works correctly.
"""

import sys
import os
from pathlib import Path

# Add the project root to sys.path
project_root = Path(__file__).parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

def test_database_separation():
    """Test that the database managers work correctly and are properly separated."""
    print("Testing database manager separation...")

    try:
        # Import the database managers
        from main_db_manager import MainDatabaseManager
        from adventure_db_manager import AdventureDatabaseManager

        # Create instances
        main_db = MainDatabaseManager()
        adventure_db = AdventureDatabaseManager()

        print("✓ Database managers imported successfully")

        # Test main database initialization
        print("\n1. Testing main database...")
        main_db.initialize_database()

        # Verify main database tables exist
        main_tables = ['users', 'channels', 'messages', 'reactions', 'folders', 'file_folders']
        for table in main_tables:
            if main_db.table_exists(table):
                print(f"   ✓ {table} table exists")
            else:
                print(f"   ✗ {table} table missing")
                return False

        # Test adventure database initialization
        print("\n2. Testing adventure database...")
        adventure_db.initialize_database()

        # Verify adventure database tables exist
        adventure_tables = ['cities', 'resources', 'villagers', 'adventurers', 'guards', 'adventurer_classes']
        for table in adventure_tables:
            if adventure_db.table_exists(table):
                print(f"   ✓ {table} table exists")
            else:
                print(f"   ✗ {table} table missing")
                return False

        # Test cross-database isolation
        print("\n3. Testing database isolation...")

        # Create a test user in main database
        test_user = "test_user_123"
        success = main_db.create_user(test_user, "test_password", "test_avatar.png")
        if success:
            print("   ✓ User created in main database")
        else:
            print("   ✗ Failed to create user in main database")
            return False

        # Verify user exists in main database
        user_data = main_db.get_user_by_username(test_user)
        if user_data:
            print("   ✓ User data retrieved from main database")
        else:
            print("   ✗ User data not found in main database")
            return False

        # Verify user does NOT exist in adventure database
        city_data = adventure_db.get_city_data(test_user)
        if city_data:
            print("   ✓ City data found in adventure database (expected)")
        else:
            print("   ✗ City data not found in adventure database (this is expected for new users)")

        # Test adventure database functionality
        print("\n4. Testing adventure database functionality...")

        # Get city data (should create a new city)
        city_data = adventure_db.get_city_data(test_user)
        if city_data:
            print("   ✓ City data retrieved/created successfully")
            print(f"      City ID: {city_data['id']}")
            print(f"      City Name: {city_data['name']}")
            print(f"      Resources: {city_data['resources']}")
            print(f"      Villagers: {len(city_data['villagers'])}")
        else:
            print("   ✗ Failed to get/create city data")
            return False

        # Test unit recruitment
        recruit_result = adventure_db.recruit_unit(test_user, 'villager')
        if recruit_result['success']:
            print("   ✓ Villager recruitment successful")
        else:
            print(f"   ✗ Villager recruitment failed: {recruit_result['message']}")
            return False

        # Test task assignment
        if city_data['villagers']:
            villager_id = city_data['villagers'][0]['id']
            task_result = adventure_db.assign_villager_task(test_user, villager_id, 'wood')
            if task_result['success']:
                print("   ✓ Villager task assignment successful")
            else:
                print(f"   ✗ Villager task assignment failed: {task_result['message']}")
                return False

        # Test city statistics
        stats = adventure_db.get_city_stats(test_user)
        if stats:
            print("   ✓ City statistics retrieved successfully")
            print(f"      Population: {stats['population']['total']}")
            print(f"      Military Power: {stats['military_power']}")
        else:
            print("   ✗ Failed to get city statistics")
            return False

        print("\n✅ All database manager tests passed!")
        print("\n📊 Database Separation Summary:")
        print("   • Main Database (devchat.db): User management, chat, file sharing")
        print("   • Adventure Database (dev-adventure.db): City management, units, resources")
        print("   • Complete isolation between systems")
        print("   • Independent initialization and management")

        return True

    except ImportError as e:
        print(f"✗ Import error: {e}")
        return False
    except Exception as e:
        print(f"✗ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    success = test_database_separation()
    sys.exit(0 if success else 1)