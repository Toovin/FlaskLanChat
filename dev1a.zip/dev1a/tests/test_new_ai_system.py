#!/usr/bin/env python3
"""
Test script for the new modular AI system
"""

import sys
import os

# Add current directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_imports():
    """Test that all modules can be imported"""
    print("Testing imports...")

    try:
        from ai_engine import ai_engine, StructuredResponse
        print("✓ ai_engine imported successfully")
    except ImportError as e:
        print(f"✗ Failed to import ai_engine: {e}")
        return False

    try:
        from ai_characters import character_manager
        print("✓ ai_characters imported successfully")
    except ImportError as e:
        print(f"✗ Failed to import ai_characters: {e}")
        return False

    try:
        from ai_context import context_manager
        print("✓ ai_context imported successfully")
    except ImportError as e:
        print(f"✗ Failed to import ai_context: {e}")
        return False

    try:
        from ai_database import ai_database
        print("✓ ai_database imported successfully")
    except ImportError as e:
        print(f"✗ Failed to import ai_database: {e}")
        return False

    try:
        from ai_modal import ai_modal
        print("✓ ai_modal imported successfully")
    except ImportError as e:
        print(f"✗ Failed to import ai_modal: {e}")
        return False

    return True

def test_database():
    """Test database initialization"""
    print("\nTesting database...")

    try:
        from ai_database import ai_database

        # Initialize tables
        ai_database.init_tables()
        print("✓ Database tables initialized")

        # Test character operations
        test_user = "test_user_123"

        # Create test character
        character_data = {
            'character_name': 'TestBot',
            'character_description': 'A test AI character',
            'ai_temperature': 0.8,
            'ai_system_prompt': 'You are a helpful test bot.'
        }

        char_id = ai_database.save_character(test_user, character_data)
        if char_id:
            print("✓ Character created successfully")
        else:
            print("✗ Failed to create character")
            return False

        # Get character
        character = ai_database.get_character(test_user, 'TestBot')
        if character and character['character_name'] == 'TestBot':
            print("✓ Character retrieved successfully")
        else:
            print("✗ Failed to retrieve character")
            return False

        # Test context operations
        conversation_key = "test:conversation:123"

        # Save context messages
        success1 = ai_database.save_context_message(conversation_key, "user", "Hello")
        success2 = ai_database.save_context_message(conversation_key, "assistant", "Hi there!")

        if success1 and success2:
            print("✓ Context messages saved successfully")
        else:
            print("✗ Failed to save context messages")
            return False

        # Get context
        messages = ai_database.get_context_messages(conversation_key, limit=10)
        if len(messages) >= 2:
            print("✓ Context messages retrieved successfully")
        else:
            print("✗ Failed to retrieve context messages")
            return False

        return True

    except Exception as e:
        print(f"✗ Database test failed: {str(e)}")
        return False

def test_ai_engine():
    """Test AI engine functionality"""
    print("\nTesting AI engine...")

    try:
        # Test structured response creation
        from ai_engine import StructuredResponse

        # Mock response data
        mock_data = {
            'choices': [{
                'message': {
                    'content': '{"response": "Hello!", "character_name": "TestBot", "mood": "happy"}'
                }
            }]
        }

        response = StructuredResponse(mock_data)
        if response.is_structured and response.structured_data:
            print("✓ Structured response parsing works")
            mood = response.get_field('mood')
            if mood == 'happy':
                print("✓ Field extraction works")
            else:
                print("✗ Field extraction failed")
                return False
        else:
            print("✗ Structured response parsing failed")
            return False

        return True

    except Exception as e:
        print(f"✗ AI engine test failed: {str(e)}")
        return False

def test_context_manager():
    """Test context management"""
    print("\nTesting context manager...")

    try:
        from ai_context import context_manager

        # Test conversation key generation
        key1 = context_manager.get_conversation_key("user123", "modal", character_name="Bot")
        key2 = context_manager.get_conversation_key("user123", "channel", channel_id="general")

        if "modal:user123:Bot" in key1 and "channel:general" in key2:
            print("✓ Conversation key generation works")
        else:
            print("✗ Conversation key generation failed")
            return False

        # Test context operations
        conversation_key = "test:context:manager"

        success1 = context_manager.add_user_message(conversation_key, "Test message")
        success2 = context_manager.add_assistant_message(conversation_key, "Test response")

        if success1 and success2:
            print("✓ Context message saving works")
        else:
            print("✗ Context message saving failed")
            return False

        # Get context
        messages = context_manager.get_recent_context(conversation_key)
        if len(messages) >= 2:
            print("✓ Context retrieval works")
        else:
            print("✗ Context retrieval failed")
            return False

        return True

    except Exception as e:
        print(f"✗ Context manager test failed: {str(e)}")
        return False

def test_character_manager():
    """Test character management"""
    print("\nTesting character manager...")

    try:
        from ai_characters import character_manager

        test_user = "test_char_user"

        # Create character
        character_data = {
            'character_name': 'CharTestBot',
            'character_description': 'Test character for manager',
            'ai_temperature': 0.9,
            'ai_system_prompt': 'You are a test character.'
        }

        success = character_manager.create_character(test_user, character_data)
        if success:
            print("✓ Character creation via manager works")
        else:
            print("✗ Character creation via manager failed")
            return False

        # Get characters
        characters = character_manager.get_user_characters(test_user)
        if len(characters) > 0 and characters[0]['character_name'] == 'CharTestBot':
            print("✓ Character retrieval via manager works")
        else:
            print("✗ Character retrieval via manager failed")
            return False

        # Set active character
        success = character_manager.set_active_character(test_user, 'CharTestBot')
        if success:
            print("✓ Active character setting works")
        else:
            print("✗ Active character setting failed")
            return False

        # Get active character
        active = character_manager.get_active_character(test_user)
        if active and active['character_name'] == 'CharTestBot':
            print("✓ Active character retrieval works")
        else:
            print("✗ Active character retrieval failed")
            return False

        return True

    except Exception as e:
        print(f"✗ Character manager test failed: {str(e)}")
        return False

def test_modal_interface():
    """Test modal interface"""
    print("\nTesting modal interface...")

    try:
        from ai_modal import ai_modal

        # Test character operations through modal
        test_user = "test_modal_user"

        characters = ai_modal.get_characters(test_user)
        print(f"✓ Modal can retrieve characters (found {len(characters)})")

        # Test character creation through modal
        character_data = {
            'character_name': 'ModalTestBot',
            'character_description': 'Created via modal interface',
            'ai_temperature': 0.7,
            'ai_system_prompt': 'You are a modal test bot.'
        }

        success = ai_modal.create_character(test_user, character_data)
        if success:
            print("✓ Modal character creation works")
        else:
            print("✗ Modal character creation failed")
            return False

        return True

    except Exception as e:
        print(f"✗ Modal interface test failed: {str(e)}")
        return False

def main():
    """Run all tests"""
    print("🧪 Testing New Modular AI System")
    print("=" * 50)

    tests = [
        ("Imports", test_imports),
        ("Database", test_database),
        ("AI Engine", test_ai_engine),
        ("Context Manager", test_context_manager),
        ("Character Manager", test_character_manager),
        ("Modal Interface", test_modal_interface),
    ]

    passed = 0
    total = len(tests)

    for test_name, test_func in tests:
        try:
            if test_func():
                passed += 1
                print(f"✅ {test_name}: PASSED")
            else:
                print(f"❌ {test_name}: FAILED")
        except Exception as e:
            print(f"❌ {test_name}: ERROR - {str(e)}")

    print("\n" + "=" * 50)
    print(f"📊 Test Results: {passed}/{total} tests passed")

    if passed == total:
        print("🎉 All tests passed! The modular AI system is ready.")
        return True
    else:
        print("⚠️  Some tests failed. Please check the implementation.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)