#!/usr/bin/env python3
"""
Test script for the simple AI system
"""

import requests
import json

def test_direct_api():
    """Test direct API call to LM Studio"""
    url = "http://127.0.0.1:1234/v1/chat/completions"
    payload = {
        "model": "auto",
        "messages": [{"role": "user", "content": "Hello, who are you?"}],
        "temperature": 0.7,
        "max_tokens": 100
    }

    try:
        response = requests.post(url, json=payload, timeout=10)
        print(f"Status: {response.status_code}")
        print(f"Response: {response.text}")
        return response.status_code == 200
    except Exception as e:
        print(f"Error: {e}")
        return False

def test_simple_system():
    """Test the simple AI system"""
    try:
        from ai_system_simple import generate_ai_response
        response = generate_ai_response("Hello, who are you?")
        print(f"Simple system response: {response}")
        return response is not None
    except Exception as e:
        print(f"Simple system error: {e}")
        return False

def test_gurb_character():
    """Test GURB character"""
    try:
        from ai_system_simple import generate_ai_response
        response = generate_ai_response("Hello GURB!", character_name="GURB")
        print(f"GURB response: {response}")
        return response is not None and "GURB" in response
    except Exception as e:
        print(f"GURB test error: {e}")
        return False

if __name__ == "__main__":
    print("Testing AI system...")

    print("\n1. Testing direct API:")
    api_ok = test_direct_api()

    print("\n2. Testing simple system:")
    simple_ok = test_simple_system()

    print("\n3. Testing GURB character:")
    gurb_ok = test_gurb_character()

    print("\nResults:")
    print(f"API: {'✓' if api_ok else '✗'}")
    print(f"Simple: {'✓' if simple_ok else '✗'}")
    print(f"GURB: {'✓' if gurb_ok else '✗'}")