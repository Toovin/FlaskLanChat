console.log('🧪 Testing Unified Settings Manager');

function testCursorSettings() {
    console.log('\n📋 Test 1: Cursor Settings');
    
    if (!window.unifiedSettingsManager) {
        console.error('❌ unifiedSettingsManager not found');
        return false;
    }
    
    console.log('Testing cursor size...');
    window.unifiedSettingsManager.setSetting('cursor_size', 32);
    const cursorSize = window.unifiedSettingsManager.getSetting('cursor_size');
    if (cursorSize !== 32) {
        console.error('❌ Cursor size not set correctly:', cursorSize);
        return false;
    }
    console.log('✅ Cursor size set correctly:', cursorSize);
    
    console.log('Testing cursor main...');
    window.unifiedSettingsManager.setSetting('cursor_main', 'default');
    const cursorMain = window.unifiedSettingsManager.getSetting('cursor_main');
    if (cursorMain !== 'default') {
        console.error('❌ Cursor main not set correctly:', cursorMain);
        return false;
    }
    console.log('✅ Cursor main set correctly:', cursorMain);
    
    console.log('Testing cursor glow...');
    window.unifiedSettingsManager.setSetting('cursor_glow', true);
    const cursorGlow = window.unifiedSettingsManager.getSetting('cursor_glow');
    if (cursorGlow !== true) {
        console.error('❌ Cursor glow not set correctly:', cursorGlow);
        return false;
    }
    console.log('✅ Cursor glow set correctly:', cursorGlow);
    
    console.log('Testing cursor effect...');
    window.unifiedSettingsManager.setSetting('cursor_effect', 'orbiting');
    const cursorEffect = window.unifiedSettingsManager.getSetting('cursor_effect');
    if (cursorEffect !== 'orbiting') {
        console.error('❌ Cursor effect not set correctly:', cursorEffect);
        return false;
    }
    console.log('✅ Cursor effect set correctly:', cursorEffect);
    
    return true;
}

function testParticleSettings() {
    console.log('\n📋 Test 2: Particle Settings');
    
    if (!window.unifiedSettingsManager) {
        console.error('❌ unifiedSettingsManager not found');
        return false;
    }
    
    console.log('Testing particle size...');
    window.unifiedSettingsManager.setSetting('particle_size', 1.5);
    const particleSize = window.unifiedSettingsManager.getSetting('particle_size');
    if (particleSize !== 1.5) {
        console.error('❌ Particle size not set correctly:', particleSize);
        return false;
    }
    console.log('✅ Particle size set correctly:', particleSize);
    
    console.log('Testing particle style...');
    window.unifiedSettingsManager.setSetting('particle_style', 'rainbow');
    const particleStyle = window.unifiedSettingsManager.getSetting('particle_style');
    if (particleStyle !== 'rainbow') {
        console.error('❌ Particle style not set correctly:', particleStyle);
        return false;
    }
    console.log('✅ Particle style set correctly:', particleStyle);
    
    console.log('Testing auto hide particles...');
    window.unifiedSettingsManager.setSetting('auto_hide_particles', true);
    const autoHide = window.unifiedSettingsManager.getSetting('auto_hide_particles');
    if (autoHide !== true) {
        console.error('❌ Auto hide particles not set correctly:', autoHide);
        return false;
    }
    console.log('✅ Auto hide particles set correctly:', autoHide);
    
    console.log('Testing auto hide timeout...');
    window.unifiedSettingsManager.setSetting('auto_hide_timeout', 15);
    const timeout = window.unifiedSettingsManager.getSetting('auto_hide_timeout');
    if (timeout !== 15) {
        console.error('❌ Auto hide timeout not set correctly:', timeout);
        return false;
    }
    console.log('✅ Auto hide timeout set correctly:', timeout);
    
    return true;
}

function testFontSettings() {
    console.log('\n📋 Test 3: Font Settings');
    
    if (!window.unifiedSettingsManager) {
        console.error('❌ unifiedSettingsManager not found');
        return false;
    }
    
    console.log('Testing font selection...');
    window.unifiedSettingsManager.setSetting('font', 'mono');
    const font = window.unifiedSettingsManager.getSetting('font');
    if (font !== 'mono') {
        console.error('❌ Font not set correctly:', font);
        return false;
    }
    console.log('✅ Font set correctly:', font);
    
    const fontFamily = getComputedStyle(document.documentElement).getPropertyValue('--font-family');
    console.log('Font family applied:', fontFamily);
    
    console.log('Testing font scale...');
    window.unifiedSettingsManager.setSetting('font_scale', 1.2);
    const fontScale = window.unifiedSettingsManager.getSetting('font_scale');
    if (fontScale !== 1.2) {
        console.error('❌ Font scale not set correctly:', fontScale);
        return false;
    }
    console.log('✅ Font scale set correctly:', fontScale);
    
    const scale = getComputedStyle(document.documentElement).getPropertyValue('--font-scale');
    console.log('Font scale applied:', scale);
    
    return true;
}

function testEffectsIntegration() {
    console.log('\n📋 Test 4: Effects.js Integration');
    
    if (!window.getUserSettings) {
        console.error('❌ getUserSettings not found in effects.js');
        return false;
    }
    
    const settings = window.getUserSettings();
    console.log('Current settings from effects.js:', settings);
    
    if (!settings.cursor_effect) {
        console.error('❌ cursor_effect not found in settings');
        return false;
    }
    console.log('✅ cursor_effect found:', settings.cursor_effect);
    
    if (settings.particle_size === undefined) {
        console.error('❌ particle_size not found in settings');
        return false;
    }
    console.log('✅ particle_size found:', settings.particle_size);
    
    return true;
}

function testParticleBridge() {
    console.log('\n📋 Test 5: Particle Settings Bridge');
    
    if (!window.getParticleSettings) {
        console.error('❌ getParticleSettings not found');
        return false;
    }
    
    const settings = window.getParticleSettings();
    console.log('Particle settings from bridge:', settings);
    
    if (!settings.particle_style) {
        console.error('❌ particle_style not found in bridge settings');
        return false;
    }
    console.log('✅ particle_style found:', settings.particle_style);
    
    if (settings.particle_size === undefined) {
        console.error('❌ particle_size not found in bridge settings');
        return false;
    }
    console.log('✅ particle_size found:', settings.particle_size);
    
    return true;
}

function testGlowFunction() {
    console.log('\n📋 Test 6: Cursor Glow Function');
    
    if (!window.updateCursorEffectGlow) {
        console.error('❌ updateCursorEffectGlow not found');
        return false;
    }
    console.log('✅ updateCursorEffectGlow found');
    
    try {
        window.updateCursorEffectGlow();
        console.log('✅ updateCursorEffectGlow executed without errors');
    } catch (error) {
        console.error('❌ updateCursorEffectGlow threw error:', error);
        return false;
    }
    
    return true;
}

function runAllTests() {
    console.log('🧪 Starting Unified Settings Manager Tests\n');
    
    const results = {
        cursor: testCursorSettings(),
        particle: testParticleSettings(),
        font: testFontSettings(),
        effects: testEffectsIntegration(),
        bridge: testParticleBridge(),
        glow: testGlowFunction()
    };
    
    console.log('\n📊 Test Results:');
    console.log('Cursor Settings:', results.cursor ? '✅ PASS' : '❌ FAIL');
    console.log('Particle Settings:', results.particle ? '✅ PASS' : '❌ FAIL');
    console.log('Font Settings:', results.font ? '✅ PASS' : '❌ FAIL');
    console.log('Effects Integration:', results.effects ? '✅ PASS' : '❌ FAIL');
    console.log('Particle Bridge:', results.bridge ? '✅ PASS' : '❌ FAIL');
    console.log('Glow Function:', results.glow ? '✅ PASS' : '❌ FAIL');
    
    const allPassed = Object.values(results).every(r => r === true);
    console.log('\n' + (allPassed ? '✅ All tests passed!' : '❌ Some tests failed'));
    
    return allPassed;
}

setTimeout(() => {
    runAllTests();
}, 2000);

window.testUnifiedSettings = runAllTests;
