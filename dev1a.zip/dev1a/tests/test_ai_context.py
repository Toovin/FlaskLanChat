#!/usr/bin/env python3
"""
Test script to verify AI context embedding is working
"""

import requests
import json
import time

# Server details
BASE_URL = "https://127.0.0.1:6969"
HEADERS = {'Content-Type': 'application/json'}

def test_ai_channel_message():
    """Test sending an AI message to a channel to verify context embedding"""

    # Test data - simulate a channel AI mention
    test_data = {
        'user_uuid': 'adc86468-56dc-4cdd-8a9d-2bab480f6fc0',  # From logs
        'channel': 'general',
        'message': '@ai hello, how are you?',
        'character_name': 'BUKA'
    }

    try:
        # Make the request to the AI channel mention endpoint
        response = requests.post(
            f"{BASE_URL}/ai_channel_mention",
            json=test_data,
            headers=HEADERS,
            verify=False  # Since it's HTTPS with self-signed cert
        )

        print(f"Response status: {response.status_code}")
        print(f"Response content: {response.text}")

        return response.status_code == 200

    except Exception as e:
        print(f"Error testing AI channel message: {str(e)}")
        return False

def test_ai_modal_message():
    """Test sending an AI message through the modal"""

    test_data = {
        'user_uuid': 'adc86468-56dc-4cdd-8a9d-2bab480f6fc0',
        'message': 'Hello, can you remember our previous conversation?',
        'character_name': 'BUKA'
    }

    try:
        response = requests.post(
            f"{BASE_URL}/ai_modal_message",
            json=test_data,
            headers=HEADERS,
            verify=False
        )

        print(f"Modal response status: {response.status_code}")
        print(f"Modal response content: {response.text}")

        return response.status_code == 200

    except Exception as e:
        print(f"Error testing AI modal message: {str(e)}")
        return False

if __name__ == "__main__":
    print("Testing AI context embedding...")

    print("\n1. Testing channel AI message:")
    channel_success = test_ai_channel_message()

    print("\n2. Testing modal AI message:")
    modal_success = test_ai_modal_message()

    print(f"\nResults: Channel: {'PASS' if channel_success else 'FAIL'}, Modal: {'PASS' if modal_success else 'FAIL'}")

    print("\nCheck the LLM API logs to verify context embedding is working.")