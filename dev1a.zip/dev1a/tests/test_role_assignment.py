#!/usr/bin/env python3
"""
Test script to verify AI conversation role assignment logic
"""

def test_role_assignment():
    """Test the role assignment logic for AI conversation history"""

    # Sample conversation history with character prefixes
    raw_context = [
        {"role": "user", "content": "TOOVIN TEXTREME™: hello"},
        {"role": "assistant", "content": "[Anabelle] Hi there! How can I help?"},
        {"role": "user", "content": "TOOVIN TEXTREME™: switch to GURB"},
        {"role": "assistant", "content": "[GURB] I AM HERE. WHAT DO YOU REQUIRE?"},
        {"role": "user", "content": "TOOVIN TEXTREME™: now back to Anabelle"},
    ]

    # Test with Anabelle as current character
    current_character = "Anabelle"

    context = []
    for msg in raw_context:
        processed_msg = dict(msg)  # Copy the message

        if msg['role'] == 'assistant':
            # Extract character name from content (format: "[Character] content" or just "content")
            content = msg['content']
            character_in_message = None

            if content.startswith('['):
                # Extract character name from brackets
                bracket_end = content.find(']')
                if bracket_end > 0:
                    character_in_message = content[1:bracket_end].strip()
                    # Remove the character prefix from content
                    processed_msg['content'] = content[bracket_end + 1:].strip()

            # Determine role: assistant if this character matches current, otherwise user
            if character_in_message == current_character or (character_in_message is None and current_character == "AI Assistant"):
                processed_msg['role'] = 'assistant'
            else:
                processed_msg['role'] = 'user'

        context.append(processed_msg)

    print("Testing with Anabelle as current character:")
    for msg in context:
        print(f"  {msg['role']}: {msg['content'][:50]}...")

    print("\n" + "="*50 + "\n")

    # Test with GURB as current character
    current_character = "GURB"

    context = []
    for msg in raw_context:
        processed_msg = dict(msg)  # Copy the message

        if msg['role'] == 'assistant':
            # Extract character name from content (format: "[Character] content" or just "content")
            content = msg['content']
            character_in_message = None

            if content.startswith('['):
                # Extract character name from brackets
                bracket_end = content.find(']')
                if bracket_end > 0:
                    character_in_message = content[1:bracket_end].strip()
                    # Remove the character prefix from content
                    processed_msg['content'] = content[bracket_end + 1:].strip()

            # Determine role: assistant if this character matches current, otherwise user
            if character_in_message == current_character or (character_in_message is None and current_character == "AI Assistant"):
                processed_msg['role'] = 'assistant'
            else:
                processed_msg['role'] = 'user'

        context.append(processed_msg)

    print("Testing with GURB as current character:")
    for msg in context:
        print(f"  {msg['role']}: {msg['content'][:50]}...")

if __name__ == "__main__":
    test_role_assignment()