#!/usr/bin/env python3
"""
Simple SSL certificate generator for FlaskLanChat
Creates a basic self-signed certificate for development use
"""

import ssl
import os
from datetime import datetime, timedelta

def generate_selfsigned_cert():
    """Generate a self-signed certificate for the network interfaces"""

    print("🔐 FlaskLanChat SSL Certificate Generator")
    print("=" * 50)
    print()
    print("This will generate self-signed SSL certificates for HTTPS.")
    print("Please provide the required details below.")
    print()

    # Prompt for IP addresses
    ip_input = input("Enter IP addresses (comma-separated, e.g., 192.168.1.1,10.0.0.1): ").strip()
    server_ips = [ip.strip() for ip in ip_input.split(',') if ip.strip()]

    if not server_ips:
        print("❌ No valid IP addresses provided.")
        return False

    # Prompt for certificate details
    cert_info = {}
    cert_info['country_name'] = input("Country code (e.g., US): ").strip().upper() or 'US'
    cert_info['state_or_province_name'] = input("State or Province: ").strip() or 'Unknown'
    cert_info['locality_name'] = input("Locality (City): ").strip() or 'Unknown'
    cert_info['organization_name'] = input("Organization: ").strip() or 'FlaskLanChat'
    cert_info['common_name'] = input(f"Common Name (default: {server_ips[0]}): ").strip() or server_ips[0]
    valid_days_input = input("Valid days (default: 365): ").strip()
    cert_info['valid_days'] = int(valid_days_input) if valid_days_input.isdigit() else 365

    # Build subjectAltName extension
    alt_names = ",".join(f"IP:{ip}" for ip in server_ips)

    # Create a basic certificate using OpenSSL command line
    openssl_cmd = f"""
openssl req -x509 -newkey rsa:4096 -keyout server_v7_key.pem -out server_v7_cert.pem -days {cert_info['valid_days']} -nodes -subj "/C={cert_info['country_name']}/ST={cert_info['state_or_province_name']}/L={cert_info['locality_name']}/O={cert_info['organization_name']}/CN={cert_info['common_name']}" -addext "subjectAltName={alt_names}"
"""

    try:
        # Try to run openssl command
        import subprocess
        result = subprocess.run(openssl_cmd.strip(), shell=True, capture_output=True, text=True)

        if result.returncode == 0:
            print("✅ SSL certificates generated successfully!")
            print("Certificate: server_v7_cert.pem")
            print("Private Key: server_v7_key.pem")
            print(f"Valid for IPs: {', '.join(server_ips)}")
            print(f"Expires: {datetime.now() + timedelta(days=cert_info['valid_days'])}")
            return True
        else:
            print("❌ OpenSSL command failed:")
            print(result.stderr)
            return False

    except Exception as e:
        print(f"❌ Failed to generate certificates: {e}")
        print("Please ensure OpenSSL is installed on your system.")
        return False

if __name__ == "__main__":
    success = generate_selfsigned_cert()
    if success:
        print("\n🎉 Ready for HTTPS! Run your server with:")
        print("python server_v7.py")
    else:
        print("\n❌ Certificate generation failed.")
        print("Make sure OpenSSL is installed and available in your PATH.")