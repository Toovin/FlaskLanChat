from database import init_db, save_user, get_user_by_username
import uuid

def create_admin_user():
    """Create a default admin user if it doesn't exist"""
    admin_username = "admin"
    admin_password = "admin123"  # Change this!

    try:
        # Check if admin already exists
        existing = get_user_by_username(admin_username)
        if existing:
            print(f"Admin user '{admin_username}' already exists.")
            return

        # Create admin user
        admin_uuid = str(uuid.uuid4())
        save_user(admin_uuid, admin_username, admin_password, is_admin=True)
        print(f"Created admin user: {admin_username}")
        print("Default password: admin123 (CHANGE THIS IMMEDIATELY!)")

    except Exception as e:
        print(f"Error creating admin user: {e}")

if __name__ == '__main__':
    init_db()
    create_admin_user()
    print("Database initialized successfully.")