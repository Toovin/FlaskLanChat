import sys
sys.path.append('.')
from database import save_user_image_preferences

uuid = 'a5597145-55b5-4fac-aa56-27db7484df47'
preferences = {'last_sd_model': 'juggernautXL'}
result = save_user_image_preferences(uuid, preferences)
print(f'Update result: {result}')