#!/usr/bin/env python3
"""
Server Reset Script for FlaskLanChat

This script resets the server to a clean, default state by:
- Clearing all user uploads
- Clearing all thumbnails
- Clearing all user avatars
- Clearing all media downloads
- Clearing all fileshare content
- Deleting the chat database

After running this script, you will need to run the setup scripts again.
"""

import os
import shutil
import sys

def get_confirmation(prompt):
    """Get yes/no confirmation from user."""
    while True:
        response = input(prompt).strip().lower()
        if response in ['y', 'yes']:
            return True
        elif response in ['n', 'no']:
            return False
        else:
            print("Please enter 'y' for yes or 'n' for no.")

def clear_directory(dir_path):
    """Clear all contents of a directory."""
    if os.path.exists(dir_path):
        print(f"Clearing directory: {dir_path}")
        try:
            # Remove all files and subdirectories
            for filename in os.listdir(dir_path):
                file_path = os.path.join(dir_path, filename)
                try:
                    if os.path.isfile(file_path) or os.path.islink(file_path):
                        os.unlink(file_path)
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                except Exception as e:
                    print(f"Failed to delete {file_path}: {e}")
        except Exception as e:
            print(f"Error clearing directory {dir_path}: {e}")
    else:
        print(f"Directory does not exist: {dir_path}")

def delete_file(file_path):
    """Delete a file if it exists."""
    if os.path.exists(file_path):
        print(f"Deleting file: {file_path}")
        try:
            os.remove(file_path)
        except Exception as e:
            print(f"Error deleting file {file_path}: {e}")
    else:
        print(f"File does not exist: {file_path}")

def main():
    print("=" * 60)
    print("FLASKLANCHAT SERVER RESET SCRIPT")
    print("=" * 60)
    print()
    print("WARNING: This will permanently delete ALL server data including:")
    print("- User accounts and settings")
    print("- All chat messages and channels")
    print("- All uploaded files and media")
    print("- All user avatars and thumbnails")
    print("- All fileshare content")
    print("- All adventure/city management data")
    print()
    print("After this reset, you will need to run the setup scripts again.")
    print()

    # First confirmation
    if not get_confirmation("THIS IS THE SERVER RESET SCRIPT. THIS WILL RETURN THE SERVER TO A CLEAN FRESH STATE. CONTINUE? (y/n) "):
        print("Reset cancelled.")
        sys.exit(0)

    print()

    # Second confirmation
    if not get_confirmation("YOU SELECTED YES TO CONTINUE RESETING THE SERVER. LAST CHANCE TO STOP! CONTINUE? (y/n) "):
        print("Reset cancelled.")
        sys.exit(0)

    print()
    print("Starting server reset...")
    print()

    # Directories to clear
    directories_to_clear = [
        'static/uploads',                    # User uploads
        'static/thumbnails/uploads',         # Upload thumbnails
        'static/user_avatars',               # User avatars
        'static/media_downloaded',           # Downloaded media
        'static/thumbnails/media_downloaded', # Media thumbnails
        'file_share_system',                # Fileshare content
        'sessions'                          # Session files
    ]

    # Files to delete
    files_to_delete = [
        'devchat.db',                        # Main database
        'dev-adventure.db'                   # Adventure database
    ]

    # Clear directories
    for dir_path in directories_to_clear:
        clear_directory(dir_path)

    # Delete files
    for file_path in files_to_delete:
        delete_file(file_path)

    print()
    print("Server reset completed!")
    print()
    print("Next steps:")
    print("1. Run 'python init_db.py' to initialize the database")
    print("2. Run 'python generate_cert.py' to generate SSL certificates")
    print("3. Start the server with 'python server_v7_b.py'")
    print()
    print("The server is now in a clean state.")

if __name__ == "__main__":
    main()