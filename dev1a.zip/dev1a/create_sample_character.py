#!/usr/bin/env python3
"""
Create a sample AI character with avatar for testing
"""

import sys
import os
import base64

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ai_database import ai_database

def create_sample_character():
    """Create a sample character with avatar"""

    # Sample character data
    character_data = {
        'character_name': 'SampleBot',
        'character_description': 'A friendly sample AI character for testing avatar functionality',
        'ai_temperature': 0.8,
        'ai_max_tokens': 2048,
        'ai_system_prompt': 'You are SampleBot, a friendly AI assistant. You help users test the AI character system and provide helpful responses.',
        'ai_custom_instructions': 'Always be helpful and mention that you are a sample character.',
        'is_public': 0,
        'is_active': 0
    }

    # Use a default avatar (base64 encoded smile_1.png)
    try:
        avatar_path = os.path.join('static', 'default_avatars', 'smile_1.png')
        if os.path.exists(avatar_path):
            with open(avatar_path, 'rb') as f:
                avatar_data = f.read()
                avatar_b64 = base64.b64encode(avatar_data).decode('utf-8')
                character_data['avatar'] = f"data:image/png;base64,{avatar_b64}"
                character_data['avatar_filename'] = 'smile_1.png'
        else:
            print("Warning: Default avatar not found, using URL")
            character_data['avatar_url'] = '/static/default_avatars/smile_1.png'
    except Exception as e:
        print(f"Error loading avatar: {e}")
        character_data['avatar_url'] = '/static/default_avatars/smile_1.png'

    # Create character for a test user
    test_user_uuid = "sample-user-uuid"

    character_data['character_name'] = 'SampleBot'
    result = ai_database.save_character(test_user_uuid, character_data)

    if result:
        print("✅ Sample character 'SampleBot' created successfully!")
        print("Character includes avatar and is ready for testing.")
    else:
        print("❌ Failed to create sample character")

if __name__ == "__main__":
    create_sample_character()