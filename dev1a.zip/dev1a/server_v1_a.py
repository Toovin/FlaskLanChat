from flask import Flask, redirect, request
from flask_socketio import SocketIO
from lc_config import UPLOAD_DIR, AVATAR_DIR, DEFAULT_AVATAR_DIR, EXTENSIONS_DIR, MEDIA_DOWNLOAD_DIR, THUMBNAILS_DIR, THUMBNAILS_MEDIA_DOWNLOADED_DIR, USE_HTTPS, SERVER_PORT, CHAT_DB_NAME
from database.database_init import init_db
from database import load_users, save_user, get_user_by_username, load_channels, load_media_channels
from ai_database import ai_database
from lc_routes_refactor import register_routes
from lc_socket_handlers_refactor import register_socket_handlers
from lc_command_processor import CommandProcessor
from ai_config import ai_config

import os
import yt_dlp

# Set default file size limit if not already set
if 'FLASKLANCHAT_MAX_FILE_SIZE' not in os.environ:
    os.environ['FLASKLANCHAT_MAX_FILE_SIZE'] = '0'  # No limit for LAN

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24).hex()
app.config['SESSION_COOKIE_SECURE'] = USE_HTTPS  # Require HTTPS for cookies only if using HTTPS
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'None' if USE_HTTPS else 'Lax'
app.config['SESSION_COOKIE_PATH'] = '/'  # Ensure cookie is available for all paths
app.config['PERMANENT_SESSION_LIFETIME'] = 3600  # 1 hour session lifetime
app.config['SESSION_REFRESH_EACH_REQUEST'] = True  # Refresh session on each request
# app.config['SESSION_TYPE'] = 'filesystem'  # Use filesystem for session storage
# app.config['SESSION_FILE_DIR'] = './sessions'  # Directory for session files
app.config['SESSION_PERMANENT'] = True  # Make sessions permanent
socketio = SocketIO(app,
                    cors_allowed_origins="*",
                    engineio_logger=False,
                    manage_session=True,
                    ping_timeout=300,  # 5 minutes ping timeout
                    ping_interval=0,  # Disable server ping
                    max_http_buffer_size=100000000,  # 100MB max buffer
                    async_mode='threading')

if USE_HTTPS:
    @app.before_request
    def redirect_to_https():
        """Redirect HTTP requests to HTTPS to ensure all clients use secure protocol"""
        if not request.is_secure and request.headers.get('X-Forwarded-Proto', 'http') != 'https':
            url = request.url.replace('http://', 'https://', 1)
            return redirect(url, code=301)

# Ensure directories exist
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(AVATAR_DIR, exist_ok=True)
os.makedirs(DEFAULT_AVATAR_DIR, exist_ok=True)
os.makedirs(EXTENSIONS_DIR, exist_ok=True)
os.makedirs(MEDIA_DOWNLOAD_DIR, exist_ok=True)
os.makedirs(THUMBNAILS_DIR, exist_ok=True)
os.makedirs(THUMBNAILS_MEDIA_DOWNLOADED_DIR, exist_ok=True)
os.makedirs('./sessions', exist_ok=True)  # Flask session directory


# Initialize database and load data
init_db()

# Initialize AI tables
print("Initializing AI database tables...")
ai_database.init_tables()

# Initialize AI configuration
print("Initializing AI configuration...")
ai_config.load_from_database()
if not ai_config.validate_endpoint():
    print("Warning: AI endpoint is not reachable. Please check your LM Studio configuration.")
else:
    print(f"AI endpoint validated: {ai_config.endpoint_url}")

# Create default admin user if it doesn't exist
def create_admin_user():
    """Create a default admin user if it doesn't exist"""
    admin_username = "admin"
    admin_password = "admin123"

    try:
        # Check if admin already exists
        existing = get_user_by_username(admin_username)
        if existing:
            print(f"Admin user '{admin_username}' already exists.")
            return

        # Create admin user
        import uuid
        admin_uuid = str(uuid.uuid4())
        save_user(admin_uuid, admin_username, admin_password, is_admin=True)
        print(f"Created admin user: {admin_username}")
        print("Default password: admin123 (CHANGE THIS IMMEDIATELY!)")

    except Exception as e:
        print(f"Error creating admin user: {e}")

create_admin_user()

users_db = load_users()
channels = load_channels()
media_channels = load_media_channels()

# Initialize command processor
command_processor = CommandProcessor(socketio, users_db)

# Register routes and socket handlers
register_routes(app, socketio, users_db)
register_socket_handlers(socketio, app, users_db, channels, media_channels, command_processor)

if __name__ == '__main__':
    protocol = "HTTPS" if USE_HTTPS else "HTTP"
    print(f"Starting {protocol} server on port {SERVER_PORT}...")

    ssl_context = ('server_v1_cert.pem', 'server_v1_key.pem') if USE_HTTPS else None

    socketio.run(app,
                  host='0.0.0.0',
                  port=SERVER_PORT,
                  debug=False,
                  allow_unsafe_werkzeug=True,
                  use_reloader=False,
                  ssl_context=ssl_context)