# FlaskLanChat AI Modal System - Integration Guide

## Overview

The FlaskLanChat AI Modal System has been completely rebuilt as a modular, structured-output AI system. This new architecture provides clean separation of concerns, consistent character responses, and efficient context management.

## Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   AI Modal UI   │────│ Character Mgmt  │────│   Database      │
│                 │    │                 │    │                 │
│ - Event handling│    │ - CRUD ops      │    │ - Queries       │
│ - UI state      │    │ - Selection     │    │ - Migrations    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         └───────────────────────┼───────────────────────┘
                                 │
                    ┌─────────────────┐    ┌─────────────────┐
                    │ AI Context     │────│ AI Engine       │
                    │                 │    │                 │
                    │ - Message store │    │ - LLM calls     │
                    │ - Context build │    │ - Config        │
                    └─────────────────┘    └─────────────────┘
```

## Key Features

### ✅ Structured Character Responses
Characters now respond with consistent JSON format:
```json
{
  "character_name": "GURB",
  "response": "*COSMIC ENERGY SURGES* I am GURB, the Unstoppable Force!",
  "actions": ["summons_energy", "flexes_powerfully"],
  "mood": "omnipotent"
}
```

### ✅ Inference-Only Context
Only stores messages needed for AI inference, not full chat history. Automatic pruning for database efficiency.

### ✅ Zero External Dependencies
Uses built-in Python + LM Studio capabilities for maximum compatibility.

### ✅ LM Studio Structured Output
Leverages JSON schema enforcement for consistent character responses.

## Files Overview

### Core Modules
- `ai_engine.py` - Structured output AI generation with LM Studio integration
- `ai_characters.py` - Character CRUD operations and management
- `ai_context.py` - Inference-only message storage and context building
- `ai_database.py` - Unified database abstraction layer
- `ai_modal.py` - Clean modal interface orchestrating all components
- `ai_socket_handlers.py` - New event handlers for real-time communication

### Client-Side
- `static/ai-modal-orchestrator-new.js` - Updated modal orchestrator
- `static/ai-character-manager.js` - Character management (already compatible)
- `static/ai-message-handler.js` - Updated message handling

## Socket Events

### Client → Server
- `ai_modal_send` - Send message to AI
  ```javascript
  socket.emit('ai_modal_send', {
    message: "Hello AI!",
    character_name: "BotName",
    conversation_key: "modal_1234567890_abc123",
    image_data: "data:image/png;base64,..."
  });
  ```

- `ai_get_characters` - Get user's characters
- `ai_create_character` - Create new character
- `ai_update_character` - Update existing character
- `ai_delete_character` - Delete character
- `ai_set_active_character` - Set active character
- `ai_get_active_character` - Get active character
- `ai_analyze_document` - Analyze document/text
- `ai_analyze_image` - Analyze image
- `ai_clear_conversation` - Clear conversation context

### Server → Client
- `ai_modal_response` - AI response
  ```javascript
  {
    response: "AI response text",
    character_name: "BotName",
    mood: "happy",
    actions: ["action1", "action2"]
  }
  ```

- `ai_characters_list` - Character list
- `ai_character_created` - Character creation confirmation
- `ai_character_updated` - Character update confirmation
- `ai_character_deleted` - Character deletion confirmation
- `ai_active_character_set` - Active character set
- `ai_active_character_data` - Active character data
- `ai_document_analysis` - Document analysis result
- `ai_image_analysis` - Image analysis result
- `ai_conversation_cleared` - Conversation cleared
- `ai_error` - Error message

## API Reference

### AIModal Class

#### send_message(user_uuid, message, character_name=None, conversation_key=None, image_data=None)
Send a message to the AI system.

**Parameters:**
- `user_uuid` (str): User identifier
- `message` (str): Message text
- `character_name` (str, optional): Character to use
- `conversation_key` (str, optional): Conversation identifier
- `image_data` (str, optional): Base64 image data

**Returns:** Dict with success status and response/error

#### get_characters(user_uuid)
Get all characters for a user.

#### create_character(user_uuid, character_data)
Create a new character.

#### update_character(user_uuid, character_name, updates)
Update an existing character.

#### delete_character(user_uuid, character_name)
Delete a character.

#### set_active_character(user_uuid, character_name)
Set the active character for a user.

#### get_active_character(user_uuid)
Get the currently active character.

#### analyze_document(content, document_type='text')
Analyze a document or text content.

#### analyze_image(image_data)
Analyze an image.

#### clear_conversation(conversation_key)
Clear conversation context.

### AICharacterManager Class

#### create_character(user_uuid, character_data)
Create character with validation.

#### get_user_characters(user_uuid)
Get all user characters.

#### set_active_character(user_uuid, character_name)
Set active character.

#### get_active_character(user_uuid)
Get active character.

### AIContextManager Class

#### add_user_message(conversation_key, message)
Add user message to context.

#### add_assistant_message(conversation_key, message)
Add assistant message to context.

#### get_recent_context(conversation_key, limit=50)
Get recent conversation context.

#### get_conversation_key(user_uuid, context_type, **kwargs)
Generate conversation key.

### AIDatabase Class

#### init_tables()
Initialize AI database tables.

#### save_character(user_uuid, character_data)
Save character to database.

#### get_character(user_uuid, character_name)
Get character by name.

#### get_user_characters(user_uuid)
Get all user characters.

#### save_context_message(conversation_key, role, content)
Save context message.

#### get_context_messages(conversation_key, limit=50)
Get context messages.

## Database Schema

### ai_characters
```sql
CREATE TABLE ai_characters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_uuid TEXT NOT NULL,
    character_name TEXT NOT NULL,
    character_description TEXT,
    avatar_url TEXT,
    ai_temperature REAL DEFAULT 0.7,
    ai_max_tokens INTEGER DEFAULT 2048,
    ai_context_window INTEGER DEFAULT 4096,
    ai_history_limit INTEGER DEFAULT 50,
    ai_model TEXT DEFAULT 'default',
    ai_system_prompt TEXT,
    ai_custom_instructions TEXT,
    is_public INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(user_uuid, character_name)
);
```

### ai_context
```sql
CREATE TABLE ai_context (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_key TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    timestamp TEXT NOT NULL
);
CREATE INDEX idx_ai_context_key_timestamp ON ai_context(conversation_key, timestamp);
```

## Configuration

### LM Studio Setup
1. Install LM Studio
2. Start local server on `http://127.0.0.1:1234`
3. Load a model with JSON schema support
4. Configure character system prompts for structured output

### Character Configuration
Characters are configured with:
- `character_name`: Display name
- `character_description`: Description text
- `ai_temperature`: Response creativity (0.0-1.0)
- `ai_system_prompt`: System instructions
- `avatar_url`: Character avatar image

## Migration Notes

### From Old System
- Character data is preserved
- Conversations use new key-based system
- Socket events updated (see above)
- UI components updated for new events

### Breaking Changes
- `ai_modal_message` → `ai_modal_send`
- Message data structure changed
- Conversation management simplified
- Settings modal temporarily disabled

## Testing

Run the comprehensive test suite:
```bash
python test_new_ai_system.py
```

Run integration tests:
```bash
python test_ai_integration.py
```

## Troubleshooting

### Common Issues
1. **Database errors**: Delete `devchat.db` and restart
2. **Import errors**: Ensure all AI modules are in the same directory
3. **Socket timeouts**: Check LM Studio is running on port 1234
4. **Character not responding**: Verify JSON schema in system prompt

### Debug Mode
Set environment variables:
```bash
export AI_DEBUG=true
export AI_API_DEBUG=true
```

## Future Enhancements

- Document analysis integration
- Image analysis with vision models
- Advanced conversation threading
- Character personality templates
- Multi-modal input support
- Conversation export/import
- Character marketplace

## Support

For issues with the AI modal system:
1. Check test suite passes: `python test_new_ai_system.py`
2. Verify LM Studio configuration
3. Check browser console for JavaScript errors
4. Review server logs for backend errors

The modular design makes it easy to extend and customize the AI system for specific use cases.