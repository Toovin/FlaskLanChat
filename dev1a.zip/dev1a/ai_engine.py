"""
AI Engine Module - Core AI functionality with structured output support
"""

import requests
import json
from typing import Dict, List, Optional, Any, Union
from ai_config import ai_config, API_DEBUG


class StructuredResponse:
    """Container for structured AI responses"""

    def __init__(self, response_data: Dict[str, Any]):
        self.raw_response = response_data
        self.content = self._extract_content()
        self.structured_data = self._extract_structured_data()

    def _extract_content(self) -> str:
        """Extract text content from LM Studio response"""
        try:
            # Handle /v1/chat/completions format
            if 'choices' in self.raw_response and self.raw_response['choices']:
                choice = self.raw_response['choices'][0]
                if 'message' in choice and 'content' in choice['message']:
                    content = choice['message']['content']
                elif 'text' in choice:
                    content = choice['text']
                else:
                    return ""

            # Handle /v1/responses format
            elif 'output' in self.raw_response:
                for item in self.raw_response['output']:
                    if item.get('type') == 'message' and item.get('content'):
                        for content_item in item['content']:
                            if content_item.get('type') == 'output_text':
                                content = content_item['text']
                                break
                        else:
                            continue
                        break
                else:
                    return ""
            else:
                return ""

            # If content is JSON and has a 'response' field, extract it
            content = content.strip()
            if content.startswith('{') and content.endswith('}'):
                try:
                    parsed = json.loads(content)
                    if 'response' in parsed:
                        return parsed['response']
                except json.JSONDecodeError:
                    pass

            return content
        except Exception as e:
            print(f"Error extracting content: {str(e)}")
            return ""

    def _extract_structured_data(self) -> Optional[Dict[str, Any]]:
        """Extract structured JSON data if present"""
        try:
            content = self.content.strip()
            if content.startswith('{') and content.endswith('}'):
                return json.loads(content)
            return None
        except json.JSONDecodeError:
            return None

    @property
    def is_structured(self) -> bool:
        """Check if response contains structured data"""
        return self.structured_data is not None

    def get_field(self, field_name: str, default=None):
        """Get a field from structured data"""
        if self.structured_data and field_name in self.structured_data:
            return self.structured_data[field_name]
        return default


class AIEngine:
    """
    Core AI engine with structured output support
    """

    def __init__(self):
        self.config = ai_config
        # Predefined structured output schemas
        self.schemas = {
            "character_response": {
                "name": "character_response",
                "strict": True,
                "schema": {
                    "type": "object",
                    "properties": {
                        "response": {"type": "string"},
                        "character_name": {"type": "string"},
                        "actions": {"type": "array", "items": {"type": "string"}},
                        "mood": {"type": "string"},
                        "emotional_state": {"type": "string"},
                        "intent": {"type": "string"}
                    },
                    "required": ["response", "character_name"]
                }
            },
            "conversation_analysis": {
                "name": "conversation_analysis",
                "strict": True,
                "schema": {
                    "type": "object",
                    "properties": {
                        "summary": {"type": "string"},
                        "topics": {"type": "array", "items": {"type": "string"}},
                        "sentiment": {"type": "string"},
                        "key_points": {"type": "array", "items": {"type": "string"}},
                        "action_items": {"type": "array", "items": {"type": "string"}},
                        "follow_up_questions": {"type": "array", "items": {"type": "string"}}
                    },
                    "required": ["summary", "topics"]
                }
            },
            "task_planning": {
                "name": "task_planning",
                "strict": True,
                "schema": {
                    "type": "object",
                    "properties": {
                        "tasks": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "description": {"type": "string"},
                                    "priority": {"type": "string", "enum": ["low", "medium", "high"]},
                                    "estimated_time": {"type": "string"},
                                    "dependencies": {"type": "array", "items": {"type": "string"}}
                                },
                                "required": ["description", "priority"]
                            }
                        },
                        "overall_strategy": {"type": "string"},
                        "estimated_completion": {"type": "string"}
                    },
                    "required": ["tasks"]
                }
            }
        }

        # Legacy alias
        self.default_character_schema = self.schemas["character_response"]

    def generate_response(self,
                           prompt: str,
                           system_prompt: Optional[str] = None,
                           character_name: Optional[str] = None,
                           context_messages: Optional[List[Dict]] = None,
                           structured_schema: Optional[Dict] = None,
                           response_format: Optional[str] = None,
                           model: Optional[str] = None,
                           temperature: Optional[float] = None,
                           max_tokens: Optional[int] = None,
                           image_data: Optional[str] = None,
                           tools: Optional[List[Dict]] = None) -> Optional[StructuredResponse]:
        """
        Generate AI response with optional structured output and tool calling

        Args:
            prompt: User input
            system_prompt: System instructions
            character_name: Character to use (applies default schema)
            context_messages: Previous conversation messages
            structured_schema: Custom JSON schema for structured output
            response_format: Response format type ("json_schema", "json_object", "text")
            model: AI model to use
            temperature: Creativity setting
            max_tokens: Response length limit
            image_data: Base64 encoded image
            tools: List of tool definitions for function calling

        Returns:
            StructuredResponse object or None if failed
        """

        # Build messages array
        messages = []

        # Add system message
        if system_prompt:
            messages.append({
                "role": "system",
                "content": system_prompt
            })

        # Add context messages
        if context_messages:
            messages.extend(context_messages)

        # Add user message (with image if provided)
        user_content = prompt
        if image_data:
            user_content = [
                {"type": "text", "text": prompt},
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{image_data}"}
                }
            ]

        messages.append({
            "role": "user",
            "content": user_content
        })

        # Prepare API payload
        payload = {
            "messages": messages,
            "temperature": temperature if temperature is not None else self.config.temperature,
            "max_tokens": max_tokens or self.config.max_tokens
        }

        # Only include model if specified (otherwise use currently loaded model)
        final_model = model or self.config.model
        if final_model:
            payload["model"] = final_model

        if API_DEBUG:
            print(f"[AI_ENGINE] API payload: {json.dumps(payload, indent=2)}")

        # Add structured output or tools if requested
        if response_format == "json_object":
            payload["response_format"] = {"type": "json_object"}
        elif response_format == "json_schema" or character_name or structured_schema:
            # Use structured schema output
            schema_to_use = structured_schema or self.default_character_schema
            payload["response_format"] = {
                "type": "json_schema",
                "json_schema": schema_to_use
            }
        elif tools:
            # Add tool calling support
            payload["tools"] = tools
            payload["tool_choice"] = "auto"  # Let model decide when to use tools

        # Legacy support for character_name parameter
        if character_name and not structured_schema and response_format != "json_schema":
            payload["response_format"] = {
                "type": "json_schema",
                "json_schema": self.default_character_schema
            }

        # Make API call
        try:
            response = requests.post(
                f"{self.config.endpoint_url}/v1/chat/completions",
                json=payload,
                headers=self.config._get_headers(),
                timeout=self.config.timeout
            )

            if response.status_code == 200:
                response_data = response.json()
                return StructuredResponse(response_data)
            else:
                print(f"AI API Error: {response.status_code} - {response.text}")
                return None

        except Exception as e:
            print(f"AI request failed: {str(e)}")
            return None

    def generate_character_response(self,
                                  prompt: str,
                                  character_name: str,
                                  system_prompt: str,
                                  context_messages: Optional[List[Dict]] = None,
                                  **kwargs) -> Optional[StructuredResponse]:
        """
        Generate a character-specific response with structured output
        """
        return self.generate_response(
            prompt=prompt,
            system_prompt=system_prompt,
            character_name=character_name,
            context_messages=context_messages,
            **kwargs
        )

    def analyze_document(self,
                        document_content: str,
                        document_type: str,
                        analysis_type: str = "general") -> Optional[StructuredResponse]:
        """
        Analyze a document with structured output
        """

        # Define analysis schemas based on document type
        schemas = {
            "code": {
                "name": "code_analysis",
                "schema": {
                    "type": "object",
                    "properties": {
                        "summary": {"type": "string"},
                        "language": {"type": "string"},
                        "functions": {"type": "array", "items": {"type": "string"}},
                        "complexity": {"type": "string"},
                        "suggestions": {"type": "array", "items": {"type": "string"}}
                    },
                    "required": ["summary", "language"]
                }
            },
            "text": {
                "name": "text_analysis",
                "schema": {
                    "type": "object",
                    "properties": {
                        "summary": {"type": "string"},
                        "key_points": {"type": "array", "items": {"type": "string"}},
                        "topics": {"type": "array", "items": {"type": "string"}},
                        "sentiment": {"type": "string"}
                    },
                    "required": ["summary"]
                }
            }
        }

        schema = schemas.get(document_type, schemas["text"])

        system_prompt = f"You are a document analysis expert. Analyze the following {document_type} document and provide structured insights."

        return self.generate_response(
            prompt=document_content,
            system_prompt=system_prompt,
            structured_schema=schema,
            max_tokens=1024  # Shorter for analysis
        )

    def analyze_image(self,
                      image_data: str,
                      analysis_type: str = "general") -> Optional[StructuredResponse]:
        """
        Analyze an image with structured output
        """

        schema = {
            "name": "image_analysis",
            "schema": {
                "type": "object",
                "properties": {
                    "description": {"type": "string"},
                    "objects": {"type": "array", "items": {"type": "string"}},
                    "colors": {"type": "array", "items": {"type": "string"}},
                    "mood": {"type": "string"},
                    "setting": {"type": "string"},
                    "composition": {"type": "string"},
                    "lighting": {"type": "string"}
                },
                "required": ["description"]
            }
        }

        system_prompt = "You are an expert image analyst. Describe this image in detail with structured information."

        return self.generate_response(
            prompt="Analyze this image:",
            system_prompt=system_prompt,
            structured_schema=schema,
            image_data=image_data,
            max_tokens=512
        )

    def analyze_conversation(self,
                           conversation_messages: List[Dict],
                           analysis_type: str = "general") -> Optional[StructuredResponse]:
        """
        Analyze a conversation with structured output
        """
        # Format conversation for analysis
        conversation_text = "\n".join([
            f"{msg.get('role', 'unknown')}: {msg.get('content', '')}"
            for msg in conversation_messages[-20:]  # Last 20 messages
        ])

        system_prompt = """You are a conversation analyst. Analyze the provided conversation and provide structured insights about its content, flow, and dynamics."""

        return self.generate_response(
            prompt=f"Analyze this conversation:\n\n{conversation_text}",
            system_prompt=system_prompt,
            structured_schema=self.schemas["conversation_analysis"],
            max_tokens=1024
        )

    def plan_tasks(self,
                  task_description: str,
                  context: Optional[str] = None) -> Optional[StructuredResponse]:
        """
        Generate a structured task plan
        """
        prompt = f"Create a detailed task plan for: {task_description}"
        if context:
            prompt += f"\n\nContext: {context}"

        system_prompt = """You are a project planning expert. Break down complex tasks into manageable, prioritized steps with time estimates and dependencies."""

        return self.generate_response(
            prompt=prompt,
            system_prompt=system_prompt,
            structured_schema=self.schemas["task_planning"],
            max_tokens=1024,
            temperature=0.3  # Lower temperature for more structured planning
        )

    def get_schema(self, schema_name: str) -> Optional[Dict]:
        """Get a predefined schema by name"""
        return self.schemas.get(schema_name)

    def create_custom_schema(self, name: str, properties: Dict, required: List[str]) -> Dict:
        """Create a custom JSON schema for structured output"""
        return {
            "name": name,
            "strict": True,
            "schema": {
                "type": "object",
                "properties": properties,
                "required": required
            }
        }

    def generate_with_tools(self,
                           prompt: str,
                           tools: List[Dict],
                           system_prompt: Optional[str] = None,
                           context_messages: Optional[List[Dict]] = None,
                           **kwargs) -> Optional[StructuredResponse]:
        """
        Generate response with tool calling capabilities
        """
        return self.generate_response(
            prompt=prompt,
            system_prompt=system_prompt,
            context_messages=context_messages,
            tools=tools,
            **kwargs
        )


# Global AI engine instance
ai_engine = AIEngine()