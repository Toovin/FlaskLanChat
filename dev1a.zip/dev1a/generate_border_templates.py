from PIL import Image, ImageDraw
import os

# Define the directory
dir_path = 'tools/cssborders/generation_4'

# Ensure directory exists
os.makedirs(dir_path, exist_ok=True)

# Define resolution, say 64x64 for testing
size = 64

# For each part
parts = ['topleft', 'top', 'topright', 'left', 'center', 'right', 'bottomleft', 'bottom', 'bottomright']

for part in parts:
    # Create a blank image with alpha
    img = Image.new('RGBA', (size, size), color=(0, 0, 0, 0))  # transparent
    draw = ImageDraw.Draw(img)
    
    # Assign colors and patterns for visual markers
    if 'top' == part:
        color = (255, 0, 0, 255)  # red
        draw.rectangle([0, 0, size-1, size//4], fill=color)
        # Add spots
        for i in range(0, size, 8):
            draw.ellipse([i, size//8 - 4, i+4, size//8], fill=(255, 255, 0, 255))  # yellow spots
    elif 'bottom' == part:
        color = (0, 0, 255, 255)  # blue
        draw.rectangle([0, 3*size//4, size-1, size-1], fill=color)
        for i in range(0, size, 8):
            draw.ellipse([i, 3*size//4 + size//8 - 4, i+4, 3*size//4 + size//8], fill=(255, 255, 0, 255))
    elif 'left' == part:
        color = (0, 255, 0, 255)  # green
        draw.rectangle([0, 0, size//4, size-1], fill=color)
        for i in range(0, size, 8):
            draw.ellipse([size//8 - 4, i, size//8, i+4], fill=(255, 0, 255, 255))  # magenta spots
    elif 'right' == part:
        color = (255, 255, 0, 255)  # yellow
        draw.rectangle([3*size//4, 0, size-1, size-1], fill=color)
        for i in range(0, size, 8):
            draw.ellipse([3*size//4 + size//8 - 4, i, 3*size//4 + size//8, i+4], fill=(255, 0, 255, 255))
    elif 'topleft' == part:
        color = (255, 0, 255, 255)  # magenta
        draw.rectangle([0, 0, size//2, size//2], fill=color)
        # Checker pattern
        for x in range(0, size//2, 4):
            for y in range(0, size//2, 4):
                if (x//4 + y//4) % 2 == 0:
                    draw.rectangle([x, y, x+2, y+2], fill=(0, 0, 0, 255))
    elif 'topright' == part:
        color = (0, 255, 255, 255)  # cyan
        draw.rectangle([size//2, 0, size-1, size//2], fill=color)
        for x in range(size//2, size, 4):
            for y in range(0, size//2, 4):
                if (x//4 + y//4) % 2 == 0:
                    draw.rectangle([x, y, x+2, y+2], fill=(0, 0, 0, 255))
    elif 'bottomleft' == part:
        color = (255, 165, 0, 255)  # orange
        draw.rectangle([0, size//2, size//2, size-1], fill=color)
        for x in range(0, size//2, 4):
            for y in range(size//2, size, 4):
                if (x//4 + y//4) % 2 == 0:
                    draw.rectangle([x, y, x+2, y+2], fill=(0, 0, 0, 255))
    elif 'bottomright' == part:
        color = (128, 0, 128, 255)  # purple
        draw.rectangle([size//2, size//2, size-1, size-1], fill=color)
        for x in range(size//2, size, 4):
            for y in range(size//2, size, 4):
                if (x//4 + y//4) % 2 == 0:
                    draw.rectangle([x, y, x+2, y+2], fill=(0, 0, 0, 255))
    elif 'center' == part:
        color = (255, 255, 255, 255)  # white
        draw.rectangle([size//4, size//4, 3*size//4, 3*size//4], fill=color)
        # Gradient stripes
        for y in range(size//4, 3*size//4):
            intensity = int(255 * (y - size//4) / (size//2))
            draw.rectangle([size//4, y, 3*size//4, y], fill=(intensity, intensity, intensity, 255))
    
    # Save the image
    img.save(os.path.join(dir_path, f'{part}.png'))

# Now create a composite 3x3 image for border-image testing
composite = Image.new('RGB', (size*3, size*3), color='black')

# Positions: 0,0 topleft; 1,0 top; 2,0 topright; 0,1 left; 1,1 center; 2,1 right; 0,2 bottomleft; 1,2 bottom; 2,2 bottomright
positions = {
    'topleft': (0, 0),
    'top': (size, 0),
    'topright': (size*2, 0),
    'left': (0, size),
    'center': (size, size),
    'right': (size*2, size),
    'bottomleft': (0, size*2),
    'bottom': (size, size*2),
    'bottomright': (size*2, size*2)
}

for part in parts:
    img_path = os.path.join(dir_path, f'{part}.png')
    if os.path.exists(img_path):
        part_img = Image.open(img_path)
        x, y = positions[part]
        composite.paste(part_img, (x, y))

composite.save(os.path.join(dir_path, 'composite.png'))