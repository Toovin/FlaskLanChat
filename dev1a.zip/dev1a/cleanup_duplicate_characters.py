#!/usr/bin/env python3
"""
Script to identify and clean up duplicate AI characters
"""

import sqlite3
import os

def cleanup_duplicate_characters():
    """Find and remove duplicate AI characters"""
    db_path = 'devchat.db'

    if not os.path.exists(db_path):
        print(f"Database {db_path} not found")
        return

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        # Find duplicate characters
        cursor.execute("""
            SELECT user_uuid, character_name, COUNT(*) as count
            FROM ai_characters
            GROUP BY user_uuid, character_name
            HAVING COUNT(*) > 1
            ORDER BY user_uuid, character_name
        """)

        duplicates = cursor.fetchall()

        if not duplicates:
            print("No duplicate characters found.")
            return

        print(f"Found {len(duplicates)} duplicate character groups:")

        for user_uuid, character_name, count in duplicates:
            print(f"  User {user_uuid}: '{character_name}' appears {count} times")

            # Get all instances of this character
            cursor.execute("""
                SELECT id, created_at, updated_at
                FROM ai_characters
                WHERE user_uuid = ? AND character_name = ?
                ORDER BY created_at DESC
            """, (user_uuid, character_name))

            instances = cursor.fetchall()

            # Keep the most recently updated one, delete the rest
            if len(instances) > 1:
                keep_id = instances[0][0]  # Most recent (first in DESC order)
                delete_ids = [instance[0] for instance in instances[1:]]

                print(f"    Keeping ID {keep_id}, deleting IDs {delete_ids}")

                for delete_id in delete_ids:
                    cursor.execute("DELETE FROM ai_characters WHERE id = ?", (delete_id,))

        conn.commit()
        print("Duplicate cleanup completed.")

    except Exception as e:
        print(f"Error during cleanup: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    cleanup_duplicate_characters()