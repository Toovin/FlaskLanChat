"""
AI Database Module - Unified database interface for AI features
"""

import sqlite3
import json
from typing import Dict, List, Optional, Any
from lc_config import AI_DB_NAME


class AIDatabase:
    """
    Unified database interface for AI features
    """

    def __init__(self):
        self.db_path = AI_DB_NAME

    def _get_connection(self):
        """Get database connection"""
        return sqlite3.connect(self.db_path)

    def _execute_query(self, query: str, params: tuple = None, fetch: bool = False):
        """Execute a database query"""
        conn = self._get_connection()
        cursor = conn.cursor()

        try:
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)

            if fetch:
                result = cursor.fetchall()
                return result
            else:
                conn.commit()
                return cursor
        except Exception as e:
            print(f"Database error: {str(e)}")
            conn.rollback()
            raise
        finally:
            conn.close()

    def init_tables(self):
        """Initialize AI tables"""
        try:
            # Characters table
            self._execute_query('''
                CREATE TABLE IF NOT EXISTS ai_characters (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_uuid TEXT NOT NULL,
                    character_name TEXT NOT NULL,
                    character_description TEXT,
                    avatar_url TEXT,
                    ai_temperature REAL DEFAULT 0.7,
                    ai_max_tokens INTEGER DEFAULT 2048,
                    ai_context_window INTEGER DEFAULT 4096,
                    ai_history_limit INTEGER DEFAULT 50,
                    ai_model TEXT DEFAULT 'default',
                    ai_system_prompt TEXT,
                    ai_custom_instructions TEXT,
                    is_public INTEGER DEFAULT 0,
                    is_active INTEGER DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(user_uuid, character_name)
                )
            ''')

            # Context messages table (inference-only)
            self._execute_query('''
                CREATE TABLE IF NOT EXISTS ai_context (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    conversation_key TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    timestamp TEXT NOT NULL
                )
            ''')

            # Create index for context table
            self._execute_query('''
                CREATE INDEX IF NOT EXISTS idx_ai_context_key_timestamp
                ON ai_context(conversation_key, timestamp)
            ''')

            # Add missing columns to existing tables (for schema updates)
            try:
                # Check if is_public column exists
                result = self._execute_query(
                    "PRAGMA table_info(ai_characters)",
                    fetch=True
                )
                columns = [row[1] for row in result]  # column names are in index 1

                if 'is_public' not in columns:
                    self._execute_query('ALTER TABLE ai_characters ADD COLUMN is_public INTEGER DEFAULT 0')
            except Exception as e:
                print(f"Warning: Could not check/add is_public column: {e}")

            # Conversations table
            self._execute_query('''
                CREATE TABLE IF NOT EXISTS ai_conversations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_uuid TEXT NOT NULL,
                    conversation_type TEXT NOT NULL,
                    channel_id TEXT,
                    character_name TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    title TEXT
                )
            ''')

            # Messages table for conversations
            self._execute_query('''
                CREATE TABLE IF NOT EXISTS ai_messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    conversation_id INTEGER NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    character_name TEXT,
                    timestamp TEXT NOT NULL,
                    FOREIGN KEY (conversation_id) REFERENCES ai_conversations(id) ON DELETE CASCADE
                )
            ''')

            print("AI database tables initialized")
        except Exception as e:
            print(f"Error initializing AI tables: {str(e)}")
            raise

    def save_character(self, user_uuid: str, character_data: Dict[str, Any]) -> Optional[int]:
        """Save a character (create or update)"""
        import datetime
        now = datetime.datetime.now().isoformat()

        character_name = character_data['character_name']

        # Check if character exists
        existing = self._execute_query(
            "SELECT id FROM ai_characters WHERE user_uuid = ? AND character_name = ?",
            (user_uuid, character_name), fetch=True
        )

        if existing:
            # Update
            query = """
                UPDATE ai_characters SET
                    character_description = ?, avatar_url = ?, ai_temperature = ?,
                    ai_max_tokens = ?, ai_context_window = ?, ai_history_limit = ?,
                    ai_model = ?, ai_system_prompt = ?, ai_custom_instructions = ?,
                    is_public = ?, updated_at = ?
                WHERE user_uuid = ? AND character_name = ?
            """
            params = (
                character_data.get('character_description', ''),
                character_data.get('avatar_url', '/static/default_avatars/smile_1.png'),
                character_data.get('ai_temperature', 0.7),
                character_data.get('ai_max_tokens', 2048),
                character_data.get('ai_context_window', 4096),
                character_data.get('ai_history_limit', 50),
                character_data.get('ai_model', 'default'),
                character_data.get('ai_system_prompt', ''),
                character_data.get('ai_custom_instructions', ''),
                character_data.get('is_public', 0),
                now, user_uuid, character_name
            )
            self._execute_query(query, params)
            return existing[0][0]
        else:
            # Create
            query = """
                INSERT INTO ai_characters
                (user_uuid, character_name, character_description, avatar_url,
                 ai_temperature, ai_max_tokens, ai_context_window, ai_history_limit,
                 ai_model, ai_system_prompt, ai_custom_instructions, is_public,
                 created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """
            params = (
                user_uuid, character_name,
                character_data.get('character_description', ''),
                character_data.get('avatar_url', '/static/default_avatars/smile_1.png'),
                character_data.get('ai_temperature', 0.7),
                character_data.get('ai_max_tokens', 2048),
                character_data.get('ai_context_window', 4096),
                character_data.get('ai_history_limit', 50),
                character_data.get('ai_model', 'default'),
                character_data.get('ai_system_prompt', ''),
                character_data.get('ai_custom_instructions', ''),
                character_data.get('is_public', 0),
                now, now
            )
            result = self._execute_query(query, params)
            return result.lastrowid if result else None

    def get_character(self, user_uuid: str, character_name: str) -> Optional[Dict[str, Any]]:
        """Get a specific character"""
        conn = self._get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        try:
            cursor.execute(
                """SELECT * FROM ai_characters
                   WHERE user_uuid = ? AND character_name = ?""",
                (user_uuid, character_name)
            )
            row = cursor.fetchone()

            if row:
                return {
                    'id': row['id'],
                    'user_uuid': row['user_uuid'],
                    'character_name': row['character_name'],
                    'character_description': row['character_description'],
                    'avatar_url': row['avatar_url'],
                    'ai_temperature': row['ai_temperature'],
                    'ai_max_tokens': row['ai_max_tokens'],
                    'ai_context_window': row['ai_context_window'],
                    'ai_history_limit': row['ai_history_limit'],
                    'ai_model': row['ai_model'],
                    'ai_system_prompt': row['ai_system_prompt'],
                    'ai_custom_instructions': row['ai_custom_instructions'],
                    'is_public': bool(row['is_public']),
                    'is_active': bool(row['is_active']),
                    'created_at': row['created_at'],
                    'updated_at': row['updated_at'],
                    'character_type': 'user'
                }

        finally:
            conn.close()

        return None

    def get_character_by_name(self, user_uuid: str, character_name: str) -> Optional[Dict[str, Any]]:
        """Get a character by name, checking user characters first, then builtin characters"""
        # First try to get user character
        character = self.get_character(user_uuid, character_name)
        if character:
            return character

        # If not found, try builtin characters
        conn = self._get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        try:
            cursor.execute(
                """SELECT * FROM ai_characters
                   WHERE user_uuid = 'system-builtin-characters' AND character_name = ?""",
                (character_name,)
            )
            row = cursor.fetchone()

            if row:
                return {
                    'id': row['id'],
                    'user_uuid': row['user_uuid'],
                    'character_name': row['character_name'],
                    'character_description': row['character_description'],
                    'avatar_url': row['avatar_url'],
                    'ai_temperature': row['ai_temperature'],
                    'ai_max_tokens': row['ai_max_tokens'],
                    'ai_context_window': row['ai_context_window'],
                    'ai_history_limit': row['ai_history_limit'],
                    'ai_model': row['ai_model'],
                    'ai_system_prompt': row['ai_system_prompt'],
                    'ai_custom_instructions': row['ai_custom_instructions'],
                    'is_public': bool(row['is_public']),
                    'is_active': bool(row['is_active']),
                    'created_at': row['created_at'],
                    'updated_at': row['updated_at'],
                    'character_type': 'builtin'
                }

        finally:
            conn.close()

        return None

    def get_user_characters(self, user_uuid: str) -> List[Dict[str, Any]]:
        """Get all characters for a user (including builtins)"""
        conn = self._get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        try:
            # Get user-created characters
            cursor.execute(
                "SELECT * FROM ai_characters WHERE user_uuid = ? ORDER BY character_name",
                (user_uuid,)
            )
            user_rows = cursor.fetchall()

            # Get built-in characters
            cursor.execute(
                "SELECT * FROM ai_characters WHERE user_uuid = 'system-builtin-characters' ORDER BY character_name"
            )
            builtin_rows = cursor.fetchall()

            characters = []

            # Add user characters
            for row in user_rows:
                characters.append({
                    'id': row['id'],
                    'user_uuid': row['user_uuid'],
                    'character_name': row['character_name'],
                    'character_description': row['character_description'],
                    'avatar_url': row['avatar_url'],
                    'ai_temperature': row['ai_temperature'],
                    'ai_max_tokens': row['ai_max_tokens'],
                    'ai_context_window': row['ai_context_window'],
                    'ai_history_limit': row['ai_history_limit'],
                    'ai_model': row['ai_model'],
                    'ai_system_prompt': row['ai_system_prompt'],
                    'ai_custom_instructions': row['ai_custom_instructions'],
                    'is_public': bool(row['is_public']),
                    'is_active': bool(row['is_active']),
                    'created_at': row['created_at'],
                    'updated_at': row['updated_at'],
                    'character_type': 'user'
                })

            # Add built-in characters (avoid duplicates by name)
            existing_names = {c['character_name'] for c in characters}
            for row in builtin_rows:
                if row['character_name'] not in existing_names:
                    characters.append({
                        'id': row['id'],
                        'user_uuid': row['user_uuid'],
                        'character_name': row['character_name'],
                        'character_description': row['character_description'],
                        'avatar_url': row['avatar_url'],
                        'ai_temperature': row['ai_temperature'],
                        'ai_max_tokens': row['ai_max_tokens'],
                        'ai_context_window': row['ai_context_window'],
                        'ai_history_limit': row['ai_history_limit'],
                        'ai_model': row['ai_model'],
                        'ai_system_prompt': row['ai_system_prompt'],
                        'ai_custom_instructions': row['ai_custom_instructions'],
                        'is_public': bool(row['is_public']),
                        'is_active': bool(row['is_active']),
                        'created_at': row['created_at'],
                        'updated_at': row['updated_at'],
                        'character_type': 'builtin'
                    })

        finally:
            conn.close()

        return characters

    def update_character(self, user_uuid: str, character_name: str, updates: Dict[str, Any]) -> bool:
        """Update a character"""
        import datetime
        now = datetime.datetime.now().isoformat()

        set_parts = ["updated_at = ?"]
        params = [now]

        for key, value in updates.items():
            if key in ['character_description', 'avatar_url', 'ai_temperature',
                      'ai_max_tokens', 'ai_context_window', 'ai_history_limit',
                      'ai_model', 'ai_system_prompt', 'ai_custom_instructions', 'is_public']:
                set_parts.append(f"{key} = ?")
                params.append(value)

        if len(set_parts) == 1:  # Only updated_at
            return True

        params.extend([user_uuid, character_name])
        query = f"UPDATE ai_characters SET {', '.join(set_parts)} WHERE user_uuid = ? AND character_name = ?"

        try:
            self._execute_query(query, tuple(params))
            return True
        except Exception:
            return False

    def delete_character(self, user_uuid: str, character_name: str) -> bool:
        """Delete a character"""
        try:
            self._execute_query(
                "DELETE FROM ai_characters WHERE user_uuid = ? AND character_name = ?",
                (user_uuid, character_name)
            )
            return True
        except Exception:
            return False

    def set_active_character(self, user_uuid: str, character_name: str) -> bool:
        """Set active character for user"""
        try:
            # Deactivate all
            self._execute_query(
                "UPDATE ai_characters SET is_active = 0 WHERE user_uuid = ?",
                (user_uuid,)
            )
            # Activate selected
            self._execute_query(
                "UPDATE ai_characters SET is_active = 1 WHERE user_uuid = ? AND character_name = ?",
                (user_uuid, character_name)
            )
            return True
        except Exception:
            return False

    def get_active_character(self, user_uuid: str) -> Optional[Dict[str, Any]]:
        """Get active character for user"""
        result = self._execute_query(
            "SELECT * FROM ai_characters WHERE user_uuid = ? AND is_active = 1",
            (user_uuid,), fetch=True
        )

        if result:
            row = result[0]
            return {
                'id': row[0],
                'user_uuid': row[1],
                'character_name': row[2],
                'character_description': row[3],
                'avatar_url': row[4],
                'ai_temperature': row[5],
                'ai_max_tokens': row[6],
                'ai_context_window': row[7],
                'ai_history_limit': row[8],
                'ai_model': row[9],
                'ai_system_prompt': row[10],
                'ai_custom_instructions': row[11],
                'is_public': bool(row[12]),
                'is_active': bool(row[13]),
                'created_at': row[14],
                'updated_at': row[15]
            }
        return None

    def get_public_characters(self) -> List[Dict[str, Any]]:
        """Get all public characters"""
        result = self._execute_query(
            "SELECT * FROM ai_characters WHERE is_public = 1 ORDER BY updated_at DESC",
            fetch=True
        )

        characters = []
        for row in result:
            characters.append({
                'id': row[0],
                'user_uuid': row[1],
                'character_name': row[2],
                'character_description': row[3],
                'avatar_url': row[4],
                'ai_temperature': row[5],
                'ai_max_tokens': row[6],
                'ai_context_window': row[7],
                'ai_history_limit': row[8],
                'ai_model': row[9],
                'ai_system_prompt': row[10],
                'ai_custom_instructions': row[11],
                'is_public': bool(row[12]),
                'is_active': bool(row[13]),
                'created_at': row[14],
                'updated_at': row[15]
            })
        return characters

    # Context management methods
    def save_context_message(self, conversation_key: str, role: str, content: str) -> bool:
        """Save a context message for inference"""
        import datetime
        timestamp = datetime.datetime.now().isoformat()

        try:
            self._execute_query(
                "INSERT INTO ai_context (conversation_key, role, content, timestamp) VALUES (?, ?, ?, ?)",
                (conversation_key, role, content, timestamp)
            )
            return True
        except Exception:
            return False

    def get_context_messages(self, conversation_key: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Get context messages for a conversation"""
        result = self._execute_query(
            "SELECT * FROM ai_context WHERE conversation_key = ? ORDER BY timestamp DESC LIMIT ?",
            (conversation_key, limit), fetch=True
        )

        messages = []
        for row in result:
            messages.append({
                'id': row[0],
                'conversation_key': row[1],
                'role': row[2],
                'content': row[3],
                'timestamp': row[4]
            })
        return messages[::-1]  # Reverse to chronological order

    def prune_old_context(self, conversation_key: str, max_messages: int = 100):
        """Prune old context messages to keep database size manageable"""
        try:
            # Keep only the most recent messages
            self._execute_query(
                """DELETE FROM ai_context
                   WHERE conversation_key = ? AND id NOT IN (
                       SELECT id FROM ai_context
                       WHERE conversation_key = ?
                       ORDER BY timestamp DESC LIMIT ?
                   )""",
                (conversation_key, conversation_key, max_messages)
            )
        except Exception as e:
            print(f"Error pruning context: {str(e)}")

    # Conversation management functions
    def create_conversation(self, user_uuid: str, conversation_type: str = 'modal',
                           channel_id: str = None, character_name: str = None,
                           title: str = None) -> Optional[int]:
        """Create a new conversation"""
        import datetime
        now = datetime.datetime.now().isoformat()

        try:
            cursor = self._execute_query('''
                INSERT INTO ai_conversations (user_uuid, conversation_type, channel_id, character_name, created_at, updated_at, title)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (user_uuid, conversation_type, channel_id, character_name, now, now, title))

            return cursor.lastrowid if cursor else None
        except Exception as e:
            print(f"Error creating conversation: {str(e)}")
            return None

    def get_user_conversations(self, user_uuid: str, conversation_type: str = None) -> List[Dict[str, Any]]:
        """Get conversations for a user"""
        try:
            if conversation_type:
                query = "SELECT * FROM ai_conversations WHERE user_uuid = ? AND conversation_type = ? ORDER BY updated_at DESC"
                params = (user_uuid, conversation_type)
            else:
                query = "SELECT * FROM ai_conversations WHERE user_uuid = ? ORDER BY updated_at DESC"
                params = (user_uuid,)

            rows = self._execute_query(query, params, fetch=True)
            conversations = []

            for row in rows:
                conversations.append({
                    'id': row[0],
                    'user_uuid': row[1],
                    'conversation_type': row[2],
                    'channel_id': row[3],
                    'character_name': row[4],
                    'created_at': row[5],
                    'updated_at': row[6],
                    'title': row[7]
                })

            return conversations
        except Exception as e:
            print(f"Error getting conversations: {str(e)}")
            return []

    def get_conversation(self, conversation_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific conversation"""
        try:
            rows = self._execute_query(
                "SELECT * FROM ai_conversations WHERE id = ?",
                (conversation_id,), fetch=True
            )

            if rows:
                row = rows[0]
                return {
                    'id': row[0],
                    'user_uuid': row[1],
                    'conversation_type': row[2],
                    'channel_id': row[3],
                    'character_name': row[4],
                    'created_at': row[5],
                    'updated_at': row[6],
                    'title': row[7]
                }
            return None
        except Exception as e:
            print(f"Error getting conversation: {str(e)}")
            return None

    def update_conversation_timestamp(self, conversation_id: int) -> bool:
        """Update the updated_at timestamp for a conversation"""
        import datetime
        now = datetime.datetime.now().isoformat()

        try:
            self._execute_query(
                "UPDATE ai_conversations SET updated_at = ? WHERE id = ?",
                (now, conversation_id)
            )
            return True
        except Exception as e:
            print(f"Error updating conversation timestamp: {str(e)}")
            return False

    def update_conversation_title(self, conversation_id: int, title: str) -> bool:
        """Update conversation title"""
        try:
            self._execute_query(
                "UPDATE ai_conversations SET title = ? WHERE id = ?",
                (title, conversation_id)
            )
            return True
        except Exception as e:
            print(f"Error updating conversation title: {str(e)}")
            return False

    def delete_conversation(self, conversation_id: int) -> bool:
        """Delete a conversation and its messages"""
        try:
            # Delete conversation messages first
            self._execute_query(
                "DELETE FROM ai_messages WHERE conversation_id = ?",
                (conversation_id,)
            )

            # Delete the conversation
            self._execute_query(
                "DELETE FROM ai_conversations WHERE id = ?",
                (conversation_id,)
            )
            return True
        except Exception as e:
            print(f"Error deleting conversation: {str(e)}")
            return False

    def delete_all_user_conversations(self, user_uuid: str) -> bool:
        """Delete all conversations and their messages for a user"""
        try:
            # Get all conversation IDs for the user first
            conversations = self._execute_query(
                "SELECT id FROM ai_conversations WHERE user_uuid = ?",
                (user_uuid,),
                fetch=True
            )

            conversation_ids = [conv[0] for conv in conversations]

            if not conversation_ids:
                return True  # No conversations to delete

            # Delete all messages for these conversations
            placeholders = ','.join('?' * len(conversation_ids))
            self._execute_query(
                f"DELETE FROM ai_messages WHERE conversation_id IN ({placeholders})",
                tuple(conversation_ids)
            )

            # Delete all conversations for the user
            self._execute_query(
                "DELETE FROM ai_conversations WHERE user_uuid = ?",
                (user_uuid,)
            )

            print(f"Deleted {len(conversation_ids)} conversations and their messages for user {user_uuid}")
            return True
        except Exception as e:
            print(f"Error deleting all conversations for user {user_uuid}: {str(e)}")
            return False

    def save_conversation_message(self, conversation_id: int, role: str, content: str,
                                 character_name: str = None) -> bool:
        """Save a message to a conversation"""
        import datetime
        timestamp = datetime.datetime.now().isoformat()

        try:
            self._execute_query('''
                INSERT INTO ai_messages (conversation_id, role, content, character_name, timestamp)
                VALUES (?, ?, ?, ?, ?)
            ''', (conversation_id, role, content, character_name, timestamp))
            return True
        except Exception as e:
            print(f"Error saving conversation message: {str(e)}")
            return False

    def get_conversation_messages(self, conversation_id: int, limit: int = 50) -> List[Dict[str, Any]]:
        """Get messages for a conversation"""
        try:
            rows = self._execute_query('''
                SELECT role, content, character_name, timestamp
                FROM ai_messages
                WHERE conversation_id = ?
                ORDER BY timestamp ASC
                LIMIT ?
            ''', (conversation_id, limit), fetch=True)

            messages = []
            for row in rows:
                messages.append({
                    'role': row[0],
                    'content': row[1],
                    'character_name': row[2],
                    'timestamp': row[3]
                })

            return messages
        except Exception as e:
            print(f"Error getting conversation messages: {str(e)}")
            return []


# Global database instance
ai_database = AIDatabase()