import sqlite3
conn = sqlite3.connect('devchat.db')
c = conn.cursor()

# Get total user count
c.execute("SELECT COUNT(*) FROM users")
count = c.fetchone()[0]
print(f'Total users: {count}')

# Get sample users (first 5)
if count > 0:
    c.execute("SELECT uuid, username FROM users LIMIT 5")
    users = c.fetchall()
    print('Sample users:')
    for user in users:
        print(f'  UUID: {user[0]}, Username: {user[1]}')

conn.close()