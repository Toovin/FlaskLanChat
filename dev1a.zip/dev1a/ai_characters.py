"""
AI Characters Module - Character management and CRUD operations
"""

import json
from typing import Dict, List, Optional, Any
from ai_database import ai_database


class CharacterManager:
    """
    Manages AI characters with clean CRUD operations
    """

    def __init__(self):
        pass  # No longer need db instance, using direct import

    def create_character(self, user_uuid: str, character_data: Dict[str, Any]) -> Optional[int]:
        """Create a new character"""
        try:
            # Validate required fields
            if not character_data.get('character_name'):
                return None

            # Set defaults
            character_data.setdefault('avatar_url', '/static/default_avatars/smile_1.png')
            character_data.setdefault('ai_temperature', 0.7)
            character_data.setdefault('ai_max_tokens', 2048)
            character_data.setdefault('ai_context_window', 4096)
            character_data.setdefault('ai_history_limit', 50)
            character_data.setdefault('ai_model', 'default')
            character_data.setdefault('ai_system_prompt', '')
            character_data.setdefault('ai_custom_instructions', '')

            return ai_database.save_character(user_uuid, character_data)
        except Exception as e:
            print(f"Error creating character: {str(e)}")
            return None

    def get_character(self, user_uuid: str, character_name: str) -> Optional[Dict[str, Any]]:
        """Get a specific character (user or builtin)"""
        try:
            return ai_database.get_character_by_name(user_uuid, character_name)
        except Exception as e:
            print(f"Error getting character: {str(e)}")
            return None

    def get_user_characters(self, user_uuid: str) -> List[Dict[str, Any]]:
        """Get all characters for a user (including builtins)"""
        try:
            return ai_database.get_user_characters(user_uuid)
        except Exception as e:
            print(f"Error getting user characters: {str(e)}")
            return []

    def update_character(self, user_uuid: str, character_name: str, updates: Dict[str, Any]) -> bool:
        """Update a character"""
        try:
            # Get existing character
            existing = ai_database.get_character(user_uuid, character_name)
            if not existing:
                return False

            # Merge updates
            updated_data = existing.copy()
            updated_data.update(updates)

            # Save updated character
            return ai_database.update_character(user_uuid, character_name, updates)
        except Exception as e:
            print(f"Error updating character: {str(e)}")
            return False

    def delete_character(self, user_uuid: str, character_name: str) -> bool:
        """Delete a character"""
        try:
            return ai_database.delete_character(user_uuid, character_name)
        except Exception as e:
            print(f"Error deleting character: {str(e)}")
            return False

    def set_active_character(self, user_uuid: str, character_name: str) -> bool:
        """Set the active character for a user"""
        try:
            from database import update_user_ai_settings
            # Update the active character in user AI settings
            update_user_ai_settings(user_uuid, {'ai_active_character': character_name})
            return True
        except Exception as e:
            print(f"Error setting active character: {str(e)}")
            return False

    def get_active_character(self, user_uuid: str) -> Optional[Dict[str, Any]]:
        """Get the active character for a user"""
        try:
            from database import get_user_ai_settings
            ai_settings = get_user_ai_settings(user_uuid)
            active_character_name = ai_settings.get('ai_active_character')

            if active_character_name:
                # Get the character data from the database
                return ai_database.get_character_by_name(user_uuid, active_character_name)
            return None
        except Exception as e:
            print(f"Error getting active character: {str(e)}")
            return None

    def get_public_characters(self) -> List[Dict[str, Any]]:
        """Get all public characters"""
        try:
            return ai_database.get_public_characters()
        except Exception as e:
            print(f"Error getting public characters: {str(e)}")
            return []


# Global character manager instance
character_manager = CharacterManager()