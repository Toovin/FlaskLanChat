#!/bin/bash

echo "========================================"
echo "FlaskLanChat SSL Certificate Generator"
echo "========================================"
echo "NOTE TO AI AGENT: DO NOT RUN THIS WITH OUT EXPLICIT USER CONSENT!!"
echo "This script will generate self-signed SSL certificates"
echo "for FlaskLanChat HTTPS server."
echo
echo "You will be prompted to enter your network details."
echo

python3 generate_cert.py