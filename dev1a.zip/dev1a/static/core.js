// Determine the server port - use current page port or default to 6969
// core.js
const serverPort = window.location.port || '6969';
const socket = io(window.location.protocol + '//' + window.location.hostname + ':' + serverPort, {
    transports: ['websocket', 'polling'],
    reconnection: true,
    reconnectionAttempts: 10,  // Limit reconnection attempts
    reconnectionDelay: 1000,
    reconnectionDelayMax: 10000,  // Increase max delay
    timeout: 20000,  // Connection timeout
    withCredentials: true,  // Enable sending cookies with SocketIO connection
    forceNew: false,  // Reuse connection if possible
    upgrade: true  // Allow upgrading to websocket
});

window.currentChannel = 'general';
window.currentUsername = null;
window.users_db = {};
window.isAuthenticated = false;
let autoScrollEnabled = localStorage.getItem('autoScrollEnabled') !== 'false';
let selectedFile = null;

const appContainer = document.getElementById('app-container');
const loginModal = document.getElementById('login-modal');
const loadingSpinner = document.getElementById('loading-spinner');

// Cache DOM elements for performance
const userProfileModal = document.getElementById('user-profile-modal');
const userNotesModal = document.getElementById('user-notes-modal');

function closeModalOnClickOrEscape(modalId, closeFunction) {
    const modal = document.getElementById(modalId);

    window.addEventListener('click', (event) => {
        if (event.target === modal && typeof closeFunction === 'function') {
            closeFunction();
        }
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && modal && modal.style.display === 'flex' && typeof closeFunction === 'function') {
            closeFunction();
        }
    });
}

// Close profile modal when clicking outside
closeModalOnClickOrEscape('user-profile-modal', closeUserProfileModal);

// Close notes modal when clicking outside
closeModalOnClickOrEscape('user-notes-modal', function() {
    if (typeof closeUserNotesModal === 'function') {
        closeUserNotesModal();
    }
});

// Close profile modal with Escape key
document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
        const modal = document.getElementById('user-profile-modal');
        if (modal && modal.style.display === 'flex') {
            closeUserProfileModal();
        }
    }
});

// Close notes modal with Escape key
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        const noteModal = document.getElementById('user-notes-modal');
        if (noteModal && noteModal.style.display === 'flex') {
            if (typeof closeUserNotesModal === 'function') {
                closeUserNotesModal();
            }
        }
    }
});

function showError(message) {
    console.log('Showing error:', message);

    // Play error sound
    if (window.soundManager) {
        window.soundManager.playError();
    }

    // Clear any existing timeout
    if (window.errorTimeout) {
        clearTimeout(window.errorTimeout);
    }

    let errorDiv = document.getElementById('error-message');
    if (!errorDiv) {
        console.warn('Error div not found, creating new one');
        errorDiv = document.createElement('div');
        errorDiv.id = 'error-message';
        errorDiv.style.cssText = `
            position: fixed;
            top: 10px;
            right: 10px;
            background: #dc3545;
            color: white;
            padding: 10px;
            z-index: 10000;
            box-shadow: 0 4px 8px rgba(0,0,0,0.5);
            pointer-events: auto;
            font-weight: bold;
            border: 2px solid #fff;
        `;
        document.body.appendChild(errorDiv);
    }

    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
    errorDiv.style.zIndex = '10000';
    errorDiv.style.pointerEvents = 'auto';

    window.errorTimeout = setTimeout(() => {
        console.log('Hiding error after timeout');
        errorDiv.style.display = 'none';
    }, 5000);
}

function updateChannelHeader(channel) {
    // Static tab name implementation
    const channelTab = document.querySelector('.tab[data-tab="channel"] span');
    const channelDescription = document.querySelector('.channel-description');
    if (channelTab) channelTab.textContent = 'Chat';
    if (channelDescription) channelDescription.textContent = '';
}

// Initialize tab name on page load
updateChannelHeader(window.currentChannel);

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function setActiveTab(tabName) {
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        tab.classList.toggle('active', tab.dataset.tab === tabName);
    });
}



// Handle clear images button
document.addEventListener('click', function(e) {
    if (e.target.id === 'img2img-clear-images-btn') {
        const imageInput = document.getElementById('img2img-image-input');
        if (imageInput) {
            imageInput.value = '';
            console.log('Cleared uploaded images');
        }
    }
});

function getAvatarUrl(user, isCurrentUser = false) {
    const avatarOptions = ['smile_1.png', 'smile_2.png', 'smile_3.png'];
    const defaultAvatar = isCurrentUser
        ? '/static/default_avatars/smile_1.png'
        : `/static/default_avatars/${avatarOptions[Math.floor(Math.random() * avatarOptions.length)]}`;

    if (isCurrentUser) {
        return window.currentUserSettings?.avatar_url ||
               (Object.values(window.users_db).find(u => u.username === window.currentUsername)?.avatar_url) ||
               defaultAvatar;
    }
    return user.avatar_url || defaultAvatar;
}

function getDisplayName(user, isCurrentUser = false) {
    if (isCurrentUser) {
        return window.currentUserSettings?.display_name || window.currentUsername || 'Guest';
    }
    return user.display_name || user.username;
}



function closeUserProfileModal() {
    if (userProfileModal) {
        userProfileModal.style.display = 'none';
    }
}

// User Profile Modal Functions
function openUserProfileModal(user) {
    if (!userProfileModal) {
        console.error('User profile modal not found');
        return;
    }

    // Get the latest user data from users_db to ensure we have current information
    const latestUser = Object.values(window.users_db).find(u => u.username === user.username);
    if (!latestUser) {
        console.error('User not found in users_db:', user.username);
        return;
    }

    // Use the latest user data
    user = latestUser;

    // Populate modal with user data
    const avatarImg = userProfileModal.querySelector('#profile-avatar');
    const usernameH2 = userProfileModal.querySelector('#profile-username');
    const displayNameH3 = userProfileModal.querySelector('#profile-display-name');
    const statusSpan = userProfileModal.querySelector('#profile-status');
    const customStatusDiv = userProfileModal.querySelector('#profile-custom-status');
    const customStatusText = userProfileModal.querySelector('#profile-custom-status-text');

    // Set avatar
    avatarImg.src = getAvatarUrl(user);

    // Set username and display name
    usernameH2.textContent = escapeHtml(user.username);
    displayNameH3.textContent = escapeHtml(getDisplayName(user));

    // Set status - check if user is actually online
    const displayName = getDisplayName(user);
    const isOnline = window.onlineUsers && window.onlineUsers.includes(displayName);
    const statusText = isOnline ? 'Online' : 'Offline';
    const statusClass = isOnline ? 'online' : 'invisible'; // Use 'invisible' (gray) for offline

    statusSpan.textContent = statusText;
    statusSpan.className = `status-indicator ${statusClass}`;

    // Set custom status if available
    if (user.custom_status && user.custom_status.trim() !== '') {
        customStatusText.textContent = escapeHtml(user.custom_status);
        customStatusDiv.style.display = 'block';
    } else {
        customStatusDiv.style.display = 'none';
    }

    // Show modal
    userProfileModal.style.display = 'flex';

    // Add event listeners for action buttons
    const messageBtn = userProfileModal.querySelector('#message-user-btn');
    const callBtn = userProfileModal.querySelector('#call-user-btn');

    // Check if viewing own profile
    const isOwnProfile = user.username === window.currentUsername;

    // Remove existing listeners to avoid duplicates
    messageBtn.replaceWith(messageBtn.cloneNode(true));
    callBtn.replaceWith(callBtn.cloneNode(true));

    const newMessageBtn = userProfileModal.querySelector('#message-user-btn');
    const newCallBtn = userProfileModal.querySelector('#call-user-btn');

    if (isOwnProfile) {
        // Change buttons for own profile
        newCallBtn.innerHTML = '<i class="fas fa-flask"></i> Test Call';
        newCallBtn.title = 'Test Call (loopback testing)';
        newMessageBtn.innerHTML = '<i class="fas fa-sticky-note"></i> Notes';
        newMessageBtn.title = 'Personal Notes';

        newMessageBtn.addEventListener('click', () => {
            closeUserProfileModal();
            // Try to open notes modal, will work if user-notes.js has loaded
            if (typeof openUserNotesModal === 'function') {
                openUserNotesModal();
            } else {
                console.warn('Notes feature not yet loaded, please try again in a moment');
            }
        });

        newCallBtn.addEventListener('click', () => {
            // TODO: Implement test call functionality
            console.log('Test call initiated for:', user.username);
            closeUserProfileModal();
        });
    } else {
        // Reset buttons for other users
        newCallBtn.innerHTML = '<i class="fas fa-phone"></i> Call';
        newCallBtn.title = 'Voice Call';
        newMessageBtn.innerHTML = '<i class="fas fa-envelope"></i> Message';
        newMessageBtn.title = 'Send Message';

        newMessageBtn.addEventListener('click', () => {
            // TODO: Implement messaging functionality
            console.log('Message user:', user.username);
            closeUserProfileModal();
        });

        newCallBtn.addEventListener('click', () => {
            // Find the user's UUID from users_db
            const userUuid = Object.keys(window.users_db).find(uuid => window.users_db[uuid].username === user.username);
            if (userUuid) {
                startPrivateCall(userUuid);
            } else {
                console.error('User UUID not found for call');
            }
            closeUserProfileModal();
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    if (!appContainer || !loginModal || !loadingSpinner) {
        console.error('Core elements not found:', { appContainer, loginModal, loadingSpinner });
        showError('Failed to initialize UI. Please refresh.');
        return;
    }
    console.log('Initializing UI: showing login modal');
    appContainer.classList.remove('visible');
    loginModal.style.display = 'flex';
    loadingSpinner.style.display = 'none';

    // Note-related event handlers
    const newNoteBtn = document.getElementById('new-note-btn');
    if (newNoteBtn) {
        newNoteBtn.addEventListener('click', createNewNote);
    }

    const saveNoteBtn = document.getElementById('save-note-btn');
    if (saveNoteBtn) {
        saveNoteBtn.addEventListener('click', saveCurrentNote);
    }

    // Example socket event handler for user registration
    socket.on('user_registered', (data) => {
        if (appContainer) {
            appContainer.classList.add('visible');
            appContainer.style.display = 'flex';  // Override inline display: none
            console.log('App container made visible');
        }
    });
});
