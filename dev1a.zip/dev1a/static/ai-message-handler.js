// ai-message-handler.js - AI Message Processing & UI Management
class AIMessageHandler {
    constructor(modalInstance) {
        this.modal = modalInstance;
        this.currentImageData = null;
    }

    // Initialize message handler
    init() {
        this.initImageHandler();
    }

    // Send a message to the AI
    sendMessage(data = null) {
        console.log('[AI_MESSAGE_HANDLER] sendMessage called with data:', data);

        let message, imageData, characterName, conversationKey, conversationId;

        if (data) {
            // Called from socket handler with data
            console.log('[AI_MESSAGE_HANDLER] Called from socket handler');
            message = data.message?.trim();
            imageData = data.image_data;
            characterName = data.character_name;
            conversationKey = data.conversation_key;
            conversationId = data.conversation_id;
        } else {
            // Called from UI
            console.log('[AI_MESSAGE_HANDLER] Called from UI');
            const input = document.getElementById('ai-message-input');
            message = input?.value?.trim();
            imageData = this.currentImageData;
            const activeCharacter = this.modal.modules.characterManager.activeCharacter;
            characterName = activeCharacter ? activeCharacter.character_name : null;
            conversationKey = this.modal.currentConversationKey;
            const conversationManager = this.modal.modules.conversationManager;
            conversationId = conversationManager ? conversationManager.currentConversationId : null;
        }

        console.log('[AI_MESSAGE_HANDLER] Message data:', {
            message: message,
            hasImage: !!imageData,
            characterName: characterName,
            conversationKey: conversationKey,
            conversationId: conversationId
        });

        if (!message && !imageData) {
            console.log('[AI_MESSAGE_HANDLER] No message or image, returning');
            return;
        }

        // Add user message to UI (only when called from UI)
        if (!data) {
            console.log('[AI_MESSAGE_HANDLER] Adding user message to UI');
            let displayContent = message;
            if (imageData) {
                displayContent = message || '[Image]';
                if (message) displayContent += ' [Image attached]';
            }
            this.addMessageToUI('user', displayContent);

            // Clear input and image
            const input = document.getElementById('ai-message-input');
            if (input) input.value = '';
            this.removeImage();
            this.modal.updateStatus('Sending...');
        }

        // Send to server
        if (typeof socket !== 'undefined') {
            const messageData = {
                message: message,
                character_name: characterName,
                conversation_key: conversationKey,
                conversation_id: conversationId,
                image_data: imageData
            };

            console.log('[AI_MESSAGE_HANDLER] Emitting ai_modal_send with data:', messageData);
            socket.emit('ai_modal_send', messageData);
        } else {
            console.error('[AI_MESSAGE_HANDLER] Socket not available');
        }
    }

    // Handle AI response from server
    handleAIResponse(data) {
        console.log('[AI_MESSAGE_HANDLER] handleAIResponse received data:', data);

        let content = data.response;
        let characterName = data.character_name;
        let avatarUrl = data.avatar_url;

        // Handle structured responses - extract content from structured_data first
        if (data.is_structured && data.structured_data) {
            console.log('[AI_MESSAGE_HANDLER] Processing structured response');
            const structured = data.structured_data;
            content = structured.response || content;
            characterName = structured.character_name || characterName;
        } else if (data.response && typeof data.response === 'string' && data.response.trim().startsWith('{')) {
            // Fallback: try to parse raw JSON response
            try {
                const parsed = JSON.parse(data.response);
                if (parsed.response) {
                    content = parsed.response;
                    characterName = parsed.character_name || characterName;
                }
            } catch (e) {
                console.log('[AI_MESSAGE_HANDLER] Could not parse response as JSON, using as-is');
            }
        }

        console.log('[AI_MESSAGE_HANDLER] Adding AI response to UI:', {
            content: content?.substring(0, 100) + '...',
            characterName: characterName,
            avatarUrl: avatarUrl
        });

        // Add AI response to UI
        this.addMessageToUI('assistant', content, characterName, avatarUrl);
        this.modal.updateStatus('Ready');
    }

    // Add a message to the UI
    addMessageToUI(role, content, characterName = null, avatarUrl = null) {
        console.log('[AI_MESSAGE_HANDLER] addMessageToUI called:', {
            role: role,
            contentLength: content?.length,
            characterName: characterName,
            avatarUrl: avatarUrl
        });

        const messagesContainer = document.getElementById('ai-messages');
        console.log('[AI_MESSAGE_HANDLER] Messages container found:', !!messagesContainer);

        if (!messagesContainer) {
            console.error('[AI_MESSAGE_HANDLER] Messages container not found!');
            return;
        }

        // Remove welcome message if it exists
        const welcome = messagesContainer.querySelector('.ai-welcome');
        if (welcome) {
            console.log('[AI_MESSAGE_HANDLER] Removing welcome message');
            welcome.remove();
        }

        const messageDiv = document.createElement('div');
        messageDiv.className = `ai-message ai-message-${role}`;

        const timestamp = new Date().toLocaleTimeString();
        const displayName = role === 'user' ? 'You' : (characterName || 'AI');
        const avatarHtml = avatarUrl ? `<img src="${avatarUrl}" alt="${displayName}" class="ai-message-avatar">` : '';

        console.log('[AI_MESSAGE_HANDLER] Creating message element:', {
            displayName: displayName,
            timestamp: timestamp,
            hasAvatar: !!avatarHtml
        });

        messageDiv.innerHTML = `
            <div class="ai-message-header">
                ${avatarHtml}
                <span class="ai-message-role">${displayName}</span>
                <span class="ai-message-time">${timestamp}</span>
            </div>
            <div class="ai-message-content">${this.formatMessage(content)}</div>
        `;

        console.log('[AI_MESSAGE_HANDLER] Appending message to container');
        messagesContainer.appendChild(messageDiv);

        // Auto-scroll if enabled
        this.scrollToBottom();

        console.log('[AI_MESSAGE_HANDLER] Message added successfully');
    }

    // Format message content with basic markdown-like formatting
    formatMessage(content) {
        // Basic markdown-like formatting
        return content
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/`(.*?)`/g, '<code>$1</code>')
            .replace(/\n/g, '<br>');
    }

    // Remove attached image
    removeImage() {
        this.currentImageData = null;
        const preview = document.getElementById('ai-image-preview');
        if (preview) {
            preview.style.display = 'none';
        }
        // Clear file input
        const fileInput = document.getElementById('ai-image-input');
        if (fileInput) {
            fileInput.value = '';
        }
    }

    // Handle image file selection
    handleImageSelection(event) {
        const file = event.target.files[0];
        if (!file) return;

        // Validate file type
        if (!file.type.startsWith('image/')) {
            alert('Please select a valid image file');
            return;
        }

        // Validate file size (max 10MB)
        if (file.size > 10 * 1024 * 1024) {
            alert('File size must be less than 10MB');
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            this.currentImageData = e.target.result;

            // Show preview
            const previewDiv = document.getElementById('ai-image-preview');
            const previewImg = document.getElementById('ai-preview-image');
            if (previewDiv && previewImg) {
                previewImg.src = e.target.result;
                previewDiv.style.display = 'block';
            }
        };
        reader.readAsDataURL(file);
    }

    // Scroll messages to bottom
    scrollToBottom(force = false) {
        const messagesContainer = document.getElementById('ai-messages');
        if (!messagesContainer) {
            console.error('AI messages container not found');
            return;
        }

        const autoScrollCheckbox = document.getElementById('ai-auto-scroll-checkbox');
        const autoScrollEnabled = autoScrollCheckbox ? autoScrollCheckbox.checked : true;

        if (!autoScrollEnabled && !force) {
            return;
        }

        requestAnimationFrame(() => {
            messagesContainer.style.overflowY = 'hidden';
            void messagesContainer.offsetHeight;
            messagesContainer.style.overflowY = 'auto';

            setTimeout(() => {
                messagesContainer.scrollTo({
                    top: messagesContainer.scrollHeight,
                    behavior: force ? 'instant' : 'smooth'
                });
            }, 50);
        });
    }

    // Initialize image input handler
    initImageHandler() {
        const imageInput = document.getElementById('ai-image-input');
        if (imageInput) {
            imageInput.addEventListener('change', (e) => this.handleImageSelection(e));
        }

        const imageButton = document.getElementById('ai-image-button');
        if (imageButton) {
            imageButton.addEventListener('click', () => {
                imageInput?.click();
            });
        }
    }
}

// Export for use in other modules
window.AIMessageHandler = AIMessageHandler;