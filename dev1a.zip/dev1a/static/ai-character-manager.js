// ai-character-manager.js - AI Character Management System
class AICharacterManager {
    constructor(modalInstance) {
        this.modal = modalInstance;
        this.characters = [];
        this.activeCharacter = null;
        this.loadingActiveCharacter = false;
        this.settingsModalOpen = false;
    }

    // Initialize character management
    init() {
        this.bindCharacterEvents();
        // Don't load characters here - wait for modal to open when user is authenticated
        this.loadActiveCharacter();
    }

    // Utility function to add cache busting to avatar URLs
    getCacheBustedAvatarUrl(avatarUrl) {
        if (!avatarUrl) return avatarUrl;
        return avatarUrl + (avatarUrl.includes('?') ? '&' : '?') + 't=' + Date.now();
    }

    // Load characters from server
    loadCharacters() {
        console.log('[DEBUG] AICharacterManager.loadCharacters called');
        if (typeof socket !== 'undefined') {
            console.log('[DEBUG] Socket available, showing loading state');
            // Show loading state immediately
            const container = document.getElementById('ai-character-tiles');
            if (container) {
                console.log('[DEBUG] Setting loading state in container');
                container.innerHTML = '<div class="loading-characters"><i class="fas fa-spinner fa-spin"></i> Loading characters...</div>';
            } else {
                console.log('[DEBUG] Container ai-character-tiles not found');
            }
            console.log('[DEBUG] Emitting ai_get_characters');
            socket.emit('ai_get_characters');
        } else {
            console.log('[DEBUG] Socket not available');
        }
    }

    // Called after character tiles are rendered
    onCharactersRendered() {
        // No image processing needed for simplified tiles
    }

    // Load active character from server
    loadActiveCharacter() {
        if (typeof socket !== 'undefined') {
            socket.emit('ai_get_active_character');
        }
    }

    // Bind character-related events
    bindCharacterEvents() {
        // Character socket events are now handled by the orchestrator
        // This method is kept for any future character-specific events

        if (typeof socket !== 'undefined') {
            socket.on('ai_character_loaded', (data) => {
                if (this.loadingActiveCharacter) {
                    // Loading for active character selection - populate main settings
                    this.populateMainSettingsFromCharacter(data.character);

                    // Also update settings modal if it's open
                    if (this.modal.modules.settingsModal) {
                        this.modal.modules.settingsModal.handleAICharacterLoaded(data);
                    }

                    this.loadingActiveCharacter = false; // Reset flag
                } else {
                    // Loading for character editing
                    this.loadCharacterData(data.character);
                }
            });
        }

        // ai_active_character_set and ai_active_character_data are now handled by the orchestrator
    }

    // Centralized character rendering logic
    renderCharacterSections(characters, containerId, showEmptyState = true) {
        console.log(`[DEBUG] renderCharacterSections called for ${containerId}`);
        const container = document.getElementById(containerId);
        if (!container) {
            console.log(`[DEBUG] Container ${containerId} not found`);
            return;
        }
        console.log(`[DEBUG] Container ${containerId} found`);

        console.log(`[DEBUG] Rendering characters to ${containerId}, count:`, characters?.length || 0);

        // Show loading state if no characters provided yet
        if (!characters) {
            container.innerHTML = '<div class="loading-characters"><i class="fas fa-spinner fa-spin"></i> Loading characters...</div>';
            return;
        }

        if (!characters || characters.length === 0) {
            if (showEmptyState) {
                container.innerHTML = `
                    <div class="no-characters">
                        <p>No characters found. Create your first AI character!</p>
                        <button class="btn btn-primary" onclick="aiCharacterManager.showCreateCharacterModal()">Create Character</button>
                    </div>
                `;
            }
            return;
        }

        // Group characters by type
        const groupedCharacters = this.groupCharactersByType(characters);
        const html = this.generateCharacterSectionsHTML(groupedCharacters);

        container.innerHTML = html;
        console.log('Character sections HTML set, length:', html.length);

        // Bind events using unified event delegation
        this.bindUnifiedCharacterEvents(container);

        // Also bind direct events as fallback
        this.bindDirectCharacterEvents();

        console.log('Character tiles updated');

        // Debug: Check if the section is visible
        const section = document.getElementById('ai-character-selector');
        if (section) {
            console.log('[DEBUG] Character section classes:', section.className);
            console.log('[DEBUG] Character section display:', window.getComputedStyle(section).display);
            console.log('[DEBUG] Character section visibility:', window.getComputedStyle(section).visibility);
            console.log('[DEBUG] Character section has active class:', section.classList.contains('active'));
        }

        // Debug: Check tile visibility
        const tiles = container.querySelectorAll('.ai-character-tile');
        if (tiles.length > 0) {
            console.log('[DEBUG] First tile display:', window.getComputedStyle(tiles[0]).display);
            console.log('[DEBUG] First tile visibility:', window.getComputedStyle(tiles[0]).visibility);
            console.log('[DEBUG] First tile offsetHeight:', tiles[0].offsetHeight);
            console.log('[DEBUG] First tile offsetWidth:', tiles[0].offsetWidth);
        }

        // Display is now controlled by tab switching in the orchestrator

        // After updating the list, refresh active character data if one is selected
        const activeCharacterSelect = document.getElementById('ai-active-character');
        if (activeCharacterSelect && this.activeCharacter) {
            activeCharacterSelect.value = this.activeCharacter.character_name;

            // Refresh active character data and update indicator
            const updatedActiveCharacter = characters.find(c => c.character_name === this.activeCharacter.character_name);
            if (updatedActiveCharacter) {
                this.activeCharacter = updatedActiveCharacter;
                this.updateActiveCharacterIndicator();
            }
        }

        // Set pending active character if any (only if no active character is set yet)
        if (window.aiModalOrchestrator && window.aiModalOrchestrator.pendingActiveCharacter && !this.activeCharacter) {
            const character = characters.find(c => c.character_name === window.aiModalOrchestrator.pendingActiveCharacter);
            if (character) {
                this.setActiveCharacter(window.aiModalOrchestrator.pendingActiveCharacter);
                window.aiModalOrchestrator.pendingActiveCharacter = null;
            }
        }

        // Try to start conversation now that characters are loaded (only if we have an active character)
        if (window.aiModalOrchestrator && window.aiModalOrchestrator.isOpen && !window.aiModalOrchestrator.currentConversationKey && this.activeCharacter) {
            window.aiModalOrchestrator.startNewConversation();
        }
    }

    handleActiveCharacterData(character) {
        console.log('Active character data received:', character);
        if (character) {
            this.activeCharacter = character;
            this.updateActiveCharacterIndicator();
            this.updateCharacterSelectOptions(this.characters);
        }
    }

    handleCharacterCreated(character) {
        console.log('Character created:', character);
        if (character) {
            this.characters.push(character);
            this.loadCharacters(); // Refresh the list
        }
    }

    handleCharacterUpdated(data) {
        console.log('Character updated:', data);
        if (data.character) {
            const index = this.characters.findIndex(c => c.character_name === data.character.character_name);
            if (index !== -1) {
                this.characters[index] = data.character;
                this.loadCharacters(); // Refresh the list
            }
        }
    }

    handleCharacterDeleted(characterName) {
        console.log('Character deleted:', characterName);
        this.characters = this.characters.filter(c => c.character_name !== characterName);
        this.loadCharacters(); // Refresh the list
    }

    handleActiveCharacterSet(character) {
        console.log('Active character set:', character);
        if (character) {
            // Only update if it's a different character or if we don't have one set
            if (!this.activeCharacter || this.activeCharacter.character_name !== character.character_name) {
                this.activeCharacter = character;
                this.updateActiveCharacterIndicator();
                this.updateCharacterSelectOptions(this.characters);
            }
        }
    }

    // Handler methods for orchestrator
    handleCharactersLoaded(characters) {
        console.log('[DEBUG] handleCharactersLoaded called with:', characters?.length || 0, 'characters');
        if (characters) {
            console.log('[DEBUG] Characters data:', characters);
            characters.forEach((char, i) => {
                console.log(`[DEBUG] Character ${i}: ${char.character_name} (type: ${char.character_type})`);
            });
        } else {
            console.log('[DEBUG] Characters is null/undefined');
        }

        this.characters = characters;
        console.log('[DEBUG] Calling updateCharacterList');
        this.updateCharacterList(characters);
        console.log('[DEBUG] Calling updateCharacterSelectOptions');
        this.updateCharacterSelectOptions(characters);
        console.log('[DEBUG] Calling updateAIModalCharacterTiles');
        this.updateAIModalCharacterTiles(characters);
        console.log('[DEBUG] Calling onCharactersRendered');
        this.onCharactersRendered();

        // Update orchestrator's character selector
        if (window.aiModalOrchestrator) {
            window.aiModalOrchestrator.updateCharacterSelector(characters);
        }

        console.log('Character tiles updated');

        // Set initial display based on active character
        const selector = document.getElementById('ai-character-selector');
        const messages = document.getElementById('ai-messages');
        if (this.activeCharacter) {
            if (selector) selector.style.display = 'none';
            if (messages) messages.style.display = 'block';
        } else {
            if (selector) selector.style.display = 'block';
            if (messages) messages.style.display = 'none';
        }

        // After updating the list, refresh active character data if one is selected
        const activeCharacterSelect = document.getElementById('ai-active-character');
        if (activeCharacterSelect && this.activeCharacter) {
            activeCharacterSelect.value = this.activeCharacter.character_name;

            // Refresh active character data and update indicator
            const updatedActiveCharacter = characters.find(c => c.character_name === this.activeCharacter.character_name);
            if (updatedActiveCharacter) {
                this.activeCharacter = updatedActiveCharacter;
                this.updateActiveCharacterIndicator();
            }
        }

        // Set pending active character if any (only if no active character is set yet)
        if (window.aiModalOrchestrator && window.aiModalOrchestrator.pendingActiveCharacter && !this.activeCharacter) {
            const character = characters.find(c => c.character_name === window.aiModalOrchestrator.pendingActiveCharacter);
            if (character) {
                this.setActiveCharacter(window.aiModalOrchestrator.pendingActiveCharacter);
                window.aiModalOrchestrator.pendingActiveCharacter = null;
            }
        }

        // Try to start conversation now that characters are loaded
        if (window.aiModalOrchestrator && window.aiModalOrchestrator.isOpen && !window.aiModalOrchestrator.currentConversationKey) {
            window.aiModalOrchestrator.startNewConversation();
        }
    }

    // Group characters by type
    groupCharactersByType(characters) {
        const groups = {
            builtin: characters.filter(c => c.character_type === 'builtin'),
            user: characters.filter(c => c.character_type === 'user'),
            shared: characters.filter(c => c.character_type === 'shared')
        };

        console.log('Character types:', {
            total: characters.length,
            builtin: groups.builtin.length,
            user: groups.user.length,
            shared: groups.shared.length
        });

        return groups;
    }

    // Generate HTML for character sections
    generateCharacterSectionsHTML(groups) {
        const sectionConfigs = [
            { key: 'builtin', icon: '🤖', title: 'Server Characters' },
            { key: 'user', icon: '👤', title: 'User Characters' },
            { key: 'shared', icon: '🌐', title: 'Shared Characters' }
        ];

        return sectionConfigs
            .filter(config => groups[config.key].length > 0)
            .map(config => this.generateCharacterSectionHTML(config, groups[config.key]))
            .join('');
    }

    // Generate HTML for a single character section
    generateCharacterSectionHTML(config, characters) {
        return `
            <div class="character-section" data-section-type="${config.key}">
                <div class="character-section-header">
                    <h3>${config.icon} ${config.title} <span class="character-count">(${characters.length})</span></h3>
                </div>
                <div class="character-section-content character-tiles-grid">
                    ${characters.map(character => this.createCharacterTile(character)).join('')}
                </div>
            </div>
        `;
    }

    // Update AI modal character tiles (now uses centralized rendering)
    updateAIModalCharacterTiles(characters) {
        console.log('[DEBUG] updateAIModalCharacterTiles called with', characters?.length || 0, 'characters');
        this.renderCharacterSections(characters, 'ai-character-tiles', true);
    }

    // Update character list UI (now uses centralized rendering)
    updateCharacterList(characters) {
        this.renderCharacterSections(characters, 'character-cards-container', true);
    }

    // Bind events for collapsible sections
    bindCollapsibleSectionEvents() {
        document.querySelectorAll('.character-section-header').forEach(header => {
            header.addEventListener('click', (e) => {
                // Don't trigger if clicking on child elements that have their own handlers
                if (e.target.closest('.character-edit-btn') || e.target.closest('.character-delete-btn')) {
                    return;
                }

                const content = header.nextElementSibling;
                const icon = header.querySelector('.collapse-icon');

                if (content.classList.contains('collapsed')) {
                    content.classList.remove('collapsed');
                    if (icon) icon.textContent = '▼';
                } else {
                    content.classList.add('collapsed');
                    if (icon) icon.textContent = '▶';
                }
            });
        });
    }

    // Create HTML for character card
    createCharacterCard(character) {
        const isBuiltIn = character.character_type === 'builtin';
        const isActive = this.activeCharacter && this.activeCharacter.character_name === character.character_name;
        const typeIcon = isBuiltIn ? '🤖 ' : '';
        const avatarUrl = this.getCacheBustedAvatarUrl(character.avatar_url || '/static/default_avatars/smile_1.png');

        return `
            <div class="character-card ${isActive ? 'active' : ''}" data-character-name="${character.character_name}" style="cursor: pointer;" title="Click to select this character">
                <div class="character-header">
                    <div class="character-card-avatar">
                        <img src="${avatarUrl}" alt="${character.character_name}" onerror="this.src='/static/default_avatars/smile_1.png'">
                    </div>
                    <div class="character-info">
                        <h4>${typeIcon}${character.character_name}</h4>
                        <p>${character.character_description || 'No description'}</p>
                    </div>
                    <div class="character-actions">
                        <button class="character-edit-btn" title="Edit character" data-character="${character.character_name}">✏</button>
                        ${!isBuiltIn ? `<button class="character-delete-btn" title="Delete character" data-character="${character.character_name}">×</button>` : ''}
                    </div>
                </div>
                <div class="character-settings">
                    <div class="character-setting">
                        <label>Temperature:</label>
                        <span>${character.ai_temperature || 'Default'}</span>
                    </div>
                    <div class="character-setting">
                        <label>Max Tokens:</label>
                        <span>${character.ai_max_tokens || 'Default'}</span>
                    </div>
                </div>
            </div>
        `;
    }

    // Create HTML for character tile (simplified)
    createCharacterTile(character) {
        const isBuiltIn = character.character_type === 'builtin';
        const isActive = this.activeCharacter && this.activeCharacter.character_name === character.character_name;
        const typeIcon = isBuiltIn ? '🤖 ' : '';

        console.log('[DEBUG] Creating tile for character:', character.character_name, 'data-character-name:', character.character_name);

        return `
            <div class="ai-character-tile ${isActive ? 'selected' : ''}" data-character-name="${character.character_name}" style="cursor: pointer; border: 2px solid #ccc; margin: 5px; padding: 10px;" onclick="console.log('Tile clicked directly:', '${character.character_name}')">
                <div class="ai-character-tile-content">
                    <div class="ai-character-tile-header">
                        <div class="ai-character-tile-name">
                            ${typeIcon}${character.character_name} (CLICK ME)
                        </div>
                        <div class="ai-character-tile-actions">
                            ${!isBuiltIn ? `<button class="character-edit-btn" title="Edit character" data-character="${character.character_name}">Edit</button>` : ''}
                            ${!isBuiltIn ? `<button class="character-delete-btn" title="Delete character" data-character="${character.character_name}">Delete</button>` : ''}
                        </div>
                    </div>
                    <div class="ai-character-tile-description">
                        ${character.character_description || 'No description'}
                    </div>
                </div>
            </div>
        `;
    }

    // Bind events for character cards
    bindCharacterCardEvents() {
        // Character selection
        document.querySelectorAll('.character-card').forEach(card => {
            card.addEventListener('click', (e) => {
                // Don't trigger selection if clicking on action buttons
                if (e.target.closest('.character-actions')) return;

                const characterName = card.dataset.characterName;
                this.selectCharacter(characterName);
            });
        });

        // Edit buttons
        document.querySelectorAll('.character-edit-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const characterName = btn.dataset.character;
                this.showEditCharacterModal(characterName);
            });
        });

        // Delete buttons
        document.querySelectorAll('.character-delete-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const characterName = btn.dataset.character;
                this.deleteCharacter(characterName);
            });
        });
    }

    // Unified event binding using event delegation
    bindUnifiedCharacterEvents(container) {
        console.log('[DEBUG] bindUnifiedCharacterEvents called on container:', container.id);
        container.addEventListener('click', (e) => {
            console.log('[DEBUG] Click event in character container');
            const target = e.target;

            // Edit buttons
            if (target.classList.contains('character-edit-btn') || target.closest('.character-edit-btn')) {
                e.stopPropagation();
                const btn = target.classList.contains('character-edit-btn') ? target : target.closest('.character-edit-btn');
                const characterName = btn.dataset.character;
                this.showEditCharacterModal(characterName);
                return;
            }

            // Delete buttons
            if (target.classList.contains('character-delete-btn') || target.closest('.character-delete-btn')) {
                e.stopPropagation();
                const btn = target.classList.contains('character-delete-btn') ? target : target.closest('.character-delete-btn');
                const characterName = btn.dataset.character;
                this.deleteCharacter(characterName);
                return;
            }

            // Character tile selection (only if not clicking on action buttons)
            if (target.closest('.ai-character-tile')) {
                const tile = target.closest('.ai-character-tile');
                const characterName = tile.dataset.characterName;
                console.log('[DEBUG] Character tile clicked:', characterName, 'tile element:', tile);
                this.selectCharacterForModal(characterName);
            }
        });
    }

    // Bind direct events to character tiles
    bindDirectCharacterEvents() {
        console.log('[DEBUG] bindDirectCharacterEvents called');
        document.querySelectorAll('.ai-character-tile').forEach(tile => {
            console.log('[DEBUG] Binding click event to tile:', tile.dataset.characterName);
            tile.addEventListener('click', (e) => {
                // Don't trigger if clicking on action buttons
                if (e.target.closest('.character-edit-btn') || e.target.closest('.character-delete-btn')) {
                    return;
                }
                console.log('[DEBUG] Direct tile click:', tile.dataset.characterName);
                e.stopPropagation();
                this.selectCharacterForModal(tile.dataset.characterName);
            });
        });
    }

    // Select character specifically for modal (different from global selection)
    selectCharacterForModal(characterName) {
        console.log('[DEBUG] selectCharacterForModal called with:', characterName);
        const character = this.characters.find(c => c.character_name === characterName);
        if (character) {
            console.log('[DEBUG] Character found:', character.character_name);
            // Update UI to show this character as selected in modal
            document.querySelectorAll('.ai-character-tile').forEach(tile => {
                tile.classList.toggle('selected', tile.dataset.characterName === characterName);
            });

            // Notify orchestrator of character selection
            if (window.aiModalOrchestrator) {
                console.log('[DEBUG] Calling aiModalOrchestrator.onCharacterSelected');
                window.aiModalOrchestrator.onCharacterSelected(character);
            } else {
                console.error('[DEBUG] aiModalOrchestrator not available');
            }
        } else {
            console.error('[DEBUG] Character not found:', characterName);
        }
    }

    // Enhanced setActiveCharacter to also update the orchestrator's indicator
    setActiveCharacter(characterName) {
        const character = this.characters.find(c => c.character_name === characterName);
        if (!character) return;

        // Set active character immediately for UI responsiveness
        this.activeCharacter = character;

        // Update UI immediately for responsiveness
        document.querySelectorAll('.character-card').forEach(card => {
            card.classList.toggle('active', card.dataset.characterName === characterName);
        });

        // Update tile selection
        document.querySelectorAll('.ai-character-tile').forEach(tile => {
            tile.classList.toggle('selected', tile.dataset.characterName === characterName);
        });

        // Update character select dropdown if it exists
        const select = document.getElementById('ai-active-character');
        if (select) {
            select.value = characterName;
        }

        // Send to server to set as active
        if (typeof socket !== 'undefined') {
            socket.emit('ai_set_active_character', { character_name: characterName });
        }

        // Load character settings into main form
        this.loadingActiveCharacter = true;
        if (typeof socket !== 'undefined') {
            socket.emit('ai_load_character', { character_name: characterName });
        }

        // Update orchestrator's character indicator
        if (window.aiModalOrchestrator) {
            window.aiModalOrchestrator.updateActiveCharacterDisplay(character);
        }
    }

    // Enhanced clearActiveCharacter to also update the orchestrator's indicator
    clearActiveCharacter() {
        this.activeCharacter = null;

        document.querySelectorAll('.character-card').forEach(card => {
            card.classList.remove('active');
        });

        // Clear tile selection
        document.querySelectorAll('.ai-character-tile').forEach(tile => {
            tile.classList.remove('selected');
        });

        // Switch to characters tab to show character selector
        if (window.aiModalOrchestrator) {
            window.aiModalOrchestrator.switchTab('characters');
        }

        // Within the chat section, show conversation selector and hide messages
        const convSelector = document.getElementById('ai-conversation-selector');
        const messages = document.getElementById('ai-messages');
        if (convSelector) convSelector.style.display = 'block';
        if (messages) messages.style.display = 'none';

        // Update character select dropdown if it exists
        const select = document.getElementById('ai-active-character');
        if (select) {
            select.value = '';
        }

        this.updateActiveCharacterIndicator();

        // Reset to default settings
        this.populateMainSettingsFromCharacter(null);

        // Save cleared active to settings
        this.saveActiveCharacterToSettings('');

        // Update orchestrator's character indicator
        if (window.aiModalOrchestrator) {
            window.aiModalOrchestrator.updateActiveCharacterDisplay(null);
        }
    }

    // Save active character (takes character object)
    saveActiveCharacter(character) {
        if (character && character.character_name) {
            this.saveActiveCharacterToSettings(character.character_name);
        }
    }

    // Save active character to user settings
    saveActiveCharacterToSettings(characterName) {
        if (typeof socket !== 'undefined') {
            socket.emit('ai_update_user_settings', {
                settings: { ai_active_character: characterName }
            });
        }
    }

    // Select a character for chat (sets active and shows conversation selector)
    selectCharacter(characterName) {
        const character = this.characters.find(c => c.character_name === characterName);
        if (character) {
            this.activeCharacter = character;
            this.saveActiveCharacter(character);
            this.updateActiveCharacterIndicator();

            // Notify orchestrator
            if (window.aiModalOrchestrator) {
                window.aiModalOrchestrator.updateActiveCharacterDisplay(character);
            }
        } else {
            this.clearActiveCharacter();
            if (window.aiModalOrchestrator) {
                window.aiModalOrchestrator.updateActiveCharacterDisplay(null);
            }
        }
    }

    // Show conversation selector for the active character
    showConversationSelector(character) {
        // Switch to chat tab first
        if (window.aiModalOrchestrator) {
            window.aiModalOrchestrator.switchTab('chat');
        }

        const convSelector = document.getElementById('ai-conversation-selector');
        const messages = document.getElementById('ai-messages');

        if (convSelector) convSelector.style.display = 'block';
        if (messages) messages.style.display = 'none';

        // Update the character name in the header
        const charNameEl = document.getElementById('conversation-character-name');
        if (charNameEl) charNameEl.textContent = character.character_name;

        // Load conversations for this character
        this.loadCharacterConversations(character.character_name);
    }

    // Load conversations for a specific character
    loadCharacterConversations(characterName) {
        // Filter conversations by character name
        if (this.modal && this.modal.modules && this.modal.modules.conversationManager) {
            const convManager = this.modal.modules.conversationManager;
            const characterConversations = convManager.conversations.filter(conv =>
                conv.character_name === characterName
            );

            this.updateCharacterConversationsUI(characterConversations);
        }
    }

    // Update the character conversations UI
    updateCharacterConversationsUI(conversations) {
        const container = document.getElementById('ai-character-conversations');
        if (!container) return;

        if (!conversations || conversations.length === 0) {
            container.innerHTML = '<div class="no-conversations">No conversations yet. Start a new one!</div>';
            return;
        }

        container.innerHTML = conversations.map(conversation => this.createCharacterConversationItem(conversation)).join('');

        // Bind click events after DOM has settled
        requestAnimationFrame(() => this.bindCharacterConversationEvents());
    }

    // Create HTML for character conversation item
    createCharacterConversationItem(conversation) {
        const timestamp = this.formatConversationTime(conversation.updated_at);
        const preview = conversation.preview || 'Start a new conversation...';

        return `
            <div class="character-conversation-item" data-conversation-id="${conversation.id}">
                <div class="conversation-title">${conversation.title || 'Untitled Conversation'}</div>
                <div class="conversation-time">${timestamp}</div>
                <div class="conversation-preview">${preview}</div>
            </div>
        `;
    }

    // Bind events for character conversation items
    bindCharacterConversationEvents() {
        document.querySelectorAll('.character-conversation-item').forEach(item => {
            item.addEventListener('click', () => {
                const conversationId = item.dataset.conversationId;
                this.startConversation(conversationId);
            });
        });
    }

    // Start a conversation (switch to chat mode)
    startConversation(conversationId = null) {
        // Ensure we're on the chat tab
        if (window.aiModalOrchestrator) {
            window.aiModalOrchestrator.switchTab('chat');
        }

        const convSelector = document.getElementById('ai-conversation-selector');
        const messages = document.getElementById('ai-messages');

        if (convSelector) convSelector.style.display = 'none';
        if (messages) messages.style.display = 'block';

        // If conversation ID provided, load it
        if (conversationId && this.modal && this.modal.modules && this.modal.modules.conversationManager) {
            this.modal.modules.conversationManager.selectConversation(conversationId);
        } else {
            // Start new conversation
            if (this.modal && this.modal.modules && this.modal.modules.conversationManager) {
                this.modal.modules.conversationManager.startNewConversation();
            }
        }
    }

    // Update active character indicator
    updateActiveCharacterIndicator() {
        const indicator = document.getElementById('ai-character-indicator');
        if (!indicator) return;

        if (this.activeCharacter) {
            indicator.style.display = 'block';
            const name = indicator.querySelector('#active-character-name');

            if (name) name.textContent = this.activeCharacter.character_name;
        } else {
            indicator.style.display = 'none';
        }

        // Also update the main AI button indicator
        this.updateMainButtonIndicator();
    }

    // Update the main AI button indicator
    updateMainButtonIndicator() {
        const mainIndicator = document.getElementById('ai-active-character-indicator');
        const mainAvatar = document.getElementById('ai-active-character-avatar');

        if (!mainIndicator || !mainAvatar) return;

        if (this.activeCharacter) {
            mainIndicator.style.display = 'flex';
            mainAvatar.src = this.activeCharacter.avatar_url || '/static/default_avatars/smile_1.png';
        } else {
            mainIndicator.style.display = 'none';
        }
    }

    // Populate main settings from character
    populateMainSettingsFromCharacter(character) {
        if (!character) {
            // Reset to defaults
            this.setValue('ai-custom-instructions', '');
            this.setValue('ai-system-prompt', '');
            return;
        }

        this.setValue('ai-custom-instructions', character.ai_custom_instructions || '');
        this.setValue('ai-system-prompt', character.ai_system_prompt || '');
    }

    // Show edit character modal
    showEditCharacterModal(characterName) {
        const character = this.characters.find(c => c.character_name === characterName);
        if (!character) return;

        // Remove any existing edit modal first
        const existingModal = document.getElementById('edit-character-modal');
        if (existingModal) {
            existingModal.remove();
        }

        const avatarUrl = this.getCacheBustedAvatarUrl(character.avatar_url);
        const modalHTML = `
            <div id="edit-character-modal" class="modal" style="z-index: 9999;">
                <div class="modal-content">
                <div class="modal-header">
                    <h2>Edit Character: ${character.character_name}</h2>
                    <button class="close-modal">close</button>
                </div>
                    <div class="modal-body">
                        <form id="edit-character-form">
                            <div class="form-group">
                                <label for="edit-character-name">Character Name *</label>
                                <input type="text" id="edit-character-name" name="character_name" value="${character.character_name}" required>
                            </div>
                            <div class="form-group">
                                <label for="edit-character-description">Description</label>
                                <textarea id="edit-character-description" name="character_description" rows="3">${character.character_description || ''}</textarea>
                            </div>
                            <div class="form-group">
                                <label for="edit-character-avatar">Avatar</label>
                                <input type="file" id="edit-character-avatar" name="avatar" accept="image/*">
                                <small>Upload a new image or leave blank to keep current avatar</small>
                                ${character.avatar_url ? `<div><img src="${avatarUrl}" alt="Current avatar" style="max-width: 100px; max-height: 100px; border-radius: 50%;"></div>` : ''}
                            </div>
                            <div class="form-group">
                                <label for="edit-character-system-prompt">System Prompt</label>
                                <textarea id="edit-character-system-prompt" name="ai_system_prompt" rows="3" placeholder="You are a helpful AI assistant...">${character.ai_system_prompt || ''}</textarea>
                            </div>
                            <div class="form-group">
                                <label for="edit-character-custom-instructions">Custom Instructions</label>
                                <textarea id="edit-character-custom-instructions" name="ai_custom_instructions" rows="3" placeholder="Additional instructions for this character...">${character.ai_custom_instructions || ''}</textarea>
                            </div>
                            <div class="form-group">
                                <label for="edit-character-temperature">Temperature</label>
                                <input type="number" id="edit-character-temperature" name="ai_temperature" min="0" max="2" step="0.1" value="${character.ai_temperature || 0.7}">
                            </div>
                            <div class="form-group">
                                <label for="edit-character-max-tokens">Max Tokens</label>
                                <input type="number" id="edit-character-max-tokens" name="ai_max_tokens" min="1" max="32768" value="${character.ai_max_tokens || 2048}">
                            </div>
                            <div class="form-actions">
                                <button type="button" class="btn btn-secondary" onclick="this.closest('.modal').remove()">Cancel</button>
                                <button type="submit" class="btn btn-primary">Update Character</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHTML);

        const modal = document.getElementById('edit-character-modal');
        const form = document.getElementById('edit-character-form');

        // Show the modal
        modal.style.display = 'block';

        // Bind events
        modal.querySelector('.close-modal').addEventListener('click', () => modal.remove());
        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.remove();
        });

        form.addEventListener('submit', (e) => {
            e.preventDefault();

            // Check if avatar file looks like a thumbnail
            const avatarInput = document.getElementById('edit-character-avatar');
            if (avatarInput && avatarInput.files.length > 0) {
                const filename = avatarInput.files[0].name;
                if (filename.toLowerCase().includes('_thumb')) {
                    this.showEditCharacterStatus('Please select the original image file, not a thumbnail file (files ending in _thumb.jpg)', 'error');
                    return;
                }
            }

            this.updateCharacter(character.character_name);
        });
    }

    // Update existing character
    updateCharacter(oldCharacterName) {
        const form = document.getElementById('edit-character-form');
        if (!form) return;

        const formData = new FormData(form);
        const characterData = {};

        console.log('DEBUG: Building characterData from form');

        // First, process all form data except avatar
        for (let [key, value] of formData.entries()) {
            if (key !== 'avatar') {
                characterData[key] = value;
            }
        }

        // Handle avatar conversion to base64
        const avatarInput = document.getElementById('edit-character-avatar');
        if (avatarInput && avatarInput.files.length > 0) {
            const file = avatarInput.files[0];
            console.log(`DEBUG: Converting avatar file to base64: ${file.name}, size: ${file.size}`);

            const reader = new FileReader();
            reader.onload = (e) => {
                characterData['avatar'] = e.target.result; // This will be the base64 data URL
                characterData['avatar_filename'] = file.name;
                this.finishUpdateCharacter(characterData, oldCharacterName);
            };
            reader.readAsDataURL(file);
            return; // Wait for the file to be read
        } else {
            // No avatar file, proceed normally
            this.finishUpdateCharacter(characterData, oldCharacterName);
        }
    }

    // Finish updating character (called after avatar processing)
    finishUpdateCharacter(characterData, oldCharacterName) {
        console.log('DEBUG: Final characterData keys:', Object.keys(characterData));

        // Validate required fields
        if (!characterData.character_name?.trim()) {
            this.showEditCharacterStatus('Character name is required', 'error');
            return;
        }

        // Check for duplicate names (excluding the current character)
        if (this.characters.some(c => c.character_name.toLowerCase() === characterData.character_name.toLowerCase() && c.character_name !== oldCharacterName)) {
            this.showEditCharacterStatus('Character name already exists', 'error');
            return;
        }

        this.showEditCharacterStatus('Updating character...', 'info');

        console.log('DEBUG: Sending ai_update_character with data:', {
            character_keys: Object.keys(characterData),
            original_name: oldCharacterName,
            has_avatar: 'avatar' in characterData
        });

        if (typeof socket !== 'undefined') {
            socket.emit('ai_update_character', {
                character: characterData,
                original_name: oldCharacterName
            });

            // Listen for response
            socket.once('ai_character_updated', (data) => {
                if (data.success || data.character) {
                    this.showEditCharacterStatus('Character updated successfully!', 'success');
                    document.getElementById('edit-character-modal').remove();

                    // Update the character in our local array
                    if (data.character) {
                        const index = this.characters.findIndex(c => c.character_name === data.character.character_name);
                        if (index !== -1) {
                            this.characters[index] = data.character;
                        }
                    }

                    // Refresh the character tiles to show updated avatar
                    this.renderCharacterSections(this.characters, 'ai-character-tiles', true);

                    // Update active character indicator if this was the active character
                    if (this.activeCharacter && this.activeCharacter.character_name === data.character.character_name) {
                        this.activeCharacter = data.character;
                        this.updateActiveCharacterIndicator();
                        if (window.aiModalOrchestrator) {
                            window.aiModalOrchestrator.updateActiveCharacterDisplay(data.character);
                        }
                    }
                } else {
                    this.showEditCharacterStatus(data.message || 'Failed to update character', 'error');
                }
            });

            socket.once('ai_character_update_error', (data) => {
                console.log('DEBUG: Received ai_character_update_error:', data);
                this.showEditCharacterStatus(data.msg || 'Failed to update character', 'error');
            });
        }
    }

    // Show edit character status
    showEditCharacterStatus(message, type = 'info') {
        const modal = document.getElementById('edit-character-modal');
        if (!modal) return;

        let statusEl = modal.querySelector('.character-status');
        if (!statusEl) {
            const form = modal.querySelector('#edit-character-form');
            if (form) {
                statusEl = document.createElement('div');
                statusEl.className = 'character-status';
                form.appendChild(statusEl);
            }
        }

        if (statusEl) {
            statusEl.textContent = message;
            statusEl.className = `character-status ${type}`;
        }
    }

    // Delete character
    deleteCharacter(characterName) {
        const character = this.characters.find(c => c.character_name === characterName);
        if (!character) return;

        // Don't allow deletion of built-in characters
        if (character.character_type === 'builtin') {
            alert('Built-in characters cannot be deleted.');
            return;
        }

        if (!confirm(`Are you sure you want to delete the character "${characterName}"? This action cannot be undone.`)) {
            return;
        }

        if (typeof socket !== 'undefined') {
            socket.emit('ai_delete_character', { character_name: characterName });

            // Listen for response
            socket.once('ai_character_deleted', (data) => {
                if (data.success) {
                    // If the deleted character was active, clear it
                    if (this.activeCharacter && this.activeCharacter.character_name === characterName) {
                        this.clearActiveCharacter();
                    }
                    this.loadCharacters(); // Refresh the list
                } else {
                    alert(data.message || 'Failed to delete character');
                }
            });
        }
    }

    // Load character data for editing
    loadCharacterData(character) {
        // This would be called when editing a character
        // Implementation would populate edit form
    }

    // Show create character modal
    showCreateCharacterModal() {
        // Remove any existing create modal first
        const existingModal = document.getElementById('create-character-modal');
        if (existingModal) {
            existingModal.remove();
        }

        const modalHTML = `
            <div id="create-character-modal" class="modal" style="z-index: 9999;">
                <div class="modal-content">
                <div class="modal-header">
                    <h2>Create New Character</h2>
                    <button class="close-modal">close</button>
                </div>
                    <div class="modal-body">
                        <form id="create-character-form">
                            <div class="form-group">
                                <label for="character-name">Character Name *</label>
                                <input type="text" id="character-name" name="character_name" required>
                            </div>
                            <div class="form-group">
                                <label for="character-description">Description</label>
                                <textarea id="character-description" name="character_description" rows="3"></textarea>
                            </div>
                            <div class="form-group">
                                <label for="character-avatar">Avatar</label>
                                <input type="file" id="character-avatar" name="avatar" accept="image/*">
                                <small>Upload an image or leave blank to use default avatar</small>
                            </div>
                            <div class="form-group">
                                <label for="character-system-prompt">System Prompt</label>
                                <textarea id="character-system-prompt" name="ai_system_prompt" rows="3" placeholder="You are a helpful AI assistant..."></textarea>
                            </div>
                            <div class="form-group">
                                <label for="character-custom-instructions">Custom Instructions</label>
                                <textarea id="character-custom-instructions" name="ai_custom_instructions" rows="3" placeholder="Additional instructions for this character..."></textarea>
                            </div>
                            <div class="form-group">
                                <label for="character-temperature">Temperature</label>
                                <input type="number" id="character-temperature" name="ai_temperature" min="0" max="2" step="0.1" value="0.7">
                            </div>
                            <div class="form-group">
                                <label for="character-max-tokens">Max Tokens</label>
                                <input type="number" id="character-max-tokens" name="ai_max_tokens" min="1" max="32768" value="2048">
                            </div>
                            <div class="form-actions">
                                <button type="button" class="btn btn-secondary" onclick="this.closest('.modal').remove()">Cancel</button>
                                <button type="submit" class="btn btn-primary">Create Character</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHTML);

        const modal = document.getElementById('create-character-modal');
        const form = document.getElementById('create-character-form');

        // Show the modal
        modal.style.display = 'block';

        // Bind events
        modal.querySelector('.close-modal').addEventListener('click', () => modal.remove());
        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.remove();
        });

        form.addEventListener('submit', (e) => {
            e.preventDefault();

            // Check if avatar file looks like a thumbnail
            const avatarInput = document.getElementById('character-avatar');
            if (avatarInput && avatarInput.files.length > 0) {
                const filename = avatarInput.files[0].name;
                if (filename.toLowerCase().includes('_thumb')) {
                    this.showCreateCharacterStatus('Please select the original image file, not a thumbnail file (files ending in _thumb.jpg)', 'error');
                    return;
                }
            }

            this.createCharacter();
        });
    }

    // Create new character
    createCharacter() {
        const form = document.getElementById('create-character-form');
        if (!form) return;

        const formData = new FormData(form);
        const characterData = {};

        console.log('DEBUG: Building characterData from create form');

        // First, process all form data except avatar
        for (let [key, value] of formData.entries()) {
            if (key !== 'avatar') {
                characterData[key] = value;
            }
        }

        // Handle avatar conversion to base64
        const avatarInput = document.getElementById('character-avatar');
        if (avatarInput && avatarInput.files.length > 0) {
            const file = avatarInput.files[0];
            console.log(`DEBUG: Converting avatar file to base64: ${file.name}, size: ${file.size}`);

            const reader = new FileReader();
            reader.onload = (e) => {
                characterData['avatar'] = e.target.result; // This will be the base64 data URL
                characterData['avatar_filename'] = file.name;
                this.finishCreateCharacter(characterData);
            };
            reader.readAsDataURL(file);
            return; // Wait for the file to be read
        } else {
            // No avatar file, proceed normally
            this.finishCreateCharacter(characterData);
        }
    }

    // Finish creating character (called after avatar processing)
    finishCreateCharacter(characterData) {
        console.log('DEBUG: Final characterData keys:', Object.keys(characterData));

        // Validate required fields
        if (!characterData.character_name?.trim()) {
            this.showCreateCharacterStatus('Character name is required', 'error');
            return;
        }

        // Check for duplicate names
        if (this.characters.some(c => c.character_name.toLowerCase() === characterData.character_name.toLowerCase())) {
            this.showCreateCharacterStatus('Character name already exists', 'error');
            return;
        }

        if (typeof socket !== 'undefined') {
            socket.emit('ai_create_character', { character: characterData });

            // Listen for response
            socket.once('ai_character_created', (data) => {
                if (data.character && data.character.character_name) {
                    this.showCreateCharacterStatus('Character created successfully!', 'success');
                    document.getElementById('create-character-modal').remove();
                    this.loadCharacters(); // Refresh the list
                } else {
                    this.showCreateCharacterStatus(data.message || 'Failed to create character', 'error');
                }
            });

            socket.once('ai_character_create_error', (data) => {
                this.showCreateCharacterStatus(data.msg || 'Failed to create character', 'error');
            });
        }
    }

    // Show create character status
    showCreateCharacterStatus(message, type = 'info') {
        const modal = document.getElementById('create-character-modal');
        if (!modal) return;

        let statusEl = modal.querySelector('.character-status');
        if (!statusEl) {
            const form = modal.querySelector('#create-character-form');
            if (form) {
                statusEl = document.createElement('div');
                statusEl.className = 'character-status';
                form.appendChild(statusEl);
            }
        }

        if (statusEl) {
            statusEl.textContent = message;
            statusEl.className = `character-status ${type}`;
        }
    }

    // Utility method to set form values
    setValue(elementId, value) {
        const element = document.getElementById(elementId);
        if (element) {
            element.value = value;
        }
    }

    // Update character select options in settings modal
    updateCharacterSelectOptions(characters) {
        const select = document.getElementById('ai-active-character');
        if (!select) return;

        // Clear existing options
        select.innerHTML = '<option value="">No character selected (use defaults)</option>';

        // Add character options
        characters.forEach(character => {
            const option = document.createElement('option');
            option.value = character.character_name;
            option.textContent = `${character.character_type === 'builtin' ? '🤖 ' : ''}${character.character_name}`;
            option.title = character.character_description || '';
            select.appendChild(option);
        });

        // Set the current active character if one exists
        if (this.activeCharacter) {
            select.value = this.activeCharacter.character_name;
        }
    }

    // Format conversation timestamp
    formatConversationTime(timestamp) {
        if (!timestamp) return '';

        const date = new Date(timestamp);
        const now = new Date();
        const diffMs = now - date;
        const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

        if (diffDays === 0) {
            return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        } else if (diffDays === 1) {
            return 'Yesterday';
        } else if (diffDays < 7) {
            return date.toLocaleDateString([], { weekday: 'short' });
        } else {
            return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
        }
    }

    // Handle active character change
    onActiveCharacterChanged() {
        const select = document.getElementById('ai-active-character');
        if (!select) return;

        const characterName = select.value;
        if (characterName) {
            this.selectCharacter(characterName);
        } else {
            this.clearActiveCharacter();
        }
    }
}