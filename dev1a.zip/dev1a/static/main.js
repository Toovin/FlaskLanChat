// main.js - Entry point for the application
import { state, socket } from './core/setup.js';
import { showError } from './core/ui-utils.js';
import { updateUserInfo, updateGeneralMemberList } from './core/member-list.js';
import { setupModalCloseHandlers } from './core/modal-utils.js';
import { openUserProfileModal, closeUserProfileModal, setupProfileModalEvents } from './core/profile-modal.js';



// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
});

function initializeApp() {
    const appContainer = document.getElementById('app-container');
    const loginModal = document.getElementById('login-modal');
    const loadingSpinner = document.getElementById('loading-spinner');

    if (!appContainer || !loginModal || !loadingSpinner) {
        console.error('Core elements not found');
        showError('Failed to initialize UI. Please refresh.');
        return;
    }

    // Setup UI
    appContainer.classList.remove('visible');
    loginModal.style.display = 'flex';
    loadingSpinner.style.display = 'none';

    // Setup modal handlers
    setupProfileModalEvents();
    setupModalCloseHandlers('user-notes-modal', window.closeUserNotesModal);

    // Setup socket events (this would need to be implemented)
    // setupSocketEvents();

// Make functions globally available for HTML onclick attributes
    window.openUserProfileModal = openUserProfileModal;
    window.closeUserProfileModal = closeUserProfileModal;
    window.showError = showError;

}