// Sound Manager for UI sound effects
class SoundManager {
    constructor() {
        this.audioCache = new Map();
        this.audioContext = null; // For Web Audio API
        this.enabled = true; // Default to enabled
        this.volume = 0.5; // Default volume
        this.soundboardEnabled = true; // Default soundboard sounds to enabled
        this.soundboardVolume = 1.0; // Default soundboard volume
        this.pendingSounds = [];
        console.log('SoundManager created, enabled by default');
    }

    // Initialize sound manager with user settings
    init(settings = {}) {
        this.enabled = settings.sound_effects !== false; // Default to enabled
        this.volume = settings.sound_volume || 0.5;
        this.soundboardEnabled = settings.soundboard_sounds !== false; // Default to enabled
        this.soundboardVolume = settings.soundboard_volume || 1.0;
        console.log('SoundManager initialized:', { enabled: this.enabled, volume: this.volume, soundboardEnabled: this.soundboardEnabled, soundboardVolume: this.soundboardVolume });
        this.unlockAudioContext();
    }

    // Unlock AudioContext for autoplay
    unlockAudioContext() {
        if (!this.audioContext) {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }
        if (this.audioContext.state === 'suspended') {
            this.audioContext.resume();
        }
        this.audioUnlocked = true;
    }

    // Update settings
    updateSettings(settings) {
        if (settings.sound_effects !== undefined) {
            this.enabled = settings.sound_effects;
        }
        if (settings.sound_volume !== undefined) {
            this.volume = settings.sound_volume;
        }
        if (settings.soundboard_sounds !== undefined) {
            this.soundboardEnabled = settings.soundboard_sounds;
        }
        if (settings.soundboard_volume !== undefined) {
            this.soundboardVolume = settings.soundboard_volume;
        }
    }

    // Load and cache audio file
    async loadSound(soundName) {
        if (this.audioCache.has(soundName)) {
            return this.audioCache.get(soundName);
        }

        try {
            const audio = new Audio(`/static/sounds/${soundName}.mp3`);
            audio.volume = this.volume;
            audio.preload = 'auto';

            // Cache the audio element
            this.audioCache.set(soundName, audio);
            return audio;
        } catch (error) {
            console.warn(`Failed to load sound: ${soundName}`, error);
            return null;
        }
    }

    // Play a sound effect
    async play(soundName) {
        console.log(`SoundManager.play called: ${soundName}, enabled: ${this.enabled}`);
        if (!this.enabled) {
            console.log('Sound disabled, skipping');
            return;
        }

        try {
            const audio = await this.loadSound(soundName);
            if (audio) {
                // Clone the audio to allow overlapping sounds
                const audioClone = audio.cloneNode();
                audioClone.volume = this.volume;
                audioClone.currentTime = 0;

                console.log(`Playing sound: ${soundName}`);
                // Play the sound
                const playPromise = audioClone.play();
                if (playPromise !== undefined) {
                    playPromise.then(() => {
                        console.log(`Sound played successfully: ${soundName}`);
                    }).catch(error => {
                        console.warn(`Failed to play sound: ${soundName}`, error);
                        // Try to play on user interaction if autoplay is blocked
                        if (error.name === 'NotAllowedError') {
                            console.log('Autoplay blocked, will try on next user interaction');
                            this.pendingSounds = this.pendingSounds || [];
                            this.pendingSounds.push(soundName);
                        }
                    });
                }
            } else {
                console.warn(`Failed to load sound: ${soundName}`);
            }
        } catch (error) {
            console.warn(`Error playing sound: ${soundName}`, error);
        }
    }

    // Predefined sound effects
    async playClick() {
        await this.play('pop_1');
    }

    async playSuccess() {
        await this.play('Accept_Ok');
    }

    async playError() {
        await this.play('General_Error');
    }

    async playMessage() {
        await this.play('Blip_1');
    }

    async playNotification() {
        await this.play('Blip_2');
    }

    // Play a soundboard sound using Web Audio API to bypass autoplay restrictions
    async playSoundboard(soundFile) {
        console.log(`SoundManager.playSoundboard called: ${soundFile}, enabled: ${this.soundboardEnabled}`);
        if (!this.soundboardEnabled) {
            console.log('Soundboard sounds disabled, skipping');
            return;
        }

        try {
            // Initialize AudioContext if not already done
            if (!this.audioContext) {
                this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
                // Resume context if suspended (required by some browsers)
                if (this.audioContext.state === 'suspended') {
                    await this.audioContext.resume();
                }
            }

            // Fetch and decode audio
            const response = await fetch(`/static/sounds/sound_board/${soundFile}`);
            const arrayBuffer = await response.arrayBuffer();
            const audioBuffer = await this.audioContext.decodeAudioData(arrayBuffer);

            // Create source and play
            const source = this.audioContext.createBufferSource();
            source.buffer = audioBuffer;

            // Create gain node for volume control
            const gainNode = this.audioContext.createGain();
            gainNode.gain.value = this.soundboardVolume;

            // Connect nodes
            source.connect(gainNode);
            gainNode.connect(this.audioContext.destination);

            // Play the sound
            source.start(0);
            console.log(`Soundboard sound played successfully: ${soundFile}`);

        } catch (error) {
            console.warn(`Error playing soundboard sound: ${soundFile}`, error);
            // Fallback to regular Audio if Web Audio API fails
            try {
                const audio = new Audio(`/static/sounds/sound_board/${soundFile}`);
                audio.volume = this.soundboardVolume;
                audio.preload = 'auto';

                const playPromise = audio.play();
                if (playPromise !== undefined) {
                    playPromise.then(() => {
                        console.log(`Soundboard sound played successfully (fallback): ${soundFile}`);
                    }).catch(fallbackError => {
                        console.warn(`Failed to play soundboard sound (fallback): ${soundFile}`, fallbackError);
                    });
                }
            } catch (fallbackError) {
                console.warn(`Error in fallback playing soundboard sound: ${soundFile}`, fallbackError);
            }
        }
    }
}

// Create global sound manager instance
window.soundManager = new SoundManager();

// Add user interaction listener to handle autoplay blocking and unlock AudioContext
const unlockHandler = () => {
    if (window.soundManager) {
        window.soundManager.unlockAudioContext();
        if (window.soundManager.pendingSounds && window.soundManager.pendingSounds.length > 0) {
            console.log('User interacted, playing pending sounds');
            const pending = [...window.soundManager.pendingSounds];
            window.soundManager.pendingSounds = [];
            pending.forEach(soundName => {
                if (soundName.startsWith('soundboard_')) {
                    const soundFile = soundName.replace('soundboard_', '');
                    window.soundManager.playSoundboard(soundFile);
                } else {
                    window.soundManager.play(soundName);
                }
            });
        }
    }
};

document.addEventListener('click', unlockHandler);
document.addEventListener('touchstart', unlockHandler);