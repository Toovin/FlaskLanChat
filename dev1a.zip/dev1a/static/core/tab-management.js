// core/tab-management.js
import { state } from './setup.js';

export function updateChannelHeader(channel) {
    const channelTab = document.querySelector('.tab[data-tab="channel"] span');
    const channelDescription = document.querySelector('.channel-description');
    if (channelTab) channelTab.textContent = 'Chat';
    if (channelDescription) channelDescription.textContent = '';
}

export function setActiveTab(tabName) {
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        tab.classList.toggle('active', tab.dataset.tab === tabName);
    });
}

// Initial call
updateChannelHeader(state.currentChannel);