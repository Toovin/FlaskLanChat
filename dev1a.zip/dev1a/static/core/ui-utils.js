// core/ui-utils.js
export function showError(message) {
    console.log('Showing error:', message);

    // Clear any existing timeout
    if (window.errorTimeout) {
        clearTimeout(window.errorTimeout);
    }

    let errorDiv = document.getElementById('error-message');
    if (!errorDiv) {
        console.warn('Error div not found, creating new one');
        errorDiv = document.createElement('div');
        errorDiv.id = 'error-message';
        errorDiv.style.cssText = `
            position: fixed;
            top: 10px;
            right: 10px;
            background: #dc3545;
            color: white;
            padding: 10px;
            z-index: 10000;
            box-shadow: 0 4px 8px rgba(0,0,0,0.5);
            pointer-events: auto;
            font-weight: bold;
            border: 2px solid #fff;
        `;
        document.body.appendChild(errorDiv);
    }

    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
    errorDiv.style.zIndex = '10000';
    errorDiv.style.pointerEvents = 'auto';

    window.errorTimeout = setTimeout(() => {
        console.log('Hiding error after timeout');
        errorDiv.style.display = 'none';
    }, 5000);
}

export function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

export function randomColor() {
    const colors = ['7289DA', '43B581', 'FAA61A', 'F04747'];
    return colors[Math.floor(Math.random() * colors.length)];
}