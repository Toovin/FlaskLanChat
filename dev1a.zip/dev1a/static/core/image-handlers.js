// core/image-handlers.js
import { showError } from './ui-utils.js';

/**
 * Handle general image-related UI events
 */
export function handleImageEvents() {
    document.addEventListener('click', function(e) {
        if (e.target.id === 'img2img-clear-images-btn') {
            const imageInput = document.getElementById('img2img-image-input');
            if (imageInput) {
                imageInput.value = '';
                console.log('Cleared uploaded images');
            } else {
                showError('Image input not found');
            }

            // Also clear the preview
            const previewContainer = document.getElementById('img2img-preview-container');
            const previewImage = document.getElementById('img2img-preview-image');
            if (previewContainer) {
                previewContainer.style.display = 'none';
            }
            if (previewImage) {
                previewImage.src = '';
            }
        }
    });
}