// core/member-list.js
import { escapeHtml, showError } from './ui-utils.js';
import { state } from './setup.js';
import { getAvatarUrl, getDisplayName, getStatusText } from './user-utils.js';
import { openUserProfileModal } from './profile-modal.js';

/**
 * Updates the current user's info displayed in the UI
 */
export function updateUserInfo() {
    const userInfos = document.querySelectorAll('.user-info');
    if (userInfos.length === 0) {
        console.error('User info elements not found');
        showError('User info elements not found. Please refresh.');
        return;
    }

    // Get display name using shared helper
    const displayName = getDisplayName(null, true);

    // Get status from settings or default to online
    const status = window.currentUserSettings?.status || 'online';
    const statusText = getStatusText(status);

    // Get avatar using shared helper
    const avatarUrl = getAvatarUrl(null, true);



    userInfos.forEach(userInfo => {
        const usernameElement = userInfo.querySelector('.username');
        const statusElement = userInfo.querySelector('.status');
        const avatarElement = userInfo.querySelector('.avatar img');
        const statusDot = userInfo.querySelector('.status-dot');

        if (usernameElement) usernameElement.textContent = displayName;
        if (statusElement) statusElement.textContent = statusText;
        if (avatarElement) {

            avatarElement.src = avatarUrl;
        }
        if (statusDot) {
            statusDot.className = 'status-dot ' + status;
        }
    });
}

/**
 * Updates the member list in the chat sidebar
 */
export function updateGeneralMemberList() {
    // Use the correct selectors matching the original core.js
    const memberHeader = document.querySelector('.chat-members-section .member-header h3');
    const memberGroup = document.getElementById('chat-members-list');

    if (!memberHeader || !memberGroup) {
        console.error('Member header or group not found:', { memberHeader, memberGroup });
        showError('Member list elements not found. Please refresh.');
        return;
    }

    const users = Object.values(state.users_db || {});

    // Sort users: online first, then offline
    const sortedUsers = users.sort((a, b) => {
        const aDisplayName = getDisplayName(a);
        const bDisplayName = getDisplayName(b);
        const aIsOnline = state.onlineUsers && state.onlineUsers.includes(aDisplayName);
        const bIsOnline = state.onlineUsers && state.onlineUsers.includes(bDisplayName);

        // Online users come first
        if (aIsOnline && !bIsOnline) return -1;
        if (!aIsOnline && bIsOnline) return 1;

        // Within same status group, sort alphabetically by display name
        return aDisplayName.localeCompare(bDisplayName);
    });

    memberHeader.textContent = `MEMBERS - ${users.length}`;
    memberGroup.innerHTML = '';

    let hasAddedOnlineHeader = false;
    let hasAddedSeparator = false;

    sortedUsers.forEach((user, index) => {
        const displayName = getDisplayName(user);
        const isOnline = state.onlineUsers && state.onlineUsers.includes(displayName);

        // Add "Online" header before first online member
        if (!hasAddedOnlineHeader && isOnline) {
            const onlineHeader = document.createElement('div');
            onlineHeader.className = 'member-online-header';
            onlineHeader.innerHTML = '<span>ONLINE</span>';
            memberGroup.appendChild(onlineHeader);
            hasAddedOnlineHeader = true;
        }

        // Add separator between online and offline sections
        if (!hasAddedSeparator && index > 0) {
            const prevUser = sortedUsers[index - 1];
            const prevDisplayName = getDisplayName(prevUser);
            const prevIsOnline = state.onlineUsers && state.onlineUsers.includes(prevDisplayName);

            if (prevIsOnline && !isOnline) {
                // Add separator between last online and first offline
                const separator = document.createElement('div');
                separator.className = 'member-separator';
                separator.innerHTML = '<span>OFFLINE</span>';
                memberGroup.appendChild(separator);
                hasAddedSeparator = true;
            }
        }

        const avatarUrl = getAvatarUrl(user);
        // Show custom status instead of online/offline
        const customStatus = user.custom_status && user.custom_status.trim() !== '' ? user.custom_status : '';
        const statusClass = state.onlineUsers && state.onlineUsers.includes(displayName) ? (user.status || 'online') : 'offline';

        const member = document.createElement('div');
        member.className = 'member' + (state.onlineUsers && state.onlineUsers.includes(displayName) ? ' online' : '');

        member.innerHTML = `
            <div class="member-avatar">
                <img src="${avatarUrl}" alt="Avatar" class="${state.onlineUsers && state.onlineUsers.includes(displayName) ? '' : 'offline'}">
                <div class="status-dot ${statusClass}"></div>
            </div>
            <div class="member-info">
                <span class="member-name">${escapeHtml(displayName)}</span>
                <span class="member-status" title="${escapeHtml(customStatus)}">${escapeHtml(customStatus)}</span>
            </div>
        `;

        // Add click event to open user profile modal
        member.addEventListener('click', () => {
            openUserProfileModal(user);
        });

        memberGroup.appendChild(member);
    });
}

// Make function globally available for real-time updates
window.updateGeneralMemberList = updateGeneralMemberList;