// core/init.js
import { state, initializeUI } from './setup.js';
import { showError } from './ui-utils.js';
import { updateChannelHeader } from './tab-management.js';
import { handleImageEvents } from './image-handlers.js';
import { setupProfileModalEvents } from './profile-modal.js';

import { createNewNote, saveCurrentNote, closeUserNotesModal } from '../user-notes.js';  // Assume exists

// Debug function to check CSS custom properties and particle system
function debugCSSProperties() {
    const root = document.documentElement;
    const computedStyle = getComputedStyle(root);

    const properties = [
        '--font-family',
        '--font-scale',
        '--bg-primary',
        '--text-primary'
    ];

    console.log('=== CSS Custom Properties Debug ===');
    properties.forEach(prop => {
        const value = computedStyle.getPropertyValue(prop);
        console.log(`${prop}: "${value}"`);
    });

    // Check particle elements
    const particles = document.querySelectorAll('[id^="pasta"]');
    console.log('Particle elements found:', particles.length);
    if (particles.length > 0) {
        console.log('First particle styles:', getComputedStyle(particles[0]));
    }

    // Check if any canvas exists
    const canvases = document.querySelectorAll('canvas');
    console.log('Canvas elements found:', canvases.length);

    // Check font loading
    document.fonts.ready.then(() => {
        console.log('Fonts loaded, available fonts:');
        document.fonts.forEach(font => console.log(font.family, font.status));
    });
}

document.addEventListener('DOMContentLoaded', () => {
    // Initialize UI
    initializeUI(showError);

    // Update channel header using state instead of window
    updateChannelHeader(state.currentChannel);

    // Setup event handlers
    handleImageEvents();
    setupProfileModalEvents();

    // Setup note-related event handlers
    setupNoteEventHandlers();

    // Setup notes modal close handlers
    setupNotesModalHandlers();

    // Apply saved font preference immediately if available
    const savedFont = window.currentUserSettings?.font;
    if (savedFont) {
        applyFont(savedFont);
    }

    // Debug CSS properties after a short delay
    setTimeout(debugCSSProperties, 1000);
});

/**
 * Setup note button event handlers
 */
function setupNoteEventHandlers() {
    const newNoteBtn = document.getElementById('new-note-btn');
    if (newNoteBtn) {
        newNoteBtn.addEventListener('click', createNewNote);
    }

    const saveNoteBtn = document.getElementById('save-note-btn');
    if (saveNoteBtn) {
        saveNoteBtn.addEventListener('click', saveCurrentNote);
    }
}

/**
 * Setup notes modal close handlers (click outside and Escape key)
 */
function setupNotesModalHandlers() {
    const noteModal = document.getElementById('user-notes-modal');
    if (!noteModal) {
        console.warn('Notes modal not found, skipping setup');
        return;
    }

    // Close on click outside
    window.addEventListener('click', function(event) {
        if (event.target === noteModal) {
            if (typeof closeUserNotesModal === 'function') {
                closeUserNotesModal();
            }
        }
    });

    // Close on Escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape' && noteModal.style.display === 'flex') {
            if (typeof closeUserNotesModal === 'function') {
                closeUserNotesModal();
            }
        }
    });
}