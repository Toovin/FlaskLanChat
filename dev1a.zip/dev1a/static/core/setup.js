// core/setup.js
export const socket = io(window.location.origin, {
    transports: ['websocket', 'polling'],
    reconnection: true,
    reconnectionAttempts: 10,
    reconnectionDelay: 1000,
    reconnectionDelayMax: 10000,
    timeout: 20000,
    withCredentials: true,
    forceNew: false,
    upgrade: true
});

// Global state (consider a state management object if globals grow)
export const state = {
    currentChannel: 'general',
    currentUsername: null,
    users_db: {},
    isAuthenticated: false,
    autoScrollEnabled: localStorage.getItem('autoScrollEnabled') !== 'false',
    selectedFile: null,
    onlineUsers: [],
    currentUserUuid: null,
    isAdmin: false,
    socketConnected: false
};

// Sync window globals
window.onlineUsers = state.onlineUsers;
window.socket = socket;
window.currentLatency = null;

// Track socket connection status
socket.on('connect', () => {
    console.log('Socket.IO connected');
    state.socketConnected = true;
    // Emit custom event for other modules to listen to
    window.dispatchEvent(new CustomEvent('socketConnected'));
});

socket.on('disconnect', () => {
    console.log('Socket.IO disconnected');
    state.socketConnected = false;
    // Emit custom event for other modules to listen to
    window.dispatchEvent(new CustomEvent('socketDisconnected'));
});

socket.on('connect_error', (error) => {
    console.error('Socket.IO connection error:', error);
    state.socketConnected = false;
    window.dispatchEvent(new CustomEvent('socketConnectionError', { detail: error }));
});

// Core DOM elements
export const elements = {
    appContainer: document.getElementById('app-container'),
    loginModal: document.getElementById('login-modal'),
    loadingSpinner: document.getElementById('loading-spinner')
};

// Initial UI setup
export function initializeUI(showError) {  // Pass showError to avoid circular dep
    const { appContainer, loginModal, loadingSpinner } = elements;
    if (!appContainer || !loginModal || !loadingSpinner) {
        console.error('Core elements not found:', { appContainer, loginModal, loadingSpinner });
        showError('Failed to initialize UI. Please refresh.');
        return false;
    }
    console.log('Initializing UI: showing login modal');
    appContainer.classList.remove('visible');
    loginModal.style.display = 'flex';
    loadingSpinner.style.display = 'none';

    // Handle server errors
    socket.on('error', (data) => {
        showError(data.msg);
    });

    return true;
}

// Handle user registration
socket.on('user_registered', (data) => {
    const { appContainer, loginModal, loadingSpinner } = elements;
    if (appContainer) {
        appContainer.classList.add('visible');
        appContainer.style.display = 'flex';
        console.log('App container made visible');
    }
    if (loginModal) {
        loginModal.classList.remove('active');
        console.log('Login modal hidden');
    }
    if (loadingSpinner) {
        loadingSpinner.style.display = 'none';
    }
    state.isAuthenticated = true;
    state.currentUserUuid = data.uuid;
    state.isAdmin = data.is_admin || false;
    const user = state.users_db[data.uuid];
    if (user) {
        state.currentUsername = user.username;
        window.currentUsername = user.username;
    }

    // Start user heartbeat to maintain online status
    startUserHeartbeat();
});

// User heartbeat to maintain online presence
function startUserHeartbeat() {
    // Send heartbeat every 30 seconds
    setInterval(() => {
        if (state.isAuthenticated) {
            socket.emit('user_heartbeat');
        }
    }, 30000);

    // Also send heartbeat on user activity (mouse move, key press, etc.)
    let activityTimeout;
    function sendActivityHeartbeat() {
        if (state.isAuthenticated) {
            socket.emit('user_heartbeat');
            clearTimeout(activityTimeout);
            activityTimeout = setTimeout(sendActivityHeartbeat, 30000);
        }
    }

    // Listen for user activity
    document.addEventListener('mousemove', sendActivityHeartbeat, { passive: true });
    document.addEventListener('keydown', sendActivityHeartbeat, { passive: true });
    document.addEventListener('click', sendActivityHeartbeat, { passive: true });
    document.addEventListener('scroll', sendActivityHeartbeat, { passive: true });
}