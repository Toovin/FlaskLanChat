// core/user-utils.js
// Shared user-related utility functions

import { state } from './setup.js';
import { showError } from './ui-utils.js';

/**
 * Get avatar URL for a user
 * @param {Object} user - User object
 * @param {boolean} isCurrentUser - Whether this is the current user
 * @returns {string} Avatar URL
 */
export function getAvatarUrl(user, isCurrentUser = false) {
    const avatarOptions = ['smile_1.png', 'smile_2.png', 'smile_3.png'];
    const defaultAvatar = isCurrentUser
        ? '/static/default_avatars/smile_1.png'
        : `/static/default_avatars/${avatarOptions[Math.floor(Math.random() * avatarOptions.length)]}`;

    if (isCurrentUser) {
        // Check settings first, then user db, then default
        return window.currentUserSettings?.avatar_url ||
               (Object.values(state.users_db).find(u => u.username === state.currentUsername)?.avatar_url) ||
               defaultAvatar;
    }
    return user.avatar_url || defaultAvatar;
}

/**
 * Get display name for a user
 * @param {Object} user - User object
 * @param {boolean} isCurrentUser - Whether this is the current user
 * @returns {string} Display name
 */
export function getDisplayName(user, isCurrentUser = false) {
    if (isCurrentUser) {
        return window.currentUserSettings?.display_name || state.currentUsername || 'Guest';
    }
    return user.display_name || user.username;
}

/**
 * Get status text for display
 * @param {string} status - Status key (online, away, busy)
 * @returns {string} Display text for status
 */
export function getStatusText(status) {
    const statusMap = {
        'online': 'Online',
        'away': 'Away',
        'busy': 'Do Not Disturb'
    };
    return statusMap[status] || 'Online';
}

/**
 * Updates the current user's info displayed in the UI
 */
export function updateUserInfo() {
    const userInfos = document.querySelectorAll('.user-info');
    if (userInfos.length === 0) {
        console.error('User info elements not found');
        showError('User info elements not found. Please refresh.');
        return;
    }

    // Get display name using shared helper
    const displayName = getDisplayName(null, true);

    // Get status from settings or default to online
    const status = window.currentUserSettings?.status || 'online';
    const statusText = getStatusText(status);

    // Get avatar using shared helper
    const avatarUrl = getAvatarUrl(null, true);

    console.log('[DEBUG] updateUserInfo - Display name:', displayName, 'Status:', statusText, 'Avatar:', avatarUrl);

    userInfos.forEach(userInfo => {
        const usernameElement = userInfo.querySelector('.username');
        const statusElement = userInfo.querySelector('.status');
        const avatarElement = userInfo.querySelector('.avatar img');
        const statusDot = userInfo.querySelector('.status-dot');

        if (usernameElement) usernameElement.textContent = displayName;
        if (statusElement) statusElement.textContent = statusText;
        if (avatarElement) {
            console.log('[DEBUG] Setting avatar src to:', avatarUrl);
            avatarElement.src = avatarUrl;
        }
        if (statusDot) {
            statusDot.className = 'status-dot ' + status;
        }
    });
}