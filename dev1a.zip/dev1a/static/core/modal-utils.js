// core/modal-utils.js
// Generic modal handling utilities

/**
 * Setup close handlers for a modal (click outside and escape key)
 * @param {string} modalId - ID of the modal element
 * @param {Function} closeFunction - Function to call to close the modal
 */
export function setupModalCloseHandlers(modalId, closeFunction) {
    const modal = document.getElementById(modalId);
    if (!modal) return;

    // Click outside to close
    window.addEventListener('click', (event) => {
        if (event.target === modal) closeFunction();
    });

    // Escape key to close
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && modal.style.display === 'flex') {
            closeFunction();
        }
    });
}