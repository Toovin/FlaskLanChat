// core/profile-modal.js
import { escapeHtml, showError } from './ui-utils.js';
import { state } from './setup.js';
import { getAvatarUrl, getDisplayName } from './user-utils.js';
import { startPrivateCall } from '../socket-events/main.js';

export function closeUserProfileModal() {
    const modal = document.getElementById('user-profile-modal');
    if (modal) {
        modal.style.display = 'none';
    }
}

export function openUserProfileModal(user) {
    console.log('openUserProfileModal called for user:', user.username);
    const modal = document.getElementById('user-profile-modal');
    if (!modal) {
        console.error('User profile modal not found');
        showError('User profile modal not found');
        return;
    }

    // Get the latest user data from users_db to ensure we have current information
    const latestUser = Object.values(state.users_db).find(u => u.username === user.username);
    if (!latestUser) {
        console.error('User not found in users_db:', user.username);
        showError('User not found');
        return;
    }

    // Use the latest user data
    user = latestUser;

    // Populate modal with user data
    const avatarImg = modal.querySelector('#profile-avatar');
    const usernameH2 = modal.querySelector('#profile-username');
    const displayNameH3 = modal.querySelector('#profile-display-name');
    const statusSpan = modal.querySelector('#profile-status');
    const customStatusDiv = modal.querySelector('#profile-custom-status');
    const customStatusText = modal.querySelector('#profile-custom-status-text');

    // Set avatar using helper function
    avatarImg.src = getAvatarUrl(user);

    // Set username and display name using helper function
    usernameH2.textContent = escapeHtml(user.username);
    displayNameH3.textContent = escapeHtml(getDisplayName(user));

    // Set status - check if user is actually online
    const displayName = getDisplayName(user);
    const isOnline = state.onlineUsers && state.onlineUsers.includes(displayName);
    const statusText = isOnline ? 'Online' : 'Offline';
    const statusClass = isOnline ? 'online' : 'offline'; // Use 'offline' (gray) for offline

    statusSpan.textContent = statusText;
    statusSpan.className = `status-indicator ${statusClass}`;

    // Set custom status if available
    if (user.custom_status && user.custom_status.trim() !== '') {
        customStatusText.textContent = escapeHtml(user.custom_status);
        customStatusDiv.style.display = 'block';
    } else {
        customStatusDiv.style.display = 'none';
    }

    // Show modal
    modal.style.display = 'flex';

    // Add event listeners for action buttons
    const messageBtn = modal.querySelector('#message-user-btn');
    const callBtn = modal.querySelector('#call-user-btn');

    console.log('messageBtn found:', !!messageBtn, 'callBtn found:', !!callBtn);

    // Check if viewing own profile
    const isOwnProfile = user.username === state.currentUsername;
    console.log('isOwnProfile:', isOwnProfile, 'user.username:', user.username, 'state.currentUsername:', state.currentUsername);

    // Remove existing listeners to avoid duplicates
    messageBtn.replaceWith(messageBtn.cloneNode(true));
    callBtn.replaceWith(callBtn.cloneNode(true));

    const newMessageBtn = modal.querySelector('#message-user-btn');
    const newCallBtn = modal.querySelector('#call-user-btn');

    if (isOwnProfile) {
        console.log('Setting buttons for own profile');
        // Change buttons for own profile
        newCallBtn.innerHTML = '<i class="fas fa-flask"></i> Test Call';
        newCallBtn.title = 'Test Call (loopback testing)';
        newMessageBtn.innerHTML = '<i class="fas fa-sticky-note"></i> Notes';
        newMessageBtn.title = 'Personal Notes';
        console.log('Own profile buttons set');

        newMessageBtn.addEventListener('click', () => {
            closeUserProfileModal();
            // Try to open notes modal, will work if user-notes.js has loaded
            if (typeof window.openUserNotesModal === 'function') {
                window.openUserNotesModal();
            } else {
                console.warn('Notes feature not yet loaded, please try again in a moment');
                showError('Notes feature not yet loaded, please try again');
            }
        });

        newCallBtn.addEventListener('click', () => {
            // TODO: Implement test call functionality
            console.log('Test call initiated for:', user.username);
            closeUserProfileModal();
        });
    } else {
        console.log('Setting buttons for other user profile');
        // Reset buttons for other users
        newCallBtn.innerHTML = '<i class="fas fa-phone"></i> Call';
        newCallBtn.title = 'Voice Call';
        newMessageBtn.innerHTML = '<i class="fas fa-envelope"></i> Message';
        newMessageBtn.title = 'Send Message';
        console.log('Other profile buttons set');

        // Disable call button if user is offline, but allow messaging
        if (!isOnline) {
            newCallBtn.disabled = true;
            newCallBtn.style.opacity = '0.5';
            newCallBtn.title = 'User is offline - cannot call';
            newMessageBtn.disabled = false;
            newMessageBtn.style.opacity = '1';
            newMessageBtn.title = 'Send message (will be delivered when user comes online)';
        } else {
            newCallBtn.disabled = false;
            newCallBtn.style.opacity = '1';
            newMessageBtn.disabled = false;
            newMessageBtn.style.opacity = '1';
        }

        newMessageBtn.addEventListener('click', () => {
            console.log('Message user:', user.username);
            closeUserProfileModal();
            // Start DM conversation with the user
            if (window.dmManager) {
                window.dmManager.startNewDM(user.username);
            } else {
                console.error('DM Manager not available');
                showError('Direct messaging not available yet. Please try again in a moment.');
            }
        });

        newCallBtn.addEventListener('click', () => {
            // Find the user's UUID from users_db
            const userUuid = Object.keys(state.users_db).find(uuid => state.users_db[uuid].username === user.username);
            if (userUuid) {
                startPrivateCall(userUuid);
            } else {
                console.error('User UUID not found for call');
                showError('Cannot initiate call: user not found');
            }
            closeUserProfileModal();
        });
    }
}

export function setupProfileModalEvents() {
    // Close profile modal when clicking outside
    window.addEventListener('click', (event) => {
        const modal = document.getElementById('user-profile-modal');
        if (event.target === modal) {
            closeUserProfileModal();
        }
    });

    // Close profile modal with Escape key
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            const modal = document.getElementById('user-profile-modal');
            if (modal && modal.style.display === 'flex') {
                closeUserProfileModal();
            }
        }
    });
}

// Make functions globally available for HTML onclick
window.closeUserProfileModal = closeUserProfileModal;