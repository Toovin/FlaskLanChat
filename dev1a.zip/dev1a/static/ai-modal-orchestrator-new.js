// ai-modal-orchestrator-new.js - Central coordinator for AI modal modules

console.log('AI Modal Orchestrator NEW script loading at:', new Date().toISOString());

// Test if document is ready
if (typeof document === 'undefined') {
    console.error('Document not available when AI Modal Orchestrator loaded');
} else {
    console.log('Document is available, body exists:', !!document.body);
}

class AIModalOrchestrator {
    constructor() {
        this.modal = null;
        this.isInitialized = false;
        this.charactersLoaded = false;
        this.pendingActiveCharacter = null;
        this.modules = {};

        // Module status tracking
        this.moduleStatus = {
            characterManager: false,
            conversationManager: false,
            messageHandler: false
        };

        // UI Update Manager
        this.ui = {
            showLoading: (elementId, message = 'Loading...') => {
                const el = document.getElementById(elementId);
                if (el) {
                    el.innerHTML = `<div class="loading-state"><i class="fas fa-spinner fa-spin"></i> ${message}</div>`;
                }
            },

            hideLoading: (elementId) => {
                const el = document.getElementById(elementId);
                if (el && el.querySelector('.loading-state')) {
                    el.innerHTML = '';
                }
            },

            updateSelectOptions: (elementId, options, placeholder = '') => {
                const select = document.getElementById(elementId);
                if (!select) return;

                select.innerHTML = placeholder ? `<option value="">${placeholder}</option>` : '';
                options.forEach(option => {
                    const opt = document.createElement('option');
                    opt.value = option.value;
                    opt.textContent = option.text;
                    if (option.title) opt.title = option.title;
                    select.appendChild(opt);
                });
            }
        };
    }

    // Utility function to add cache busting to avatar URLs
    getCacheBustedAvatarUrl(avatarUrl) {
        if (!avatarUrl) return avatarUrl;
        return avatarUrl + (avatarUrl.includes('?') ? '&' : '?') + 't=' + Date.now();
    }

    // Initialize the orchestrator and all modules
    async init() {
        try {
            console.log('[DEBUG] Initializing AI Modal Orchestrator...');

            // Create modal infrastructure first
            console.log('[DEBUG] Creating modal infrastructure');
            this.createModalInfrastructure();

            // Initialize modules in dependency order
            console.log('[DEBUG] Initializing modules');
            await this.initModules();

            // Bind global events
            console.log('[DEBUG] Binding global events');
            this.bindGlobalEvents();

            this.isInitialized = true;
            console.log('[DEBUG] AI Modal Orchestrator initialized successfully');
        } catch (error) {
            console.error('[DEBUG] Failed to initialize AI Modal Orchestrator:', error);
            throw error;
        }
    }

    // Bind global events
    bindGlobalEvents() {
        console.log('Binding global events');

        // Modal controls
        const closeBtn = document.getElementById('ai-close-modal');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                this.close();
            });
            console.log('Close button event bound');
        } else {
            console.log('Close button not found');
        }

        // Tab switching
        const tabButtons = document.querySelectorAll('.ai-tab-button');
        console.log('Found tab buttons:', tabButtons.length);
        tabButtons.forEach((button, index) => {
            console.log(`Attaching listener to tab button ${index}:`, button.getAttribute('data-tab'));

            button.addEventListener('click', () => {
                console.log('Tab clicked:', button.getAttribute('data-tab'));
                this.switchTab(button.getAttribute('data-tab'));
            });
        });

        // Conversation events handled inline

        // Conversation events handled inline
    }

    // Create the core modal HTML structure
    createModalInfrastructure() {
        if (!document.body) {
            console.error('Document body not available for modal creation');
            return;
        }

        const modalHTML = `
            <div id="ai-modal" class="modal" style="display: none;">
                <div class="modal-content">
                     <div class="modal-header">
                         <h2>AI Chat</h2>
                         <button id="ai-close-modal" class="close-modal">&times;</button>
                     </div>
                    <div class="ai-modal-content">
                        <!-- Main Character Indicator Header -->
                        <div class="ai-character-header">
                            <div class="character-indicator">
                                <div class="character-indicator-label">Active Character:</div>
                                <div class="character-indicator-content" id="ai-character-indicator">
                                    <div class="no-character-selected">
                                        <span class="character-name">None (Raw API)</span>
                                        <span class="character-description">Send messages directly to AI without character context</span>
                                    </div>
                                </div>
                                <button id="ai-clear-character" class="btn btn-sm btn-outline" title="Clear character selection" style="display: none;">&times;</button>
                            </div>
                        </div>

                           <!-- Tab Navigation -->
                           <div class="ai-modal-tabs">
                               <button class="ai-tab-button active" data-tab="characters" onclick="switchAIModalTab('characters')">Characters</button>
                               <button class="ai-tab-button" data-tab="chat" onclick="switchAIModalTab('chat')">Chat</button>
                               <button class="ai-tab-button" data-tab="settings" onclick="switchAIModalTab('settings')">Settings</button>
                               <button class="ai-tab-button" data-tab="system" onclick="switchAIModalTab('system')">System</button>
                           </div>

                          <div class="ai-main-area">
                               <!-- Characters Tab -->
                               <div id="ai-character-selector" class="ai-content-section active">
                                   <div class="character-tab-header">
                                       <h3>Manage Characters</h3>
                                       <button id="ai-create-character" class="btn btn-primary">Create New Character</button>
                                   </div>
                                   <div id="ai-character-tiles" class="ai-character-tiles">
                                       <!-- Character tiles will be loaded here -->
                                   </div>
                               </div>

                               <!-- Chat Tab -->
                               <div id="ai-chat-section" class="ai-content-section">
                                   <div class="ai-chat-layout">
                                       <!-- Conversation History Sidebar -->
                                        <div class="ai-chat-sidebar">
                                            <div class="conversation-header">
                                                <h4>Conversations</h4>
                                                <div class="conversation-actions">
                                                    <button id="ai-toggle-sidebar" class="btn btn-sm btn-outline" title="Toggle Sidebar">
                                                        <i class="fas fa-chevron-left"></i>
                                                    </button>
                                                    <button id="ai-new-conversation" class="btn btn-sm btn-primary" title="New Conversation">
                                                        <i class="fas fa-plus"></i> New
                                                    </button>
                                                    <button id="ai-clear-all-conversations" class="btn btn-sm btn-danger" title="Clear All Conversations">
                                                        <i class="fas fa-trash-alt"></i> Clear All
                                                    </button>
                                                </div>
                                            </div>
                                           <div id="ai-conversations-container" class="conversations-list">
                                               <!-- Conversations will be loaded here -->
                                           </div>
                                       </div>

                                       <!-- Main Chat Area -->
                                       <div class="ai-chat-main">
                                           <div class="ai-chat-messages">
                                               <div id="ai-messages" class="ai-messages">
                                                   <div class="ai-welcome">
                                                       <h3>Welcome to AI Chat!</h3>
                                                       <p>Start a conversation with your selected character.</p>
                                                       <p>You can also mention @ai or @assistant in any channel for quick responses.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ai-input-area">
                                                <div class="ai-input-container">
                                                    <textarea id="ai-message-input" placeholder="Type your message to AI..." rows="2"></textarea>
                                                     <div class="ai-input-controls">
                                                         <input type="file" id="ai-image-input" accept="image/*" style="display: none;">
                                                         <button id="ai-image-button" class="btn btn-secondary" title="Attach Image">
                                                             <i class="fas fa-image"></i>
                                                         </button>
                                                         <label class="ai-auto-scroll-label">
                                                             <input type="checkbox" id="ai-auto-scroll-checkbox" checked> Auto-Scroll
                                                         </label>
                                                         <button id="ai-send-button" class="btn btn-primary">Send</button>
                                                     </div>
                                                </div>
                                                <div id="ai-image-preview" class="ai-image-preview" style="display: none;">
                                                    <img id="ai-preview-image" alt="Image preview">
                                                    <button id="ai-remove-image" class="remove-image-btn" title="Remove image">&times;</button>
                                                </div>
                                                <div class="ai-status">
                                                    <span id="ai-status-text">Ready</span>
                                </div>

                                <!-- System Tab -->
                                <div id="ai-system-section" class="ai-content-section">
                                    <div class="ai-settings-content">
                                        <h3>System Configuration</h3>
                                        <div class="settings-form-container">
                                          <form id="ai-system-settings-form">
                                            <div class="settings-section">
                                                <h4>Global AI Configuration</h4>
                                                <div class="form-group">
                                                    <label for="system-ai-endpoint-url">Default AI Endpoint URL:</label>
                                                    <input type="text" id="system-ai-endpoint-url" name="ai_endpoint_url" placeholder="http://localhost:1234" value="http://localhost:1234">
                                                    <small>Default LM Studio API endpoint for all users</small>
                                                </div>
                                                <div class="form-group">
                                                    <label for="system-debug-mode">
                                                        <input type="checkbox" id="system-debug-mode" name="debug_mode">
                                                        Enable Debug Mode
                                                    </label>
                                                    <small>Enable detailed logging for troubleshooting</small>
                                                </div>
                                                <div class="form-group">
                                                    <label for="system-max-users">Maximum Users:</label>
                                                    <input type="number" id="system-max-users" name="max_users" min="1" max="1000" value="100">
                                                    <small>Maximum number of users allowed on the server</small>
                                                </div>
                                            </div>
                                          </form>
                                        </div>

                                        <div class="settings-actions">
                                            <button type="button" id="ai-system-settings-save" class="btn btn-primary">Save System Settings</button>
                                            <button type="button" id="ai-system-settings-load" class="btn btn-secondary">Load System Settings</button>
                                        </div>
                                    </div>
                                </div>
                           </div>
                     </div>
                 </div>
             </div>

                              <!-- Settings Tab -->
                               <div id="ai-settings-section" class="ai-content-section">
                                   <div class="ai-settings-content">
                                       <h3>AI Configuration</h3>
                                       <div class="settings-form-container">
                                         <form id="ai-modal-settings-form">
                                           <div class="settings-section">
                                               <h4>Server Configuration</h4>
                                               <div class="form-group">
                                                   <label for="ai-server-host">LM Studio Server:</label>
                                                    <input type="text" id="ai-server-host" name="ai_server_host" placeholder="127.0.0.1:1234" value="127.0.0.1:6969">
                                                   <small>Host and port for LM Studio API server</small>
                                               </div>
                                               <div class="form-group">
                                                   <label for="ai-model-select">Model:</label>
                                                   <select id="ai-model-select" name="ai_model">
                                                       <option value="">Auto (use server default)</option>
                                                       <!-- Models will be loaded dynamically -->
                                                   </select>
                                                   <small>Select a specific model or leave auto</small>
                                               </div>
                                           </div>

                                           <div class="settings-section">
                                               <h4>Context Management</h4>

                                               <div class="form-group">
                                                   <label for="ai-context-management-mode">Context Management Mode:</label>
                                                   <select id="ai-context-management-mode" name="ai_context_management_mode">
                                                       <option value="client">Client-side Context (Default)</option>
                                                       <option value="api">API-side Context (LM Studio)</option>
                                                   </select>
                                                   <small>Client-side: App manages conversation history. API-side: LM Studio manages context (more efficient for long conversations)</small>
                                               </div>

                                               <div class="form-group">
                                                   <label for="ai-api-debug">
                                                       <input type="checkbox" id="ai-api-debug" name="ai_api_debug">
                                                       Enable API Debug Logging
                                                   </label>
                                                   <small>Log detailed API requests and responses to server console (can be verbose)</small>
                                               </div>

                                               <div class="form-group">
                                                   <label for="ai-history-limit">Global Context Limit:</label>
                                                   <input type="number" id="ai-history-limit" name="ai_history_limit"
                                                          min="1" max="100" value="50">
                                                   <small>Maximum number of messages to include in context for modal/DM conversations</small>
                                               </div>

                                               <div class="form-group">
                                                   <label for="ai-modal-memory-enabled">
                                                       <input type="checkbox" id="ai-modal-memory-enabled" name="ai_modal_memory_enabled" checked>
                                                       Enable Modal Memory
                                                   </label>
                                                   <small>Include conversation history in modal AI chat responses</small>
                                               </div>

                                               <div class="form-group" id="modal-memory-limit-group">
                                                   <label for="ai-modal-memory-limit">Modal Memory Messages:</label>
                                                   <input type="number" id="ai-modal-memory-limit" name="ai_modal_memory_limit"
                                                          min="1" max="50" value="15">
                                                   <small>Number of recent messages to include in modal AI context</small>
                                               </div>

                                               <div class="form-group">
                                                   <label for="ai-channel-memory-enabled">
                                                       <input type="checkbox" id="ai-channel-memory-enabled" name="ai_channel_memory_enabled">
                                                       Enable Channel Memory
                                                   </label>
                                                   <small>Allow AI to remember recent channel messages for context when mentioned</small>
                                               </div>

                                               <div class="form-group" id="channel-memory-limit-group" style="display: none;">
                                                   <label for="ai-channel-memory-limit">Channel Context Limit:</label>
                                                   <input type="number" id="ai-channel-memory-limit" name="ai_channel_memory_limit"
                                                          min="0" max="50" value="10">
                                                   <small>Number of recent text messages to include for channel AI conversations</small>
                                               </div>
                                           </div>

                                           <div class="settings-section">
                                               <h4>Advanced Customization</h4>

                                               <div class="form-group">
                                                   <label for="ai-system-prepend">System Prompt Prepend:</label>
                                                   <textarea id="ai-system-prepend" name="ai_system_prepend"
                                                             placeholder="Text to prepend to all system prompts (added before character/system instructions)..."
                                                             rows="2"></textarea>
                                                   <small>Advanced: Add custom instructions that will be prepended to every system prompt</small>
                                               </div>

                                               <div class="form-group">
                                                   <label for="ai-user-prepend">User Message Prepend:</label>
                                                   <textarea id="ai-user-prepend" name="ai_user_prepend"
                                                             placeholder="Text to prepend to all user messages..."
                                                             rows="2"></textarea>
                                                   <small>Advanced: Add custom formatting or instructions to every user message</small>
                                               </div>
                                           </div>

                                           <div class="settings-section">
                                               <h4>AI Parameters</h4>

                                              <div class="form-group">
                                                  <label for="ai-max-tokens">Max Tokens (Response Length):</label>
                                                  <input type="number" id="ai-max-tokens" name="ai_max_tokens"
                                                         min="100" max="4096" value="2048">
                                              </div>

                                              <div class="form-group">
                                                  <label for="ai-temperature">Temperature (Creativity):</label>
                                                  <input type="number" id="ai-temperature" name="ai_temperature"
                                                         min="0" max="2" step="0.1" value="0.7">
                                                  <small>Lower = more focused, Higher = more creative (0.0-2.0)</small>
                                              </div>


                                           </div>

                                         </form>
                                       </div>

                                       <div class="settings-actions">
                                           <button type="button" id="ai-settings-save" class="btn btn-primary">Save Settings</button>
                                           <button type="button" id="ai-test-connection" class="btn btn-secondary">Test Connection</button>
                                       </div>
                                   </div>
                               </div>
                          </div>
                    </div>
                </div>
            </div>
        `;

        try {
            document.body.insertAdjacentHTML('beforeend', modalHTML);
            this.modal = document.getElementById('ai-modal');
            console.log('AI Modal infrastructure created');
        } catch (error) {
            console.error('Failed to create modal infrastructure:', error);
        }
    }

    // Initialize all modules in the correct order
    async initModules() {
        // Character Manager (no dependencies)
        try {
            console.log('[DEBUG] Creating Character Manager');
            this.modules.characterManager = new AICharacterManager(this);
            console.log('[DEBUG] Calling characterManager.init()');
            await this.modules.characterManager.init();
            this.moduleStatus.characterManager = true;
            // Make characterManager globally accessible for HTML onclick handlers
            window.aiCharacterManager = this.modules.characterManager;
            console.log('[DEBUG] Character Manager initialized');
        } catch (error) {
            console.error('[DEBUG] Failed to initialize Character Manager:', error);
            throw error;
        }

        // Conversation Manager (depends on character manager)
        try {
            this.modules.conversationManager = new AIConversationManager(this);
            await this.modules.conversationManager.init();
            this.moduleStatus.conversationManager = true;
            console.log('Conversation Manager initialized');
        } catch (error) {
            console.error('Failed to initialize Conversation Manager:', error);
            throw error;
        }

        // Message Handler (depends on modal infrastructure)
        try {
            this.modules.messageHandler = new AIMessageHandler(this);
            await this.modules.messageHandler.init();
            this.moduleStatus.messageHandler = true;
            console.log('Message Handler initialized');
        } catch (error) {
            console.error('Failed to initialize Message Handler:', error);
            throw error;
        }

        // Settings Modal (depends on modal infrastructure)
        try {
            this.modules.settingsModal = new AISettingsModal(this);
            await this.modules.settingsModal.init();
            this.moduleStatus.settingsModal = true;
            console.log('Settings Modal initialized');
        } catch (error) {
            console.error('Failed to initialize Settings Modal:', error);
            throw error;
        }
    }

    // Bind global modal events
    bindGlobalEvents() {
        // Modal controls
        document.getElementById('ai-close-modal')?.addEventListener('click', () => {
            this.close();
        });

        // New conversation button
        document.getElementById('ai-new-conversation')?.addEventListener('click', () => {
            this.startNewConversation();
        });

        // Clear all conversations button
        document.getElementById('ai-clear-all-conversations')?.addEventListener('click', () => {
            this.clearAllConversations();
        });

        // Toggle sidebar button
        document.getElementById('ai-toggle-sidebar')?.addEventListener('click', () => {
            this.toggleSidebar();
        });

        // Conversation events handled inline



        // Send message
        document.getElementById('ai-send-button')?.addEventListener('click', () => {
            this.modules.messageHandler.sendMessage();
        });

        // Auto-scroll checkbox
        const autoScrollCheckbox = document.getElementById('ai-auto-scroll-checkbox');
        if (autoScrollCheckbox) {
            // Load saved preference or default to true
            const savedAutoScroll = localStorage.getItem('aiAutoScrollEnabled');
            autoScrollCheckbox.checked = savedAutoScroll !== null ? savedAutoScroll === 'true' : true;

            autoScrollCheckbox.addEventListener('change', (e) => {
                localStorage.setItem('aiAutoScrollEnabled', e.target.checked);
                if (e.target.checked) {
                    this.modules.messageHandler.scrollToBottom(true);
                }
            });
        }

        // Remove image button
        document.getElementById('ai-remove-image')?.addEventListener('click', () => {
            this.modules.messageHandler.removeImage();
        });

        // Clear active character button
        document.getElementById('clear-active-character')?.addEventListener('click', () => {
            this.modules.characterManager.clearActiveCharacter();
        });

        // Start new conversation button
        document.getElementById('ai-start-new-conversation')?.addEventListener('click', () => {
            this.modules.characterManager.startConversation();
        });

        // Back to characters button
        document.getElementById('ai-back-to-characters')?.addEventListener('click', () => {
            this.showCharacterSelector();
        });

        // Enter key in textarea
        document.getElementById('ai-message-input')?.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.modules.messageHandler.sendMessage();
            }
        });

        // Socket.IO event listeners
        if (typeof socket !== 'undefined') {
            socket.on('ai_modal_response', (data) => {
                this.modules.messageHandler.handleAIResponse(data);
            });

             socket.on('ai_characters_list', (data) => {
                 console.log('[DEBUG] ai_characters_list received:', data);
                 this.modules.characterManager.handleCharactersLoaded(data.characters);
             });

            socket.on('ai_character_created', (data) => {
                this.modules.characterManager.handleCharacterCreated(data.character);
            });

            socket.on('ai_character_updated', (data) => {
                this.modules.characterManager.handleCharacterUpdated(data);
            });

            socket.on('ai_character_deleted', (data) => {
                this.modules.characterManager.handleCharacterDeleted(data.character_name);
            });

             socket.on('ai_active_character_set', (data) => {
                 this.modules.characterManager.handleActiveCharacterSet(data.character);
                 this.updateActiveCharacterDisplay(data.character);
             });

            socket.on('ai_active_character_data', (data) => {
                 this.modules.characterManager.handleActiveCharacterData(data.character);
                 this.updateActiveCharacterDisplay(data.character);
             });

            // Models list for settings
            socket.on('ai_models_list', (data) => {
                this.populateModelsList(data.models);
            });

            socket.on('ai_connection_test_result', (data) => {
                this.handleConnectionTestResult(data);
            });

            socket.on('ai_config_updated', (data) => {
                if (data.success) {
                    this.updateStatus('Settings saved successfully');
                    setTimeout(() => this.updateStatus(''), 2000);
                } else {
                    this.updateStatus('Failed to save settings');
                }
            });

            socket.on('ai_settings_loaded', (data) => {
                console.log('[AI_SETTINGS] Settings loaded via socket:', data);
                this.handleAISettingsLoaded(data);
            });

            socket.on('ai_settings_updated', (data) => {
                console.log('[AI_SETTINGS] Settings updated successfully');
                this.updateStatus('AI settings saved successfully');
            });

            socket.on('ai_config_data', (data) => {
                this.populateSettings(data);
            });

            socket.on('ai_system_settings_data', (data) => {
                this.populateSystemSettings(data);
            });

            socket.on('ai_system_settings_saved', (data) => {
                if (data.success) {
                    this.updateStatus('System settings saved successfully');
                    setTimeout(() => this.updateStatus(''), 2000);
                } else {
                    this.updateStatus('Failed to save system settings');
                }
            });

            // Conversation events
            socket.on('ai_conversations_list', (data) => {
                console.log('[ORCHESTRATOR] Received ai_conversations_list:', data);
                this.updateConversationsList(data.conversations);
            });

            socket.on('ai_conversation_history', (data) => {
                console.log('[ORCHESTRATOR] Received ai_conversation_history:', data);
                this.modules.conversationManager.loadConversationHistory(data.history);
            });

            socket.on('ai_conversation_created', (data) => {
                console.log('[ORCHESTRATOR] Received ai_conversation_created:', data);
                this.loadConversations();
                if (data.conversation_id) {
                    this.selectConversation(data.conversation_id);
                }
            });

            socket.on('ai_error', (data) => {
                this.handleAIError(data.message);
            });
        }
    }

    // Start a new conversation
    startNewConversation() {
        // Use conversation manager to start new conversation
        if (this.modules.conversationManager) {
            this.modules.conversationManager.startNewConversation();
        }

        // Generate a new conversation key for backward compatibility
        const timestamp = Date.now();
        const randomId = Math.random().toString(36).substr(2, 9);
        this.currentConversationKey = `modal_${timestamp}_${randomId}`;

        console.log('Started new conversation with key:', this.currentConversationKey);
    }

    // Open the modal
    open() {
        console.log('[DEBUG] AIModalOrchestrator.open() called');
        if (!this.isInitialized) {
            console.log('[DEBUG] Orchestrator not initialized');
            throw new Error('AI Modal Orchestrator not initialized. Call init() first.');
        }

        // Prevent multiple opens
        if (this.isOpen) {
            console.log('[DEBUG] Modal already open, skipping');
            return;
        }

        if (this.modal) {
            console.log('[DEBUG] Setting modal display to block');
            this.modal.style.display = 'block';
            this.isOpen = true;

            // Initialize character indicator
            const activeCharacter = this.modules.characterManager?.activeCharacter;
            this.updateActiveCharacterDisplay(activeCharacter);

            // Show characters tab by default
            this.switchTab('characters');

            // Load characters if not already loaded
            console.log('[DEBUG] Modal open - checking character loading');
            if (typeof socket !== 'undefined') {
                console.log('[DEBUG] Socket available, connected:', socket.connected);
                console.log('[DEBUG] characterManager exists:', !!this.modules.characterManager);
                console.log('[DEBUG] charactersLoaded:', this.charactersLoaded);
                if (this.modules.characterManager && !this.charactersLoaded) {
                    console.log('[DEBUG] Loading characters');
                    this.modules.characterManager.loadCharacters();
                    this.charactersLoaded = true;
                } else {
                    console.log('[DEBUG] Not loading characters - either already loaded or no manager');
                }
            } else {
                console.log('[DEBUG] Socket not available');
            }

            // Load AI settings
            console.log('[AI_SETTINGS] About to load AI settings...');
            this.loadAISettings();

            // Bind modal-specific events
            this.bindModalEvents();

            // Focus appropriate element
            const activeTab = document.querySelector('.ai-tab-button.active')?.getAttribute('data-tab');
            if (activeTab === 'chat') {
                document.getElementById('ai-message-input')?.focus();
            }
        }
    }

    // Bind events that require the modal to be open
    bindModalEvents() {
        // Bind create character button
        document.getElementById('ai-create-character')?.addEventListener('click', () => {
            this.modules.characterManager.showCreateCharacterModal();
        });

        // Bind clear character button
        document.getElementById('ai-clear-character')?.addEventListener('click', () => {
            this.clearCharacterSelection();
        });

        // Bind test connection button
        document.getElementById('ai-test-connection')?.addEventListener('click', () => {
            this.testServerConnection();
        });

        document.getElementById('ai-settings-save')?.addEventListener('click', () => {
            this.saveSettings();
        });

        document.getElementById('ai-system-settings-save')?.addEventListener('click', () => {
            this.saveSystemSettings();
        });

        document.getElementById('ai-system-settings-load')?.addEventListener('click', () => {
            this.loadSystemSettings();
        });

        // Modal memory toggle
        const modalMemoryEnabled = document.getElementById('ai-modal-memory-enabled');
        const modalMemoryLimitGroup = document.getElementById('modal-memory-limit-group');
        if (modalMemoryEnabled && modalMemoryLimitGroup) {
            const updateModalMemoryVisibility = () => {
                modalMemoryLimitGroup.style.display = modalMemoryEnabled.checked ? 'block' : 'none';
            };
            modalMemoryEnabled.addEventListener('input', updateModalMemoryVisibility);
            // Set initial state
            updateModalMemoryVisibility();
        }

        // Channel memory toggle
        const channelMemoryEnabled = document.getElementById('ai-channel-memory-enabled');
        const channelMemoryLimitGroup = document.getElementById('channel-memory-limit-group');
        if (channelMemoryEnabled && channelMemoryLimitGroup) {
            const updateChannelMemoryVisibility = () => {
                channelMemoryLimitGroup.style.display = channelMemoryEnabled.checked ? 'block' : 'none';
            };
            channelMemoryEnabled.addEventListener('input', updateChannelMemoryVisibility);
            // Set initial state
            updateChannelMemoryVisibility();
        }

        // Bind escape key to close modal
        const handleEscapeKey = (e) => {
            if (e.key === 'Escape' && this.isOpen) {
                this.close();
            }
        };
        document.addEventListener('keydown', handleEscapeKey);

        // Store the handler so we can remove it when modal closes
        this.escapeKeyHandler = handleEscapeKey;
    }

    // Close the modal
    close() {
        if (this.modal) {
            this.modal.style.display = 'none';
            this.isOpen = false;

            // Remove escape key handler
            if (this.escapeKeyHandler) {
                document.removeEventListener('keydown', this.escapeKeyHandler);
                this.escapeKeyHandler = null;
            }

            // Reset conversation state
            this.currentConversationKey = null;

            // Reset to characters tab for next open
            this.switchTab('characters');
        }
    }

    // Handle user settings loaded
    handleUserSettingsLoaded(data) {
        const settings = data.settings;

        // Store active character preference for later (when characters are loaded)
        if (settings && settings.ai_active_character) {
            this.pendingActiveCharacter = settings.ai_active_character;
            // Character loading will handle setting the active character
        }

        // Also handle settings modal if it's open
        if (this.modules.settingsModal) {
            this.modules.settingsModal.handleAISettingsLoaded(data);
        }
    }

    // Show character selector
    showCharacterSelector() {
        this.switchTab('characters');
        // Load characters if not already loaded
        if (!this.charactersLoaded) {
            this.getModule('characterManager').loadCharacters();
            this.charactersLoaded = true;
        }
    }

    // Show chat section
    showChatSection() {
        this.switchTab('chat');
    }

    // Update character selector dropdown
    updateCharacterSelector(characters) {
        const options = characters.map(character => ({
            value: character.character_name,
            text: character.character_name
        }));

        this.ui.updateSelectOptions('ai-character-select', options, 'Select a character...');

        // Set current active character
        const activeCharacter = this.getModule('characterManager').activeCharacter;
        if (activeCharacter) {
            const select = document.getElementById('ai-character-select');
            if (select) select.value = activeCharacter.character_name;
        }
    }

    // Update main character indicator header
    updateActiveCharacterDisplay(character) {
        const indicator = document.getElementById('ai-character-indicator');
        const clearBtn = document.getElementById('ai-clear-character');

        if (!indicator) return;

        if (character) {
            const avatarUrl = this.getCacheBustedAvatarUrl(character.avatar_url || '/static/default_avatars/smile_1.png');
            indicator.innerHTML = `
                <div class="character-selected">
                    <img src="${avatarUrl}" alt="${character.character_name}" class="character-avatar">
                    <div class="character-details">
                        <span class="character-name">${character.character_name}</span>
                        <span class="character-description">${character.character_description || 'AI Character'}</span>
                    </div>
                </div>
            `;
            if (clearBtn) clearBtn.style.display = 'block';
        } else {
            indicator.innerHTML = `
                <div class="no-character-selected">
                    <span class="character-name">None (Raw API)</span>
                    <span class="character-description">Send messages directly to AI without character context</span>
                </div>
            `;
            if (clearBtn) clearBtn.style.display = 'none';
        }
    }

    // Handle character selection from modal
    onCharacterSelected(character) {
        this.updateActiveCharacterDisplay(character);

        // Update the active character in character manager
        if (this.modules.characterManager) {
            this.modules.characterManager.setActiveCharacter(character.character_name);
        }

        // Stay on characters tab after selection
    }

    // Clear character selection
    clearCharacterSelection() {
        this.updateActiveCharacterDisplay(null);

        if (this.modules.characterManager) {
            this.modules.characterManager.clearActiveCharacter();
        }
    }

    // Select character from dropdown
    selectCharacter(characterName) {
        if (characterName) {
            this.getModule('characterManager').selectCharacter(characterName);
            // Removed automatic tab switching to keep users on characters tab for continued browsing
        }
    }

    // Switch between tabs
    switchTab(tabName) {
        console.log('[DEBUG] switchTab called with:', tabName);

        // Update tab buttons
        document.querySelectorAll('.ai-tab-button').forEach(button => {
            button.classList.remove('active');
        });
        const activeButton = document.querySelector(`[data-tab="${tabName}"]`);
        if (activeButton) {
            activeButton.classList.add('active');
            console.log('Active button found and updated');
        } else {
            console.log('Active button not found for tab:', tabName);
        }

        // Update content sections
        document.querySelectorAll('.ai-content-section').forEach(section => {
            section.classList.remove('active');
            // Clear any inline display styles that might override CSS
            section.style.display = '';
        });

        // Map tab names to correct section IDs
        const sectionIdMap = {
            'characters': 'ai-character-selector',
            'chat': 'ai-chat-section',
            'settings': 'ai-settings-section',
            'system': 'ai-system-section'
        };

        const sectionId = sectionIdMap[tabName] || `ai-${tabName}-section`;
        const activeSection = document.getElementById(sectionId);
        if (activeSection) {
            activeSection.classList.add('active');
            console.log('Active section found and updated:', sectionId);
            console.log('Active section classes after update:', activeSection.className);
            console.log('Active section display after update:', window.getComputedStyle(activeSection).display);
        } else {
            console.log('Active section not found for tab:', tabName, 'looking for ID:', sectionId);
        }

        // Handle input area visibility - only show for chat tab
        const inputArea = document.querySelector('.ai-input-area');
        if (tabName === 'chat') {
            if (inputArea) inputArea.style.display = 'block';
            // Load conversations when switching to chat tab
            this.loadConversations();
        } else {
            if (inputArea) inputArea.style.display = 'none';
        }

        // Handle tab-specific logic
        if (tabName === 'settings') {
            this.loadSettingsTab();
        } else if (tabName === 'chat') {
            // Ensure we have an active conversation
            if (!this.currentConversationKey) {
                this.startNewConversation();
            }
        } else if (tabName === 'characters') {
            // Show loading state if characters not loaded yet
            if (!this.charactersLoaded && this.modules.characterManager) {
                this.modules.characterManager.renderCharacterSections(null, 'ai-character-tiles', true);
            }
        }
    }

    // Load settings tab content
    loadSettingsTab() {
        // Load available models from server
        this.loadAvailableModels();

        // Load current server settings
        this.loadServerSettings();

        // Reload AI settings in case initial load failed due to auth timing
        this.loadAISettings();
    }

    // Load available models from LM Studio
    loadAvailableModels() {
        if (typeof socket !== 'undefined') {
            socket.emit('ai_get_models');
        }
    }

    // Load server settings
    loadServerSettings() {
        // Request current config from server
        if (typeof socket !== 'undefined') {
            socket.emit('ai_config_get');
        }
    }

    // Test server connection
    testServerConnection() {
        const hostInput = document.getElementById('ai-server-host');
        if (!hostInput) return;

        const host = hostInput.value.trim();
        if (!host) {
            alert('Please enter a server host');
            return;
        }

        this.updateStatus('Testing connection...');

        if (typeof socket !== 'undefined') {
            socket.emit('ai_test_connection', { host });
        }
    }

    // Save settings
    saveSettings() {
        const form = document.getElementById('ai-modal-settings-form');
        if (!form) return;

        const formData = new FormData(form);
        const settings = {};

        // Get all form elements to handle checkboxes properly
        const formElements = form.querySelectorAll('input, select, textarea');
        formElements.forEach(element => {
            const key = element.name;
            if (key && key.startsWith('ai_')) {
                if (element.type === 'checkbox') {
                    settings[key] = element.checked;
                } else if (element.type === 'number') {
                    settings[key] = parseFloat(element.value) || parseInt(element.value) || element.value;
                } else {
                    settings[key] = element.value;
                }
            }
        });

        // Handle server host separately for backward compatibility
        const hostInput = document.getElementById('ai-server-host');
        if (hostInput) {
            const host = hostInput.value.trim();
            if (host) {
                // Parse host and port
                const [hostname, port] = host.split(':');
                settings.endpoint_url = `https://${hostname}:${port || '6969'}`;
            }
        }

        this.updateStatus('Saving settings...');

        if (typeof socket !== 'undefined') {
            socket.emit('ai_update_user_settings', { settings: settings });
            this.showToast('Settings saved successfully!', 'success');
        } else {
            this.showToast('Unable to save settings - socket not available', 'error');
        }
    }

    showToast(message, type = 'info') {
        // Use existing toast element if available
        let toast = document.getElementById('toast');
        if (!toast) {
            // Create toast element if it doesn't exist
            toast = document.createElement('div');
            toast.id = 'toast';
            toast.className = 'toast';
            document.body.appendChild(toast);
        }

        toast.textContent = message;
        toast.className = `toast ${type}`;
        toast.style.display = 'block';

        // Trigger show animation
        setTimeout(() => toast.classList.add('show'), 10);

        // Auto-hide after 3 seconds
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                toast.style.display = 'none';
            }, 300);
        }, 3000);
    }

    loadAISettings() {
        console.log('[AI_SETTINGS] Loading AI settings via socket...');
        if (typeof socket !== 'undefined') {
            socket.emit('ai_get_user_settings');
        } else {
            console.error('[AI_SETTINGS] Socket not available for loading settings');
        }
    }

    handleAISettingsLoaded(data) {
        const settings = data.settings;
        const form = document.getElementById('ai-modal-settings-form');

        if (!form) return;

        // Populate AI settings
        const aiSettings = settings.ai_settings || settings || {};
        Object.keys(aiSettings).forEach(key => {
            const element = form.querySelector(`[name="${key}"]`);
            if (element) {
                if (element.type === 'checkbox') {
                    element.checked = aiSettings[key] || false;
                } else {
                    element.value = aiSettings[key] || element.defaultValue;
                }
            }
        });

        // Handle server host separately
        if (aiSettings.endpoint_url) {
            const hostInput = document.getElementById('ai-server-host');
            if (hostInput) {
                // Extract host and port from endpoint_url
                const url = new URL(aiSettings.endpoint_url);
                const host = url.hostname;
                const port = url.port || '1234';
                hostInput.value = `${host}:${port}`;
            }
        }

        // Update toggle visibility after loading settings
        const modalMemoryEnabled = document.getElementById('ai-modal-memory-enabled');
        const modalMemoryLimitGroup = document.getElementById('modal-memory-limit-group');
        if (modalMemoryEnabled && modalMemoryLimitGroup) {
            modalMemoryLimitGroup.style.display = modalMemoryEnabled.checked ? 'block' : 'none';
        }

        const channelMemoryEnabled = document.getElementById('ai-channel-memory-enabled');
        const channelMemoryLimitGroup = document.getElementById('channel-memory-limit-group');
        if (channelMemoryEnabled && channelMemoryLimitGroup) {
            channelMemoryLimitGroup.style.display = channelMemoryEnabled.checked ? 'block' : 'none';
        }
    }

    // Load conversations
    loadConversations() {
        // This will be implemented when conversation management is added
        console.log('Loading conversations...');
    }

    // Start new conversation
    startNewConversation() {
        // Prevent multiple simultaneous calls
        if (this.startingConversation) {
            return;
        }

        this.startingConversation = true;

        try {
            const characterManager = this.getModule('characterManager');
            const activeCharacter = characterManager?.activeCharacter;

            // If no active character and characters are loaded, prompt user
            if (!activeCharacter && this.charactersLoaded && characterManager?.characters?.length > 0) {
                // Prevent spam by checking if we're already on characters tab
                if (this.currentTab !== 'characters') {
                    alert('Please select a character first.');
                    this.switchTab('characters');
                }
                return;
            }

            // If characters are still loading, just wait
            if (!this.charactersLoaded) {
                return;
            }

            // This will be implemented when conversation management is added
            console.log('Starting new conversation with:', activeCharacter?.character_name || 'no character');
        } finally {
            // Reset flag after a short delay
            setTimeout(() => {
                this.startingConversation = false;
            }, 500);
        }
    }

    // Show settings
    showSettings() {
        // This will be implemented when settings modal is integrated
        console.log('Showing settings...');
    }

    // Populate settings form
    populateSettings(config) {
        const hostInput = document.getElementById('ai-server-host');
        const modelSelect = document.getElementById('ai-model-select');

        if (hostInput && config.endpoint_url) {
            // Extract host and port from endpoint_url
            const url = new URL(config.endpoint_url);
            const host = `${url.hostname}:${url.port}`;
            hostInput.value = host;
        }

        if (modelSelect) {
            modelSelect.value = config.model || '';
        }

        // Populate models list
        this.populateModelsList(config.available_models || []);
    }

    // Populate models dropdown in settings
    populateModelsList(models) {
        const select = document.getElementById('ai-model-select');
        if (!select) return;

        // Clear existing options except the first one
        select.innerHTML = '<option value="">Auto (use server default)</option>';

        if (models && models.length > 0) {
            models.forEach(model => {
                const option = document.createElement('option');
                option.value = model.id || model;
                option.textContent = model.id || model;
                select.appendChild(option);
            });
        }
    }

    // Populate system settings form
    populateSystemSettings(settings) {
        const form = document.getElementById('ai-system-settings-form');

        if (!form) return;

        // Populate system settings
        Object.keys(settings).forEach(key => {
            const element = form.querySelector(`[name="${key}"]`);
            if (element) {
                if (element.type === 'checkbox') {
                    element.checked = settings[key] || false;
                } else {
                    element.value = settings[key] || element.defaultValue;
                }
            }
        });

        this.updateStatus('System settings loaded');
        setTimeout(() => this.updateStatus(''), 2000);
    }

    // Handle connection test result
    handleConnectionTestResult(data) {
        if (data.success) {
            this.updateStatus('Connection successful!');
            setTimeout(() => this.updateStatus('Ready'), 3000);
        } else {
            this.updateStatus(`Connection failed: ${data.message}`);
        }
    }

    // Update conversations list in sidebar
    updateConversationsList(conversations) {
        const container = document.getElementById('ai-conversations-container');
        if (!container) return;

        if (!conversations || conversations.length === 0) {
            container.innerHTML = '<div class="no-conversations">No conversations yet</div>';
            return;
        }

        container.innerHTML = conversations.map(conv => `
            <div class="conversation-item" data-conversation-id="${conv.id}">
                <div class="conversation-title">${conv.title || 'Untitled'}</div>
                <div class="conversation-character">${conv.character_display || 'Default AI'}</div>
                <div class="conversation-preview">${conv.preview || 'Start a new conversation...'}</div>
                <div class="conversation-date">${this.formatConversationDate(conv.updated_at)}</div>
                <div class="conversation-actions">
                    <button class="conversation-edit" data-conversation-id="${conv.id}" title="Edit conversation title">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="conversation-delete" data-conversation-id="${conv.id}" title="Delete conversation">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');

        // Bind conversation item events
        container.addEventListener('click', (e) => {
            const item = e.target.closest('.conversation-item');
            const deleteBtn = e.target.closest('.conversation-delete');
            const editBtn = e.target.closest('.conversation-edit');

            if (deleteBtn) {
                e.stopPropagation();
                this.deleteConversation(deleteBtn.dataset.conversationId);
            } else if (editBtn) {
                e.stopPropagation();
                this.editConversation(editBtn.dataset.conversationId);
            } else if (item) {
                this.selectConversation(item.dataset.conversationId);
            }
        });
    }

    // Format conversation date for display
    formatConversationDate(timestamp) {
        if (!timestamp) return '';
        const date = new Date(timestamp);
        const now = new Date();
        const diffDays = Math.floor((now - date) / (1000 * 60 * 60 * 24));

        if (diffDays === 0) return 'Today';
        if (diffDays === 1) return 'Yesterday';
        if (diffDays < 7) return date.toLocaleDateString([], { weekday: 'short' });
        return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }

    // Load conversations (simplified)
    loadConversations() {
        // This will be implemented when conversation management is added
        console.log('Loading conversations...');
    }

    // Save system settings
    saveSystemSettings() {
        const form = document.getElementById('ai-system-settings-form');
        if (!form) return;

        const formData = new FormData(form);
        const settings = {};

        // Get all form elements to handle checkboxes properly
        const formElements = form.querySelectorAll('input, select, textarea');
        formElements.forEach(element => {
            const key = element.name;
            if (key) {
                if (element.type === 'checkbox') {
                    settings[key] = element.checked;
                } else if (element.type === 'number') {
                    settings[key] = parseFloat(element.value) || parseInt(element.value) || element.value;
                } else {
                    settings[key] = element.value;
                }
            }
        });

        this.updateStatus('Saving system settings...');

        if (typeof socket !== 'undefined') {
            socket.emit('ai_save_system_settings', { settings: settings });
            this.showToast('System settings saved successfully!', 'success');
        } else {
            this.showToast('Unable to save system settings - socket not available', 'error');
        }
    }

    // Load system settings
    loadSystemSettings() {
        this.updateStatus('Loading system settings...');

        if (typeof socket !== 'undefined') {
            socket.emit('ai_get_system_settings');
        } else {
            this.showToast('Unable to load system settings - socket not available', 'error');
        }
    }

    // Select conversation
    selectConversation(conversationId) {
        if (this.modules.conversationManager) {
            this.modules.conversationManager.selectConversation(conversationId);
        }
    }

    // Edit conversation title
    editConversation(conversationId) {
        const newTitle = prompt('Enter new conversation title:');
        if (newTitle && newTitle.trim()) {
            if (this.modules.conversationManager) {
                this.modules.conversationManager.updateConversationTitle(conversationId, newTitle.trim());
            }
        }
    }

    // Delete conversation
    deleteConversation(conversationId) {
        if (confirm('Delete this conversation?')) {
            if (typeof socket !== 'undefined') {
                socket.emit('ai_delete_conversation', { conversation_id: conversationId });
            }
        }
    }

    // Clear all conversations
    clearAllConversations() {
        if (!confirm('Are you sure you want to delete ALL conversations? This action cannot be undone.')) {
            return;
        }

        if (typeof socket !== 'undefined') {
            socket.emit('ai_clear_all_conversations');

            socket.once('ai_conversations_cleared', (data) => {
                if (data.success) {
                    // Clear local conversation list
                    if (this.modules.conversationManager) {
                        this.modules.conversationManager.conversations = [];
                        this.modules.conversationManager.currentConversationId = null;
                        this.modules.conversationManager.updateConversationsUI();
                    }

                    // Start a new conversation
                    this.startNewConversation();

                    this.updateStatus('All conversations cleared');
                } else {
                    this.handleAIError(data.message || 'Failed to clear conversations');
                }
            });
        }
    }

    // Handle AI errors
    handleAIError(message) {
        console.error('AI Error:', message);
        this.updateStatus(`Error: ${message}`);
        // Could show a toast notification or modal here
        alert(`AI Error: ${message}`);
    }

    // Update status text
    updateStatus(text) {
        const statusEl = document.getElementById('ai-status-text');
        if (statusEl) {
            statusEl.textContent = text;
        }
    }

    // Toggle sidebar collapse/expand
    toggleSidebar() {
        const sidebar = document.querySelector('.ai-chat-sidebar');
        if (sidebar) {
            sidebar.classList.toggle('collapsed');
            const icon = document.querySelector('#ai-toggle-sidebar .fas');
            if (icon) {
                if (sidebar.classList.contains('collapsed')) {
                    icon.className = 'fas fa-chevron-right';
                } else {
                    icon.className = 'fas fa-chevron-left';
                }
            }
        }
    }

    // Get module by name
    getModule(moduleName) {
        return this.modules[moduleName];
    }

    // Check if all modules are ready
    isReady() {
        return this.isInitialized && Object.values(this.moduleStatus).every(status => status);
    }
}

// Global orchestrator instance
let aiModalOrchestrator;

// Global API functions
function initAIModal() {
    console.log('[DEBUG] initAIModal called, aiModalOrchestrator exists:', !!aiModalOrchestrator);
    try {
        if (!aiModalOrchestrator) {
            console.log('[DEBUG] Creating new AIModalOrchestrator');
            aiModalOrchestrator = new AIModalOrchestrator();
            window.aiModalOrchestrator = aiModalOrchestrator; // Set global immediately
            console.log('[DEBUG] Created orchestrator, calling init');
            return aiModalOrchestrator.init();
        }
        console.log('[DEBUG] Orchestrator already exists');
        return Promise.resolve();
    } catch (error) {
        console.error('[DEBUG] Error in initAIModal:', error);
        throw error;
    }
}

function openAIModal() {
    console.log('[DEBUG] openAIModal called, aiModalOrchestrator exists:', !!aiModalOrchestrator);
    if (!aiModalOrchestrator) {
        console.log('[DEBUG] Initializing modal first');
        initAIModal().then(() => {
            console.log('[DEBUG] Init complete, opening modal');
            aiModalOrchestrator.open();
        }).catch(error => {
            console.error('[DEBUG] Failed to initialize modal:', error);
        });
    } else {
        console.log('[DEBUG] Opening existing modal');
        aiModalOrchestrator.open();
    }
}

function closeAIModal() {
    if (aiModalOrchestrator) {
        aiModalOrchestrator.close();
    }
}

function switchAIModalTab(tabName) {
    if (aiModalOrchestrator) {
        aiModalOrchestrator.switchTab(tabName);
    } else {
        console.warn('AI Modal orchestrator not initialized, cannot switch tab');
    }
}

// Export for global access
try {
    console.log('AI Modal: Defining global functions');
    window.openAIModal = openAIModal;
    window.closeAIModal = closeAIModal;
    window.switchAIModalTab = switchAIModalTab;
    window.aiModalOrchestrator = aiModalOrchestrator;
    console.log('AI Modal: Global functions defined', typeof window.openAIModal);
    console.log('AI Modal: Script loaded successfully at end');
} catch (error) {
    console.error('AI Modal: Failed to define global functions:', error);
}