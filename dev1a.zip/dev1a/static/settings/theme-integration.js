// ============================================================================
// Theme Integration - Handles theme switching and cursor/particle theming
// ============================================================================

import { showError } from '../core/ui-utils.js';

/**
 * ThemeIntegration - Manages theme switching and integration with cursors/particles
 */
export class ThemeIntegration {
    constructor() {
        // Current theme state
        this.currentTheme = 'dobo';

        // Callbacks
        this.onThemeChange = null;
    }

    /**
     * Set theme change callback
     */
    setOnThemeChange(callback) {
        this.onThemeChange = callback;
    }

    /**
     * Initialize theme integration
     */
    initialize() {
        this.loadCustomThemes();
        this.setupThemeListeners();
    }

    /**
     * Setup theme change listeners
     */
    setupThemeListeners() {
        // Listen for theme option clicks
        document.addEventListener('click', (event) => {
            const themeOption = event.target.closest('.theme-option');
            if (themeOption && !event.target.closest('.theme-edit-icon, .theme-delete-icon')) {
                const themeName = themeOption.getAttribute('data-theme');
                if (themeName) {
                    this.applyTheme(themeName);
                }
            }
        });
    }

    /**
     * Apply a theme by name
     */
    applyTheme(themeName, triggerCallback = true) {
        console.log('Applying theme:', themeName);

        // Remove any existing theme classes
        document.documentElement.className = document.documentElement.className.replace(/theme-\w+/g, '').trim();

        // Add the new theme class
        document.documentElement.classList.add(`theme-${themeName}`);

        // Clear any inline CSS variables from previous custom themes
        this.clearCustomThemeVariables();

        // For custom themes, apply the CSS variables
        if (themeName.startsWith('custom-')) {
            this.applyCustomThemeVariables(themeName);
        }

        // Update themed cursor
        this.updateThemedCursor(themeName);

        // Update theme for particles
        if (window.updateCursorEffectTheme) {
            window.updateCursorEffectTheme();
        }

        // Update current theme
        this.currentTheme = themeName;

        // Notify listeners
        if (this.onThemeChange && triggerCallback) {
            this.onThemeChange(themeName);
        }

        // Update theme previews
        this.updateThemePreviews();
    }

    /**
     * Clear custom theme CSS variables
     */
    clearCustomThemeVariables() {
        const root = document.documentElement.style;
        const cssVarsToClear = [
            '--bg-primary', '--bg-secondary', '--bg-tertiary', '--bg-quaternary',
            '--text-primary', '--text-secondary', '--text-muted',
            '--accent', '--accent-hover', '--green', '--border', '--neon-glow',
            '--hover', '--active', '--pulse-color', '--theme-accent-color'
        ];
        cssVarsToClear.forEach(varName => root.removeProperty(varName));
    }

    /**
     * Apply custom theme CSS variables
     */
    applyCustomThemeVariables(themeName) {
        // Find the custom theme data
        const themeOptions = document.querySelectorAll('.theme-option');
        const customOption = Array.from(themeOptions).find(option =>
            option.getAttribute('data-theme') === themeName && option._themeData
        );

        if (customOption && customOption._themeData) {
            this.applyCustomTheme(customOption._themeData.colors);
        }
    }

    /**
     * Apply custom theme colors
     */
    applyCustomTheme(colors) {
        // Apply custom theme colors to CSS variables with proper mapping
        const root = document.documentElement.style;

        // Map custom theme color keys to CSS variable names
        const colorMapping = {
            'primary': '--bg-primary',
            'secondary': '--bg-secondary',
            'tertiary': '--bg-tertiary',
            'textPrimary': '--text-primary',
            'textSecondary': '--text-secondary',
            'textMuted': '--text-muted',
            'accent': '--accent',
            'accentHover': '--accent-hover',
            'green': '--green',
            'border': '--border',
            'neonGlow': '--neon-glow'
        };

        Object.entries(colors).forEach(([key, value]) => {
            const cssVar = colorMapping[key] || `--${key}`;
            root.setProperty(cssVar, value);
        });

        // Set additional required variables that might be missing
        if (!colors.quaternary) {
            // Calculate a quaternary color based on tertiary (slightly lighter/darker)
            const tertiary = colors.tertiary || '#2a2a2a';
            root.setProperty('--bg-quaternary', tertiary);
        }

        // Set hover and active states based on accent
        if (colors.accent) {
            const accent = colors.accent;
            // Convert hex to rgba for opacity
            const r = parseInt(accent.slice(1, 3), 16);
            const g = parseInt(accent.slice(3, 5), 16);
            const b = parseInt(accent.slice(5, 7), 16);
            root.setProperty('--hover', `rgba(${r}, ${g}, ${b}, 0.1)`);
            root.setProperty('--active', `rgba(${r}, ${g}, ${b}, 0.2)`);
            root.setProperty('--pulse-color', `rgba(${r}, ${g}, ${b}, 0.3)`);
        }

        // Set theme accent color defaults (font is handled by settings system)
        if (colors.accent) {
            root.setProperty('--theme-accent-color', `${colors.accent}15`); // 8% opacity
        }
    }

    /**
     * Update themed cursor when theme changes
     */
    updateThemedCursor(theme) {
        // This will be handled by the cursor manager
        console.log('Theme changed to:', theme, '- cursor will be updated by cursor manager');
    }

    /**
     * Load custom themes from server
     */
    async loadCustomThemes() {
        try {
            const response = await fetch('/load-custom-themes?username=' + encodeURIComponent(window.currentUsername || 'admin'), {
                credentials: 'include'
            });
            const data = await response.json();

            if (response.ok && data.themes) {
                this.populateCustomThemes(data.themes);
            }
        } catch (error) {
            console.error('Failed to load custom themes:', error);
        }
    }

    /**
     * Populate custom themes in the UI
     */
    populateCustomThemes(themes) {
        const themeGrid = document.getElementById('theme-grid');
        if (!themeGrid) return;

        // Clear existing custom themes
        const existingCustom = themeGrid.querySelectorAll('.theme-option[data-theme^="custom-"]');
        existingCustom.forEach(option => option.remove());

        // Add custom themes
        themes.forEach(theme => {
            const themeOption = this.createThemeOption(`custom-${theme.name.toLowerCase().replace(/\s+/g, '-')}`, theme.colors, theme.name);
            themeOption._themeData = theme;
            themeGrid.appendChild(themeOption);
        });

        // Add theme edit icons
        this.addThemeEditIcons();
    }

    /**
     * Create a theme option element
     */
    createThemeOption(themeName, colors, displayName = null) {
        const option = document.createElement('div');
        option.className = 'theme-option';
        option.setAttribute('data-theme', themeName);

        const name = displayName || themeName.replace('custom-', '').replace(/-/g, ' ');

        // Create color preview
        const colorsArray = [
            colors.primary, colors.secondary, colors.tertiary, colors.quaternary,
            colors.textPrimary, colors.textSecondary, colors.textMuted,
            colors.accent, colors.accentHover, colors.green,
            colors.border, colors.borderLight, colors.neonGlow, colors.pulseColor
        ].filter(color => color && color !== '');

        let colorGrid = '<div class="theme-color-grid">';
        colorsArray.slice(0, 12).forEach(color => {
            colorGrid += `<div class="theme-color-square" style="background-color: ${color};" title="${color}"></div>`;
        });
        colorGrid += '</div>';

        option.innerHTML = `
            ${colorGrid}
            <div class="theme-name">${name}</div>
        `;

        return option;
    }

    /**
     * Add edit icons to custom themes
     */
    addThemeEditIcons() {
        const themeOptions = document.querySelectorAll('.theme-option');
        themeOptions.forEach(option => {
            const themeName = option.getAttribute('data-theme');

            // Skip built-in themes for now, only allow editing custom themes
            if (!themeName || !themeName.startsWith('custom-')) {
                return;
            }

            // Skip if icons already exist
            if (option.querySelector('.theme-icons-container')) {
                return;
            }

            // Add icons container
            const iconsContainer = document.createElement('div');
            iconsContainer.className = 'theme-icons-container';

            // Add gear icon for editing
            const gearIcon = document.createElement('div');
            gearIcon.className = 'theme-edit-icon';
            gearIcon.innerHTML = '⚙️';
            gearIcon.title = 'Edit theme';
            gearIcon.onclick = (e) => {
                e.stopPropagation(); // Prevent theme selection
                this.editTheme(themeName);
            };

            // Add delete icon
            const deleteIcon = document.createElement('div');
            deleteIcon.className = 'theme-delete-icon';
            deleteIcon.innerHTML = '🗑️';
            deleteIcon.title = 'Delete theme';
            deleteIcon.onclick = (e) => {
                e.stopPropagation(); // Prevent theme selection
                this.deleteTheme(themeName);
            };

            iconsContainer.appendChild(gearIcon);
            iconsContainer.appendChild(deleteIcon);
            option.appendChild(iconsContainer);
        });
    }

    /**
     * Edit a custom theme
     */
    async editTheme(themeName) {
        if (!window.state?.isAuthenticated) {
            showError('You must be logged in to edit themes');
            return;
        }

        if (!themeName.startsWith('custom-')) {
            showError('Built-in themes cannot be edited yet. Create a custom theme instead.');
            return;
        }

        try {
            // Load custom themes to find the one to edit
            const response = await fetch('/load-custom-themes?username=' + encodeURIComponent(window.currentUsername || 'admin'), {
                credentials: 'include'
            });
            const data = await response.json();

            if (response.ok && data.themes) {
                const themeToEdit = data.themes.find(theme => `custom-${theme.name.toLowerCase().replace(/\s+/g, '-')}` === themeName);

                if (themeToEdit) {
                    // Populate the theme creator with the existing theme data
                    this.populateThemeCreator(themeToEdit);
                    window.editingThemeName = themeToEdit.name;
                    this.openThemeCreatorModal();
                } else {
                    showError('Theme not found');
                }
            } else {
                showError('Failed to load theme data');
            }
        } catch (error) {
            console.error('Error loading theme for editing:', error);
            showError('Failed to load theme for editing');
        }
    }

    /**
     * Delete a custom theme
     */
    async deleteTheme(themeName) {
        if (!window.state?.isAuthenticated) {
            showError('You must be logged in to delete themes');
            return;
        }

        if (!themeName.startsWith('custom-')) {
            showError('Built-in themes cannot be deleted');
            return;
        }

        // Confirm deletion
        if (!confirm(`Are you sure you want to delete the theme "${themeName.replace('custom-', '').replace(/-/g, ' ')}"?`)) {
            return;
        }

        try {
            const response = await fetch('/delete-custom-theme?username=' + encodeURIComponent(window.currentUsername || 'admin'), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'include',
                body: JSON.stringify({ theme_name: themeName.replace('custom-', '') })
            });

            const data = await response.json();

            if (response.ok && data.success) {
                // Remove theme from UI
                const themeOption = document.querySelector(`.theme-option[data-theme="${themeName}"]`);
                if (themeOption) {
                    themeOption.remove();
                }

                console.log(`Theme deleted successfully!`);
            } else {
                showError(data.error || 'Failed to delete theme');
            }
        } catch (error) {
            console.error('Error deleting custom theme:', error);
            showError('Failed to delete theme: ' + error.message);
        }
    }

    /**
     * Populate theme creator with existing theme data
     */
    populateThemeCreator(theme) {
        // Set theme name
        const nameInput = document.getElementById('theme-name');
        if (nameInput) nameInput.value = theme.name || '';

        // Set color values
        const colors = theme.colors || {};
        Object.keys(colors).forEach(key => {
            const input = document.getElementById(key);
            if (input) input.value = colors[key];
        });

        // Update preview
        this.updateThemeCreatorPreview();
    }

    /**
     * Open theme creator modal
     */
    openThemeCreatorModal() {
        try {
            const modal = document.getElementById('theme-creator-modal');
            if (modal) {
                modal.style.display = 'flex';
                this.updateThemeCreatorPreview();
                console.log('Theme creator modal opened successfully');
            } else {
                console.error('Theme creator modal not found in DOM');
                if (window.showError) {
                    window.showError('Theme creator modal is not available. Please refresh the page.');
                }
            }
        } catch (error) {
            console.error('Error opening theme creator modal:', error);
            if (window.showError) {
                window.showError('Failed to open theme creator: ' + error.message);
            }
        }
    }

    /**
     * Close theme creator modal
     */
    closeThemeCreatorModal() {
        const modal = document.getElementById('theme-creator-modal');
        if (modal) {
            modal.style.display = 'none';
            // Reset editing state
            this.editingThemeName = null;
            // Reset modal title and button text
            const modalTitle = modal.querySelector('.modal-header h2');
            const saveButton = modal.querySelector('.btn-primary');
            if (modalTitle) modalTitle.textContent = 'Create Custom Theme';
            if (saveButton) saveButton.textContent = 'Create Theme';
        }
    }

    /**
     * Save custom theme
     */
    async saveCustomTheme() {
        // This is a complex function that needs to be implemented
        // For now, just log that it's not implemented
        console.log('saveCustomTheme not fully implemented in modular version');
    }

    /**
     * Update theme creator preview
     */
    updateThemeCreatorPreview() {
        // This would update the theme preview in the creator modal
        console.log('Updating theme creator preview');
    }

    /**
     * Update theme previews with color grids
     */
    updateThemePreviews() {
        const themeOptions = document.querySelectorAll('.theme-option');
        themeOptions.forEach(option => {
            const themeName = option.getAttribute('data-theme');
            if (themeName === this.currentTheme) {
                option.classList.add('active');
            } else {
                option.classList.remove('active');
            }
        });
    }

    /**
     * Get current theme
     */
    getCurrentTheme() {
        return this.currentTheme;
    }
}