// ============================================================================
// Settings UI - Handles settings modal and form interactions
// ============================================================================

import { showError } from '../core/ui-utils.js';

/**
 * SettingsUI - Manages the settings modal and form interactions
 */
export class SettingsUI {
    constructor() {
        // DOM elements (will be set by orchestrator)
        this.elements = {};

        // Modal state
        this.settingsModal = null;
        this.settingsChanged = false;

        // Callbacks
        this.onSettingsChange = null;
        this.onSaveSettings = null;
    }

    /**
     * Set DOM elements reference
     */
    setElements(elements) {
        this.elements = elements;
    }

    /**
     * Set settings change callback
     */
    setOnSettingsChange(callback) {
        this.onSettingsChange = callback;
    }

    /**
     * Set save settings callback
     */
    setOnSaveSettings(callback) {
        this.onSaveSettings = callback;
    }

    /**
     * Initialize settings UI
     */
    initialize() {
        this.cacheElements();
        this.setupEventListeners();
        this.addDynamicElements();
    }

    /**
     * Cache DOM elements
     */
    cacheElements() {
        this.settingsModal = document.getElementById('user-settings-modal');

        // Extend elements with all settings form elements
        this.elements = {
            ...this.elements,
            // Avatar
            currentAvatarImg: document.getElementById('settings-current-avatar'),
            avatarInput: document.getElementById('settings-avatar-input'),
            // Text inputs
            displayNameInput: document.getElementById('settings-display-name'),
            customStatusInput: document.getElementById('settings-custom-status'),

            // Selects
            statusSelect: document.getElementById('settings-status'),
            fontSelect: document.getElementById('settings-font'),
            fontScaleInput: document.getElementById('settings-font-scale'),
            animatedBgSelect: document.getElementById('settings-animated-bg'),

            // Checkboxes
            compactModeCheckbox: document.getElementById('settings-compact-mode'),
            showTimestampsCheckbox: document.getElementById('settings-show-timestamps'),
            soundEffectsCheckbox: document.getElementById('settings-sound-effects'),
            annoyingHoverSoundsCheckbox: document.getElementById('settings-annoying-hover-sounds'),
            soundboardSoundsCheckbox: document.getElementById('settings-soundboard-sounds'),
            cursorGlowCheckbox: document.getElementById('settings-cursor-glow'),
            allowDmsCheckbox: document.getElementById('settings-allow-dms'),
            showOnlineStatusCheckbox: document.getElementById('settings-show-online-status'),
            typingIndicatorsCheckbox: document.getElementById('settings-typing-indicators'),
            muteCheckbox: document.getElementById('settings-mute'),

            // Sliders
            micVolumeInput: document.getElementById('settings-mic-volume'),
            receiveVolumeInput: document.getElementById('settings-receive-volume'),
            soundboardVolumeInput: document.getElementById('settings-soundboard-volume'),

            // Cursor/Particle elements (will be added dynamically)
            cursorMainSelect: document.getElementById('settings-cursor-main'),
            cursorParticleSelect: document.getElementById('settings-cursor-particle'),
            cursorEffectSelect: document.getElementById('settings-cursor-effect'),
            particleStyleSelect: document.getElementById('settings-particle-style'),
            particleSizeInput: document.getElementById('settings-particle-size'),
            cursorSizeSelect: document.getElementById('settings-cursor-size'),
            autoHideParticlesCheckbox: document.getElementById('settings-auto-hide-particles'),
            autoHideTimeoutInput: document.getElementById('settings-auto-hide-timeout')
        };
    }

    /**
     * Setup event listeners for all settings controls
     */
    setupEventListeners() {
        // Text inputs
        this.attachInputListener(this.elements.displayNameInput, 'display_name');
        this.attachInputListener(this.elements.customStatusInput, 'custom_status');

        // Selects
        this.attachChangeListener(this.elements.statusSelect, 'status');
        this.attachChangeListener(this.elements.fontSelect, 'font');
        this.attachInputListener(this.elements.fontScaleInput, 'font_scale', parseFloat);
        this.attachChangeListener(this.elements.animatedBgSelect, 'animated_bg');

        // Checkboxes
        this.attachCheckboxListener(this.elements.compactModeCheckbox, 'compact_mode');
        this.attachCheckboxListener(this.elements.showTimestampsCheckbox, 'show_timestamps');
        this.attachCheckboxListener(this.elements.soundEffectsCheckbox, 'sound_effects');
        this.attachCheckboxListener(this.elements.annoyingHoverSoundsCheckbox, 'annoying_hover_sounds');
        this.attachCheckboxListener(this.elements.cursorGlowCheckbox, 'cursor_glow');
        this.attachCheckboxListener(this.elements.allowDmsCheckbox, 'allow_dms');
        this.attachCheckboxListener(this.elements.showOnlineStatusCheckbox, 'show_online_status');
        this.attachCheckboxListener(this.elements.typingIndicatorsCheckbox, 'typing_indicators');
        this.attachCheckboxListener(this.elements.muteCheckbox, 'mute');
        this.attachCheckboxListener(this.elements.soundboardSoundsCheckbox, 'soundboard_sounds');

        // Sliders
        this.attachInputListener(this.elements.micVolumeInput, 'mic_volume', parseFloat);
        this.attachInputListener(this.elements.receiveVolumeInput, 'receive_volume', parseFloat);
        this.attachInputListener(this.elements.soundboardVolumeInput, 'soundboard_volume', parseFloat);

        // Cursor/Particle browse buttons
        this.setupBrowseButtons();

        // Modal close handlers
        this.setupModalCloseHandlers();

        // Save button
        this.setupSaveButton();

        // Tab switching
        this.setupTabSwitching();
    }

    /**
     * Attach input listener to element
     */
    attachInputListener(element, settingKey, parser = null) {
        if (!element) return;

        element.addEventListener('input', () => {
            let value = element.value;
            if (parser) {
                value = parser(value);
            }
            this.handleSettingChange(settingKey, value);
        });
    }

    /**
     * Attach change listener to element
     */
    attachChangeListener(element, settingKey, parser = null) {
        if (!element) return;

        element.addEventListener('change', () => {
            let value = element.value;
            if (parser) {
                value = parser(value);
            }
            this.handleSettingChange(settingKey, value);
        });
    }

    /**
     * Attach checkbox listener to element
     */
    attachCheckboxListener(element, settingKey) {
        if (!element) return;

        element.addEventListener('change', () => {
            this.handleSettingChange(settingKey, element.checked);
        });
    }

    /**
     * Handle setting change
     */
    handleSettingChange(key, value) {
        this.settingsChanged = true;
        this.updateSaveButtonState();

        if (this.onSettingsChange) {
            this.onSettingsChange(key, value);
        }
    }

    /**
     * Setup modal close handlers
     */
    setupModalCloseHandlers() {
        // Close button
        const closeBtn = document.querySelector('.settings-modal .close');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.closeSettings());
        }

        // Click outside to close
        if (this.settingsModal) {
            this.settingsModal.addEventListener('click', (event) => {
                if (event.target === this.settingsModal) {
                    this.closeSettings();
                }
            });
        }

        // Escape key to close
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape' && this.settingsModal && this.settingsModal.style.display === 'flex') {
                this.closeSettings();
            }
        });
    }

    /**
     * Setup save button functionality
     */
    setupSaveButton() {
        const saveButton = document.querySelector('.save-settings-btn');
        if (saveButton) {
            saveButton.addEventListener('click', () => {
                if (this.onSaveSettings) {
                    this.onSaveSettings();
                }
            });
        }
    }

    /**
     * Setup tab switching functionality
     */
    setupTabSwitching() {
        const tabs = document.querySelectorAll('.settings-tab');
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const tabName = tab.dataset.tab;

                // Update active tab
                tabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');

                // Show corresponding content
                const contents = document.querySelectorAll('.settings-tab-content');
                contents.forEach(content => {
                    if (content.id === `settings-tab-${tabName}`) {
                        content.style.display = 'block';
                    } else {
                        content.style.display = 'none';
                    }
                });
            });
        });
    }

    /**
     * Setup browse button functionality for cursor/particle selection
     */
    setupBrowseButtons() {
        // Cursor browse button
        const cursorBrowseBtn = document.getElementById('browse-cursor-main');
        if (cursorBrowseBtn) {
            cursorBrowseBtn.addEventListener('click', () => {
                if (window.openCursorSelection) {
                    window.openCursorSelection('settings-cursor-main');
                }
            });
        }

        // Particle browse button
        const particleBrowseBtn = document.getElementById('browse-cursor-particle');
        if (particleBrowseBtn) {
            particleBrowseBtn.addEventListener('click', () => {
                if (window.openParticleSelection) {
                    window.openParticleSelection('settings-cursor-particle');
                }
            });
        }
    }

    /**
     * Add dynamic elements that may not exist in HTML
     */
    addDynamicElements() {
        this.addFontScaleSelector();
        this.addCursorSizeSelector();
    }

    /**
     * Add font scale selector if it doesn't exist
     */
    addFontScaleSelector() {
        const fontSelect = this.elements.fontSelect;
        if (!fontSelect || document.getElementById('settings-font-scale')) return;

        const fontScaleGroup = document.createElement('div');
        fontScaleGroup.className = 'form-group';
        fontScaleGroup.innerHTML = `
            <label for="settings-font-scale">Font Scale</label>
            <input type="range" id="settings-font-scale" name="font_scale" min="0.5" max="2.0" step="0.1" value="1.0">
            <span id="font-scale-value">1.0x</span>
        `;

        fontSelect.closest('.form-group').after(fontScaleGroup);

        // Update display value
        const input = fontScaleGroup.querySelector('#settings-font-scale');
        const display = fontScaleGroup.querySelector('#font-scale-value');

        input.addEventListener('input', () => {
            display.textContent = input.value + 'x';
        });

        // Auto-save on change
        input.addEventListener('change', () => {
            if (this.onSaveSettings) {
                this.onSaveSettings();
            }
        });
    }

    /**
     * Add cursor size selector if it doesn't exist
     */
    addCursorSizeSelector() {
        const cursorGlowCheckbox = document.getElementById('settings-cursor-glow');
        if (!cursorGlowCheckbox || document.getElementById('settings-cursor-size')) return;

        const sizeGroup = document.createElement('div');
        sizeGroup.className = 'form-group';
        sizeGroup.innerHTML = `
            <label for="settings-cursor-size">Cursor Size</label>
            <select id="settings-cursor-size" name="cursor_size">
                <option value="32">Small (32x32)</option>
                <option value="48">Medium-Small (48x48)</option>
                <option value="64">Medium (64x64)</option>
                <option value="96">Medium-Large (96x96)</option>
                <option value="128">Large (128x128)</option>
            </select>
        `;

        cursorGlowCheckbox.closest('.form-group').after(sizeGroup);
    }

    /**
     * Get current user avatar URL
     */
    getCurrentUserAvatar() {
        // Use the global getAvatarUrl function if available
        if (window.getAvatarUrl) {
            return window.getAvatarUrl(null, true);
        }

        // Fallback: check current user settings or users_db
        return window.currentUserSettings?.avatar_url ||
               (Object.values(window.users_db || {}).find(u => u.username === window.currentUsername)?.avatar_url) ||
               '/static/default_avatars/smile_1.png';
    }

    /**
     * Populate form with current settings
     */
    populateForm(settings) {
        // Update avatar
        if (this.elements.currentAvatarImg) {
            // Get user avatar from global state
            const userAvatar = this.getCurrentUserAvatar();
            if (userAvatar) {
                this.elements.currentAvatarImg.src = userAvatar;
            }
        }

        // Text inputs
        if (this.elements.displayNameInput) {
            // Use setting value, or fall back to current user's display name
            const displayName = settings.display_name ||
                               (window.getDisplayName ? window.getDisplayName(null, true) : '') ||
                               window.currentUsername || '';
            this.elements.displayNameInput.value = displayName;
        }
        if (this.elements.customStatusInput) {
            this.elements.customStatusInput.value = settings.custom_status || '';
        }

        // Selects
        if (this.elements.statusSelect) {
            this.elements.statusSelect.value = settings.status || 'online';
        }
        if (this.elements.fontSelect) {
            this.elements.fontSelect.value = settings.font || 'system';
        }
        if (this.elements.fontScaleInput) {
            this.elements.fontScaleInput.value = settings.font_scale || 1.0;
        }
        if (this.elements.animatedBgSelect) {
            this.elements.animatedBgSelect.value = settings.animated_bg || 'none';
        }

        // Checkboxes
        if (this.elements.compactModeCheckbox) {
            this.elements.compactModeCheckbox.checked = settings.compact_mode || false;
        }
        if (this.elements.showTimestampsCheckbox) {
            this.elements.showTimestampsCheckbox.checked = settings.show_timestamps !== false;
        }
        if (this.elements.soundEffectsCheckbox) {
            this.elements.soundEffectsCheckbox.checked = settings.sound_effects !== false;
        }
        if (this.elements.annoyingHoverSoundsCheckbox) {
            this.elements.annoyingHoverSoundsCheckbox.checked = settings.annoying_hover_sounds || false;
        }
        if (this.elements.cursorGlowCheckbox) {
            this.elements.cursorGlowCheckbox.checked = settings.cursor_glow || false;
        }
        if (this.elements.allowDmsCheckbox) {
            this.elements.allowDmsCheckbox.checked = settings.allow_dms !== false;
        }
        if (this.elements.showOnlineStatusCheckbox) {
            this.elements.showOnlineStatusCheckbox.checked = settings.show_online_status !== false;
        }
        if (this.elements.typingIndicatorsCheckbox) {
            this.elements.typingIndicatorsCheckbox.checked = settings.typing_indicators !== false;
        }
        if (this.elements.muteCheckbox) {
            this.elements.muteCheckbox.checked = settings.mute || false;
        }

        // Sliders
        if (this.elements.micVolumeInput) {
            this.elements.micVolumeInput.value = settings.mic_volume || 1.0;
        }
        if (this.elements.receiveVolumeInput) {
            this.elements.receiveVolumeInput.value = settings.receive_volume || 1.0;
        }

        // Cursor/Particle settings
        if (this.elements.cursorEffectSelect) {
            this.elements.cursorEffectSelect.value = settings.cursor_effect || 'orbiting';
        }
        if (this.elements.particleStyleSelect) {
            this.elements.particleStyleSelect.value = settings.particle_style || 'theme';
        }
        if (this.elements.particleSizeInput) {
            this.elements.particleSizeInput.value = settings.particle_size || 1.0;
        }
        if (this.elements.cursorSizeSelect) {
            this.elements.cursorSizeSelect.value = settings.cursor_size || 64;
        }
        if (this.elements.autoHideParticlesCheckbox) {
            this.elements.autoHideParticlesCheckbox.checked = settings.auto_hide_particles !== false;
        }
        if (this.elements.autoHideTimeoutInput) {
            this.elements.autoHideTimeoutInput.value = settings.auto_hide_timeout || 10;
        }
    }

    /**
     * Update save button state
     */
    updateSaveButtonState() {
        const saveButton = document.querySelector('.save-settings-btn');
        if (saveButton) {
            saveButton.disabled = !this.settingsChanged;
            saveButton.textContent = this.settingsChanged ? 'Save Settings' : 'Settings Saved';
        }
    }

    /**
     * Show settings message
     */
    showMessage(message, type = 'info') {
        const messageDiv = document.createElement('div');
        messageDiv.className = `settings-message ${type}`;
        messageDiv.textContent = message;

        const modalContent = this.settingsModal?.querySelector('.modal-content');
        if (modalContent) {
            const firstChild = modalContent.querySelector('h2');
            if (firstChild) {
                modalContent.insertBefore(messageDiv, firstChild.nextSibling);
            }

            // Auto-remove after 5 seconds
            setTimeout(() => {
                if (messageDiv.parentNode) {
                    messageDiv.remove();
                }
            }, 5000);
        }
    }

    /**
     * Open settings modal
     */
    openSettings() {
        if (this.settingsModal) {
            this.settingsModal.style.display = 'flex';
        }
    }

    /**
     * Close settings modal
     */
    closeSettings() {
        if (this.settingsModal) {
            this.settingsModal.style.display = 'none';
        }
    }

    /**
     * Mark settings as saved
     */
    markSettingsSaved() {
        this.settingsChanged = false;
        this.updateSaveButtonState();
    }

    /**
     * Check if settings have unsaved changes
     */
    hasUnsavedChanges() {
        return this.settingsChanged;
    }
}