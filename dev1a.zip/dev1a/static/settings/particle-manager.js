// ============================================================================
// Particle Manager - Handles particle effects and styling
// ============================================================================

/**
 * ParticleManager - Manages particle effects and cursor particle styling
 */
export class ParticleManager {
    constructor() {
        // DOM elements (will be set by orchestrator)
        this.elements = {};

        // Current particle settings
        this.currentSettings = {
            particle_style: 'theme',
            particle_size: 1.0,
            auto_hide_particles: true,
            auto_hide_timeout: 10
        };

        // Callbacks
        this.onParticleChange = null;
    }

    /**
     * Set DOM elements reference
     */
    setElements(elements) {
        this.elements = elements;
    }

    /**
     * Set current particle settings
     */
    setSettings(settings) {
        this.currentSettings = { ...this.currentSettings, ...settings };
        this.applyParticleSettings();
    }

    /**
     * Set particle change callback
     */
    setOnParticleChange(callback) {
        this.onParticleChange = callback;
    }

    /**
     * Initialize particle manager
     */
    initialize() {
        this.setupParticleControls();
        this.applyParticleSettings();
    }

    /**
     * Setup particle control elements
     */
    setupParticleControls() {
        this.attachParticleEventListeners();
    }

    /**
     * Attach event listeners to particle controls
     */
    attachParticleEventListeners() {
        const particleStyleSelect = this.elements.particleStyleSelect;
        const particleSizeInput = this.elements.particleSizeInput;
        const autoHideParticlesCheckbox = this.elements.autoHideParticlesCheckbox;
        const autoHideTimeoutInput = this.elements.autoHideTimeoutInput;

        // Particle style select
        if (particleStyleSelect) {
            particleStyleSelect.addEventListener('change', () => {
                this.currentSettings.particle_style = particleStyleSelect.value;
                this.applyParticleSettings();
                if (this.onParticleChange) {
                    this.onParticleChange('particle_style', particleStyleSelect.value);
                }
            });
        }

        // Particle size input
        if (particleSizeInput) {
            particleSizeInput.addEventListener('input', () => {
                this.currentSettings.particle_size = parseFloat(particleSizeInput.value) || 1.0;
                this.applyParticleSettings();
                if (this.onParticleChange) {
                    this.onParticleChange('particle_size', this.currentSettings.particle_size);
                }
            });
        }

        // Auto-hide particles checkbox
        if (autoHideParticlesCheckbox) {
            autoHideParticlesCheckbox.addEventListener('change', () => {
                this.currentSettings.auto_hide_particles = autoHideParticlesCheckbox.checked;
                this.applyParticleSettings();
                if (this.onParticleChange) {
                    this.onParticleChange('auto_hide_particles', autoHideParticlesCheckbox.checked);
                }
            });
        }

        // Auto-hide timeout input
        if (autoHideTimeoutInput) {
            autoHideTimeoutInput.addEventListener('input', () => {
                this.currentSettings.auto_hide_timeout = parseInt(autoHideTimeoutInput.value) || 10;
                this.applyParticleSettings();
                if (this.onParticleChange) {
                    this.onParticleChange('auto_hide_timeout', this.currentSettings.auto_hide_timeout);
                }
            });
        }
    }

    /**
     * Apply particle settings to the cursor effects system
     */
    applyParticleSettings() {
        if (this.isApplying) {
            return; // Prevent multiple simultaneous calls
        }

        this.isApplying = true;
        console.log('✨ applyParticleSettings called with settings:', this.currentSettings);

        // Update particle sizes
        if (window.updateCursorEffect) {
            console.log('✨ Calling updateCursorEffect');
            window.updateCursorEffect();
        } else {
            console.log('✨ updateCursorEffect not available');
        }

        // Reset flag after a short delay
        setTimeout(() => {
            this.isApplying = false;
        }, 100);

        // Update particle style/theme
        if (window.updateCursorEffectTheme) {
            console.log('✨ Calling updateCursorEffectTheme');
            window.updateCursorEffectTheme();
        } else {
            console.log('✨ updateCursorEffectTheme not available');
        }

        // Update particle visibility settings
        this.updateParticleVisibility();
    }

    /**
     * Update particle visibility based on auto-hide settings
     */
    updateParticleVisibility() {
        // This would typically interface with the effects.js system
        // For now, we'll rely on the existing global functions
        if (window.updateCursorEffectIcon) {
            window.updateCursorEffectIcon();
        }

        if (window.updateCursorEffectGlow) {
            window.updateCursorEffectGlow();
        }
    }

    /**
     * Update particle theme when theme changes
     */
    updateTheme(theme) {
        if (window.updateCursorEffectTheme) {
            window.updateCursorEffectTheme();
        }
    }

    /**
     * Get current particle settings
     */
    getSettings() {
        return { ...this.currentSettings };
    }

    /**
     * Set particle size programmatically
     */
    setParticleSize(size) {
        this.currentSettings.particle_size = Math.max(0.1, Math.min(3.0, size));
        this.applyParticleSettings();

        // Update UI element if it exists
        const particleSizeInput = this.elements.particleSizeInput;
        if (particleSizeInput) {
            particleSizeInput.value = this.currentSettings.particle_size;
        }
    }

    /**
     * Set particle style programmatically
     */
    setParticleStyle(style) {
        this.currentSettings.particle_style = style;
        this.applyParticleSettings();

        // Update UI element if it exists
        const particleStyleSelect = this.elements.particleStyleSelect;
        if (particleStyleSelect) {
            particleStyleSelect.value = style;
        }
    }

    /**
     * Toggle auto-hide particles
     */
    setAutoHideParticles(enabled) {
        this.currentSettings.auto_hide_particles = enabled;
        this.applyParticleSettings();

        // Update UI element if it exists
        const autoHideParticlesCheckbox = this.elements.autoHideParticlesCheckbox;
        if (autoHideParticlesCheckbox) {
            autoHideParticlesCheckbox.checked = enabled;
        }
    }

    /**
     * Set auto-hide timeout
     */
    setAutoHideTimeout(seconds) {
        this.currentSettings.auto_hide_timeout = Math.max(1, Math.min(60, seconds));
        this.applyParticleSettings();

        // Update UI element if it exists
        const autoHideTimeoutInput = this.elements.autoHideTimeoutInput;
        if (autoHideTimeoutInput) {
            autoHideTimeoutInput.value = this.currentSettings.auto_hide_timeout;
        }
    }

    /**
     * Open particle selection modal
     */
    async openParticleSelection(targetSelectId) {
        const modal = document.getElementById('particle-selection-modal');
        const grid = document.getElementById('particle-grid');

        if (modal && grid) {
            // Clear existing content
            grid.innerHTML = '';

            try {
                // Fetch available particles
                const response = await fetch('/list-particle-files');
                if (response.ok) {
                    const data = await response.json();
                    if (data.files && Array.isArray(data.files)) {
                        data.files.forEach(particle => {
                            const option = document.createElement('div');
                            option.className = 'cursor-option'; // Reuse cursor-option styling
                            option.setAttribute('data-particle', particle.path);

                            // Create preview image
                            const preview = document.createElement('div');
                            preview.className = 'cursor-preview';
                            const img = document.createElement('img');
                            img.src = particle.path;
                            img.alt = particle.name;
                            img.style.width = '100%';
                            img.style.height = '100%';
                            img.style.objectFit = 'contain';
                            preview.appendChild(img);

                            // Create name label
                            const name = document.createElement('div');
                            name.className = 'cursor-name';
                            name.textContent = particle.name;

                            option.appendChild(preview);
                            option.appendChild(name);

                            // Add click handler
                            option.addEventListener('click', () => {
                                this.selectParticle(particle.path, targetSelectId);
                                modal.style.display = 'none';
                            });

                            grid.appendChild(option);
                        });
                    }
                }
            } catch (error) {
                console.error('Failed to load particles:', error);
            }

            modal.style.display = 'flex';
        }
    }

    /**
     * Select a particle
     */
    selectParticle(particlePath, targetSelectId) {
        const targetSelect = document.getElementById(targetSelectId);
        if (targetSelect) {
            targetSelect.value = particlePath;
            // Trigger change event
            targetSelect.dispatchEvent(new Event('change'));
        }
    }

    /**
     * Close particle selection modal
     */
    closeParticleSelection() {
        const modal = document.getElementById('particle-selection-modal');
        if (modal) {
            modal.style.display = 'none';
        }
    }
}