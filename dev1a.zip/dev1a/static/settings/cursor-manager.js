// ============================================================================
// Cursor Manager - Handles cursor selection, sizing, tinting, and application
// ============================================================================

import { showError } from '../core/ui-utils.js';

/**
 * CursorManager - Manages cursor selection, sizing, and visual application
 */
export class CursorManager {
    constructor() {
        // DOM elements (will be set by orchestrator)
        this.elements = {};

        // Current cursor settings
        this.currentSettings = {
            cursor_main: 'default',
            cursor_particle: 'default',
            cursor_size: 64,
            cursor_glow: false,
            cursor_effect: 'orbiting'
        };

        // Callbacks
        this.onCursorChange = null;
    }

    /**
     * Set DOM elements reference
     */
    setElements(elements) {
        this.elements = elements;
    }

    /**
     * Set current cursor settings
     */
    setSettings(settings) {
        this.currentSettings = { ...this.currentSettings, ...settings };
        this.applyCursor();
    }

    /**
     * Set cursor change callback
     */
    setOnCursorChange(callback) {
        this.onCursorChange = callback;
    }

    /**
     * Initialize cursor manager
     */
    initialize() {
        this.setupCursorSelects();
        this.applyCursor();
    }

    /**
     * Setup cursor selection dropdowns
     */
    setupCursorSelects() {
        // Event listeners are attached here, but population happens later when settings are loaded
        this.attachCursorEventListeners();
    }

    /**
     * Populate cursor selection dropdowns with available cursors
     */
    async populateCursorSelects() {
        const cursorMainSelect = this.elements.cursorMainSelect;
        const cursorParticleSelect = this.elements.cursorParticleSelect;

        try {
            // Populate cursor main select
            if (cursorMainSelect) {
                const cursorResponse = await fetch('/list-cursor-files');
                if (cursorResponse.ok) {
                    const cursorData = await cursorResponse.json();
                    if (cursorData.files && Array.isArray(cursorData.files)) {
                        // Clear existing options except default
                        cursorMainSelect.innerHTML = '<option value="default">Default</option>';
                        // Add cursor options
                        cursorData.files.forEach(cursor => {
                            const option = document.createElement('option');
                            option.value = cursor.path;
                            option.textContent = cursor.name;
                            cursorMainSelect.appendChild(option);
                        });
                    }
                }
                // Set current value
                cursorMainSelect.value = this.currentSettings.cursor_main || 'default';
            }

            // Populate cursor particle select
            if (cursorParticleSelect) {
                const particleResponse = await fetch('/list-particle-files');
                if (particleResponse.ok) {
                    const particleData = await particleResponse.json();
                    if (particleData.files && Array.isArray(particleData.files)) {
                        // Clear existing options except default
                        cursorParticleSelect.innerHTML = '<option value="default">Default</option>';
                        // Add particle options
                        particleData.files.forEach(particle => {
                            const option = document.createElement('option');
                            option.value = particle.path;
                            option.textContent = particle.name;
                            cursorParticleSelect.appendChild(option);
                        });
                    }
                }
                // Set current value
                cursorParticleSelect.value = this.currentSettings.cursor_particle || 'default';
            }
        } catch (error) {
            console.error('Failed to populate cursor selects:', error);
        }
    }

    /**
     * Attach event listeners to cursor selects
     */
    attachCursorEventListeners() {
        const cursorMainSelect = this.elements.cursorMainSelect;
        const cursorParticleSelect = this.elements.cursorParticleSelect;
        const cursorSizeSelect = this.elements.cursorSizeSelect;
        const cursorGlowCheckbox = this.elements.cursorGlowCheckbox;
        const cursorEffectSelect = this.elements.cursorEffectSelect;

        // Cursor main select
        if (cursorMainSelect) {
            cursorMainSelect.addEventListener('change', () => {
                this.currentSettings.cursor_main = cursorMainSelect.value;
                this.applyCursor();
                if (this.onCursorChange) {
                    this.onCursorChange('cursor_main', cursorMainSelect.value);
                }
            });
        }

        // Cursor particle select
        if (cursorParticleSelect) {
            cursorParticleSelect.addEventListener('change', () => {
                this.currentSettings.cursor_particle = cursorParticleSelect.value;
                if (this.onCursorChange) {
                    this.onCursorChange('cursor_particle', cursorParticleSelect.value);
                }
            });
        }

        // Cursor size select
        if (cursorSizeSelect) {
            cursorSizeSelect.addEventListener('change', () => {
                this.currentSettings.cursor_size = parseInt(cursorSizeSelect.value) || 64;
                this.applyCursor();
                if (this.onCursorChange) {
                    this.onCursorChange('cursor_size', this.currentSettings.cursor_size);
                }
            });
        }

        // Cursor glow checkbox
        if (cursorGlowCheckbox) {
            cursorGlowCheckbox.addEventListener('change', () => {
                this.currentSettings.cursor_glow = cursorGlowCheckbox.checked;
                if (this.onCursorChange) {
                    this.onCursorChange('cursor_glow', cursorGlowCheckbox.checked);
                }
            });
        }

        // Cursor effect select
        if (cursorEffectSelect) {
            cursorEffectSelect.addEventListener('change', () => {
                this.currentSettings.cursor_effect = cursorEffectSelect.value;
                if (this.onCursorChange) {
                    this.onCursorChange('cursor_effect', cursorEffectSelect.value);
                }
            });
        }
    }

    /**
     * Apply cursor settings to the document
     */
    applyCursor(theme = 'dobo') {
        console.log('🖱️ applyCursor called with theme:', theme, 'settings:', this.currentSettings);
        const cursorSize = this.currentSettings.cursor_size || 64;
        const cursorMain = this.currentSettings.cursor_main || 'default';

        let cursorPath = '/static/images/default_cursors/cursor2.png'; // default

        if (cursorMain !== 'default') {
            cursorPath = cursorMain;
        }

        console.log('🖱️ Cursor path:', cursorPath, 'Size:', cursorSize);

        // Check if the cursor is a GIF or SVG - if so, skip tinting to preserve animation/vector graphics
        const isGif = cursorPath.toLowerCase().endsWith('.gif');
        const isSvg = cursorPath.toLowerCase().endsWith('.svg');

        if (isGif || isSvg || cursorMain === 'default') {
            // For GIFs, SVGs or default cursor, use directly without tinting
            const cursorValue = cursorMain === 'default' ? 'default' : `url('${cursorPath}'), auto`;
            console.log('🖱️ Setting cursor to:', cursorValue);
            document.body.style.cursor = cursorValue;
        } else {
            // For non-GIF custom cursors, apply canvas tinting with uniform sizing
            console.log('🖱️ Applying tinted cursor');
            this.applyTintedCursor(cursorPath, cursorSize, theme);
        }
    }

    /**
     * Apply tinted cursor using canvas
     */
    applyTintedCursor(cursorPath, cursorSize, theme) {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const img = new Image();

        img.onload = () => {
            canvas.width = cursorSize;
            canvas.height = cursorSize;

            // Calculate scaling to fit the cursor size while maintaining aspect ratio
            const scale = Math.min(cursorSize / img.width, cursorSize / img.height);
            const scaledWidth = img.width * scale;
            const scaledHeight = img.height * scale;

            // Center the image
            const x = (cursorSize - scaledWidth) / 2;
            const y = (cursorSize - scaledHeight) / 2;

            // Get theme accent color for tinting
            const accentColor = this.getThemeAccentColor(theme);

            // Apply tint by drawing the image with a color overlay
            ctx.drawImage(img, x, y, scaledWidth, scaledHeight);

            // Apply color tint
            ctx.globalCompositeOperation = 'source-atop';
            ctx.fillStyle = accentColor;
            ctx.fillRect(0, 0, cursorSize, cursorSize);

            // Convert to data URL and set as cursor
            const tintedCursor = canvas.toDataURL();
            document.body.style.cursor = `url('${tintedCursor}'), auto`;
        };

        img.onerror = () => {
            // Fallback to default cursor if image fails to load
            document.body.style.cursor = `url('/static/images/default_cursors/cursor2.png'), auto`;
        };

        img.src = cursorPath;
    }

    /**
     * Get theme accent color for cursor tinting
     */
    getThemeAccentColor(theme) {
        // Try to get accent color from CSS variables
        const root = document.documentElement;
        const accentColor = getComputedStyle(root).getPropertyValue('--accent').trim();

        if (accentColor && accentColor !== '') {
            return accentColor;
        }

        // Fallback colors based on theme
        const fallbackColors = {
            'dobo': '#ff6b6b',
            'dark': '#bb86fc',
            'light': '#007acc',
            'neon': '#00ff88',
            'retro': '#ff9500'
        };

        return fallbackColors[theme] || '#ff6b6b';
    }

    /**
     * Update cursor when theme changes
     */
    updateTheme(theme) {
        this.applyCursor(theme);
    }

    /**
     * Get current cursor settings
     */
    getSettings() {
        return { ...this.currentSettings };
    }

    /**
     * Open cursor selection modal
     */
    async openCursorSelection(targetSelectId) {
        const modal = document.getElementById('cursor-selection-modal');
        const grid = document.getElementById('cursor-grid');

        if (modal && grid) {
            // Clear existing content
            grid.innerHTML = '';

            try {
                // Fetch available cursors
                const response = await fetch('/list-cursor-files');
                if (response.ok) {
                    const data = await response.json();
                    if (data.files && Array.isArray(data.files)) {
                        data.files.forEach(cursor => {
                            const option = document.createElement('div');
                            option.className = 'cursor-option';
                            option.setAttribute('data-cursor', cursor.path);

                            // Create preview image
                            const preview = document.createElement('div');
                            preview.className = 'cursor-preview';
                            const img = document.createElement('img');
                            img.src = cursor.path;
                            img.alt = cursor.name;
                            img.style.width = '100%';
                            img.style.height = '100%';
                            img.style.objectFit = 'contain';
                            preview.appendChild(img);

                            // Create name label
                            const name = document.createElement('div');
                            name.className = 'cursor-name';
                            name.textContent = cursor.name;

                            option.appendChild(preview);
                            option.appendChild(name);

                            // Add click handler
                            option.addEventListener('click', () => {
                                this.selectCursor(cursor.path, targetSelectId);
                                modal.style.display = 'none';
                            });

                            grid.appendChild(option);
                        });
                    }
                }
            } catch (error) {
                console.error('Failed to load cursors:', error);
            }

            modal.style.display = 'flex';
        }
    }

    /**
     * Select a cursor
     */
    selectCursor(cursorPath, targetSelectId) {
        const targetSelect = document.getElementById(targetSelectId);
        if (targetSelect) {
            targetSelect.value = cursorPath;
            // Trigger change event
            targetSelect.dispatchEvent(new Event('change'));
        }
    }

    /**
     * Select a particle
     */
    selectParticle(particlePath, targetSelectId) {
        const targetSelect = document.getElementById(targetSelectId);
        if (targetSelect) {
            targetSelect.value = particlePath;
            // Trigger change event
            targetSelect.dispatchEvent(new Event('change'));
        }
    }

    /**
     * Close cursor selection modal
     */
    closeCursorSelection() {
        const modal = document.getElementById('cursor-selection-modal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    /**
     * Close particle selection modal
     */
    closeParticleSelection() {
        const modal = document.getElementById('particle-selection-modal');
        if (modal) {
            modal.style.display = 'none';
        }
    }
}