// ai-manager.js - AI Settings Management
export class AIManager {
    constructor() {
        this.aiConfig = null;
        this.isAdmin = false;
        this.initialized = false;
    }

    /**
     * Initialize AI settings manager
     */
    async initialize() {
        if (this.initialized) return;

        console.log('Initializing AI settings manager...');

        // Check if user is admin
        this.isAdmin = window.appState?.isAdmin || false;

        if (!this.isAdmin) {
            console.log('AI settings only available to admins');
            this.hideAISettingsTab();
            return;
        }

        this.setupEventListeners();
        await this.loadAISettings();

        this.initialized = true;
        console.log('AI settings manager initialized');
    }

    /**
     * Hide AI settings tab for non-admin users
     */
    hideAISettingsTab() {
        const aiTab = document.querySelector('.settings-tab[data-tab="ai"]');
        if (aiTab) {
            aiTab.style.display = 'none';
        }
    }

    /**
     * Setup event listeners for AI settings
     */
    setupEventListeners() {
        // Tab switching
        const aiTab = document.querySelector('.settings-tab[data-tab="ai"]');
        if (aiTab) {
            aiTab.addEventListener('click', () => this.onAITabClick());
        }

        // Form controls
        document.getElementById('ai-test-connection')?.addEventListener('click', () => this.testConnection());
        document.getElementById('ai-refresh-models')?.addEventListener('click', () => this.refreshModels());

        // Auto-save on change
        const inputs = [
            'ai-endpoint-url', 'ai-model', 'ai-max-tokens', 'ai-temperature',
            'ai-context-window', 'ai-history-limit', 'ai-system-prompt', 'ai-timeout'
        ];

        inputs.forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.addEventListener('change', () => this.saveSettings());
                if (element.tagName === 'TEXTAREA') {
                    element.addEventListener('input', () => this.debounceSave());
                }
            }
        });
    }

    /**
     * Handle AI tab click
     */
    async onAITabClick() {
        if (!this.aiConfig) {
            await this.loadAISettings();
        }
    }

    /**
     * Load AI settings from server
     */
    async loadAISettings() {
        try {
            this.updateStatus('Loading AI settings...', 'info');

            // Request AI config from server
            socket.emit('ai_config_get');

            // Wait for response
            const configPromise = new Promise((resolve, reject) => {
                const timeout = setTimeout(() => reject(new Error('Timeout')), 5000);

                socket.once('ai_config_data', (data) => {
                    clearTimeout(timeout);
                    resolve(data);
                });

                socket.once('error', (error) => {
                    clearTimeout(timeout);
                    reject(new Error(error.message));
                });
            });

            const config = await configPromise;
            this.aiConfig = config;
            this.populateForm(config);
            this.updateStatus('AI settings loaded successfully', 'success');

        } catch (error) {
            console.error('Failed to load AI settings:', error);
            this.updateStatus(`Failed to load AI settings: ${error.message}`, 'error');
        }
    }

    /**
     * Populate form with AI config data
     */
    populateForm(config) {
        // Basic settings
        this.setValue('ai-endpoint-url', config.endpoint_url || 'https://127.0.0.1:6969');
        this.setValue('ai-model', config.model || 'default');
        this.setValue('ai-max-tokens', config.max_tokens || 2048);
        this.setValue('ai-temperature', config.temperature || 0.7);
        this.setValue('ai-context-window', config.context_window || 4096);
        this.setValue('ai-history-limit', config.history_limit || 50);
        this.setValue('ai-system-prompt', config.system_prompt || '');
        this.setValue('ai-timeout', config.timeout || 30);

        // Update connection status
        const status = config.endpoint_valid ? 'Connected' : 'Not Connected';
        const statusClass = config.endpoint_valid ? 'success' : 'error';
        this.updateStatus(`Endpoint: ${status}`, statusClass);

        // Populate models dropdown
        this.populateModelsList(config.available_models || []);
    }

    /**
     * Populate models dropdown
     */
    populateModelsList(models) {
        const select = document.getElementById('ai-model');
        if (!select) return;

        // Clear existing options except default
        select.innerHTML = '<option value="default">Default</option>';

        // Add available models
        models.forEach(model => {
            const option = document.createElement('option');
            option.value = model;
            option.textContent = model;
            select.appendChild(option);
        });
    }

    /**
     * Save AI settings to server
     */
    async saveSettings() {
        if (!this.aiConfig) return;

        try {
            const modelValue = this.getValue('ai-model');
            const settings = {
                endpoint_url: this.getValue('ai-endpoint-url'),
                model: modelValue === 'default' ? null : modelValue,
                max_tokens: parseInt(this.getValue('ai-max-tokens')) || 2048,
                temperature: parseFloat(this.getValue('ai-temperature')) || 0.7,
                context_window: parseInt(this.getValue('ai-context-window')) || 4096,
                history_limit: parseInt(this.getValue('ai-history-limit')) || 50,
                system_prompt: this.getValue('ai-system-prompt'),
                timeout: parseInt(this.getValue('ai-timeout')) || 30
            };

            this.updateStatus('Saving AI settings...', 'info');

            // Send to server
            socket.emit('ai_config_update', settings);

            // Wait for response
            const responsePromise = new Promise((resolve, reject) => {
                const timeout = setTimeout(() => reject(new Error('Timeout')), 5000);

                socket.once('ai_config_updated', (data) => {
                    clearTimeout(timeout);
                    resolve(data);
                });

                socket.once('error', (error) => {
                    clearTimeout(timeout);
                    reject(new Error(error.message));
                });
            });

            await responsePromise;
            this.updateStatus('AI settings saved successfully', 'success');

            // Reload config to get updated status
            setTimeout(() => this.loadAISettings(), 1000);

        } catch (error) {
            console.error('Failed to save AI settings:', error);
            this.updateStatus(`Failed to save settings: ${error.message}`, 'error');
        }
    }

    /**
     * Test AI endpoint connection
     */
    async testConnection() {
        try {
            this.updateStatus('Testing connection...', 'info');

            // This will trigger a config reload which tests the connection
            await this.loadAISettings();

        } catch (error) {
            this.updateStatus(`Connection test failed: ${error.message}`, 'error');
        }
    }

    /**
     * Refresh available models list
     */
    async refreshModels() {
        try {
            this.updateStatus('Refreshing models...', 'info');
            await this.loadAISettings();
            this.updateStatus('Models refreshed', 'success');

        } catch (error) {
            this.updateStatus(`Failed to refresh models: ${error.message}`, 'error');
        }
    }

    /**
     * Debounced save for textarea input
     */
    debounceSave() {
        clearTimeout(this.saveTimeout);
        this.saveTimeout = setTimeout(() => this.saveSettings(), 1000);
    }

    /**
     * Update status display
     */
    updateStatus(message, type = 'info') {
        const statusEl = document.getElementById('ai-connection-status');
        if (statusEl) {
            statusEl.textContent = message;
            statusEl.className = `ai-status-${type}`;
        }
    }

    /**
     * Helper: Get form value
     */
    getValue(id) {
        const element = document.getElementById(id);
        return element ? element.value : '';
    }

    /**
     * Helper: Set form value
     */
    setValue(id, value) {
        const element = document.getElementById(id);
        if (element) {
            element.value = value;
        }
    }
}

// Create global instance
export const aiManager = new AIManager();