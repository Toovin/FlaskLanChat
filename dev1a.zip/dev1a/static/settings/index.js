// ============================================================================
// Settings System Orchestrator - Modular Settings Management
// ============================================================================

import { CursorManager } from './cursor-manager.js';
import { ParticleManager } from './particle-manager.js';
import { SettingsPersistence } from './settings-persistence.js';
import { SettingsUI } from './settings-ui.js';
import { ThemeIntegration } from './theme-integration.js';
import { unifiedSettingsManager } from './unified-settings-manager.js';
import { aiManager } from './ai-manager.js';

/**
 * SettingsOrchestrator - Main orchestrator for the modular settings system
 */
export class SettingsOrchestrator {
    constructor() {
        // Module instances
        this.cursorManager = null;
        this.particleManager = null;
        this.settingsPersistence = null;
        this.settingsUI = null;
        this.themeIntegration = null;
        this.aiManager = aiManager;
        this.unifiedManager = unifiedSettingsManager;

        // Global settings state
        this.currentSettings = {};
    }

    /**
     * Initialize the settings system
     */
    async initialize() {
        console.log('Initializing modular settings system...');

        // Create module instances
        this.createModules();

        // Setup module relationships
        this.setupModuleRelationships();

        // Initialize all modules
        await this.initializeModules();

        // Setup global functions
        this.exposeGlobalFunctions();

        console.log('Settings system initialized successfully');
    }

    /**
     * Create all module instances
     */
    createModules() {
        this.cursorManager = new CursorManager();
        this.particleManager = new ParticleManager();
        this.settingsPersistence = new SettingsPersistence();
        this.settingsUI = new SettingsUI();
        this.themeIntegration = new ThemeIntegration();
    }

    /**
     * Setup relationships between modules
     */
    setupModuleRelationships() {
        // Settings persistence callbacks
        this.settingsPersistence.setOnSettingsLoaded((settings) => {
            this.handleSettingsLoaded(settings);
        });

        this.settingsPersistence.setOnSettingsSaved(() => {
            this.settingsUI.markSettingsSaved();
        });

        this.settingsPersistence.setOnSettingsError((error) => {
            this.settingsUI.showMessage(error, 'error');
        });

        // Settings UI callbacks
        this.settingsUI.setOnSettingsChange((key, value) => {
            this.handleSettingChange(key, value);
        });

        this.settingsUI.setOnSaveSettings(() => {
            this.saveSettings();
        });

        // Theme integration callbacks
        this.themeIntegration.setOnThemeChange((theme) => {
            this.handleThemeChange(theme);
        });

        // Cursor manager callbacks
        this.cursorManager.setOnCursorChange((key, value) => {
            this.handleSettingChange(key, value);
        });

        // Particle manager callbacks
        this.particleManager.setOnParticleChange((key, value) => {
            this.handleSettingChange(key, value);
        });
    }

    /**
     * Initialize all modules
     */
    async initializeModules() {
        // Initialize persistence first to load settings
        this.settingsPersistence.initialize();

        // Initialize UI first to cache elements
        this.settingsUI.initialize();

        // Get elements from UI manager and pass to other managers
        const elements = this.settingsUI.elements;

        // Initialize cursor manager with elements
        this.cursorManager.setElements({
            cursorMainSelect: elements.cursorMainSelect,
            cursorParticleSelect: elements.cursorParticleSelect,
            cursorSizeSelect: elements.cursorSizeSelect,
            cursorGlowCheckbox: elements.cursorGlowCheckbox,
            cursorEffectSelect: elements.cursorEffectSelect
        });
        this.cursorManager.initialize();

        // Initialize particle manager with elements
        this.particleManager.setElements({
            particleStyleSelect: elements.particleStyleSelect,
            particleSizeInput: elements.particleSizeInput,
            autoHideParticlesCheckbox: elements.autoHideParticlesCheckbox,
            autoHideTimeoutInput: elements.autoHideTimeoutInput
        });
        this.particleManager.initialize();

        // Initialize theme integration
        await this.themeIntegration.initialize();

        // Initialize AI manager
        await this.aiManager.initialize();

        // Load initial settings
        this.settingsPersistence.loadSettings();
    }

    /**
     * Handle settings loaded from server
     */
    async handleSettingsLoaded(settings) {
        console.log('⚙️ Settings loaded from server:', settings);
        console.log('⚙️ Font settings - font:', settings.font, 'font_scale:', settings.font_scale);
        console.log('⚙️ Cursor settings - main:', settings.cursor_main, 'particle:', settings.cursor_particle, 'effect:', settings.cursor_effect);
        console.log('⚙️ Particle settings - style:', settings.particle_style, 'size:', settings.particle_size, 'auto_hide:', settings.auto_hide_particles);

        // Update current settings
        this.currentSettings = { ...settings };

        // Set global for backward compatibility
        window.currentUserSettings = { ...settings };

        // Update unified settings manager
        this.unifiedManager.updateSettings(settings);

        // Update all modules with loaded settings
        this.cursorManager.setSettings({
            cursor_main: settings.cursor_main,
            cursor_particle: settings.cursor_particle,
            cursor_size: settings.cursor_size,
            cursor_glow: settings.cursor_glow,
            cursor_effect: settings.cursor_effect
        });

        this.particleManager.setSettings({
            particle_style: settings.particle_style,
            particle_size: settings.particle_size,
            auto_hide_particles: settings.auto_hide_particles,
            auto_hide_timeout: settings.auto_hide_timeout
        });

        // Apply theme
        if (settings.theme) {
            this.themeIntegration.applyTheme(settings.theme);
        }

        // Populate UI with settings
        this.settingsUI.populateForm(settings);

        // Populate cursor selects after UI is populated
        await this.cursorManager.populateCursorSelects();

        // Initialize sound manager with settings
        if (window.soundManager) {
            window.soundManager.init(settings);
        }

        // Apply settings to the application
        this.applySettingsToApplication(settings);
    }

    /**
     * Handle individual setting changes
     */
    handleSettingChange(key, value) {
        console.log(`Setting changed: ${key} =`, value);

        // Update local settings
        this.currentSettings[key] = value;

        // Update global settings for backward compatibility
        window.currentUserSettings = { ...this.currentSettings };

        // Update unified settings manager
        this.unifiedManager.setSetting(key, value);

        // Update persistence layer
        this.settingsPersistence.updateSetting(key, value);

        // Apply setting to application immediately
        this.applySettingToApplication(key, value);
    }

    /**
     * Handle theme changes
     */
    handleThemeChange(theme) {
        console.log('Theme changed to:', theme);

        // Update cursor and particle themes
        this.cursorManager.updateTheme(theme);
        this.particleManager.updateTheme(theme);

        // Update setting
        this.handleSettingChange('theme', theme);
    }

    /**
     * Apply a single setting to the application
     */
    applySettingToApplication(key, value) {
        switch (key) {
            case 'font':
                this.applyFont(value);
                break;
            case 'font_scale':
                this.applyFontScale(value);
                break;
            case 'compact_mode':
                this.applyCompactMode(value);
                break;
            case 'animated_bg':
                this.applyAnimatedBackground(value);
                break;
            case 'sound_effects':
                this.applySoundEffects(value);
                break;
            case 'annoying_hover_sounds':
                this.applyAnnoyingHoverSounds(value);
                break;
            case 'theme':
                this.themeIntegration.applyTheme(value, false);
                break;
            case 'cursor_effect':
                if (window.updateCursorEffect) {
                    window.updateCursorEffect();
                }
                break;
            // Cursor and particle settings are handled by their respective managers
        }
    }

    /**
     * Apply all settings to the application
     */
    applySettingsToApplication(settings) {
        console.log('🎯 applySettingsToApplication called with:', settings);

        // Apply font settings
        if (settings.font) {
            console.log('🎯 Applying font setting:', settings.font);
            this.applyFont(settings.font);
        }
        if (settings.font_scale) {
            console.log('🎯 Applying font scale setting:', settings.font_scale);
            this.applyFontScale(settings.font_scale);
        }

        // Apply UI settings
        if (settings.compact_mode) {
            this.applyCompactMode(settings.compact_mode);
        }
        if (settings.animated_bg) {
            this.applyAnimatedBackground(settings.animated_bg);
        }

        // Apply sound settings
        if (settings.sound_effects !== undefined) {
            this.applySoundEffects(settings.sound_effects);
        }
        if (settings.annoying_hover_sounds !== undefined) {
            this.applyAnnoyingHoverSounds(settings.annoying_hover_sounds);
        }
        if (settings.soundboard_sounds !== undefined) {
            this.applySoundboardSounds(settings.soundboard_sounds);
        }
        if (settings.soundboard_volume !== undefined) {
            this.applySoundboardVolume(settings.soundboard_volume);
        }

        // Apply cursor settings
        if (settings.cursor_main || settings.cursor_particle || settings.cursor_size !== undefined || settings.cursor_glow !== undefined) {
            console.log('🎯 Applying cursor settings:', {
                cursor_main: settings.cursor_main,
                cursor_particle: settings.cursor_particle,
                cursor_size: settings.cursor_size,
                cursor_glow: settings.cursor_glow,
                cursor_effect: settings.cursor_effect
            });
            this.cursorManager.setSettings({
                cursor_main: settings.cursor_main,
                cursor_particle: settings.cursor_particle,
                cursor_size: settings.cursor_size,
                cursor_glow: settings.cursor_glow,
                cursor_effect: settings.cursor_effect
            });
        } else {
            console.log('🎯 No cursor settings to apply');
        }

        // Apply particle settings
        if (settings.particle_style || settings.particle_size !== undefined || settings.auto_hide_particles !== undefined || settings.auto_hide_timeout !== undefined) {
            console.log('🎯 Applying particle settings:', {
                particle_style: settings.particle_style,
                particle_size: settings.particle_size,
                auto_hide_particles: settings.auto_hide_particles,
                auto_hide_timeout: settings.auto_hide_timeout
            });
            this.particleManager.setSettings({
                particle_style: settings.particle_style,
                particle_size: settings.particle_size,
                auto_hide_particles: settings.auto_hide_particles,
                auto_hide_timeout: settings.auto_hide_timeout
            });
        } else {
            console.log('🎯 No particle settings to apply');
        }

        // Update user info display
        this.updateUserInfo(settings);
    }

    /**
     * Apply font setting
     */
    applyFont(font) {
        console.log('🔤 applyFont called with:', font);
        const root = document.documentElement.style;
        const fontMap = {
            'system': '-apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif',
            'serif': 'Georgia, \'Times New Roman\', serif',
            'mono': 'Monaco, \'Courier New\', monospace',
            'vt323': '\'VT323\', \'Courier New\', \'Terminal\', monospace',
            'jacquarda': '\'Jacquarda Bastarda 9\', serif',
            'pixelify': '\'Pixelify Sans\', sans-serif',
            'newrocker': '\'New Rocker\', cursive',
            'caesardressing': '\'Caesar Dressing\', cursive',
            'cutivemono': '\'Cutive Mono\', monospace',
            'macondoswashcaps': '\'Macondo Swash Caps\', cursive',
            'toovin': '\'Toovin Font\', sans-serif'
        };

        const fontValue = fontMap[font] || fontMap.system;
        console.log('🔤 Setting --font-family to:', fontValue);
        root.setProperty('--font-family', fontValue);

        // Verify the property was set
        const computedFont = getComputedStyle(document.documentElement).getPropertyValue('--font-family');
        console.log('🔤 Computed --font-family:', computedFont);

        // Check if body has the font applied
        const bodyFont = getComputedStyle(document.body).fontFamily;
        console.log('🔤 Body font-family:', bodyFont);
    }

    /**
     * Apply font scale setting
     */
    applyFontScale(scale) {
        console.log('📏 applyFontScale called with:', scale);
        const root = document.documentElement.style;
        const scaleValue = scale || 1.0;
        console.log('📏 Setting --font-scale to:', scaleValue);
        root.setProperty('--font-scale', scaleValue);

        // Verify the property was set
        const computedScale = getComputedStyle(document.documentElement).getPropertyValue('--font-scale');
        console.log('📏 Computed --font-scale:', computedScale);

        // Check body font size calculation
        const bodyFontSize = getComputedStyle(document.body).fontSize;
        console.log('📏 Body font-size:', bodyFontSize);
    }

    /**
     * Apply compact mode setting
     */
    applyCompactMode(enabled) {
        const appContainer = document.getElementById('app-container');
        if (appContainer) {
            if (enabled) {
                appContainer.classList.add('compact-mode');
            } else {
                appContainer.classList.remove('compact-mode');
            }
        }
        console.log('Applied compact mode:', enabled);
    }

    /**
     * Apply animated background setting
     */
    applyAnimatedBackground(bgType) {
        const appContainer = document.getElementById('app-container');
        if (appContainer) {
            // Remove all animation classes
            appContainer.classList.remove('animated-bg', 'animated-bg-crt', 'animated-bg-water', 'animated-bg-ice', 'animated-bg-gems', 'animated-bg-chat-scan', 'animated-bg-spiral', 'animated-bg-hpos10i-wall');

            if (bgType !== 'none') {
                if (bgType === 'crt') {
                    appContainer.classList.add('animated-bg-crt');
                } else if (bgType === 'water') {
                    appContainer.classList.add('animated-bg-water');
                } else if (bgType === 'ice') {
                    appContainer.classList.add('animated-bg-ice');
                } else if (bgType === 'gems') {
                    appContainer.classList.add('animated-bg-gems');
                } else if (bgType === 'chat-scan') {
                    appContainer.classList.add('animated-bg-chat-scan');
                } else if (bgType === 'spiral') {
                    appContainer.classList.add('animated-bg-spiral');
                } else if (bgType === 'hpos10i-wall') {
                    appContainer.classList.add('animated-bg-hpos10i-wall');
                } else {
                    appContainer.classList.add('animated-bg');
                }
            }
        }
        console.log('Applied animated background:', bgType);
    }

    /**
     * Apply sound effects setting
     */
    applySoundEffects(enabled) {
        if (window.soundManager) {
            window.soundManager.updateSettings({ sound_effects: enabled });
        }
        console.log('Applied sound effects:', enabled);
    }

    /**
     * Apply annoying hover sounds setting
     */
    applyAnnoyingHoverSounds(enabled) {
        // This is handled by the sound manager's init method
        console.log('Applied annoying hover sounds:', enabled);
    }

    /**
     * Apply soundboard sounds setting
     */
    applySoundboardSounds(enabled) {
        if (window.soundManager) {
            window.soundManager.updateSettings({ soundboard_sounds: enabled });
        }
        if (this.settingsUI && this.settingsUI.elements.soundboardSoundsCheckbox) {
            this.settingsUI.elements.soundboardSoundsCheckbox.checked = enabled;
        }
        console.log('Applied soundboard sounds:', enabled);
    }

    /**
     * Apply soundboard volume setting
     */
    applySoundboardVolume(volume) {
        if (window.soundManager) {
            window.soundManager.updateSettings({ soundboard_volume: volume });
        }
        if (this.settingsUI && this.settingsUI.elements.soundboardVolumeInput) {
            this.settingsUI.elements.soundboardVolumeInput.value = volume;
        }
        console.log('Applied soundboard volume:', volume);
    }

    /**
     * Update user info display
     */
    updateUserInfo(settings) {
        // Update display name if changed
        if (settings.display_name && window.updateUserInfo) {
            window.updateUserInfo();
        }

        // Update member list
        if (window.updateGeneralMemberList) {
            window.updateGeneralMemberList();
        }
    }

    /**
     * Save current settings
     */
    async saveSettings() {
        // Handle avatar upload first if there's a new file
        const avatarInput = document.getElementById('settings-avatar-input');
        if (avatarInput && avatarInput.files && avatarInput.files[0]) {
            try {
                const formData = new FormData();
                formData.append('avatar', avatarInput.files[0]);
                formData.append('type', 'user');
                formData.append('id', window.currentUsername || 'unknown');

                const response = await fetch('/upload-avatar', {
                    method: 'POST',
                    body: formData
                });

                if (response.ok) {
                    const data = await response.json();
                    if (data.url) {
                        // Update the avatar_url in settings
                        this.settingsPersistence.updateSetting('avatar_url', data.url);
                        // Clear the input
                        avatarInput.value = '';
                        // Update the preview
                        const currentAvatarImg = document.getElementById('settings-current-avatar');
                        if (currentAvatarImg) {
                            currentAvatarImg.src = data.url;
                        }
                    }
                } else {
                    console.error('Avatar upload failed');
                    // Continue with saving other settings
                }
            } catch (error) {
                console.error('Avatar upload error:', error);
                // Continue with saving other settings
            }
        }

        // Save the settings
        this.settingsPersistence.saveSettings();
    }

    /**
     * Open settings modal
     */
    openSettings() {
        this.settingsUI.openSettings();
    }

    /**
     * Close settings modal
     */
    closeSettings() {
        this.settingsUI.closeSettings();
    }

    /**
     * Get current settings
     */
    getCurrentSettings() {
        return { ...this.currentSettings };
    }

    /**
     * Expose functions to global scope for HTML onclick handlers
     */
    exposeGlobalFunctions() {
        // Create a single global object for all exposed functions
        window.settingsManager = {
            openSettings: () => this.openSettings(),
            closeSettings: () => this.closeSettings(),
            saveSettings: () => this.saveSettings(),
            openCursorSelection: (targetId) => this.cursorManager.openCursorSelection(targetId),
            openParticleSelection: (targetId) => this.particleManager.openParticleSelection ? this.particleManager.openParticleSelection(targetId) : this.cursorManager.openParticleSelection(targetId)
        };

        // Also expose individual functions for backward compatibility
        Object.entries(window.settingsManager).forEach(([key, value]) => {
            window[key] = value;
        });

        // Expose original function names for backward compatibility
        window.openUserSettings = () => this.openSettings();
        window.closeUserSettings = () => this.closeSettings();
        window.closeCursorSelection = () => this.cursorManager.closeCursorSelection ? this.cursorManager.closeCursorSelection() : console.log('closeCursorSelection not implemented');
        window.closeParticleSelection = () => this.particleManager.closeParticleSelection ? this.particleManager.closeParticleSelection() : console.log('closeParticleSelection not implemented');

        // Expose theme functions
        window.applyCustomTheme = (colors) => this.themeIntegration.applyCustomTheme(colors);
        window.openThemeCreatorModal = () => this.themeIntegration.openThemeCreatorModal();
        window.closeThemeCreatorModal = () => this.themeIntegration.closeThemeCreatorModal ? this.themeIntegration.closeThemeCreatorModal() : console.log('closeThemeCreatorModal not implemented');
        window.saveCustomTheme = () => this.themeIntegration.saveCustomTheme ? this.themeIntegration.saveCustomTheme() : console.log('saveCustomTheme not implemented');

        // Expose font function
        window.applyFont = (font) => this.applyFont(font);
    }
}

// Create and export the orchestrator instance
const settingsOrchestrator = new SettingsOrchestrator();

// Expose global functions immediately for HTML onclick handlers
window.settingsManager = {
    openSettings: () => {
        if (settingsOrchestrator.settingsUI) {
            settingsOrchestrator.openSettings();
        } else {
            console.warn('Settings system not yet initialized');
        }
    },
    closeSettings: () => {
        if (settingsOrchestrator.settingsUI) {
            settingsOrchestrator.closeSettings();
        } else {
            console.warn('Settings system not yet initialized');
        }
    },
    saveSettings: () => {
        if (settingsOrchestrator.settingsPersistence) {
            settingsOrchestrator.saveSettings();
        } else {
            console.warn('Settings system not yet initialized');
        }
    },
    openCursorSelection: (targetId) => {
        if (settingsOrchestrator.cursorManager) {
            settingsOrchestrator.cursorManager.openCursorSelection(targetId);
        } else {
            console.warn('Settings system not yet initialized');
        }
    },
    openParticleSelection: (targetId) => {
        if (settingsOrchestrator.particleManager) {
            settingsOrchestrator.particleManager.openParticleSelection(targetId);
        } else {
            console.warn('Settings system not yet initialized');
        }
    }
};

// Also expose individual functions for backward compatibility
Object.entries(window.settingsManager).forEach(([key, value]) => {
    window[key] = value;
});

// Backward compatibility functions that delegate to the orchestrator
window.openUserSettings = () => {
    if (settingsOrchestrator.settingsUI) {
        settingsOrchestrator.openSettings();
    } else {
        console.warn('Settings system not yet initialized, trying to initialize...');
        // Try to initialize immediately if DOM is ready
        if (document.readyState !== 'loading') {
            settingsOrchestrator.initialize();
        }
    }
};
window.closeUserSettings = () => {
    if (settingsOrchestrator.settingsUI) {
        settingsOrchestrator.closeSettings();
    } else {
        console.warn('Settings system not yet initialized');
    }
};

// Debug function for troubleshooting settings
window.debugSettings = function() {
    console.log('🔍 SETTINGS DEBUG INFO');
    console.log('Current user settings:', window.currentUserSettings);
    console.log('CSS Variables:');
    console.log('--font-family:', getComputedStyle(document.documentElement).getPropertyValue('--font-family'));
    console.log('--font-scale:', getComputedStyle(document.documentElement).getPropertyValue('--font-scale'));
    console.log('Body font-family:', getComputedStyle(document.body).fontFamily);
    console.log('Body font-size:', getComputedStyle(document.body).fontSize);
    console.log('Cursor style:', document.body.style.cursor);
    console.log('Particles visible:', document.querySelectorAll('[id^="pasta-"]').length);
    console.log('OrbitingEffect available:', !!window.OrbitingEffect);
    return 'Debug info logged to console';
};

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        settingsOrchestrator.initialize();
    });
} else {
    settingsOrchestrator.initialize();
}

export default settingsOrchestrator;