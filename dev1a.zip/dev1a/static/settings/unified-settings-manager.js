export class UnifiedSettingsManager {
    constructor() {
        this.settings = {
            cursor_main: 'default',
            cursor_particle: 'default',
            cursor_size: 64,
            cursor_glow: false,
            cursor_effect: 'orbiting',
            
            particle_style: 'theme',
            particle_size: 1.0,
            auto_hide_particles: false,
            auto_hide_timeout: 10,
            
            font: 'system',
            font_scale: 1.0
        };
        
        this.callbacks = {
            onCursorChange: null,
            onParticleChange: null,
            onFontChange: null
        };
    }
    
    setCallback(type, callback) {
        if (this.callbacks.hasOwnProperty(`on${type}Change`)) {
            this.callbacks[`on${type}Change`] = callback;
        }
    }
    
    updateSettings(newSettings) {
        const oldSettings = { ...this.settings };
        this.settings = { ...this.settings, ...newSettings };
        
        if (window.currentUserSettings) {
            window.currentUserSettings = { ...window.currentUserSettings, ...newSettings };
        }
        
        this.applyChangedSettings(oldSettings, this.settings);
    }
    
    applyChangedSettings(oldSettings, newSettings) {
        const cursorChanged = ['cursor_main', 'cursor_particle', 'cursor_size', 'cursor_glow', 'cursor_effect'].some(
            key => oldSettings[key] !== newSettings[key]
        );
        
        const particleChanged = ['particle_style', 'particle_size', 'auto_hide_particles', 'auto_hide_timeout'].some(
            key => oldSettings[key] !== newSettings[key]
        );
        
        const fontChanged = ['font', 'font_scale'].some(
            key => oldSettings[key] !== newSettings[key]
        );
        
        if (cursorChanged) {
            this.applyCursorSettings();
        }
        
        if (particleChanged) {
            this.applyParticleSettings();
        }
        
        if (fontChanged) {
            this.applyFontSettings();
        }
    }
    
    applyCursorSettings() {
        console.log('🖱️ Applying cursor settings:', {
            main: this.settings.cursor_main,
            particle: this.settings.cursor_particle,
            size: this.settings.cursor_size,
            glow: this.settings.cursor_glow,
            effect: this.settings.cursor_effect
        });
        
        this.applyCursorAppearance();
        this.applyCursorSize();
        
        if (window.updateCursorEffect) {
            window.updateCursorEffect();
        }
        
        if (window.updateCursorEffectIcon) {
            window.updateCursorEffectIcon();
        }
        
        if (this.callbacks.onCursorChange) {
            this.callbacks.onCursorChange(this.settings);
        }
    }
    
    applyCursorAppearance() {
        const cursorSize = this.settings.cursor_size || 64;
        const cursorMain = this.settings.cursor_main || 'default';
        const cursorGlow = this.settings.cursor_glow || false;
        
        let cursorPath = '/static/images/default_cursors/cursor2.png';
        
        if (cursorMain !== 'default') {
            cursorPath = cursorMain;
        }
        
        const isGif = cursorPath.toLowerCase().endsWith('.gif');
        const isSvg = cursorPath.toLowerCase().endsWith('.svg');
        
        if (isGif || isSvg || cursorMain === 'default') {
            const cursorValue = cursorMain === 'default' ? 'default' : `url('${cursorPath}'), auto`;
            document.body.style.cursor = cursorValue;
        } else {
            this.applyTintedCursor(cursorPath, cursorSize);
        }
    }
    
    applyCursorSize() {
        const cursorSize = this.settings.cursor_size || 64;
        document.documentElement.style.setProperty('--cursor-size', `${cursorSize}px`);
    }
    
    applyTintedCursor(cursorPath, cursorSize) {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const img = new Image();
        
        img.onload = () => {
            canvas.width = cursorSize;
            canvas.height = cursorSize;
            
            const scale = Math.min(cursorSize / img.width, cursorSize / img.height);
            const scaledWidth = img.width * scale;
            const scaledHeight = img.height * scale;
            
            const x = (cursorSize - scaledWidth) / 2;
            const y = (cursorSize - scaledHeight) / 2;
            
            ctx.drawImage(img, x, y, scaledWidth, scaledHeight);
            
            const accentColor = this.getThemeAccentColor();
            ctx.globalCompositeOperation = 'source-atop';
            ctx.fillStyle = accentColor;
            ctx.fillRect(0, 0, cursorSize, cursorSize);
            
            const tintedCursor = canvas.toDataURL();
            document.body.style.cursor = `url('${tintedCursor}'), auto`;
        };
        
        img.onerror = () => {
            document.body.style.cursor = `url('/static/images/default_cursors/cursor2.png'), auto`;
        };
        
        img.src = cursorPath;
    }
    
    getThemeAccentColor() {
        const root = document.documentElement;
        const accentColor = getComputedStyle(root).getPropertyValue('--accent').trim();
        
        if (accentColor && accentColor !== '') {
            return accentColor;
        }
        
        const fallbackColors = {
            'dobo': '#ff6b6b',
            'dark': '#bb86fc',
            'light': '#007acc',
            'neon': '#00ff88',
            'retro': '#ff9500'
        };
        
        const themeClasses = Array.from(document.documentElement.classList);
        const themeClass = themeClasses.find(cls => cls.startsWith('theme-'));
        const theme = themeClass ? themeClass.replace('theme-', '') : 'dobo';
        
        return fallbackColors[theme] || '#ff6b6b';
    }
    
    applyParticleSettings() {
        console.log('✨ Applying particle settings:', {
            style: this.settings.particle_style,
            size: this.settings.particle_size,
            auto_hide: this.settings.auto_hide_particles,
            timeout: this.settings.auto_hide_timeout
        });
        
        this.applyParticleAppearance();
        this.applyParticleSize();
        
        if (window.updateCursorEffectTheme) {
            window.updateCursorEffectTheme();
        }
        
        if (window.updateCursorEffectGlow) {
            window.updateCursorEffectGlow();
        }
        
        if (this.callbacks.onParticleChange) {
            this.callbacks.onParticleChange(this.settings);
        }
    }
    
    applyParticleAppearance() {
        const particleStyle = this.settings.particle_style || 'theme';
        document.documentElement.style.setProperty('--particle-style', particleStyle);
    }
    
    applyParticleSize() {
        const particleSize = this.settings.particle_size || 1.0;
        document.documentElement.style.setProperty('--particle-size', particleSize.toString());
        
        if (window.updateParticleSizes) {
            window.updateParticleSizes();
        }
    }
    
    applyFontSettings() {
        console.log('🔤 Applying font settings:', {
            font: this.settings.font,
            scale: this.settings.font_scale
        });
        
        this.applyFont();
        this.applyFontScale();
        
        if (this.callbacks.onFontChange) {
            this.callbacks.onFontChange(this.settings);
        }
    }
    
    applyFont() {
        const font = this.settings.font || 'system';
        const root = document.documentElement.style;
        
        const fontMap = {
            'system': '-apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif',
            'serif': 'Georgia, \'Times New Roman\', serif',
            'mono': 'Monaco, \'Courier New\', monospace',
            'vt323': '\'VT323\', \'Courier New\', \'Terminal\', monospace',
            'jacquarda': '\'Jacquarda Bastarda 9\', serif',
            'pixelify': '\'Pixelify Sans\', sans-serif',
            'newrocker': '\'New Rocker\', cursive',
            'caesardressing': '\'Caesar Dressing\', cursive',
            'cutivemono': '\'Cutive Mono\', monospace',
            'macondoswashcaps': '\'Macondo Swash Caps\', cursive',
            'toovin': '\'Toovin Font\', sans-serif'
        };
        
        const fontValue = fontMap[font] || fontMap.system;
        root.setProperty('--font-family', fontValue);
        
        console.log('🔤 Font family set to:', fontValue);
    }
    
    applyFontScale() {
        const scale = this.settings.font_scale || 1.0;
        const root = document.documentElement.style;
        
        root.setProperty('--font-scale', scale.toString());
        
        console.log('📏 Font scale set to:', scale);
    }
    
    getSettings() {
        return { ...this.settings };
    }
    
    getSetting(key) {
        return this.settings[key];
    }
    
    setSetting(key, value) {
        const oldValue = this.settings[key];
        this.settings[key] = value;
        
        if (window.currentUserSettings) {
            window.currentUserSettings[key] = value;
        }
        
        const oldSettings = { ...this.settings, [key]: oldValue };
        this.applyChangedSettings(oldSettings, this.settings);
    }
}

export const unifiedSettingsManager = new UnifiedSettingsManager();
window.unifiedSettingsManager = unifiedSettingsManager;
