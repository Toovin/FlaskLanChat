// ============================================================================
// Settings Persistence - Handles saving/loading user settings via socket
// ============================================================================

import { socket, state } from '../core/setup.js';
import { showError } from '../core/ui-utils.js';

/**
 * SettingsPersistence - Manages saving and loading user settings
 */
export class SettingsPersistence {
    constructor() {
        // Current settings state
        this.currentSettings = {};
        this.settingsChanged = false;

        // Callbacks
        this.onSettingsLoaded = null;
        this.onSettingsSaved = null;
        this.onSettingsError = null;
    }

    /**
     * Set settings loaded callback
     */
    setOnSettingsLoaded(callback) {
        this.onSettingsLoaded = callback;
    }

    /**
     * Set settings saved callback
     */
    setOnSettingsSaved(callback) {
        this.onSettingsSaved = callback;
    }

    /**
     * Set settings error callback
     */
    setOnSettingsError(callback) {
        this.onSettingsError = callback;
    }

    /**
     * Initialize settings persistence
     */
    initialize() {
        this.setupSocketListeners();
    }

    /**
     * Setup socket event listeners for settings
     */
    setupSocketListeners() {
        // Handle settings response from server
        socket.on('user_settings', (settings) => {
            console.log('Received user_settings:', settings);
            this.currentSettings = { ...this.currentSettings, ...settings };
            this.settingsChanged = false;

            if (this.onSettingsLoaded) {
                this.onSettingsLoaded(settings);
            }
        });

        // Handle settings update response
        socket.on('settings_updated', (data) => {
            if (data.success) {
                this.settingsChanged = false;
                console.log('Settings saved successfully');

                if (this.onSettingsSaved) {
                    this.onSettingsSaved(data);
                }
            } else {
                console.error('Settings save failed:', data.error);

                if (this.onSettingsError) {
                    this.onSettingsError(data.error || 'Failed to save settings');
                }
            }
        });

        // Handle settings errors
        socket.on('error', (data) => {
            if (data.msg && data.msg.includes('settings')) {
                console.error('Settings error:', data.msg);

                if (this.onSettingsError) {
                    this.onSettingsError(data.msg);
                }
            }
        });
    }

    /**
     * Load user settings from server
     */
    loadSettings() {
        console.log('Loading user settings...');
        socket.emit('get_user_settings');
    }

    /**
     * Save current settings to server
     */
    saveSettings() {
        if (!state.isAuthenticated) {
            showError('You must be logged in to save settings');
            return;
        }

        console.log('Saving user settings:', this.currentSettings);
        socket.emit('update_user_settings', {
            settings: this.currentSettings
        });
    }

    /**
     * Update a specific setting
     */
    updateSetting(key, value) {
        this.currentSettings[key] = value;
        this.settingsChanged = true;
        console.log(`Setting updated: ${key} =`, value);
    }

    /**
     * Update multiple settings at once
     */
    updateSettings(settings) {
        this.currentSettings = { ...this.currentSettings, ...settings };
        this.settingsChanged = true;
        console.log('Multiple settings updated:', settings);
    }

    /**
     * Get current value of a setting
     */
    getSetting(key, defaultValue = null) {
        return this.currentSettings[key] !== undefined ? this.currentSettings[key] : defaultValue;
    }

    /**
     * Get all current settings
     */
    getAllSettings() {
        return { ...this.currentSettings };
    }

    /**
     * Check if settings have been modified
     */
    hasChanges() {
        return this.settingsChanged;
    }

    /**
     * Mark settings as unchanged (after successful save)
     */
    markUnchanged() {
        this.settingsChanged = false;
    }

    /**
     * Reset settings to default values
     */
    resetToDefaults() {
        // Default settings based on the original userSettings.js
        const defaults = {
            theme: 'dobo',
            font: 'system',
            font_scale: 1.0,
            compact_mode: false,
            show_timestamps: true,
            animated_bg: 'none',
            sound_effects: true,
            annoying_hover_sounds: false,
            soundboard_sounds: true,
            soundboard_volume: 1.0,
            cursor_effect: 'orbiting',
            particle_style: 'theme',
            particle_size: 1.0,
            cursor_main: 'default',
            cursor_particle: 'default',
            cursor_glow: false,
            cursor_size: 64,
            auto_hide_particles: true,
            auto_hide_timeout: 10,
            allow_dms: true,
            show_online_status: true,
            typing_indicators: true,
            mic_volume: 1.0,
            receive_volume: 1.0,
            mute: false,
            display_name: '',
            custom_status: '',
            status: 'online'
        };

        this.currentSettings = { ...defaults };
        this.settingsChanged = true;
        console.log('Settings reset to defaults');
    }

    /**
     * Export settings as JSON string
     */
    exportSettings() {
        return JSON.stringify(this.currentSettings, null, 2);
    }

    /**
     * Import settings from JSON string
     */
    importSettings(jsonString) {
        try {
            const imported = JSON.parse(jsonString);
            this.currentSettings = { ...this.currentSettings, ...imported };
            this.settingsChanged = true;
            console.log('Settings imported successfully');
            return true;
        } catch (error) {
            console.error('Failed to import settings:', error);
            if (this.onSettingsError) {
                this.onSettingsError('Invalid settings format');
            }
            return false;
        }
    }
}