 window.currentChannels = ['general'];
import { socket, state } from './core/setup.js';
import { openUserProfileModal } from './core/profile-modal.js';
import { typingSet, updateStatuses } from './socket-events/utils.js';
import { escapeHtml, showError } from './core/ui-utils.js';

  window.currentChannel = 'general';
   window.currentMediaChannel = 'default';
   state.currentChannel = 'general';

   // Available icons for channel creation
   const availableIcons = [
       'far fa-hashtag', 'fas fa-star', 'fas fa-heart', 'fas fa-smile', 'fas fa-thumbs-up',
       'fas fa-fire', 'fas fa-lightbulb', 'fas fa-cog', 'fas fa-users', 'fas fa-comments',
       'fas fa-music', 'fas fa-gamepad', 'fas fa-camera', 'fas fa-image', 'fas fa-video',
       'fas fa-bell', 'fas fa-envelope', 'fas fa-phone', 'fas fa-map', 'fas fa-calendar',
       '😀', '👍', '🔥', '💡', '⚙️', '👥', '💬', '🎵', '🎮', '📷', '🔔', '✉️', '📞', '🗺️', '📅'
   ];

  // Unread message counts for channels
  const channelUnreadCounts = new Map();

// Utility functions
function showSuccess(msg) { console.log('Success:', msg); }
function updateChannelHeader(channel) { /* TODO: implement channel header update */ }

function incrementChannelUnreadCount(channel) {
    const currentCount = channelUnreadCounts.get(channel) || 0;
    channelUnreadCounts.set(channel, currentCount + 1);
    updateChannelUnreadDisplay(channel);
}

function resetChannelUnreadCount(channel) {
    channelUnreadCounts.set(channel, 0);
    updateChannelUnreadDisplay(channel);
}

function updateChannelUnreadDisplay(channel) {
    const count = channelUnreadCounts.get(channel) || 0;
    document.querySelectorAll(`.channel[data-channel="${channel}"] .unread-count`).forEach(el => {
        el.textContent = count;
        el.style.display = count > 0 ? 'inline' : 'none';
    });
    document.querySelectorAll(`.media-channel[data-media-channel="${channel}"] .unread-count`).forEach(el => {
        el.textContent = count;
        el.style.display = count > 0 ? 'inline' : 'none';
    });
}

// Expose functions globally for use by other modules
window.incrementChannelUnreadCount = incrementChannelUnreadCount;
window.resetChannelUnreadCount = resetChannelUnreadCount;

function updateChannelIndicators() {
    document.querySelectorAll('.channel').forEach(ch => {
        const indicator = ch.querySelector('.channel-indicator');
        if (indicator) {
            indicator.innerHTML = ch.classList.contains('active') ? '<i class="fas fa-hashtag"></i>' : '<i class="far fa-hashtag"></i>';
        }
    });
    document.querySelectorAll('.media-channel').forEach(ch => {
        const indicator = ch.querySelector('.channel-indicator');
        if (indicator) {
            indicator.innerHTML = ch.classList.contains('active') ? '<i class="fas fa-volume-up"></i>' : '<i class="far fa-volume-down"></i>';
        }
    });
}

// Generic modal functions
function showModal(modalId, inputId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
        if (inputId) {
            const input = document.getElementById(inputId);
            if (input) {
                input.focus();
            }
        }
    }
}

function hideModal(modalId, formId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        if (formId) {
            const form = document.getElementById(formId);
            if (form) {
                form.reset();
            }
        }
    }
}

// Generic volume control setup
function setupVolumeControls(suffix = '') {
    const receiveVolumeSlider = document.getElementById(`receive-volume${suffix}`);
    if (receiveVolumeSlider) {
        receiveVolumeSlider.addEventListener('input', (e) => {
            const volume = parseFloat(e.target.value) / 100;
            if (window.webrtcManager) {
                window.webrtcManager.setRemoteVolume(volume);
            }
        });
    }

    const micVolumeSlider = document.getElementById(`mic-volume${suffix}`);
    if (micVolumeSlider) {
        micVolumeSlider.addEventListener('input', (e) => {
            const volume = parseFloat(e.target.value) / 100; // Normalize to 0-1 range
            if (window.webrtcManager) {
                window.webrtcManager.setLocalVolume(volume);
            }
        });
    }

    const muteBtn = document.getElementById(`mute-btn${suffix}`);
    if (muteBtn) {
        muteBtn.addEventListener('click', () => {
            if (window.webrtcManager) {
                const isCurrentlyMuted = muteBtn.classList.contains('muted');
                const willMute = !isCurrentlyMuted;
                window.webrtcManager.muteRemoteAudio(willMute);
                muteBtn.classList.toggle('muted');
                muteBtn.innerHTML = willMute ? '<i class="fas fa-volume-mute"></i>' : '<i class="fas fa-volume-up"></i>';
            }
        });
    }
}

// Generic RTC control setup
function setupRTCControls(suffix = '') {
    const voiceIcon = document.getElementById(`voice-icon${suffix}`);
    if (voiceIcon) {
        voiceIcon.addEventListener('click', () => {
            if (!window.isInMediaChannel) {
                showError('You must join a media channel first');
                return;
            }
            if (window.webrtcManager) {
                if (window.webrtcManager.activeMediaTypes.has('audio')) {
                    window.webrtcManager.mediaManager.stopVoice();
                } else {
                    window.webrtcManager.mediaManager.startVoice().catch(err => {
                        console.error('Error starting voice:', err);
                    });
                }
            }
        });
    }

    const webcamIcon = document.getElementById(`webcam-icon${suffix}`);
    if (webcamIcon) {
        webcamIcon.addEventListener('click', () => {
            if (!window.isInMediaChannel) {
                showError('You must join a media channel first');
                return;
            }
            if (window.webrtcManager) {
                if (window.webrtcManager.activeMediaTypes.has('video')) {
                    window.webrtcManager.mediaManager.stopVideo();
                } else {
                    window.webrtcManager.mediaManager.startVideo().catch(err => {
                        console.error('Error starting video:', err);
                    });
                }
            }
        });
    }

    const screenshareIcon = document.getElementById(`screen-share-icon${suffix}`);
    if (screenshareIcon) {
        screenshareIcon.addEventListener('click', () => {
            if (!window.isInMediaChannel) {
                showError('You must join a media channel first');
                return;
            }
            if (window.webrtcManager) {
                if (window.webrtcManager.activeMediaTypes.has('screenshare')) {
                    window.webrtcManager.stopScreenshare();
                } else {
                    openScreenShareModal();
                }
            }
        });
    }
}



// Setup user info section with proper controls
function setupUserInfoSection(containerId, suffix = '') {
    // Listen for ping updates
    window.addEventListener('connectionQualityChanged', (event) => {
        updatePingDisplay();
    });
    const container = document.getElementById(containerId);
    if (!container) return;

    // Clear existing content
    container.innerHTML = '';

    // Add RTC controls
    const rtcControls = document.createElement('div');
    rtcControls.className = 'rtc-controls';
    rtcControls.innerHTML = `
        <i class="fas fa-microphone-slash rtc-icon disabled" id="voice-icon${suffix}" title="Voice"></i>
        <i class="fas fa-video-slash rtc-icon disabled" id="webcam-icon${suffix}" title="Webcam"></i>
        <i class="fas fa-desktop rtc-icon disabled" id="screen-share-icon${suffix}" title="Screen Share"></i>
        <div class="media-status-indicator" id="media-status-indicator${suffix}"></div>
    `;
    container.appendChild(rtcControls);

    // Add divider
    const divider = document.createElement('hr');
    divider.className = 'divider';
    container.appendChild(divider);

    // Add audio controls
    const audioControls = document.createElement('div');
    audioControls.className = 'audio-controls';
    audioControls.innerHTML = `
        <div class="audio-sliders">
            <div class="audio-slider-group">
                <label for="mic-volume${suffix}">Mic</label>
                <input type="range" id="mic-volume${suffix}" min="0" max="100" value="100">
            </div>
            <div class="audio-slider-group">
                <label for="receive-volume${suffix}">Receive</label>
                <input type="range" id="receive-volume${suffix}" min="0" max="100" value="100">
            </div>
        </div>
        <button class="mute-btn" id="mute-btn${suffix}" title="Mute">
            <i class="fas fa-volume-up"></i>
        </button>
    `;
    container.appendChild(audioControls);

    // Add user info content
    const userInfoContent = document.createElement('div');
    userInfoContent.className = 'user-info-content';

    // Get current user info
    const currentUser = state.users_db && state.currentUserUuid ? state.users_db[state.currentUserUuid] : null;
    const displayName = currentUser ? (currentUser.display_name || currentUser.username) : (window.currentUsername || 'Guest');
    const userStatus = currentUser ? (currentUser.status || 'online') : 'online';
    const statusText = userStatus.charAt(0).toUpperCase() + userStatus.slice(1);
    const avatarUrl = currentUser && currentUser.avatar_url ? currentUser.avatar_url : '/static/default_avatars/smile_1.png';

    // Get current ping
    const pingValue = window.currentLatency;
    const pingDisplay = (pingValue != null && typeof pingValue === 'number') ? `${pingValue}ms` : '----';

    userInfoContent.innerHTML = `
        <div class="avatar">
            <img src="${avatarUrl}" alt="User Avatar">
        </div>
        <div class="user-details">
            <span class="username">${displayName}</span>
            <div class="status-row">
                <span class="status-indicator ${userStatus}">${statusText}</span>
                <span class="ping-display" title="Connection Ping">${pingDisplay}</span>
            </div>
        </div>
        <button class="settings-btn" onclick="event.stopPropagation(); openUserSettings()" title="User Settings">
            <i class="fas fa-cog"></i>
        </button>
    `;
    container.appendChild(userInfoContent);

    // Add click handler to open self profile
    userInfoContent.addEventListener('click', () => {
        const currentUser = state.users_db[state.currentUserUuid];
        if (currentUser) {
            openUserProfileModal(currentUser);
        }
    });

    // Setup controls for this section
    setupRTCControls(suffix);
    setupVolumeControls(suffix);

    // Initial ping display update
    updatePingDisplay();
}

// Update ping display in user info
function updatePingDisplay() {
    const pingDisplays = document.querySelectorAll('.ping-display');
    pingDisplays.forEach(display => {
        const pingValue = window.currentLatency;
        const pingText = (pingValue != null && typeof pingValue === 'number') ? `${pingValue}ms` : '----';
        display.textContent = pingText;
    });
}

// Specific modal functions using generics
function showCreateChannelModal() {
    const modal = document.getElementById('create-channel-modal');
    if (modal) {
        modal.style.display = 'block';
        const input = document.getElementById('channel-name-input');
        if (input) {
            input.focus();
        }
        // Reset icon to default
        selectedIcon = 'far fa-hashtag';
        document.getElementById('channel-icon-input').value = selectedIcon;
        const display = document.getElementById('channel-icon-display');
        display.innerHTML = '<i class="far fa-hashtag"></i>';
    }
}

function hideCreateChannelModal() {
    const form = document.getElementById('create-channel-form');
    const modal = document.getElementById('create-channel-modal');
    if (form) {
        form.removeAttribute('data-editing');
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) {
            submitBtn.textContent = 'Create Channel';
        }
    }
    if (modal) {
        const modalTitle = modal.querySelector('h2');
        if (modalTitle) {
            modalTitle.textContent = 'Create Channel';
        }
    }
    hideModal('create-channel-modal', 'create-channel-form');
}



function sanitizeChannelName(name) {
    return name.toLowerCase()
               .replace(/[^a-z0-9-_]/g, '-')
               .replace(/[-_]+/g, '-')
               .replace(/^[-_]|[-_]$/g, '')
               .substring(0, 50);
}

function createChannel() {
    const input = document.getElementById('channel-name-input');
    const iconInput = document.getElementById('channel-icon-input');
    const form = document.getElementById('create-channel-form');
    const editingChannel = form ? form.getAttribute('data-editing') : null;
    const channelName = input.value.trim();
    const channelIcon = iconInput.value.trim();

    if (!channelName) {
        showError('Channel name is required');
        return;
    }

    const sanitizedName = sanitizeChannelName(channelName);

    if (!sanitizedName) {
        showError('Invalid channel name');
        return;
    }

    if (!editingChannel && window.currentChannels.some(c => c.name === sanitizedName)) {
        showError('Channel already exists');
        return;
    }

    if (editingChannel) {
        // Update existing channel
        socket.emit('update_channel', {
            id: editingChannel,
            name: sanitizedName,
            icon: channelIcon
        });
    } else {
        // Create new channel
        socket.emit('create_channel', {
            channel: sanitizedName,
            icon: channelIcon
        });
    }
}

function switchToChannel(channelId) {
    if (window.currentChannel === channelId) return;

    const channels = document.querySelectorAll('.channel');
    channels.forEach(ch => ch.classList.remove('active'));

    const targetChannel = document.querySelector(`.channel[data-channel="${channelId}"]`);
    if (targetChannel) {
        targetChannel.classList.add('active');
    }

    updateChannelIndicators();

    window.currentChannel = channelId;
    state.currentChannel = channelId;
    resetChannelUnreadCount(channelId);

    // Find the channel name for header and placeholder
    const channelObj = window.currentChannels.find(c => c.id === channelId);
    const channelName = channelObj ? channelObj.name : channelId;
    updateChannelHeader(channelName);

    const messageInput = document.querySelector('.message-input');
    if (messageInput) {
        messageInput.placeholder = `Message in ${channelName}`;
    }

    // Clear messages immediately when switching channels
    const messagesContainer = document.getElementById('messages-container');
    if (messagesContainer) {
        messagesContainer.innerHTML = '';
        messagesContainer.style.overflow = 'hidden';
        setTimeout(() => messagesContainer.style.overflow = 'auto', 0);
    }

    socket.emit('join_channel', {
        channel: channelId
    });
}

function renderChannelList(channels) {
    const channelsList = document.getElementById('channels-list');
    if (!channelsList) return;

    window.currentChannels = channels;
    channelsList.innerHTML = '';

    // Check if currentChannel exists in the channels list
    if (!channels.some(c => c.id === window.currentChannel)) {
        window.currentChannel = 'general';
        updateChannelHeader('general');
        const messageInput = document.querySelector('.message-input');
        if (messageInput) {
            messageInput.placeholder = 'Message in general';
        }
    }

    channels.forEach(channelObj => {
        const channelId = channelObj.id;
        const channelName = channelObj.name;
        const channelElement = document.createElement('div');
        channelElement.className = `channel${channelId === window.currentChannel ? ' active' : ''}`;
        channelElement.setAttribute('data-channel', channelId);

        const unreadCount = channelUnreadCounts.get(channelId) || 0;
        const icon = channelObj.icon || 'fas fa-circle';
        const iconHtml = icon.startsWith('fa') ? `<i class="${icon}"></i>` : icon;
        channelElement.innerHTML = `
            <span class="channel-icon">${iconHtml}</span>
            <span class="channel-name">${escapeHtml(channelName)}</span>
            ${unreadCount > 0 ? `<span class="unread-count">${unreadCount}</span>` : ''}
            <button class="edit-channel-btn" onclick="editChannel('${channelId}')" title="Edit Channel"><i class="fas fa-edit"></i></button>
            ${channelId !== 'general' ? '<button class="delete-channel-btn" onclick="deleteChannel(\'' + channelId + '\')" title="Delete Channel"><i class="fas fa-times"></i></button>' : ''}
        `;

        channelElement.addEventListener('click', (e) => {
            if (!e.target.classList.contains('delete-channel-btn') && !e.target.closest('.delete-channel-btn') &&
                !e.target.classList.contains('edit-channel-btn') && !e.target.closest('.edit-channel-btn')) {
                switchToChannel(channelId);
            }
        });

        channelsList.appendChild(channelElement);
    });

    updateChannelIndicators();
}

function deleteChannel(channelId) {
    if (channelId === 'general') {
        showError('Cannot delete the general channel');
        return;
    }

    const channelObj = window.currentChannels.find(c => c.id === channelId);
    const channelName = channelObj ? channelObj.name : channelId;

    if (confirm(`Are you sure you want to delete #${channelName}? This will delete all messages in the channel.`)) {
        socket.emit('delete_channel', {
            channel: channelId
        });

        if (window.currentChannel === channelId) {
            switchToChannel('general');
        }
    }
}

function editChannel(channelId) {
    // Find the channel object
    const channelObj = window.currentChannels.find(c => c.id === channelId);
    if (!channelObj) return;

    // Pre-fill the create channel modal for editing
    const modal = document.getElementById('create-channel-modal');
    const form = document.getElementById('create-channel-form');
    const nameInput = document.getElementById('channel-name-input');
    const iconInput = document.getElementById('channel-icon-input');
    const iconDisplay = document.getElementById('channel-icon-display');

    if (modal && form && nameInput && iconInput && iconDisplay) {
        nameInput.value = channelObj.name;
        iconInput.value = channelObj.icon || 'fas fa-circle';
        iconDisplay.innerHTML = `<i class="${channelObj.icon || 'fas fa-circle'}"></i>`;

        // Change modal title and submit button text
        const modalTitle = modal.querySelector('h2');
        if (modalTitle) {
            modalTitle.textContent = 'Edit Channel';
        }
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) {
            submitBtn.textContent = 'Update Channel';
        }

        // Store editing state
        form.setAttribute('data-editing', channelId);

        modal.style.display = 'flex';
    }
}

function renderMediaChannelList(channels) {
    const mediaChannelsList = document.getElementById('media-channels-list');
    if (!mediaChannelsList) return;

    window.currentMediaChannels = channels;
    mediaChannelsList.innerHTML = '';

    // Check if currentMediaChannel exists in the channels list
    if (!channels.includes(window.currentMediaChannel)) {
        window.currentMediaChannel = 'default';
    }

    channels.forEach(channelName => {
        const channelElement = document.createElement('div');
        channelElement.className = `media-channel${channelName === window.currentMediaChannel ? ' active' : ''}`;
        channelElement.setAttribute('data-media-channel', channelName);

        const unreadCount = channelUnreadCounts.get(channelName) || 0;
        channelElement.innerHTML = `
            <span class="channel-indicator"><i class="far fa-volume-down"></i></span>
            <span class="channel-name">${escapeHtml(channelName)}</span>
            ${unreadCount > 0 ? `<span class="unread-count">${unreadCount}</span>` : ''}
            ${channelName !== 'default' ? '<button class="delete-media-channel-btn" onclick="deleteMediaChannel(\'' + channelName + '\')" title="Delete Media Channel"><i class="fas fa-times"></i></button>' : ''}
        `;

        channelElement.addEventListener('click', (e) => {
            if (!e.target.classList.contains('delete-media-channel-btn') && !e.target.closest('.delete-media-channel-btn')) {
                switchToMediaChannel(channelName);
            }
        });

        mediaChannelsList.appendChild(channelElement);
    });

    updateChannelIndicators();
}

function switchToMediaChannel(channelName) {
    if (window.currentMediaChannel === channelName) return;

    const mediaChannels = document.querySelectorAll('.media-channel');
    mediaChannels.forEach(ch => ch.classList.remove('active'));

    const targetChannel = document.querySelector(`.media-channel[data-media-channel="${channelName}"]`);
    if (targetChannel) {
        targetChannel.classList.add('active');
    }

    updateChannelIndicators();

    window.currentMediaChannel = channelName;

    // Only switch media room if user is already joined to a media channel
    if (window.isInMediaChannel && window.webrtcManager) {
        window.webrtcManager.leaveRoom();
        window.webrtcManager.joinRoom(channelName, window.currentUserUuid || window.currentUsername || 'guest');
    }
}

function deleteMediaChannel(channelName) {
    if (channelName === 'default') {
        showError('Cannot delete the default media channel');
        return;
    }

    if (confirm(`Are you sure you want to delete media channel "${channelName}"?`)) {
        socket.emit('delete_media_channel', {
            channel: channelName
        });

        if (window.currentMediaChannel === channelName) {
            switchToMediaChannel('default');
        }
    }
}

// Media channel join/leave functionality
window.isInMediaChannel = false;

function joinMediaChannel() {
    if (window.isInMediaChannel) {
        leaveMediaChannel();
    }

    const selectedChannel = window.currentMediaChannel || 'default';
    console.log(`Joining media channel: ${selectedChannel}`);

    if (window.webrtcManager) {
        window.webrtcManager.joinRoom(selectedChannel, window.currentUserUuid || window.currentUsername || 'guest');
        window.isInMediaChannel = true;
        updateMediaButtons();
    }
}

function leaveMediaChannel() {
    if (!window.isInMediaChannel) return;

    console.log('Leaving media channel');

    if (window.webrtcManager) {
        window.webrtcManager.leaveRoom();
        window.isInMediaChannel = false;
        updateMediaButtons();
    }
}

function updateMediaButtons() {
    const joinBtn = document.getElementById('media-join-btn');
    const leaveBtn = document.getElementById('media-leave-btn');
    const statusIndicator = document.getElementById('media-status-indicator');
    const voiceIcon = document.getElementById('voice-icon');
    const webcamIcon = document.getElementById('webcam-icon');
    const screenShareIcon = document.getElementById('screen-share-icon');

    if (window.isInMediaChannel) {
        joinBtn.classList.add('disabled');
        leaveBtn.classList.remove('disabled');
        if (statusIndicator) {
            statusIndicator.className = 'media-status-indicator connected';
            statusIndicator.title = 'Connected to media channel';
        }
        voiceIcon.classList.remove('disabled');
        webcamIcon.classList.remove('disabled');
        screenShareIcon.classList.remove('disabled');
    } else {
        joinBtn.classList.remove('disabled');
        leaveBtn.classList.add('disabled');
        if (statusIndicator) {
            statusIndicator.className = 'media-status-indicator disconnected';
            statusIndicator.title = 'Disconnected from media channels';
        }
        voiceIcon.classList.add('disabled');
        webcamIcon.classList.add('disabled');
        screenShareIcon.classList.add('disabled');
    }
}

// Screen Share Functions
let screenStream = null;

function openScreenShareModal() {
    if (!window.isInMediaChannel) return;
    // Bypass modal and directly start screen share since browser handles selection
    startScreenShare();
}

function closeScreenShareModal() {
    document.getElementById('screen-share-modal').style.display = 'none';
    document.getElementById('screen-share-preview').style.display = 'none';
}

async function startScreenShare(type) {
    try {
        if (!window.isInMediaChannel) return;
        const constraints = {
            video: { displaySurface: type === 'screen' ? 'monitor' : type === 'window' ? 'window' : 'browser' },
            audio: false
        };

        screenStream = await navigator.mediaDevices.getDisplayMedia(constraints);
        console.log('Screen share stream obtained:', screenStream);

        const videoElement = document.getElementById('screen-share-video');
        videoElement.srcObject = screenStream;
        document.getElementById('screen-share-preview').style.display = 'block';

        // Add to WebRTC
        if (window.webrtcManager) {
            window.webrtcManager.startScreenshare(screenStream);
            console.log('Screen share started with WebRTC');
        }

    } catch (error) {
        console.error('Error starting screen share:', error);
        alert('Failed to start screen share: ' + error.message);
    }
}

function stopScreenShare() {
    if (screenStream) {
        screenStream.getTracks().forEach(track => track.stop());
        screenStream = null;
        console.log('Screen share stopped');
    }

    document.getElementById('screen-share-preview').style.display = 'none';

    if (window.webrtcManager) {
        window.webrtcManager.stopScreenshare();
        console.log('Screen share stopped in WebRTC');
    }

    closeScreenShareModal();
}

document.addEventListener('DOMContentLoaded', () => {
    // Setup user info sections
    setupUserInfoSection('main-user-info', '');



    const createChannelForm = document.getElementById('create-channel-form');
    if (createChannelForm) {
        createChannelForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const input = document.getElementById('channel-name-input');
            if (input && input.value.trim()) {
                createChannel();
                hideCreateChannelModal();
            }
        });
    }

    const cancelButton = document.querySelector('#create-channel-modal .cancel-button');
    if (cancelButton) {
        cancelButton.addEventListener('click', hideCreateChannelModal);
    }

    const modal = document.getElementById('create-channel-modal');
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                hideCreateChannelModal();
            }
        });
    }

    // Media channel form handling
    const createMediaChannelForm = document.getElementById('create-media-channel-form');
    if (createMediaChannelForm) {
        createMediaChannelForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const input = document.getElementById('media-channel-name-input');
            if (input && input.value.trim()) {
                createMediaChannel(input.value.trim());
                hideCreateMediaChannelModal();
            }
        });
    }

    const mediaCancelButton = document.querySelector('#create-media-channel-modal .cancel-button');
    if (mediaCancelButton) {
        mediaCancelButton.addEventListener('click', hideCreateMediaChannelModal);
    }

    const mediaModal = document.getElementById('create-media-channel-modal');
    if (mediaModal) {
        mediaModal.addEventListener('click', (e) => {
            if (e.target === mediaModal) {
                hideCreateMediaChannelModal();
            }
        });
    }

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            const modal = document.getElementById('create-channel-modal');
            if (modal && modal.style.display === 'block') {
                hideCreateChannelModal();
            }
            const mediaModal = document.getElementById('create-media-channel-modal');
            if (mediaModal && mediaModal.style.display === 'block') {
                hideCreateMediaChannelModal();
            }
        }
    });

    // Media icon event listeners - only work when joined to media channel
    setupRTCControls('');

    // Volume control event listeners
    setupVolumeControls('');

    // Generic volume control setup
    setupVolumeControls('');



    // Also for file-share tab icons - only work when joined to media channel
    setupRTCControls('-fs');

    // Volume controls for file-share tab
    setupVolumeControls('-fs');
});

function showCreateMediaChannelModal() {
    showModal('create-media-channel-modal', 'media-channel-name-input');
}

function hideCreateMediaChannelModal() {
    hideModal('create-media-channel-modal', 'create-media-channel-form');
}

function createMediaChannel(channelName) {
    const sanitizedName = sanitizeChannelName(channelName);

    if (!sanitizedName) {
        showError('Invalid media channel name');
        return;
    }

    if (window.currentMediaChannels && window.currentMediaChannels.includes(sanitizedName)) {
        showError('Media channel already exists');
        return;
    }

    socket.emit('create_media_channel', {
        channel: sanitizedName
    });
}

if (typeof socket !== 'undefined') {
    socket.on('update_channels', (data) => {
        if (data.channels) {
            renderChannelList(data.channels);
        }
    });

    socket.on('channel_created', (data) => {
        if (data.channel) {
            showSuccess(`Channel created successfully`);
            // Automatically switch to the new channel
            switchToChannel(data.channel);
        }
    });

    socket.on('channel_updated', (data) => {
        if (data.channel_id && data.new_name) {
            if (window.currentChannel === data.channel_id) {
                updateChannelHeader(data.new_name);
                const messageInput = document.querySelector('.message-input');
                if (messageInput) {
                    messageInput.placeholder = `Message in ${data.new_name}`;
                }
            }
            showSuccess(`Channel updated to "${data.new_name}"`);
        }
    });

    socket.on('update_media_channels', (data) => {
        if (data.channels) {
            renderMediaChannelList(data.channels);
        }
    });

    socket.on('media_channel_created', (data) => {
        if (data.channel) {
            showSuccess(`Media channel "${data.channel}" created`);
            // The list will be updated via update_media_channels
        }
    });

    socket.on('media_channel_deleted', (data) => {
        if (data.channel) {
            showSuccess(`Media channel "${data.channel}" deleted`);
            // The list will be updated via update_media_channels
        }
    });

    // Request initial channels after listeners are set up
    socket.emit('request_channels');
}

// Icon picker variables
let selectedIcon = 'far fa-hashtag';

// Icon picker functions
function openIconPicker() {
    const container = document.getElementById('icon-picker-container');
    container.innerHTML = '';
    availableIcons.forEach(icon => {
        const wrapper = document.createElement('div');
        wrapper.className = 'icon-wrapper';
        const div = document.createElement('div');
        div.className = 'icon-option';
        if (!icon.startsWith('fa')) {
            div.classList.add('emoji-icon');
        }
        div.setAttribute('data-icon', icon);
        const iconHtml = icon.startsWith('fa') ? `<i class="${icon}"></i>` : icon;
        div.innerHTML = iconHtml;
        if (icon === selectedIcon) {
            div.classList.add('selected');
        }
        div.addEventListener('click', () => selectIcon(icon));
        wrapper.appendChild(div);
        container.appendChild(wrapper);
    });
    document.getElementById('icon-picker-modal').style.display = 'flex';
}

function selectIcon(icon) {
    selectedIcon = icon;
    document.querySelectorAll('.icon-option').forEach(opt => {
        opt.classList.remove('selected');
        if (opt.getAttribute('data-icon') === icon) {
            opt.classList.add('selected');
        }
    });
}

function applyIcon() {
    document.getElementById('channel-icon-input').value = selectedIcon;
    const display = document.getElementById('channel-icon-display');
    const iconHtml = selectedIcon.startsWith('fa') ? `<i class="${selectedIcon}"></i>` : selectedIcon;
    display.innerHTML = iconHtml;
    document.getElementById('icon-picker-modal').style.display = 'none';
}

function cancelIcon() {
    document.getElementById('icon-picker-modal').style.display = 'none';
}

// Event listeners for icon picker
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('choose-icon-btn').addEventListener('click', openIconPicker);
    document.getElementById('apply-icon-btn').addEventListener('click', applyIcon);
    document.getElementById('cancel-icon-btn').addEventListener('click', cancelIcon);
});

// Make functions globally available for HTML onclick
window.showCreateChannelModal = showCreateChannelModal;
window.showCreateMediaChannelModal = showCreateMediaChannelModal;
window.joinMediaChannel = joinMediaChannel;
window.leaveMediaChannel = leaveMediaChannel;
window.editChannel = editChannel;
window.deleteChannel = deleteChannel;
window.deleteMediaChannel = deleteMediaChannel;