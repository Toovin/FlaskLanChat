// Collaborative Drawing Integration Client-side Logic

let drawingDemo = null;

// Initialize drawing integration
function initDraw() {
    console.log('🎨 [DEBUG] Initializing drawing integration...');
}

// Function called when draw tab is activated
function activateDrawTab() {
    console.log('🎨 [DEBUG] Draw tab activated');

    // Initialize the drawing demo if not already done
    if (!drawingDemo) {
        console.log('🎨 [DEBUG] Initializing collaborative drawing demo...');
        drawingDemo = new CollaborativeDrawingDemo();
    } else {
        console.log('🎨 [DEBUG] Drawing demo already initialized');
    }
}

// Collaborative Drawing Demo Class - Modified from original drawing_demo_rcmpg.js
class CollaborativeDrawingDemo {
    constructor() {
        this.canvas = document.getElementById('drawingCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.contextMenu = document.getElementById('contextMenu');
        this.colorPickerModal = document.getElementById('colorPickerModal');
        this.layersPanel = document.querySelector('.layers-panel');
        this.isDragging = false;
        this.dragOffset = 0;

        this.layers = [
            { type: 'background', color: '#ffffff', texture: null, opacity: 1, visible: true },
            { type: 'image', image: null, opacity: 1, visible: true },
            { type: 'strokes', name: 'Base Layer', paths: [], opacity: 1, visible: true }
        ];
        this.activeLayer = 2; // Base Layer
        this.currentPath = null;
        this.isDrawing = false;
        this.isDot = false;
        this.dotX = 0;
        this.dotY = 0;
        this.previewX = undefined;
        this.previewY = undefined;
        this.tool = 'brush';
        this.brushSize = 5;
        this.brushShape = 'round';
        this.brushOpacity = 1;
        this.strokeColor = '#000000';

        this.init();
        this.setupSocketListeners();
    }

    init() {
        this.setupCanvas();
        this.setupEventListeners();
        this.setupColorPicker();
        this.updateBrushSizeDisplay();
        this.updateBrushOpacityDisplay();
        this.drawCanvas();
        this.createLayersUI();
    }

    setupCanvas() {
        // Set canvas size to 768x768
        this.canvas.width = 768;
        this.canvas.height = 768;
        this.canvas.style.width = '768px';
        this.canvas.style.height = '768px';
    }

    setupEventListeners() {
        // Drawing events
        this.canvas.addEventListener('mousedown', this.startDrawing.bind(this));
        this.canvas.addEventListener('mousemove', this.draw.bind(this));
        this.canvas.addEventListener('mouseup', this.stopDrawing.bind(this));
        this.canvas.addEventListener('mouseout', (e) => { this.stopDrawing(); this.clearPreview(); });

        // Touch events for mobile
        this.canvas.addEventListener('touchstart', this.handleTouch.bind(this));
        this.canvas.addEventListener('touchmove', this.handleTouch.bind(this));
        this.canvas.addEventListener('touchend', this.stopDrawing.bind(this));

        // Right-click context menu
        this.canvas.addEventListener('contextmenu', this.showContextMenu.bind(this));
        document.addEventListener('click', this.hideContextMenu.bind(this));

        // Layer context menu
        document.addEventListener('click', this.hideLayerContextMenu.bind(this));

        // Tool buttons
        document.getElementById('brushTool').addEventListener('click', () => this.setTool('brush'));
        document.getElementById('eraserTool').addEventListener('click', () => this.setTool('eraser'));
        document.getElementById('brushSize').addEventListener('input', this.updateBrushSize.bind(this));
        document.getElementById('brushOpacity').addEventListener('input', this.updateBrushOpacity.bind(this));
        document.getElementById('brushShape').addEventListener('change', (e) => this.setBrushShape(e.target.value));
        document.getElementById('brushColorBtn').addEventListener('click', () => this.openColorPicker('brush'));
        document.getElementById('bgColorBtn').addEventListener('click', () => this.openColorPicker('background'));
        document.getElementById('textureBtn').addEventListener('click', this.generateTexture.bind(this));
        document.getElementById('clearBtn').addEventListener('click', this.clearCanvas.bind(this));
        document.getElementById('saveImageBtn').addEventListener('click', this.saveImage.bind(this));
        document.getElementById('exportProjectBtn').addEventListener('click', this.exportProject.bind(this));
        document.getElementById('addLayer').addEventListener('click', this.addLayer.bind(this));

        // Drag functionality
        const header = document.querySelector('.layers-header');
        header.addEventListener('mousedown', this.startDrag.bind(this));
        document.addEventListener('mousemove', this.drag.bind(this));
        document.addEventListener('mouseup', this.stopDrag.bind(this));

        // Context menu items
        document.getElementById('strokeColor').addEventListener('click', () => this.openColorPicker('stroke'));
        document.getElementById('bgColor').addEventListener('click', () => this.openColorPicker('background'));
        document.getElementById('clearArea').addEventListener('click', this.clearCanvas.bind(this));
    }

    setupSocketListeners() {
        // Listen for drawing events from other users
        socket.on('draw_path', (data) => {
            this.receiveDrawPath(data);
        });

        socket.on('draw_dot', (data) => {
            this.receiveDrawDot(data);
        });

        socket.on('clear_canvas', (data) => {
            this.receiveClearCanvas(data);
        });

        socket.on('update_background', (data) => {
            this.receiveUpdateBackground(data);
        });

        socket.on('add_image', (data) => {
            this.receiveAddImage(data);
        });
    }

    startDrawing(e) {
        if (e.button === 2) return; // Ignore right-click
        this.isDrawing = true;
        this.isDot = true;
        this.clearPreview();
        this.currentPath = new Path2D();
        const rect = this.canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        this.dotX = x;
        this.dotY = y;
        this.currentPath.moveTo(x, y);
        this.ctx.beginPath();
        this.ctx.moveTo(x, y);
    }

    draw(e) {
        if (!this.isDrawing) {
            // Update preview
            const rect = this.canvas.getBoundingClientRect();
            this.previewX = e.clientX - rect.left;
            this.previewY = e.clientY - rect.top;
            this.drawCanvas();
            return;
        }
        this.isDot = false;
        const rect = this.canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        this.currentPath.lineTo(x, y);
        this.ctx.lineTo(x, y);
        this.ctx.strokeStyle = this.tool === 'eraser' ? this.layers[0].color : this.strokeColor;
        this.ctx.lineWidth = this.brushSize;
        this.ctx.lineCap = this.brushShape === 'round' ? 'round' : 'butt';
        this.ctx.lineJoin = this.brushShape === 'round' ? 'round' : 'miter';
        this.ctx.save();
        this.ctx.globalAlpha = this.brushOpacity;
        this.ctx.stroke();
        this.ctx.restore();
    }

    stopDrawing() {
        if (this.isDrawing) {
            if (this.isDot) {
                // Draw and store dot
                this.ctx.save();
                this.ctx.globalAlpha = this.brushOpacity;
                this.ctx.fillStyle = this.tool === 'eraser' ? this.layers[0].color : this.strokeColor;
                this.ctx.beginPath();
                if (this.brushShape === 'round') {
                    this.ctx.arc(this.dotX, this.dotY, this.brushSize / 2, 0, 2 * Math.PI);
                    this.ctx.fill();
                } else {
                    this.ctx.fillRect(this.dotX - this.brushSize / 2, this.dotY - this.brushSize / 2, this.brushSize, this.brushSize);
                }
                this.ctx.restore();

                const dotData = {
                    x: this.dotX,
                    y: this.dotY,
                    color: this.tool === 'eraser' ? this.layers[0].color : this.strokeColor,
                    size: this.brushSize,
                    shape: this.brushShape,
                    opacity: this.brushOpacity,
                    layer: this.activeLayer
                };
                this.layers[this.activeLayer].paths.push({
                    type: 'dot',
                    ...dotData
                });

                // Send to server
                socket.emit('draw_dot', dotData);
            } else if (this.currentPath) {
                // For collaborative drawing, send basic path info
                // In a full implementation, we'd track all coordinates
                const pathData = {
                    color: this.tool === 'eraser' ? this.layers[0].color : this.strokeColor,
                    size: this.brushSize,
                    shape: this.brushShape,
                    opacity: this.brushOpacity,
                    layer: this.activeLayer,
                    startX: this.dotX,
                    startY: this.dotY
                };
                this.layers[this.activeLayer].paths.push({
                    type: 'path',
                    path: this.currentPath,
                    ...pathData
                });

                // Send to server - for now just send that a path was drawn
                socket.emit('draw_path', pathData);
            }
        }
        this.isDrawing = false;
        this.currentPath = null;
        this.isDot = false;
    }

    receiveDrawPath(data) {
        // For now, just redraw the canvas when receiving path data
        // In a full implementation, you'd reconstruct the path properly
        this.drawCanvas();
    }

    receiveDrawDot(data) {
        this.layers[data.layer].paths.push({
            type: 'dot',
            x: data.x,
            y: data.y,
            color: data.color,
            size: data.size,
            shape: data.shape,
            opacity: data.opacity
        });
        this.drawCanvas();
    }

    receiveClearCanvas(data) {
        this.clearCanvas();
    }

    receiveUpdateBackground(data) {
        this.layers[0].color = data.color;
        this.drawCanvas();
    }

    receiveAddImage(data) {
        // Handle image addition from other users
        // This would require image data transmission
    }

    // Rest of the methods from original DrawingDemo class
    handleTouch(e) {
        e.preventDefault();
        const touch = e.touches[0];
        const mouseEvent = new MouseEvent(e.type.replace('touch', 'mouse'), {
            clientX: touch.clientX,
            clientY: touch.clientY
        });
        this.canvas.dispatchEvent(mouseEvent);
    }

    showContextMenu(e) {
        e.preventDefault();
        this.contextMenu.style.display = 'block';
        this.contextMenu.style.left = e.clientX + 'px';
        this.contextMenu.style.top = e.clientY + 'px';
    }

    hideContextMenu() {
        this.contextMenu.style.display = 'none';
    }

    setTool(tool) {
        this.tool = tool;
        document.querySelectorAll('.tool-btn').forEach(btn => btn.classList.remove('active'));
        document.getElementById(tool + 'Tool').classList.add('active');
    }

    setBrushShape(shape) {
        this.brushShape = shape;
    }

    updateBrushSize() {
        this.brushSize = document.getElementById('brushSize').value;
        this.updateBrushSizeDisplay();
    }

    updateBrushSizeDisplay() {
        document.getElementById('brushSizeValue').textContent = this.brushSize;
    }

    updateBrushOpacity() {
        this.brushOpacity = parseFloat(document.getElementById('brushOpacity').value);
        this.updateBrushOpacityDisplay();
    }

    updateBrushOpacityDisplay() {
        document.getElementById('brushOpacityValue').textContent = this.brushOpacity;
    }

    openColorPicker(type) {
        this.colorPickerType = type;
        const titles = {
            brush: 'Brush',
            stroke: 'Stroke',
            background: 'Background'
        };
        document.getElementById('colorPickerTitle').textContent = `Select ${titles[type]} Color`;
        this.colorPickerModal.style.display = 'block';
        this.updateColorPreview();
    }

    closeColorPicker() {
        this.colorPickerModal.style.display = 'none';
    }

    updateColorPreview() {
        const h = document.getElementById('hueRange').value;
        const s = document.getElementById('satRange').value;
        const l = document.getElementById('lightRange').value;
        const a = document.getElementById('alphaRange').value;
        const color = `hsla(${h}, ${s}%, ${l}%, ${a})`;
        document.getElementById('colorPreview').style.background = color;
        document.getElementById('hexText').value = this.hslaToHex(h, s, l, a);
    }

    updateFromHex() {
        const hex = document.getElementById('hexText').value;
        const hsla = this.hexToHsla(hex);
        if (hsla) {
            document.getElementById('hueRange').value = hsla.h;
            document.getElementById('satRange').value = hsla.s;
            document.getElementById('lightRange').value = hsla.l;
            document.getElementById('alphaRange').value = hsla.a;
            document.getElementById('hueText').value = hsla.h;
            document.getElementById('satText').value = hsla.s;
            document.getElementById('lightText').value = hsla.l;
            document.getElementById('alphaText').value = hsla.a;
            this.updateColorPreview();
        }
    }

    applyColor() {
        const h = document.getElementById('hueRange').value;
        const s = document.getElementById('satRange').value;
        const l = document.getElementById('lightRange').value;
        const a = document.getElementById('alphaRange').value;
        const color = `hsla(${h}, ${s}%, ${l}%, ${a})`;

        if (this.colorPickerType === 'brush' || this.colorPickerType === 'stroke') {
            this.strokeColor = color;
        } else {
            this.layers[0].color = color;
            this.drawCanvas();
            // Send background update
            socket.emit('update_background', { color: color });
        }
        this.closeColorPicker();
    }

    drawCanvas() {
        // Background layer
        if (this.layers[0].visible) {
            this.ctx.fillStyle = this.layers[0].color;
            this.ctx.fillRect(0, 0, 768, 768);
            if (this.layers[0].texture) {
                this.ctx.save();
                this.ctx.globalAlpha = this.layers[0].opacity;
                this.ctx.fillStyle = this.layers[0].texture;
                this.ctx.fillRect(0, 0, 768, 768);
                this.ctx.restore();
            }
        }

        // Image layer
        if (this.layers[1].visible && this.layers[1].image) {
            this.ctx.save();
            this.ctx.globalAlpha = this.layers[1].opacity;
            // Image layer functionality removed
            this.ctx.restore();
        }

        // Strokes layers
        this.redrawLayers();

        // Preview
        this.drawPreview();
    }

    generateTexture() {
        const imageData = this.ctx.createImageData(256, 256);
        const data = imageData.data;
        for (let i = 0; i < data.length; i += 4) {
            const noise = Math.random() * 50 - 25;
            data[i] = Math.max(0, Math.min(255, 128 + noise));     // R
            data[i + 1] = Math.max(0, Math.min(255, 128 + noise)); // G
            data[i + 2] = Math.max(0, Math.min(255, 128 + noise)); // B
            data[i + 3] = 30; // Alpha for subtle texture
        }
        const textureCanvas = document.createElement('canvas');
        textureCanvas.width = 256;
        textureCanvas.height = 256;
        textureCanvas.getContext('2d').putImageData(imageData, 0, 0);
        this.layers[0].texture = this.ctx.createPattern(textureCanvas, 'repeat');
        this.drawCanvas();
    }



    clearCanvas() {
        this.layers[0].color = '#ffffff';
        this.layers[0].texture = null;
        this.layers[1].image = null;
        this.layers.forEach(layer => {
            if (layer.type === 'strokes') {
                layer.paths = [];
            }
        });
        this.drawCanvas();
        this.createLayersUI();

        // Send clear event
        socket.emit('clear_canvas', {});
    }

    redrawLayers() {
        for (let i = 2; i < this.layers.length; i++) {
            const layer = this.layers[i];
            if (layer.visible) {
                this.ctx.save();
                this.ctx.globalAlpha = layer.opacity;
                layer.paths.forEach(pathData => {
                    this.ctx.save();
                    this.ctx.globalAlpha *= pathData.opacity;
                    if (pathData.type === 'dot') {
                        this.ctx.fillStyle = pathData.color;
                        this.ctx.beginPath();
                        if (pathData.shape === 'round') {
                            this.ctx.arc(pathData.x, pathData.y, pathData.size / 2, 0, 2 * Math.PI);
                            this.ctx.fill();
                        } else {
                            this.ctx.fillRect(pathData.x - pathData.size / 2, pathData.y - pathData.size / 2, pathData.size, pathData.size);
                        }
                    } else {
                        this.ctx.strokeStyle = pathData.color;
                        this.ctx.lineWidth = pathData.size;
                        this.ctx.lineCap = pathData.shape === 'round' ? 'round' : 'butt';
                        this.ctx.lineJoin = pathData.shape === 'round' ? 'round' : 'miter';
                        this.ctx.stroke(pathData.path);
                    }
                    this.ctx.restore();
                });
                this.ctx.restore();
            }
        }
    }

    addLayer() {
        const strokeLayers = this.layers.filter(l => l.type === 'strokes');
        const newName = `Layer ${strokeLayers.length}`;
        this.layers.push({ type: 'strokes', name: newName, paths: [], opacity: 1, visible: true });
        this.activeLayer = this.layers.length - 1;
        this.createLayersUI();
    }

    createLayersUI() {
        const layersList = document.getElementById('layersList');
        layersList.innerHTML = '';

        this.layers.forEach((layer, index) => {
            const layerDiv = document.createElement('div');
            layerDiv.className = 'layer-item' + (index === this.activeLayer ? ' active' : '');

            const nameSpan = document.createElement('span');
            nameSpan.className = 'layer-name';
            nameSpan.textContent = layer.name || (layer.type === 'background' ? 'Background' : layer.type === 'image' ? 'Image (disabled)' : layer.name);
            if (layer.type === 'strokes') {
                nameSpan.addEventListener('click', () => this.setActiveLayer(index));
            }

            const opacityDiv = document.createElement('div');
            opacityDiv.className = 'layer-opacity';
            const opacityInput = document.createElement('input');
            opacityInput.type = 'range';
            opacityInput.min = '0';
            opacityInput.max = '1';
            opacityInput.step = '0.01';
            opacityInput.value = layer.opacity;
            opacityInput.addEventListener('input', (e) => this.setLayerOpacity(index, parseFloat(e.target.value)));
            opacityDiv.appendChild(opacityInput);

            const controlsDiv = document.createElement('div');
            controlsDiv.className = 'layer-controls';

            const visibilityBtn = document.createElement('button');
            visibilityBtn.className = 'layer-btn';
            visibilityBtn.innerHTML = layer.visible ? '👁️' : '🙈';
            visibilityBtn.addEventListener('click', () => this.toggleLayerVisibility(index));
            controlsDiv.appendChild(visibilityBtn);

            if (layer.type === 'background') {
                const clearBtn = document.createElement('button');
                clearBtn.className = 'layer-btn';
                clearBtn.textContent = '🗑️';
                clearBtn.addEventListener('click', () => this.clearBackgroundLayer());
                controlsDiv.appendChild(clearBtn);
            } else if (layer.type === 'image') {
                // Image layer controls removed
            } else if (layer.type === 'strokes' && index > 2) { // Not base layer
                const deleteBtn = document.createElement('button');
                deleteBtn.className = 'layer-btn';
                deleteBtn.textContent = '🗑️';
                deleteBtn.addEventListener('click', () => this.deleteLayer(index));
                controlsDiv.appendChild(deleteBtn);
            }

            layerDiv.appendChild(nameSpan);
            layerDiv.appendChild(opacityDiv);
            layerDiv.appendChild(controlsDiv);

            layerDiv.addEventListener('contextmenu', (e) => this.showLayerContextMenu(e, index));

            layersList.appendChild(layerDiv);
        });
    }

    setActiveLayer(index) {
        this.activeLayer = index;
        this.createLayersUI();
    }

    setLayerOpacity(index, opacity) {
        this.layers[index].opacity = opacity;
        this.drawCanvas();
    }

    toggleLayerVisibility(index) {
        this.layers[index].visible = !this.layers[index].visible;
        this.drawCanvas();
        this.createLayersUI();
    }

    clearBackgroundLayer() {
        this.layers[0].texture = null;
        this.layers[0].color = '#ffffff';
        this.drawCanvas();
    }



    deleteLayer(index) {
        if (this.layers[index].type === 'strokes' && index > 2) {
            this.layers.splice(index, 1);
            if (this.activeLayer >= index) {
                this.activeLayer = Math.max(2, this.activeLayer - 1);
            }
            this.drawCanvas();
            this.createLayersUI();
        }
    }

    startDrag(e) {
        this.isDragging = true;
        this.dragOffset = e.clientY - this.layersPanel.offsetTop;
        e.preventDefault();
    }

    drag(e) {
        if (this.isDragging) {
            const newTop = e.clientY - this.dragOffset;
            const maxTop = window.innerHeight - this.layersPanel.offsetHeight;
            this.layersPanel.style.top = Math.max(0, Math.min(maxTop, newTop)) + 'px';
        }
    }

    stopDrag() {
        this.isDragging = false;
        this.savePanelPosition();
    }

    loadPanelPosition() {
        const savedTop = localStorage.getItem('layersPanelTop');
        if (savedTop) {
            this.layersPanel.style.top = savedTop;
        }
    }

    savePanelPosition() {
        localStorage.setItem('layersPanelTop', this.layersPanel.style.top);
    }

    drawPreview() {
        if (this.previewX !== undefined && this.previewY !== undefined) {
            this.ctx.save();
            this.ctx.setLineDash([5, 5]);
            this.ctx.strokeStyle = this.tool === 'eraser' ? 'rgba(255, 0, 0, 0.7)' : 'rgba(0, 0, 0, 0.7)';
            this.ctx.lineWidth = 1;
            this.ctx.beginPath();
            if (this.brushShape === 'round') {
                this.ctx.arc(this.previewX, this.previewY, this.brushSize / 2, 0, 2 * Math.PI);
            } else {
                this.ctx.strokeRect(this.previewX - this.brushSize / 2, this.previewY - this.brushSize / 2, this.brushSize, this.brushSize);
            }
            this.ctx.stroke();
            this.ctx.restore();
        }
    }

    clearPreview() {
        this.previewX = undefined;
        this.previewY = undefined;
        this.drawCanvas();
    }

    showLayerContextMenu(e, index) {
        e.preventDefault();
        const menu = document.getElementById('layerContextMenu');
        menu.innerHTML = '';

        if (index >= 2) { // strokes layers
            const clearItem = document.createElement('div');
            clearItem.className = 'context-menu-item';
            clearItem.textContent = 'Clear Layer';
            clearItem.addEventListener('click', () => {
                this.clearLayer(index);
                this.hideLayerContextMenu();
            });
            menu.appendChild(clearItem);
        }

        menu.style.display = 'block';
        menu.style.left = e.clientX + 'px';
        menu.style.top = e.clientY + 'px';
    }

    hideLayerContextMenu() {
        document.getElementById('layerContextMenu').style.display = 'none';
    }

    clearLayer(index) {
        if (index >= 2) {
            this.layers[index].paths = [];
            this.drawCanvas();
        }
    }

    saveImage() {
        const link = document.createElement('a');
        link.download = 'masterpiece.png';
        link.href = this.canvas.toDataURL('image/png');
        link.click();
    }

    exportProject() {
        // Create serializable version of layers (remove Path2D objects)
        const serializableLayers = this.layers.map(layer => ({
            ...layer,
            paths: layer.paths.map(pathData => ({
                ...pathData,
                path: null // Remove non-serializable Path2D
            }))
        }));

        const project = {
            layers: serializableLayers,
            canvasData: this.canvas.toDataURL('image/png')
        };

        const blob = new Blob([JSON.stringify(project, null, 2)], { type: 'application/json' });
        const link = document.createElement('a');
        link.download = 'project.json';
        link.href = URL.createObjectURL(blob);
        link.click();
    }

    setupColorPicker() {
        const ranges = ['hueRange', 'satRange', 'lightRange', 'alphaRange'];
        const texts = ['hueText', 'satText', 'lightText', 'alphaText'];

        ranges.forEach((id, i) => {
            const range = document.getElementById(id);
            const text = document.getElementById(texts[i]);
            range.addEventListener('input', () => {
                text.value = range.value;
                this.updateColorPreview();
            });
            text.addEventListener('input', () => {
                range.value = text.value;
                this.updateColorPreview();
            });
        });

        document.getElementById('hexText').addEventListener('input', this.updateFromHex.bind(this));
        document.getElementById('applyColor').addEventListener('click', this.applyColor.bind(this));
        document.getElementById('cancelColor').addEventListener('click', this.closeColorPicker.bind(this));
    }

    // Utility functions
    hslaToHex(h, s, l, a) {
        // Convert HSLA to HEX (simplified, ignoring alpha for now)
        const c = (1 - Math.abs(2 * l / 100 - 1)) * (s / 100);
        const x = c * (1 - Math.abs((h / 60) % 2 - 1));
        const m = l / 100 - c / 2;
        let r, g, b;
        if (0 <= h && h < 60) { r = c; g = x; b = 0; }
        else if (60 <= h && h < 120) { r = x; g = c; b = 0; }
        else if (120 <= h && h < 180) { r = 0; g = c; b = x; }
        else if (180 <= h && h < 240) { r = 0; g = x; b = c; }
        else if (240 <= h && h < 300) { r = x; g = 0; b = c; }
        else { r = c; g = 0; b = x; }
        r = Math.round((r + m) * 255);
        g = Math.round((g + m) * 255);
        b = Math.round((b + m) * 255);
        return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
    }

    hexToHsla(hex) {
        // Simplified HEX to HSLA conversion
        const r = parseInt(hex.slice(1, 3), 16) / 255;
        const g = parseInt(hex.slice(3, 5), 16) / 255;
        const b = parseInt(hex.slice(5, 7), 16) / 255;
        const max = Math.max(r, g, b);
        const min = Math.min(r, g, b);
        let h, s, l = (max + min) / 2;
        if (max === min) {
            h = s = 0;
        } else {
            const d = max - min;
            s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
            switch (max) {
                case r: h = (g - b) / d + (g < b ? 6 : 0); break;
                case g: h = (b - r) / d + 2; break;
                case b: h = (r - g) / d + 4; break;
            }
            h /= 6;
        }
        return { h: Math.round(h * 360), s: Math.round(s * 100), l: Math.round(l * 100), a: 1 };
    }
}

// Initialize when script loads
initDraw();