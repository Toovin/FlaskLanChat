// message-utils/interactions.js
import { socket, state } from '../core/setup.js';
import { addMessage } from './rendering.js';
import { updateReactions } from './reactions.js';

export async function getMessageById(messageId) {
    return new Promise((resolve) => {
        socket.emit('get_message', { message_id: messageId, channel: state.currentChannel });
        socket.once('message_data', (data) => {
            resolve(data.message || null);
        });
        socket.once('error', (data) => {
            console.error('Failed to fetch message:', data.msg);
            resolve(null);
        });
    });
}

export function scrollToMessage(messageId) {
    const messageGroup = document.querySelector(`.message-group[data-message-id="${messageId}"]`);
    if (messageGroup) {
        messageGroup.scrollIntoView({ behavior: 'smooth', block: 'center' });
        messageGroup.style.transition = 'background-color 0.5s ease';
        messageGroup.style.backgroundColor = 'rgba(255, 107, 107, 0.3)';
        setTimeout(() => {
            messageGroup.style.backgroundColor = 'var(--bg-secondary)';
        }, 1000);
    } else {
        const requestId = Date.now() + Math.random();
        socket.emit('load_more_messages', { channel: state.currentChannel, before_message_id: messageId, request_id: requestId });
        socket.once('channel_history', (data) => {
            if (data.channel === state.currentChannel && data.request_id === requestId) {
                data.messages.forEach(msg => {
                    addMessage(msg.sender, msg.message, msg.is_media, msg.timestamp, false, msg.id, msg.replied_to, msg.replies_count || 0, msg.image_url, msg.thumbnail_url, msg.replied_sender, msg.replied_text, msg.avatar_url);
                    if (msg.reactions && msg.reactions.length > 0) {
                        updateReactions(msg.id, msg.reactions);
                    }
                });
                const messageGroupRetry = document.querySelector(`.message-group[data-message-id="${messageId}"]`);
                if (messageGroupRetry) {
                    messageGroupRetry.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    messageGroupRetry.style.transition = 'background-color 0.5s ease';
                    messageGroupRetry.style.backgroundColor = 'rgba(255, 107, 107, 0.3)';
                    setTimeout(() => {
                        messageGroupRetry.style.backgroundColor = 'var(--bg-secondary)';
                    }, 1000);
                }
            }
        });
    }
}

// Keyboard event listener for canceling reply with Escape key
document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
        const messageInput = document.querySelector('.message-input');
        const replyBar = document.querySelector('.reply-bar');
        if (messageInput && replyBar && messageInput.dataset.replyTo) {
            delete messageInput.dataset.replyTo;
            messageInput.placeholder = `Message #${state.currentChannel}`;
            replyBar.style.display = 'none';
        }
    }
});