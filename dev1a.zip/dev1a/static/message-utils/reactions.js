// message-utils/reactions.js
import { socket, state } from '../core/setup.js';
import { showError } from '../core/ui-utils.js';

export function showReactionPicker(messageId, messageGroup) {
    console.log('showReactionPicker called', { messageId, messageGroup });
    try {
        if (!state.currentChannel) {
            console.error('currentChannel is undefined');
            showError('Channel not set. Please refresh.');
            return;
        }
        if (!state.users_db || !Object.keys(state.users_db).length) {
            console.error('users_db is empty or undefined');
            showError('User data not loaded. Please refresh.');
            return;
        }

        document.querySelectorAll('.reaction-picker').forEach(picker => picker.remove());
        const picker = document.createElement('div');
        picker.className = 'reaction-picker';
        console.log('Reaction picker created');

        const emojis = ['👍', '👎', '❤️', '☠', '😂', '😮', '😢', '😡', '🙂', '😱', '🐕', '🐈', '🐿', '🐓'];
        emojis.forEach(emoji => {
            const button = document.createElement('button');
            button.className = 'reaction-emoji-btn';
            button.textContent = emoji;
            button.addEventListener('click', (e) => {
                e.stopPropagation();
                console.log('Emoji clicked:', emoji);
                socket.emit('add_reaction', {
                    message_id: messageId,
                    emoji: emoji,
                    channel: state.currentChannel
                });
                picker.remove();
            });
            picker.appendChild(button);
        });

        const addReactionBtn = messageGroup.querySelector('.add-reaction-btn');
        if (!addReactionBtn) {
            console.error('add-reaction-btn not found in messageGroup');
            showError('Reaction button not found. Please refresh.');
            return;
        }
        messageGroup.appendChild(picker);
        console.log('Picker appended to messageGroup');

        const messagesContainer = document.getElementById('messages-container');
        if (!messagesContainer) {
            console.error('messages-container not found');
            showError('Messages container not found. Please refresh.');
            return;
        }
        const buttonRect = addReactionBtn.getBoundingClientRect();
        const containerRect = messagesContainer.getBoundingClientRect();
        const pickerWidth = 200;

        const spaceRight = window.innerWidth - buttonRect.right;
        const wouldOverflowRight = spaceRight < pickerWidth;

        picker.style.position = 'absolute';
        if (wouldOverflowRight) {
            picker.style.left = 'auto';
            picker.style.right = '100%';
            picker.style.marginRight = '8px';
            picker.style.marginLeft = '0';
        } else {
            picker.style.left = '';
            picker.style.right = 'auto';
            picker.style.marginLeft = '';
            picker.style.marginRight = '0';
        }

        const pickerRect = picker.getBoundingClientRect();
        if (pickerRect.bottom > containerRect.bottom) {
            messagesContainer.scrollTo({
                top: messagesContainer.scrollTop + (pickerRect.bottom - containerRect.bottom + 10),
                behavior: 'smooth'
            });
        }

        const closePicker = (event) => {
            if (!picker.contains(event.target) && !event.target.closest('.add-reaction-btn')) {
                console.log('Closing picker');
                picker.remove();
                document.removeEventListener('click', closePicker);
            }
        };
        setTimeout(() => {
            document.addEventListener('click', closePicker);
        }, 0);
    } catch (error) {
        console.error('Error in showReactionPicker:', error);
        showError('Failed to show reaction picker. Please refresh.');
    }
}

export function updateReactions(messageId, reactions) {
    const messageGroup = document.querySelector(`.message-group[data-message-id="${messageId}"]`);
    if (!messageGroup) return;
    const reactionsContainer = messageGroup.querySelector('.reactions-container');
    const reactionCountSpan = messageGroup.querySelector('.add-reaction-btn .reaction-count');
    if (!reactionsContainer) return;
    const reactionCounts = {};
    reactions.forEach(r => {
        reactionCounts[r.emoji] = (reactionCounts[r.emoji] || 0) + 1;
    });
    reactionsContainer.innerHTML = '';
    Object.entries(reactionCounts).forEach(([emoji, count]) => {
        const reactionEl = document.createElement('span');
        reactionEl.className = 'reaction';
        const userUuid = Object.values(state.users_db).find(u => u.username === state.currentUsername)?.uuid;
        const isUserReaction = reactions.some(r => r.user_uuid === userUuid && r.emoji === emoji);
        reactionEl.classList.toggle('user-reacted', isUserReaction);
        reactionEl.innerHTML = `${emoji} ${count}`;
        reactionEl.addEventListener('click', () => {
            if (isUserReaction) {
                socket.emit('remove_reaction', { message_id: messageId, emoji, channel: state.currentChannel });
            } else {
                socket.emit('add_reaction', { message_id: messageId, emoji, channel: state.currentChannel });
            }
        });
        reactionsContainer.appendChild(reactionEl);
    });
    if (reactionCountSpan) {
        reactionCountSpan.textContent = reactions.length || '0';
    }
}