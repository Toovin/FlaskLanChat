// message-utils/scrolling.js
import { showError } from '../core/ui-utils.js';
import { scrollTimeout } from './utils.js';

export function scrollMessagesToTop(force = false) {
    const messagesContainer = document.getElementById('messages-container');
    if (!messagesContainer) {
        console.error('messages-container not found');
        showError('Chat container not found. Please refresh.');
        return;
    }
    clearTimeout(scrollTimeout);
    scrollTimeout = setTimeout(() => {
        messagesContainer.scrollTo({
            top: 0,
            behavior: force ? 'instant' : 'smooth'
        });
    }, 100);
}

export function scrollMessagesToBottom(force = false) {
    const messagesContainer = document.getElementById('messages-container');
    if (!messagesContainer) {
        console.error('messages-container not found');
        showError('Chat container not found. Please refresh.');
        return;
    }
    clearTimeout(scrollTimeout);

    requestAnimationFrame(() => {
        messagesContainer.style.overflowY = 'hidden';
        void messagesContainer.offsetHeight;
        messagesContainer.style.overflowY = 'auto';

        setTimeout(() => {
            messagesContainer.scrollTo({
                top: messagesContainer.scrollHeight,
                behavior: force ? 'instant' : 'smooth'
            });

            console.log('Scrolled to bottom:', messagesContainer.scrollHeight);

            const newMessagesButton = document.getElementById('new-messages-button');
            if (newMessagesButton) newMessagesButton.style.display = 'none';
        }, 50);
    });
}