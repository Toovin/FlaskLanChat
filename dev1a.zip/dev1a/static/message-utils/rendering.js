// message-utils/rendering.js
import { socket, state } from '../core/setup.js';
import { showError, escapeHtml } from '../core/ui-utils.js';
import thumbnailLoader from '../thumbnailLoader.js';
import { openImageViewer, openVideoViewer } from '../viewers.js';
import { decodeHtmlEntities, linkifyText } from './utils.js';
import { scrollMessagesToBottom } from './scrolling.js';
import { loadLazyMedia, loadSingleImage, loadVideoDirectly, loadStickerImage } from './media-loader.js';
import { createCarousel, setupCarousel, buildMetadataHtml } from './modals.js';
console.log('buildMetadataHtml imported:', typeof buildMetadataHtml);
import { showReactionPicker, updateReactions } from './reactions.js';
import { getMessageById, scrollToMessage } from './interactions.js';



export async function addMessage(sender, text, isMedia, timestamp, isTemp = false, messageId = null, repliedTo = null, repliesCount = 0, imageUrl = null, thumbnailUrl = null, repliedSender = null, repliedText = null, avatarUrl = null) {
    const messagesContainer = document.getElementById('messages-container');
    if (!messagesContainer) {
        console.error('messages-container not found in DOM.');
        return;
    }

    const messageGroup = document.createElement('div');
    messageGroup.className = 'message-group';
    messageGroup.style.position = 'relative';
    if (isTemp) messageGroup.classList.add('temp');
    if (messageId) messageGroup.dataset.messageId = messageId;

    const user = Object.values(state.users_db).find(u => u.username === sender);
    const avatarOptions = ['smile_1.png', 'smile_2.png', 'smile_3.png'];
    const randomAvatar = avatarOptions[Math.floor(Math.random() * avatarOptions.length)];

    // Use custom avatar if provided (for AI characters), otherwise use user avatar or default
    if (!avatarUrl) {
        avatarUrl = user && user.avatar_url ? user.avatar_url : `/static/default_avatars/${randomAvatar}`;
    }

    console.log('[DEBUG] addMessage - Avatar URL for sender', sender, ':', {
        userFound: !!user,
        userAvatar: user?.avatar_url,
        randomAvatar: randomAvatar,
        finalAvatarUrl: avatarUrl
    });

    let replyIndicator = '';
    if (repliedTo) {
        // Use stored reply context if available, otherwise fetch the message
        if (!repliedSender || !repliedText) {
            // Fallback to fetching if not stored
            const repliedMessage = await getMessageById(repliedTo);
            repliedSender = repliedMessage?.sender || 'Unknown';
            repliedText = repliedMessage?.message ? linkifyText(repliedMessage.message.substring(0, 50)) + (repliedMessage.message.length > 50 ? '...' : '') : 'Message not found';
        } else {
            repliedText = linkifyText(repliedText);
        }

        replyIndicator = `
            <div class="reply-indicator" data-replied-to="${repliedTo}">
                <i class="fas fa-reply"></i>
                <span>Replying to ${escapeHtml(repliedSender)}: ${repliedText}</span>
            </div>`;
    }

    let repliesIndicator = '';
    if (repliesCount > 0) {
        repliesIndicator = `<div class="replies-indicator"><i class="fas fa-reply"></i> ${repliesCount} ${repliesCount === 1 ? 'reply' : 'replies'}</div>`;
    }

    let parsedText = text;
    let attachments = [];
    let metadata = {};
    let messageContentStyle = '';

    if (isMedia) {
        console.log('addMessage isMedia, text:', text);
        if (typeof text === 'string') {
            // Decode HTML entities first (in case the message was HTML-encoded when stored)
            const decodedText = decodeHtmlEntities(text);

            // Check if text looks like JSON (starts with '{' or '[')
            if (decodedText.trim().startsWith('{') || decodedText.trim().startsWith('[')) {
                try {
                    const parsed = JSON.parse(decodedText);
                    console.log('Parsed JSON, parsed.metadata:', parsed.metadata);
                     parsedText = parsed.message || parsed.text || '';
                     attachments = Array.isArray(parsed.attachments) ? parsed.attachments.filter(att =>
                         att && att.url && typeof att.url === 'string' &&
                         (att.thumbnail_url === null || att.thumbnail_url === undefined || typeof att.thumbnail_url === 'string')
                     ).map(att => ({
                         url: att.url,
                         thumbnail_url: att.thumbnail_url || null,
                         size: att.size || 0,
                         metadata: att.metadata || {}  // Preserve individual image metadata
                     })) : [];

                    // Extract metadata if present
                    metadata = parsed.metadata || {};
                } catch (e) {
                    console.warn('Failed to parse JSON message:', e, 'Text:', text, 'Decoded:', decodedText);
                    // Fall back to treating as plain text
                    parsedText = decodedText || '';
                    if (imageUrl && typeof imageUrl === 'string') {
                        attachments = [{ url: imageUrl, thumbnail_url: thumbnailUrl || null, size: 0 }];
                    } else {
                        console.warn('No valid image_url or thumbnail_url, treating as text message');
                        isMedia = false;
                    }
                }
            } else {
                // Plain text message (like "Media downloaded: filename.mp4")
                console.log('Treating media message as plain text:', text);
                parsedText = text || '';
                if (imageUrl && typeof imageUrl === 'string') {
                    attachments = [{ url: imageUrl, thumbnail_url: thumbnailUrl || null, size: 0 }];
                } else {
                    console.warn('No valid image_url or thumbnail_url for plain text media message');
                    isMedia = false;
                }
            }
        } else if (typeof text === 'object' && text.image_url && typeof text.image_url === 'string') {
            parsedText = text.message || '';
            attachments = [{ url: text.image_url, thumbnail_url: text.thumbnail_url || null, size: 0 }];
            metadata = text.metadata || {};
        } else {
            console.warn('Invalid media message format, treating as text message');
            isMedia = false;
        }

        // Validate attachments
        if (isMedia && attachments.length > 0) {
            attachments = attachments.filter(att => att.url && typeof att.url === 'string');
            if (attachments.length === 0) {
                console.warn('No valid attachments after filtering, treating as text message');
                isMedia = false;
            }
        }
    }

    const effectiveImageUrl = attachments.length > 0 ? attachments[0].url : imageUrl;
    const effectiveThumbnailUrl = attachments.length > 0 ? attachments[0].thumbnail_url : thumbnailUrl;

    const wrappedText = String(parsedText);
    let messageContent = `<div class="message-text${wrappedText.startsWith('!') ? ' command' : ''}">${linkifyText(wrappedText)}</div>`;

    if (isMedia && attachments.length > 0) {
        if (attachments.length === 1) {
            console.log('Single attachment detected, attachments:', attachments);
            const att = attachments[0];
            // For single images, attach message-level metadata if present
            if (metadata && Object.keys(metadata).length > 0) {
                att.metadata = metadata;
            }
            const url = att.url;
            const ext = url.split('.').pop().toLowerCase();
            let thumbnailUrl = att.thumbnail_url;
            if (!thumbnailUrl) {
                const urlParts = url.split('/');
                const storageDir = urlParts[2] || 'uploads';
                const filename = urlParts[urlParts.length - 1];
                const baseName = filename.replace(/\.[^.]+$/, '');
                thumbnailUrl = `/static/thumbnails/${storageDir}/${baseName}_thumb.jpg`;
                if (thumbnailUrl && !thumbnailUrl.includes('/uploads/') && url.includes('/Uploads/')) {
                    thumbnailUrl = thumbnailUrl.replace('/static/thumbnails/', '/static/thumbnails/uploads/');
                }
            }

            const imageExtensions = ['png', 'webp', 'jpg', 'jpeg', 'gif', 'jfif'];
            const videoExtensions = ['mp4', 'webm', 'avi', 'mov'];

            let mediaHtml = '';
            if (imageExtensions.includes(ext)) {
                mediaHtml = `
                    <div class="message-image" data-full-url="${escapeHtml(url)}" data-thumbnail-url="${escapeHtml(thumbnailUrl)}" style="position: relative;">
                        <div class="media-placeholder">
                            <i class="fas fa-image fa-2x"></i>
                            <span>Loading thumbnail...</span>
                        </div>
                        <button class="send-to-img2img-btn" style="position: absolute; bottom: 10px; right: 10px; background: rgba(0, 0, 0, 0.7); color: white; border: none; border-radius: 4px; padding: 4px 8px; font-size: 12px; cursor: pointer; opacity: 0; transition: opacity 0.2s; z-index: 10;" title="Send to img2img">→ img2img</button>
                    </div>`;
            } else if (videoExtensions.includes(ext)) {
                const lazyUrl = url.replace('/static/', '/lazy-file/');
                const size = att.size || 0;

                // Check if this is a sticker (from stickers directory)
                const isSticker = url.includes('/static/stickers/');

                if (isSticker) {
                    // Display sticker without border, with looping for videos or static for images
                    const stickerClass = ext === 'webm' ? 'message-sticker-video' : 'message-sticker-image';
                    const mediaType = ext === 'webm' ? 'video' : 'image';
                    mediaHtml = `
                        <div class="message-sticker ${stickerClass}" data-media-url="${escapeHtml(lazyUrl)}" data-media-type="${mediaType}" data-file-ext="${ext}">
                            <div class="media-placeholder">
                                <i class="fas fa-sticky-note fa-2x"></i>
                                <span>Loading sticker...</span>
                            </div>
                        </div>`;
                } else {
                    // Regular video with controls
                    mediaHtml = `
                        <div class="message-video lazy-media" data-media-url="${escapeHtml(lazyUrl)}" data-media-type="video" data-video-ext="${ext}" data-size="${size}">
                            <div class="media-placeholder">
                                <i class="fas fa-video fa-2x"></i>
                                <span>Click to load video${size > 0 ? ` (${(size / (1024 * 1024)).toFixed(1)}MB)` : ''}</span>
                            </div>
                        </div>`;
                }
            }

            if (att.metadata && Object.keys(att.metadata).length > 0) {
                console.log('Adding single image metadata, metadata:', att.metadata);
                messageContent += `
                    <div class="single-image-with-metadata">
                        ${mediaHtml}
                        ${buildMetadataHtml(att.metadata, messageId)}
                    </div>`;
                messageContentStyle = 'max-width: none;';
            } else {
                console.log('No metadata for single image, metadata:', metadata);
                messageContent += mediaHtml;
            }
        } else {
            messageContent += createCarousel(attachments, messageId, metadata);
            // Check if we added a carousel with metadata and adjust message width
            if (metadata && Object.keys(metadata).length > 0) {
                messageContentStyle = 'max-width: none;';
            }
        }
    }

    const deleteButton = `<button class="action-btn delete-btn" aria-label="Delete message"><i class="fas fa-trash"></i></button>`;
    const replyButton = `<button class="action-btn reply-btn" aria-label="Reply to message"><i class="fas fa-reply"></i></button>`;
    const reactionsButton = `<button class="action-btn add-reaction-btn" aria-label="Add reaction"><i class="fas fa-smile"></i></button>`;

    messageGroup.innerHTML = `
        <div class="message-avatar">
            <img src="${avatarUrl}" alt="Avatar">
        </div>
        <div class="message-content" ${messageContentStyle ? `style="${messageContentStyle}"` : ''}>
            ${replyIndicator}
            <div class="message-header">
                <span class="username">${escapeHtml(sender)}</span>
                <span class="timestamp">${timestamp ? moment(timestamp).format('MMM D, YYYY h:mm A') : 'Just now'}</span>
            </div>
            ${repliesIndicator}
            ${messageContent}
            <div class="reactions-container"></div>
        </div>
        <div class="message-actions">
            ${deleteButton}
            ${replyButton}
            ${reactionsButton}
        </div>
    `;

    // Adjust message width if it contains carousel with metadata or single image with metadata
    const messageContentEl = messageGroup.querySelector('.message-content');
    if (messageContentEl && (messageContentEl.querySelector('.image-carousel-with-metadata') || messageContentEl.querySelector('.single-image-with-metadata'))) {
        messageContentEl.style.maxWidth = 'none';
    }

    const messages = Array.from(messagesContainer.children);
    const timestampMoment = timestamp ? moment(timestamp) : moment();
    let inserted = false;

    for (let i = 0; i < messages.length; i++) {
        const existingMessage = messages[i];
        const existingTimestamp = existingMessage.querySelector('.timestamp')?.textContent;
        const existingMoment = existingTimestamp && existingTimestamp !== 'Just now'
            ? moment(existingTimestamp, 'MMM D, YYYY h:mm A')
            : moment();

        if (timestampMoment.isBefore(existingMoment)) {
            messagesContainer.insertBefore(messageGroup, existingMessage);
            inserted = true;
            break;
        }
    }

    if (!inserted) {
        messagesContainer.appendChild(messageGroup);
    }

    if (isTemp || state.autoScrollEnabled) {
        scrollMessagesToBottom(true);
    }

    const addReactionBtn = messageGroup.querySelector('.add-reaction-btn');
    if (addReactionBtn && messageId && !isTemp) {
        addReactionBtn.addEventListener('click', () => showReactionPicker(messageId, messageGroup));
    }

    const replyBtn = messageGroup.querySelector('.reply-btn');
    if (replyBtn && messageId) {
        replyBtn.addEventListener('click', () => {
            const messageInput = document.querySelector('.message-input');
            const replyBar = document.querySelector('.reply-bar');
            if (messageInput && replyBar) {
                messageInput.placeholder = `Replying to ${sender}...`;
                messageInput.dataset.replyTo = messageId;
                replyBar.innerHTML = `
                    <span>Replying to ${escapeHtml(sender)}</span>
                    <button class="cancel-reply-btn" aria-label="Cancel reply"><i class="fas fa-times"></i></button>
                `;
                replyBar.style.display = 'flex';
                const cancelReplyBtn = replyBar.querySelector('.cancel-reply-btn');
                if (cancelReplyBtn) {
                    cancelReplyBtn.addEventListener('click', () => {
                        delete messageInput.dataset.replyTo;
                        messageInput.placeholder = `Message #${currentChannel}`;
                        replyBar.style.display = 'none';
                    });
                }
                messageInput.focus();
            }
        });
    }

    // Handle metadata action buttons
    const generateMoreBtn = messageGroup.querySelector('.generate-more-btn');
    if (generateMoreBtn) {
        generateMoreBtn.addEventListener('click', () => {
            // Use Unicode-safe base64 decoding
            const metadataJson = decodeURIComponent(escape(atob(generateMoreBtn.dataset.metadata)));
            const metadata = JSON.parse(metadataJson);

            // Check if this was originally a batch generation
            const carousel = messageGroup.querySelector('.image-carousel');
            if (carousel) {
                const imageCount = carousel.querySelectorAll('.carousel-thumb').length;
                if (imageCount > 1) {
                    // This was a batch generation, use the carousel count as batch size
                    metadata.batch_size = imageCount;
                    console.log(`Detected batch generation with ${imageCount} images, setting batch_size to ${imageCount}`);
                }
            }

            // Prompt user for number of images to generate
            const defaultBatchSize = metadata.batch_size || 1;
            const userInput = prompt(`How many images do you want to generate? (Current batch size: ${defaultBatchSize})`, defaultBatchSize);

            if (userInput === null) {
                // User cancelled
                return;
            }

            const numImages = parseInt(userInput);
            if (isNaN(numImages) || numImages < 1 || numImages > 10) {
                alert('Please enter a valid number between 1 and 10.');
                return;
            }

            // Update batch size with user input
            metadata.batch_size = numImages;

            console.log('Generate more clicked with metadata:', metadata);

            // Open image generation modal with pre-filled metadata
            if (window.imageAPI && typeof window.imageAPI.openImageGenModal === 'function') {
                // Store the metadata for the modal to use
                window.pendingGenerateMoreMetadata = metadata;
                window.imageAPI.openImageGenModal().then(() => {
                    // The modal will be populated by the stored metadata
                    console.log('Modal opened for generate more');
                }).catch(error => {
                    console.error('Failed to open modal for generate more:', error);
                    // Fallback to immediate generation
                    socket.emit('generate_more', {
                        metadata: metadata,
                        channel: state.currentChannel
                    });
                });
            } else {
                // Fallback to immediate generation if modal API not available
                socket.emit('generate_more', {
                    metadata: metadata,
                    channel: state.currentChannel
                });
            }
        });
    }

    const img2imgMoreBtn = messageGroup.querySelector('.img2img-more-btn');
    if (img2imgMoreBtn) {
        img2imgMoreBtn.addEventListener('click', async () => {
            // Use Unicode-safe base64 decoding
            const metadataJson = decodeURIComponent(escape(atob(img2imgMoreBtn.dataset.metadata)));
            const metadata = JSON.parse(metadataJson);
            const messageId = img2imgMoreBtn.dataset.messageId;

            console.log('Img2img more clicked with metadata:', metadata, 'messageId:', messageId);

            // Find the active/selected image from the carousel or single image
            let imageUrl = null;
            const carousel = messageGroup.querySelector('.image-carousel');

            if (carousel) {
                // Check if this was originally a batch generation
                const imageCount = carousel.querySelectorAll('.carousel-thumb').length;
                if (imageCount > 1) {
                    // This was a batch generation, use the carousel count as batch size
                    metadata.batch_size = imageCount;
                    console.log(`Detected batch generation with ${imageCount} images, setting batch_size to ${imageCount} for img2img`);
                }

                // For carousel, get the active image or first image
                const activeThumb = carousel.querySelector('.carousel-thumb.active') ||
                                   carousel.querySelector('.carousel-thumb');
                if (activeThumb) {
                    imageUrl = activeThumb.dataset.fullUrl;
                }
            } else {
                // For single image
                const messageImage = messageGroup.querySelector('.message-image img');
                if (messageImage) {
                    imageUrl = messageImage.src;
                }
            }

            if (!imageUrl) {
                showError('No image found for img2img');
                return;
            }

            // Set default denoising strength if not present
            if (!metadata.denoising_strength) {
                metadata.denoising_strength = 0.75;
            }

            // Store metadata and image URL for modal
            window.pendingImg2ImgMetadata = {
                ...metadata,
                mode: 'img2img',
                init_image_url: imageUrl
            };

            // Open image generation modal directly
            if (window.imageAPI && typeof window.imageAPI.openImageGenModal === 'function') {
                window.imageAPI.openImageGenModal().then(() => {
                    // The modal will be populated and image will be loaded
                    console.log('Modal opened for img2img more');
                }).catch(error => {
                    console.error('Failed to open modal for img2img more:', error);
                    // Fallback to immediate generation
                    convertAndEmit();
                });
            } else {
                // Fallback to immediate generation if modal API not available
                convertAndEmit();
            }

            async function convertAndEmit() {
                try {
                    // Convert image to base64
                    const response = await fetch(imageUrl);
                    const blob = await response.blob();
                    const base64 = await new Promise((resolve) => {
                        const reader = new FileReader();
                        reader.onload = () => resolve(reader.result);
                    });

                    // Emit socket event for img2img
                    socket.emit('img2img_more', {
                        image_base64: base64,
                        metadata: metadata,
                        channel: state.currentChannel
                    });
                } catch (error) {
                    console.error('Error converting image to base64:', error);
                    showError('Failed to process image for img2img');
                }
            }
        });
    }

    const deleteBtn = messageGroup.querySelector('.delete-btn');
    if (deleteBtn && messageId) {
        deleteBtn.addEventListener('click', () => {
            socket.emit('delete_message', {
                message_id: messageId,
                channel: state.currentChannel
            });
        });
    }

    if (isMedia && attachments.length > 0) {
        const imgElement = messageGroup.querySelector('.message-image');
        if (imgElement && messageId) {
            setTimeout(() => loadSingleImage(imgElement, effectiveImageUrl, effectiveThumbnailUrl), 10);
        }

        const videoElement = messageGroup.querySelector('.message-video');
        if (videoElement && messageId) {
            videoElement.addEventListener('click', () => loadLazyVideo(videoElement, effectiveImageUrl, effectiveImageUrl.split('.').pop().toLowerCase()));
        }
    }

    const replyIndicatorEl = messageGroup.querySelector('.reply-indicator');
    if (replyIndicatorEl && repliedTo) {
        replyIndicatorEl.addEventListener('click', (e) => {
            e.stopPropagation();
            scrollToMessage(repliedTo);
        });
    }

    if (messageId && !isTemp) {
        socket.emit('get_reactions', { message_id: messageId, channel: state.currentChannel });
    }

    requestAnimationFrame(() => setupLazyMediaLoading(messageGroup));
}

function setupLazyMediaLoading(messageGroup) {
    // Handle automatic loading for single images
    const singleImageElements = messageGroup.querySelectorAll('.message-image');
    singleImageElements.forEach(element => {
        if (!element.classList.contains('lazy-media')) {
            // This is a single image that should load automatically
            const fullUrl = element.dataset.fullUrl;
            const thumbnailUrl = element.dataset.thumbnailUrl;
            if (fullUrl) {
                setTimeout(() => loadSingleImage(element, fullUrl, thumbnailUrl), 10);
            }
        }
    });

    // Handle automatic loading for stickers
    const stickerVideoElements = messageGroup.querySelectorAll('.message-sticker-video');
    stickerVideoElements.forEach(element => {
        const mediaUrl = element.dataset.mediaUrl;
        const fileExt = element.dataset.fileExt;
        if (mediaUrl && fileExt) {
            setTimeout(() => loadVideoDirectly(element, mediaUrl, fileExt), 10);
        }
    });

    // Handle automatic loading for sticker images
    const stickerImageElements = messageGroup.querySelectorAll('.message-sticker-image');
    stickerImageElements.forEach(element => {
        const mediaUrl = element.dataset.mediaUrl;
        if (mediaUrl) {
            setTimeout(() => loadStickerImage(element, mediaUrl), 10);
        }
    });

    // Handle click-to-load for videos and other lazy media
    const lazyMediaElements = messageGroup.querySelectorAll('.lazy-media');
    lazyMediaElements.forEach(element => {
        element.addEventListener('click', () => loadLazyMedia(element));
    });
}

