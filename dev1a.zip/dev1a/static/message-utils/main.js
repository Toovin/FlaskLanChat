// message-utils/main.js - Main entry point for message utilities
export { addMessage } from './rendering.js';
export { scrollMessagesToTop, scrollMessagesToBottom } from './scrolling.js';
export { showReactionPicker, updateReactions } from './reactions.js';
export { getMessageById, scrollToMessage } from './interactions.js';
export { createCarousel, setupCarousel, initCarousel } from './modals.js';
export { decodeHtmlEntities, getDocIcon, scrollTimeout, modalData } from './utils.js';

// Re-export media loading functions for backward compatibility
export {
    loadLazyMedia,
    loadSingleImage,
    loadLazyImage,
    loadFullCarouselImage,
    loadFullSingleImage,
    loadCarouselVideo,
    loadCarouselImage,
    loadThumbImageWithFallback,
    loadThumbImage,
    loadFullResolutionImage,
    loadLazyVideo,
    loadVideoDirectly,
    loadStickerImage
} from './media-loader.js';