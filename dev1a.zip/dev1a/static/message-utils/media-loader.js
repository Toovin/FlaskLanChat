// message-utils/media-loader.js
import thumbnailLoader from '../thumbnailLoader.js';
import { openImageViewer, openVideoViewer } from '../viewers.js';

function loadLazyMedia(element) {
    const mediaUrl = element.dataset.mediaUrl;
    const mediaType = element.dataset.mediaType;
    const videoExt = element.dataset.videoExt;

    if (!mediaUrl || !mediaType) {
        console.error('Missing media URL or type:', { mediaUrl, mediaType });
        element.innerHTML = '<div class="media-placeholder"><i class="fas fa-exclamation-triangle fa-2x"></i><span>Missing media info</span></div>';
        element.classList.remove('loading');
        return;
    }

    element.classList.add('loading');
    const placeholder = element.querySelector('.media-placeholder');
    if (placeholder) {
        placeholder.innerHTML = '<i class="fas fa-spinner fa-2x"></i><span>Loading...</span>';
    }

    if (mediaType === 'image') {
        loadLazyImage(element, mediaUrl);
    } else if (mediaType === 'video') {
        loadLazyVideo(element, mediaUrl, videoExt);
    } else {
        console.error('Unsupported media type:', mediaType);
        element.innerHTML = '<div class="media-placeholder"><i class="fas fa-exclamation-triangle fa-2x"></i><span>Unsupported media type</span></div>';
        element.classList.remove('loading');
    }
}

function loadSingleImage(element, fullUrl, thumbnailUrl) {
    // Use the unified thumbnail loader
    thumbnailLoader.loadSingleImage(element, fullUrl, thumbnailUrl, {
        onClick: () => openImageViewer(fullUrl)
    });
}

function loadLazyImage(element, mediaUrl) {
    const thumbnailUrl = element.dataset.thumbnailUrl;
    console.log(`Attempting to load thumbnail: ${thumbnailUrl}, full URL: ${mediaUrl}`);

    if (thumbnailUrl) {
        const thumbImg = new Image();
        thumbImg.onload = () => {
            console.log(`Thumbnail loaded successfully: ${thumbnailUrl}`);
            element.innerHTML = `<img src="${thumbnailUrl}" alt="Shared image thumbnail" style="max-width: 300px; max-height: 200px; object-fit: contain; border-radius: 8px; cursor: pointer;" data-full-url="${mediaUrl}">`;
            element.classList.remove('loading');
            const imgElement = element.querySelector('img');
            if (imgElement) {
                imgElement.addEventListener('click', () => {
                    loadFullResolutionImage(element, mediaUrl);
                });
            }
        };
        thumbImg.onerror = () => {
            console.warn(`Thumbnail failed to load: ${thumbnailUrl}, falling back to full image`);
            loadFullResolutionImage(element, mediaUrl);
        };
        thumbImg.src = thumbnailUrl;
    } else {
        console.warn(`No thumbnail URL for ${mediaUrl}, loading full image`);
        loadFullResolutionImage(element, mediaUrl);
    }
}

function loadFullCarouselImage(element, fullUrl, index, attachments) {
    const img = new Image();
    img.onload = () => {
        element.innerHTML = `<img src="${fullUrl}" alt="Carousel image" style="max-width: 300px; max-height: 200px; object-fit: contain; border-radius: 8px; cursor: pointer;" data-full-url="${fullUrl}" data-index="${index}">`;
        element.classList.remove('loading');

        const imgElement = element.querySelector('img');
        if (imgElement) {
            imgElement.addEventListener('click', () => {
                // Get all image URLs from attachments for the viewer
                const allImageUrls = attachments
                    .filter(att => {
                        const url = typeof att === 'string' ? att : att.url;
                        const ext = url.split('.').pop().toLowerCase();
                        return ['png', 'webp', 'jpg', 'jpeg', 'gif', 'jfif'].includes(ext);
                    })
                    .map(att => typeof att === 'string' ? att : att.url);

                openImageViewer(allImageUrls, index);
            });
        }
    };
    img.onerror = () => {
        element.innerHTML = '<div class="media-placeholder"><i class="fas fa-exclamation-triangle fa-2x"></i><span>Failed to load image</span></div>';
        element.classList.remove('loading');
    };
    img.src = fullUrl;
}

function loadFullSingleImage(element, fullUrl) {
    const img = new Image();
    img.onload = () => {
        element.innerHTML = `<img src="${fullUrl}" alt="Shared image" style="max-width: 300px; max-height: 200px; object-fit: contain; border-radius: 8px; cursor: pointer;">`;
        element.classList.remove('loading');

        const imgElement = element.querySelector('img');
        if (imgElement) {
            imgElement.addEventListener('click', () => {
                openImageViewer(fullUrl);
            });
        }
    };
    img.onerror = () => {
        element.innerHTML = '<div class="media-placeholder"><i class="fas fa-exclamation-triangle fa-2x"></i><span>Failed to load image</span></div>';
        element.classList.remove('loading');
    };
    img.src = fullUrl;
}

function loadCarouselVideo(element, mediaUrl, videoExt, index, attachments) {
    console.log(`Loading carousel video: ${mediaUrl}`);

    const tempVideo = document.createElement('video');
    tempVideo.src = mediaUrl;
    tempVideo.onloadedmetadata = () => {
        const shouldLoop = tempVideo.duration < 60;
        tempVideo.remove();

        element.innerHTML = `
            <video controls autoplay muted ${shouldLoop ? 'loop' : ''} style="max-width: 300px; max-height: 200px; border-radius: 8px; cursor: pointer;" data-index="${index}">
                <source src="${mediaUrl}" type="video/${videoExt === 'mov' ? 'quicktime' : videoExt}">
                Your browser does not support the video tag.
            </video>`;

        element.classList.remove('loading');

        const videoElement = element.querySelector('video');
        if (videoElement) {
            videoElement.addEventListener('click', () => {
                // Get all video URLs from attachments for the viewer
                const allVideoUrls = attachments
                    .filter(att => {
                        const url = typeof att === 'string' ? att : att.url;
                        const ext = url.split('.').pop().toLowerCase();
                        return ['mp4', 'webm', 'avi', 'mov'].includes(ext);
                    })
                    .map(att => typeof att === 'string' ? att : att.url);

                openVideoViewer(allVideoUrls, index);
            });
        }
    };
    tempVideo.onerror = () => {
        element.innerHTML = '<div class="media-placeholder"><i class="fas fa-exclamation-triangle fa-2x"></i><span>Failed to load video</span></div>';
        element.classList.remove('loading');
    };
    tempVideo.load();
}

function loadCarouselImage(imgElement, fullUrl, thumbnailUrl, index, attachments) {
    if (thumbnailUrl) {
        const thumbImg = new Image();
        thumbImg.onload = () => {
            imgElement.src = thumbnailUrl;
            imgElement.style.display = 'block';
            imgElement.classList.remove('loading');
            imgElement.addEventListener('click', () => {
                loadFullCarouselImage(imgElement.parentElement, fullUrl, index, attachments);
            });
        };
        thumbImg.onerror = () => {
            loadFullCarouselImage(imgElement.parentElement, fullUrl, index, attachments);
        };
        thumbImg.src = thumbnailUrl;
    } else {
        loadFullCarouselImage(imgElement.parentElement, fullUrl, index, attachments);
    }
}

function loadThumbImageWithFallback(element, fullUrl, thumbnailUrl, index, messageId = null) {
    if (thumbnailUrl) {
        const thumbImg = new Image();
        thumbImg.onload = () => {
            element.innerHTML = `<img src="${thumbnailUrl}" alt="Thumbnail" style="max-width: 120px; max-height: 120px; object-fit: cover; border-radius: 4px; cursor: pointer;" data-full-url="${fullUrl}" data-index="${index}">`;
            element.classList.remove('loading');
            const imgElement = element.querySelector('img');
            if (imgElement) {
                imgElement.addEventListener('click', () => {
                    loadFullCarouselImage(element, fullUrl, index, []);
                });
            }
        };
        thumbImg.onerror = () => {
            loadThumbImage(element, fullUrl, thumbnailUrl, index, messageId);
        };
        thumbImg.src = thumbnailUrl;
    } else {
        loadThumbImage(element, fullUrl, thumbnailUrl, index, messageId);
    }
}

function loadThumbImage(element, fullUrl, thumbnailUrl, index, messageId = null) {
    const img = new Image();
    img.onload = () => {
        element.innerHTML = `<img src="${thumbnailUrl || fullUrl}" alt="Thumbnail" style="max-width: 120px; max-height: 120px; object-fit: cover; border-radius: 4px; cursor: pointer;" data-full-url="${fullUrl}" data-index="${index}">`;
        element.classList.remove('loading');
        const imgElement = element.querySelector('img');
        if (imgElement) {
            imgElement.addEventListener('click', () => {
                loadFullCarouselImage(element, fullUrl, index, []);
            });
        }
    };
    img.onerror = () => {
        element.innerHTML = '<div class="media-placeholder"><i class="fas fa-exclamation-triangle"></i><span>Failed</span></div>';
        element.classList.remove('loading');
    };
    img.src = thumbnailUrl || fullUrl;
}

function loadFullResolutionImage(element, mediaUrl) {
    const img = new Image();
    img.onload = () => {
        element.innerHTML = `<img src="${mediaUrl}" alt="Full resolution image" style="max-width: 100%; max-height: 400px; object-fit: contain; border-radius: 8px; cursor: pointer;">`;
        element.classList.remove('loading');
        const imgElement = element.querySelector('img');
        if (imgElement) {
            imgElement.addEventListener('click', () => {
                openImageViewer(mediaUrl);
            });
        }
    };
    img.onerror = () => {
        element.innerHTML = '<div class="media-placeholder"><i class="fas fa-exclamation-triangle fa-2x"></i><span>Failed to load image</span></div>';
        element.classList.remove('loading');
    };
    img.src = mediaUrl;
}

function loadLazyVideo(element, mediaUrl, videoExt) {
    // Auto-load all videos regardless of size
    loadVideoDirectly(element, mediaUrl, videoExt);
}

function loadVideoDirectly(element, mediaUrl, videoExt) {
    const tempVideo = document.createElement('video');
    tempVideo.src = mediaUrl;
    tempVideo.onloadedmetadata = () => {
        const shouldLoop = tempVideo.duration < 60;
        tempVideo.remove();

        // Check if this is a sticker
        const isSticker = element.classList.contains('message-sticker-video');

        if (isSticker) {
            // Sticker: no controls, always loop, no border, transparent background
            element.innerHTML = `
                <video autoplay muted loop style="max-width: 200px; max-height: 200px; border: none; background: transparent;">
                    <source src="${mediaUrl}" type="video/${videoExt === 'mov' ? 'quicktime' : videoExt}">
                    Your browser does not support the video tag.
                </video>`;
        } else {
            // Regular video: with controls
            element.innerHTML = `
                <video controls autoplay muted ${shouldLoop ? 'loop' : ''} style="max-width: 300px; max-height: 200px; border-radius: 8px;">
                    <source src="${mediaUrl}" type="video/${videoExt === 'mov' ? 'quicktime' : videoExt}">
                    Your browser does not support the video tag.
                </video>`;
        }

        element.classList.remove('loading');

        const videoElement = element.querySelector('video');
        if (videoElement && !isSticker) {
            // Only add click handler for regular videos, not stickers
            videoElement.addEventListener('click', () => {
                openVideoViewer(mediaUrl, shouldLoop);
            });
        }
    };
    tempVideo.onerror = () => {
        element.innerHTML = '<div class="media-placeholder"><i class="fas fa-exclamation-triangle fa-2x"></i><span>Failed to load video</span></div>';
        element.classList.remove('loading');
    };
    tempVideo.load();
}

function loadStickerImage(element, mediaUrl) {
    const img = new Image();
    img.onload = () => {
        element.innerHTML = `<img src="${mediaUrl}" alt="Sticker" style="max-width: 200px; max-height: 200px; border: none; background: transparent;">`;
        element.classList.remove('loading');
    };
    img.onerror = () => {
        element.innerHTML = '<div class="media-placeholder"><i class="fas fa-exclamation-triangle fa-2x"></i><span>Failed to load sticker</span></div>';
        element.classList.remove('loading');
    };
    img.src = mediaUrl;
}

export {
    loadLazyMedia,
    loadSingleImage,
    loadLazyImage,
    loadFullCarouselImage,
    loadFullSingleImage,
    loadCarouselVideo,
    loadCarouselImage,
    loadThumbImageWithFallback,
    loadThumbImage,
    loadFullResolutionImage,
    loadLazyVideo,
    loadVideoDirectly,
    loadStickerImage
};