// message-utils/modals.js
import { socket, state } from '../core/setup.js';
import { showError, escapeHtml } from '../core/ui-utils.js';
import thumbnailLoader from '../thumbnailLoader.js';
import { openImageViewer, openVideoViewer } from '../viewers.js';

export function buildMetadataHtml(metadata, messageId = null) {
    console.log('buildMetadataHtml called with metadata:', metadata, 'messageId:', messageId);
    if (!metadata || typeof metadata !== 'object' || Object.keys(metadata).length === 0) {
        console.log('buildMetadataHtml returning empty');
        return '';
    }

    let html = '<div class="generation-metadata-details">';

    // Define the order and labels for metadata - more concise
    const metadataOrder = [
        { key: 'model', label: 'Model' },
        { key: 'seed', label: 'Seed' },
        { key: 'steps', label: 'Steps' },
        { key: 'sampler', label: 'Sampler' },
        { key: 'scheduler', label: 'Scheduler' },
        { key: 'cfg_scale', label: 'CFG' },
        { key: 'width', label: 'W' },
        { key: 'height', label: 'H' }
    ];

    metadataOrder.forEach(({ key, label }) => {
        if (metadata[key] !== undefined && metadata[key] !== null) {
            html += `<div class="metadata-row"><span class="metadata-label">${escapeHtml(label)}:</span> <span class="metadata-value">${escapeHtml(String(metadata[key]))}</span></div>`;
        }
    });

    // Display prompts separately if they exist
    if (metadata.prompt) {
        html += `<div class="metadata-row metadata-prompt"><span class="metadata-label">Prompt:</span> <span class="metadata-value">${escapeHtml(metadata.prompt.length > 60 ? metadata.prompt.substring(0, 60) + '...' : metadata.prompt)}</span></div>`;
    }
    if (metadata.negative_prompt) {
        html += `<div class="metadata-row metadata-negative"><span class="metadata-label">Negative:</span> <span class="metadata-value">${escapeHtml(metadata.negative_prompt.length > 40 ? metadata.negative_prompt.substring(0, 40) + '...' : metadata.negative_prompt)}</span></div>`;
    }

    // Add action buttons if messageId is provided
    if (messageId) {
        const metadataJson = JSON.stringify(metadata);
        // Use Unicode-safe base64 encoding to handle emojis and non-Latin characters
        const metadataB64 = btoa(unescape(encodeURIComponent(metadataJson)));
        html += `<div class="metadata-actions">
            <button class="metadata-action-btn generate-more-btn" data-message-id="${messageId}" data-metadata="${metadataB64}">Generate More!</button>
            <button class="metadata-action-btn img2img-more-btn" data-message-id="${messageId}" data-metadata="${metadataB64}">Img2Img More!</button>
        </div>`;
    }

    html += '</div>'; // Close generation-metadata-details div
    return html;
}

export function createCarousel(attachments, messageId, metadata = {}) {
    if (!attachments || attachments.length === 0) return '';

    let carouselHtml = '<div class="image-carousel-with-metadata" data-message-id="' + messageId + '">';

    // Start the carousel container div
    carouselHtml += '<div class="image-carousel-container">';

    // Build the carousel content
    carouselHtml += '<div class="image-carousel" data-message-id="' + messageId + '">';

    // Main image display
    carouselHtml += '<div class="carousel-main-image" style="position: relative;">';
    carouselHtml += '<div class="carousel-main-' + messageId + '" style="width: 100%; height: 300px; display: flex; align-items: center; justify-content: center;">';
    carouselHtml += '<div class="media-placeholder"><i class="fas fa-image fa-3x"></i><span>Loading carousel image...</span></div>';
    carouselHtml += '</div>';
    carouselHtml += '<button class="carousel-prev-btn" style="position: absolute; top: 50%; left: 10px; transform: translateY(-50%); background: rgba(0, 0, 0, 0.7); color: white; border: none; border-radius: 50%; width: 32px; height: 32px; cursor: pointer; opacity: 0; transition: opacity 0.2s; z-index: 10;" title="Previous image"><i class="fas fa-chevron-left"></i></button>';
    carouselHtml += '<button class="carousel-next-btn" style="position: absolute; top: 50%; right: 10px; transform: translateY(-50%); background: rgba(0, 0, 0, 0.7); color: white; border: none; border-radius: 50%; width: 32px; height: 32px; cursor: pointer; opacity: 0; transition: opacity 0.2s; z-index: 10;" title="Next image"><i class="fas fa-chevron-right"></i></button>';
    carouselHtml += '<button class="send-to-img2img-btn" style="position: absolute; bottom: 10px; right: 10px; background: rgba(0, 0, 0, 0.7); color: white; border: none; border-radius: 4px; padding: 4px 8px; font-size: 12px; cursor: pointer; opacity: 0; transition: opacity 0.2s; z-index: 10;" title="Send to img2img">→ img2img</button>';
    carouselHtml += '</div>';

    // Thumbnail strip
    carouselHtml += '<div class="carousel-thumbnails">';
    attachments.forEach((att, index) => {
        // Use server-provided thumbnail URL if available, otherwise construct it
        let thumbnailUrl = att.thumbnail_url;
        if (!thumbnailUrl && att.url) {
            // Construct thumbnail URL: replace /static/{dir}/ with /static/thumbnails/{dir}/ and add _thumb.jpg
            const urlParts = att.url.split('/');
            const storageDir = urlParts[2] || 'uploads';
            const filename = urlParts[urlParts.length - 1];
            const baseName = filename.replace(/\.[^.]+$/, '');
            thumbnailUrl = `/static/thumbnails/${storageDir}/${baseName}_thumb.jpg`;
            if (thumbnailUrl && !thumbnailUrl.includes('/uploads/') && att.url.includes('/Uploads/')) {
                thumbnailUrl = thumbnailUrl.replace('/static/thumbnails/', '/static/thumbnails/uploads/');
            }
        }


        // Handle both old and new thumbnail URL formats for backward compatibility
        if (thumbnailUrl && !thumbnailUrl.includes('/uploads/') && att.url && att.url.includes('/uploads/')) {
            // Old format: add /uploads/ to match the full image path
            thumbnailUrl = thumbnailUrl.replace('/static/thumbnails/', '/static/thumbnails/uploads/');
        }
        // Final fallback to full image if thumbnail URL construction failed
        if (!thumbnailUrl) {
            thumbnailUrl = att.url;
        }
        carouselHtml += `<div class="carousel-thumb" data-index="${index}" data-full-url="${escapeHtml(att.url)}" data-thumb-url="${escapeHtml(thumbnailUrl)}">`;
        carouselHtml += '<div class="thumb-placeholder loading">';
        carouselHtml += '<i class="fas fa-image"></i>';
        carouselHtml += '</div>';
        carouselHtml += '</div>';
    });
    carouselHtml += '</div>';

    carouselHtml += '</div>'; // Close image-carousel div
    carouselHtml += '</div>'; // Close image-carousel-container div

    // Add metadata section if any attachment has metadata
    const firstImageWithMetadata = attachments.find(att => att.metadata && Object.keys(att.metadata).length > 0);
    if (firstImageWithMetadata && firstImageWithMetadata.metadata) {
        carouselHtml += buildMetadataHtml(firstImageWithMetadata.metadata, messageId);
    }

    carouselHtml += '</div>'; // Close image-carousel-with-metadata div

    // Add carousel functionality after the HTML is inserted
    const initCarousel = () => {
        const mainElement = document.querySelector(`.carousel-main-${messageId}`);
        if (mainElement) {
            setupCarousel(messageId, attachments);
        } else {
            // Retry after a short delay
            setTimeout(initCarousel, 50);
        }
    };
    setTimeout(initCarousel, 10);

    return carouselHtml;
}

export function setupCarousel(messageId, attachments) {
    const mainElement = document.querySelector(`.carousel-main-${messageId}`);
    if (!mainElement) {
        console.warn(`setupCarousel: Main element not found for messageId ${messageId}`);
        return;
    }

    const carouselContainer = mainElement.closest('.image-carousel');
    if (!carouselContainer) {
        console.warn(`setupCarousel: Carousel container not found for messageId ${messageId}`);
        return;
    }

    const mainImageContainer = mainElement;
    const thumbnails = carouselContainer.querySelectorAll('.carousel-thumb');
    const sendToImg2ImgBtn = mainElement.parentElement.querySelector('.send-to-img2img-btn');
    const prevBtn = mainElement.parentElement.querySelector('.carousel-prev-btn');
    const nextBtn = mainElement.parentElement.querySelector('.carousel-next-btn');

    if (!mainImageContainer || thumbnails.length === 0) return;

    // Create isolated state for this carousel
    let currentImageIndex = parseInt(mainElement.dataset.index) || 0;

    // Function to update button visibility and current image
    const updateSendToImg2ImgBtn = () => {
        const currentImageUrl = attachments[currentImageIndex]?.url;
        if (currentImageUrl && sendToImg2ImgBtn) {
            sendToImg2ImgBtn.onclick = () => {
                if (typeof sendImageToImg2Img === 'function') {
                    sendImageToImg2Img(currentImageUrl);
                }
            };
        }
    };



    // Function to update carousel metadata display
    const updateCarouselMetadata = (index) => {
        const metadataContainer = mainElement.closest('.image-carousel-with-metadata')?.querySelector('.generation-metadata-details');
        if (!metadataContainer) {
            return;
        }

        const currentAttachment = attachments[index];
        if (!currentAttachment || !currentAttachment.metadata) {
            return;
        }

        const metadata = currentAttachment.metadata;
        const baseSeed = attachments[0]?.metadata?.seed;

        const metadataRows = metadataContainer.querySelectorAll('.metadata-row');
        metadataRows.forEach(row => {
            const labelSpan = row.querySelector('.metadata-label');
            const valueSpan = row.querySelector('.metadata-value');
            if (!labelSpan || !valueSpan) return;

            const labelText = labelSpan.textContent.trim();

            if (labelText === 'Seed:' && baseSeed !== undefined && baseSeed !== null) {
                valueSpan.textContent = String(baseSeed + index);
            } else if (labelText === 'Model:' && metadata.model !== undefined) {
                valueSpan.textContent = String(metadata.model);
            } else if (labelText === 'Steps:' && metadata.steps !== undefined) {
                valueSpan.textContent = String(metadata.steps);
            } else if (labelText === 'Sampler:' && metadata.sampler !== undefined) {
                valueSpan.textContent = String(metadata.sampler);
            } else if (labelText === 'CFG:' && metadata.cfg_scale !== undefined) {
                valueSpan.textContent = String(metadata.cfg_scale);
            } else if (labelText === 'W:' && metadata.width !== undefined) {
                valueSpan.textContent = String(metadata.width);
            } else if (labelText === 'H:' && metadata.height !== undefined) {
                valueSpan.textContent = String(metadata.height);
            }
        });
    };

    // Function to update the main image for THIS carousel only
    const updateMainImage = (index) => {
        currentImageIndex = index;
        const image = attachments[index];

        // Load main image with unique messageId
        thumbnailLoader.loadCarouselMainImage(
            mainImageContainer,
            image.url,
            image.thumbnail_url,
            {
                maxWidth: '100%',
                maxHeight: 300,
                messageId: messageId,
                onClick: () => {
                    const allImageUrls = attachments
                        .filter(att => {
                            const url = typeof att === 'string' ? att : att.url;
                            const ext = url.split('.').pop().toLowerCase();
                            return ['png', 'webp', 'jpg', 'jpeg', 'gif', 'jfif'].includes(ext);
                        })
                        .map(att => typeof att === 'string' ? att : att.url);

                    openImageViewer(allImageUrls, currentImageIndex);
                }
            }
        );

        thumbnails.forEach((thumb, idx) => {
            thumb.classList.toggle('active', idx === index);
        });

        updateCarouselMetadata(index);

        updateSendToImg2ImgBtn();
    };

    // Load first image by default
    if (attachments.length > 0) {
        updateMainImage(0);
    }

    // Setup send to img2img button
    if (sendToImg2ImgBtn) {
        // Show/hide button on hover
        const carouselMainImage = mainElement.parentElement;
        carouselMainImage.addEventListener('mouseenter', () => {
            sendToImg2ImgBtn.style.opacity = '1';
        });
        carouselMainImage.addEventListener('mouseleave', () => {
            sendToImg2ImgBtn.style.opacity = '0';
        });

        updateSendToImg2ImgBtn();
    }

    // Setup thumbnail click handlers
    thumbnails.forEach((thumb, index) => {
        const thumbPlaceholder = thumb.querySelector('.thumb-placeholder');
        const att = attachments[index];
        if (!att) return; // Skip if no attachment

        // Load thumbnail with unique messageId to prevent conflicts
        thumbnailLoader.loadCarouselThumbnail(
            thumbPlaceholder,
            att.url,
            att.thumbnail_url,
            index,
            {
                size: 60,
                messageId: messageId, // Pass messageId for unique loading keys
                onClick: () => {
                    // Update THIS carousel only
                    updateMainImage(index);
                }
            }
        );
    });

    // Setup arrow navigation buttons
    if (prevBtn) {
        prevBtn.onclick = (e) => {
            e.stopPropagation();
            const newIndex = (currentImageIndex - 1 + attachments.length) % attachments.length;
            updateMainImage(newIndex);
        };
    }

    if (nextBtn) {
        nextBtn.onclick = (e) => {
            e.stopPropagation();
            const newIndex = (currentImageIndex + 1) % attachments.length;
            updateMainImage(newIndex);
        };
    }
}

export function initCarousel(id, attachments) {
    const container = document.getElementById(id);
    if (!container) return;
    attachments = attachments.filter(att => {
        if (typeof att === 'string' && att.trim()) {
            return true;
        } else if (typeof att === 'object' && att !== null && att.url && typeof att.url === 'string') {
            return true;
        }
        console.warn('Skipping invalid carousel attachment:', att);
        return false;
    });
    if (attachments.length === 0) {
        container.innerHTML = '<div class="media-placeholder"><i class="fas fa-exclamation-triangle fa-2x"></i><span>No valid attachments</span></div>';
        return;
    }
    const main = container.querySelector('.carousel-main');
    const thumbs = container.querySelector('.carousel-thumbs');
    const prevBtn = container.querySelector('.carousel-prev');
    const nextBtn = container.querySelector('.carousel-next');
    const slideshowBtn = container.querySelector('.carousel-slideshow');
    let currentIndex = 0;
    let slideshowInterval = null;

    function renderAttachment(index) {
        const att = attachments[index];
        const url = typeof att === 'string' ? att : att.url;
        if (!url) {
            main.innerHTML = '<div class="media-placeholder"><i class="fas fa-exclamation-triangle fa-2x"></i><span>Invalid attachment</span></div>';
            return;
        }
        const cleanAtt = url.replace(/[\n\r]/g, '');
        const ext = cleanAtt.split('.').pop().toLowerCase();
        let content = '';
        const imageExtensions = ['png', 'webp', 'jpg', 'jpeg', 'gif', 'jfif'];
        const videoExtensions = ['mp4', 'webm', 'avi', 'mov'];
        if (imageExtensions.includes(ext)) {
            const pathParts = cleanAtt.split('/');
            const storageDir = pathParts[2];
            let thumbnailUrl = (typeof att === 'object' && att.thumbnail_url) ?
                att.thumbnail_url :
                cleanAtt.replace(`/static/${storageDir}/`, `/static/thumbnails/${storageDir}/`).replace(/\.[^.]+$/, '_thumb.jpg');

            // Handle both old and new thumbnail URL formats for backward compatibility
            if (thumbnailUrl && !thumbnailUrl.includes('/uploads/') && cleanAtt.includes('/uploads/')) {
                // Old format: add /uploads/ to match the full image path
                thumbnailUrl = thumbnailUrl.replace('/static/thumbnails/', '/static/thumbnails/uploads/');
            }
            content = `
                <div class="carousel-main-image" data-full-url="${escapeHtml(cleanAtt)}" data-thumbnail-url="${escapeHtml(thumbnailUrl)}" data-index="${index}">
                    <div class="media-placeholder">
                        <i class="fas fa-image fa-3x"></i>
                        <span>Loading thumbnail...</span>
                    </div>
                </div>`;
                // Load thumbnail immediately
                setTimeout(() => {
                    const mainImageElement = main.querySelector('.carousel-main-image');
                    if (mainImageElement) {
                        thumbnailLoader.loadCarouselMainImage(mainImageElement, cleanAtt, thumbnailUrl, {
                            onClick: () => {
                                // Get all image URLs from attachments for the viewer
                                const allImageUrls = attachments
                                    .filter(att => {
                                        const url = typeof att === 'string' ? att : att.url;
                                        const ext = url.split('.').pop().toLowerCase();
                                        return ['png', 'webp', 'jpg', 'jpeg', 'gif', 'jfif'].includes(ext);
                                    })
                                    .map(att => typeof att === 'string' ? att : att.url);

                                openImageViewer(allImageUrls, index);
                            }
                        });
                    }
                }, 10);
        } else if (videoExtensions.includes(ext)) {
            const lazyUrl = cleanAtt.replace('/static/', '/lazy-file/');
            const size = (typeof att === 'object' && att.size) ? att.size : 0;

            // Auto-load all videos regardless of size
            content = `
                <div class="carousel-main-video" data-media-url="${escapeHtml(lazyUrl)}" data-media-type="video" data-video-ext="${ext}" data-size="${size}">
                    <div class="media-placeholder">
                        <i class="fas fa-video fa-3x"></i>
                        <span>Loading video...</span>
                    </div>
                </div>`;
            // Load video immediately
            setTimeout(() => {
                const mainVideoElement = main.querySelector('.carousel-main-video');
                if (mainVideoElement) {
                    loadCarouselVideo(mainVideoElement, lazyUrl, ext, index, attachments);
                }
            }, 10);
        } else {
            const icon = getDocIcon(ext);
            const fileName = cleanAtt.split('/').pop();
            content = `
                <div class="carousel-main-file">
                    <i class="fas ${icon} fa-3x"></i>
                    <a href="${escapeHtml(cleanAtt)}" target="_blank" class="file-link">${escapeHtml(fileName)}</a>
                </div>`;
        }
        main.innerHTML = content;
    }

    function renderThumbs() {
        thumbs.innerHTML = '';
        attachments.forEach((att, idx) => {
            const url = typeof att === 'string' ? att : att.url;
            if (!url) return;
            const cleanAtt = url.replace(/[\n\r]/g, '');
            const ext = cleanAtt.split('.').pop().toLowerCase();
            let thumb = '';
            if (['png', 'webp', 'jpg', 'jpeg', 'gif', 'jfif'].includes(ext)) {
                const pathParts = cleanAtt.split('/');
                const storageDir = pathParts[2] || 'uploads';
                let thumbnailUrl = (typeof att === 'object' && att.thumbnail_url) ?
                    att.thumbnail_url :
                    cleanAtt.replace(`/static/${storageDir}/`, `/static/thumbnails/${storageDir}/`).replace(/\.[^.]+$/, '_thumb.jpg');

                // Handle both old and new thumbnail URL formats for backward compatibility
                if (thumbnailUrl && !thumbnailUrl.includes('/uploads/') && cleanAtt.includes('/uploads/')) {
                    // Old format: add /uploads/ to match the full image path
                    thumbnailUrl = thumbnailUrl.replace('/static/thumbnails/', '/static/thumbnails/uploads/');
                }
                thumb = `<div class="carousel-thumb-image" data-full-url="${escapeHtml(cleanAtt)}" data-thumbnail-url="${escapeHtml(thumbnailUrl)}" data-index="${idx}">
                    <div class="media-placeholder">
                        <i class="fas fa-image fa-2x"></i>
                        <span>Loading...</span>
                    </div>
                </div>`;
                setTimeout(() => {
                    const thumbElement = thumbs.querySelectorAll('.carousel-thumb-image')[idx];
                    if (thumbElement) {
                        thumbnailLoader.loadCarouselThumbnail(thumbElement, cleanAtt, thumbnailUrl, idx, {
                            messageId: id // Pass id for unique loading keys
                        });
                    }
                }, 10 + (idx * 20));
            } else if (['mp4', 'webm', 'avi', 'mov'].includes(ext)) {
                thumb = `<div class="carousel-thumb-video" data-index="${idx}"><i class="fas fa-video"></i></div>`;
            } else {
                thumb = `<div class="carousel-thumb-file" data-index="${idx}"><i class="fas ${getDocIcon(ext)}"></i></div>`;
            }
            const thumbDiv = document.createElement('div');
            thumbDiv.className = 'carousel-thumb' + (idx === currentIndex ? ' active' : '');
            thumbDiv.innerHTML = thumb;
            thumbDiv.onclick = () => {
                // For all carousels, navigate within the carousel consistently
                // This provides uniform behavior regardless of media type
                showIndex(idx);
            };
            thumbs.appendChild(thumbDiv);
        });
    }

    function showIndex(index) {
        currentIndex = (index + attachments.length) % attachments.length;
        renderAttachment(currentIndex);
        renderThumbs();
    }

    function toggleSlideshow() {
        if (slideshowInterval) {
            clearInterval(slideshowInterval);
            slideshowInterval = null;
            slideshowBtn.textContent = '▶️';
        } else {
            slideshowInterval = setInterval(() => showIndex(currentIndex + 1), 3000);
            slideshowBtn.textContent = '⏸️';
        }
    }

    prevBtn.onclick = () => showIndex(currentIndex - 1);
    nextBtn.onclick = () => showIndex(currentIndex + 1);
    slideshowBtn.onclick = toggleSlideshow;
    renderThumbs();
    showIndex(0);
}

// Helper function for loadCarouselVideo - this should be in media-loader.js but is used here
function loadCarouselVideo(element, mediaUrl, videoExt, index, attachments) {

    const tempVideo = document.createElement('video');
    tempVideo.src = mediaUrl;
    tempVideo.onloadedmetadata = () => {
        const shouldLoop = tempVideo.duration < 60;
        tempVideo.remove();

        element.innerHTML = `
            <video controls autoplay muted ${shouldLoop ? 'loop' : ''} style="max-width: 300px; max-height: 200px; border-radius: 8px; cursor: pointer;" data-index="${index}">
                <source src="${mediaUrl}" type="video/${videoExt === 'mov' ? 'quicktime' : videoExt}">
                Your browser does not support the video tag.
            </video>`;
        element.classList.remove('loading');

        const videoElement = element.querySelector('video');
        if (videoElement) {
            videoElement.addEventListener('click', () => {
                // Get all video URLs from attachments for the viewer
                const allVideoUrls = attachments
                    .filter(att => {
                        const url = typeof att === 'string' ? att : att.url;
                        const ext = url.split('.').pop().toLowerCase();
                        return ['mp4', 'webm', 'avi', 'mov'].includes(ext);
                    })
                    .map(att => typeof att === 'string' ? att : att.url);

                openVideoViewer(allVideoUrls, index);
            });
        }
    };
    tempVideo.onerror = () => {
        element.innerHTML = '<div class="media-placeholder"><i class="fas fa-exclamation-triangle fa-2x"></i><span>Failed to load video</span></div>';
        element.classList.remove('loading');
    };
    tempVideo.load();
}

// Import getDocIcon from utils
import { getDocIcon } from './utils.js';