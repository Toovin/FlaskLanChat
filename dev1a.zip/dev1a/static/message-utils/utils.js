// message-utils/utils.js
import { escapeHtml } from '../core/ui-utils.js';

// Function to decode HTML entities
export function decodeHtmlEntities(text) {
    const textarea = document.createElement('textarea');
    textarea.innerHTML = text;
    return textarea.value;
}

// Function to convert URLs in text to clickable links
export function linkifyText(text) {
    if (!text) return text;

    // URL regex pattern - matches http://, https://, and www. URLs
    const urlRegex = /(\b(https?:\/\/|www\.)[^\s<>"{}|\\^`[\]]+)/gi;

    // First escape HTML to prevent XSS
    const escaped = escapeHtml(text);

    // Then replace URLs with links
    return escaped.replace(urlRegex, (match) => {
        let url = match;

        // Add protocol if missing (for www. links)
        if (url.startsWith('www.')) {
            url = 'https://' + url;
        }

        // Return clickable link that opens in new tab
        return `<a href="${url}" target="_blank" rel="noopener noreferrer" class="message-link">${match}</a>`;
    });
}

// Get document icon based on file extension
export function getDocIcon(ext) {
    const iconMap = {
        'pdf': 'fa-file-pdf',
        'doc': 'fa-file-word',
        'docx': 'fa-file-word',
        'xls': 'fa-file-excel',
        'xlsx': 'fa-file-excel',
        'ppt': 'fa-file-powerpoint',
        'pptx': 'fa-file-powerpoint',
        'txt': 'fa-file-alt',
        'zip': 'fa-file-archive',
        'rar': 'fa-file-archive',
        '7z': 'fa-file-archive',
        'tar': 'fa-file-archive',
        'gz': 'fa-file-archive',
        'mp3': 'fa-file-audio',
        'wav': 'fa-file-audio',
        'flac': 'fa-file-audio',
        'mp4': 'fa-file-video',
        'avi': 'fa-file-video',
        'mov': 'fa-file-video',
        'webm': 'fa-file-video'
    };
    return iconMap[ext] || 'fa-file';
}

// Global variables that were in messageUtils.js
export let scrollTimeout;
export let modalData = null;