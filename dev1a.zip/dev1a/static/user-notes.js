// User Notes Feature - Separate Module
import { socket, state } from './core/setup.js';
import { showError, escapeHtml } from './core/ui-utils.js';
import { showToast } from './socket-events/main.js';

let currentNotes = [];
let currentNoteId = null;

// Utility functions
function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}



export function createNewNote() {
    const newNote = {
        uuid: generateUUID(),
        title: 'New Note',
        content: '',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
    };

    // Add to current notes optimistically
    currentNotes.push(newNote);

    // Emit to server
    socket.emit('create_user_note', {
        user_uuid: state.currentUsername,
        note_uuid: newNote.uuid,
        title: newNote.title,
        content: newNote.content
    });

    // Update UI
    renderNotesList();
    selectNote(newNote.uuid);
}

export function openUserNotesModal() {
    const modal = document.getElementById('user-notes-modal');
    if (!modal) return;

    // Load user notes
    loadUserNotes();

    // Show modal
    modal.style.display = 'flex';
}

export function closeUserNotesModal() {
    const modal = document.getElementById('user-notes-modal');
    if (modal) {
        modal.style.display = 'none';
    }
    // Reset state
    currentNotes = [];
    currentNoteId = null;
}

function loadUserNotes() {
    // Emit request to get user notes
    socket.emit('get_user_notes', { user_uuid: state.currentUsername });
}

function renderNotesList() {
    const notesList = document.getElementById('notes-list');
    if (!notesList) return;

    notesList.innerHTML = '';

    if (currentNotes.length === 0) {
        notesList.innerHTML = '<div style="text-align: center; color: var(--text-muted); padding: 20px; font-style: italic;">No notes yet. Create your first note!</div>';
        return;
    }

    currentNotes.forEach(note => {
        const noteItem = document.createElement('div');
        noteItem.className = 'note-item';
        noteItem.setAttribute('data-note-id', note.uuid);

        const title = note.title || 'Untitled Note';
        const content = note.content || '';
        const preview = content ? content.substring(0, 50) + (content.length > 50 ? '...' : '') : 'No content';

        noteItem.innerHTML = `
            <div class="note-title">${escapeHtml(title)}</div>
            <div class="note-preview">${escapeHtml(preview)}</div>
            <div class="note-date">${formatNoteDate(note.updated_at)}</div>
            <div class="note-actions">
                <button class="note-action-btn" onclick="renameNote('${note.uuid}')" title="Rename">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="note-action-btn delete" onclick="deleteNote('${note.uuid}')" title="Delete">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;

        noteItem.addEventListener('click', (e) => {
            // Don't trigger if clicking on action buttons
            if (e.target.closest('.note-actions')) return;
            selectNote(note.uuid);
        });

        notesList.appendChild(noteItem);
    });
}

function selectNote(noteId) {
    currentNoteId = noteId;
    const note = currentNotes.find(n => n.uuid === noteId);
    if (!note) return;

    // Update selected state in list
    document.querySelectorAll('.note-item').forEach(item => {
        item.classList.remove('selected');
    });
    document.querySelector(`[data-note-id="${noteId}"]`).classList.add('selected');

    // Show editor
    const editor = document.getElementById('note-editor');
    const placeholder = document.getElementById('notes-placeholder');

    editor.style.display = 'flex';
    placeholder.style.display = 'none';

    // Populate editor
    document.getElementById('note-title-input').value = note.title || 'Untitled Note';
    document.getElementById('note-content-textarea').value = note.content || '';
    document.getElementById('note-created-date').textContent = `Created: ${formatNoteDate(note.created_at)}`;
    document.getElementById('note-updated-date').textContent = `Updated: ${formatNoteDate(note.updated_at)}`;
}

function showNotesPlaceholder() {
    const editor = document.getElementById('note-editor');
    const placeholder = document.getElementById('notes-placeholder');

    editor.style.display = 'none';
    placeholder.style.display = 'flex';

    // Clear selection
    document.querySelectorAll('.note-item').forEach(item => {
        item.classList.remove('selected');
    });
    currentNoteId = null;
}



export function saveCurrentNote() {
    if (!currentNoteId) return;

    const title = document.getElementById('note-title-input').value.trim();
    const content = document.getElementById('note-content-textarea').value;

    if (!title) {
        showError('Note title cannot be empty');
        return;
    }

    const note = currentNotes.find(n => n.uuid === currentNoteId);
    if (!note) {
        console.error('Note not found in currentNotes:', currentNoteId);
        return;
    }

    // Update note locally
    note.title = title;
    note.content = content;
    note.updated_at = new Date().toISOString();

    // Emit to server
    socket.emit('update_user_note', {
        user_uuid: state.currentUsername,
        note_uuid: currentNoteId,
        title: title,
        content: content
    });

    // Update UI immediately
    renderNotesList();
    selectNote(currentNoteId);

    showToast('Note saved successfully', 'success');
}

function deleteNote(noteId) {
    if (!confirm('Are you sure you want to delete this note?')) return;

    // Remove from current notes
    currentNotes = currentNotes.filter(n => n.uuid !== noteId);

    // Emit to server
    socket.emit('delete_user_note', {
        user_uuid: state.currentUsername,
        note_uuid: noteId
    });

    // Update UI
    renderNotesList();
    showNotesPlaceholder();

    showToast('Note deleted', 'info');
}

function renameNote(noteId) {
    const note = currentNotes.find(n => n.uuid === noteId);
    if (!note) return;

    const newTitle = prompt('Enter new title:', note.title);
    if (!newTitle || newTitle.trim() === '') return;

    note.title = newTitle.trim();
    note.updated_at = new Date().toISOString();

    // Emit to server
    socket.emit('rename_user_note', {
        user_uuid: state.currentUsername,
        note_uuid: noteId,
        new_title: note.title
    });

    // Update UI
    renderNotesList();
    if (currentNoteId === noteId) {
        selectNote(noteId);
    }
}

function formatNoteDate(dateString) {
    if (!dateString) return 'Unknown';

    const date = new Date(dateString);

    // Check if date is valid
    if (isNaN(date.getTime())) {
        return 'Invalid Date';
    }

    const now = new Date();
    const diffMs = now - date;
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffDays === 0) {
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diffDays === 1) {
        return 'Yesterday';
    } else if (diffDays < 7) {
        return date.toLocaleDateString([], { weekday: 'short' });
    } else {
        return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
}

// Function to set up event listeners for user profile modal notes buttons
function setupUserProfileNotesButtons() {
    // Find all user profile modals that might be open
    const profileModals = document.querySelectorAll('#user-profile-modal');
    profileModals.forEach(modal => {
        const notesBtn = modal.querySelector('#message-user-btn');
        if (notesBtn && notesBtn.textContent.includes('Notes')) {
            // Remove existing listeners to avoid duplicates
            const newBtn = notesBtn.cloneNode(true);
            notesBtn.parentNode.replaceChild(newBtn, notesBtn);

            // Add the proper listener
            newBtn.addEventListener('click', () => {
                const modal = newBtn.closest('#user-profile-modal');
                if (modal) {
                    modal.style.display = 'none';
                }
                openUserNotesModal();
            });
        }
    });
}

// Socket event handlers for notes
socket.on('user_notes_loaded', function(data) {
    currentNotes = (data.notes || []).map(note => ({
        uuid: note.uuid,
        title: note.title || 'Untitled Note',
        content: note.content || '',
        created_at: note.created_at || new Date().toISOString(),
        updated_at: note.updated_at || new Date().toISOString()
    }));
    renderNotesList();
    showNotesPlaceholder();

    // Set up any pending event listeners now that we're loaded
    setupUserProfileNotesButtons();
});

socket.on('note_created', function(data) {
    // Update the note that was optimistically added
    const existingNoteIndex = currentNotes.findIndex(n => n.uuid === data.note_uuid);
    if (existingNoteIndex !== -1) {
        // Update with server data
        currentNotes[existingNoteIndex] = {
            uuid: data.note_uuid,
            title: data.title || 'Untitled Note',
            content: data.content || '',
            created_at: data.created_at || new Date().toISOString(),
            updated_at: data.updated_at || new Date().toISOString()
        };
    } else {
        // Fallback: add new note if not found
        const newNote = {
            uuid: data.note_uuid,
            title: data.title || 'Untitled Note',
            content: data.content || '',
            created_at: data.created_at || new Date().toISOString(),
            updated_at: data.updated_at || new Date().toISOString()
        };
        currentNotes.unshift(newNote);
    }

    renderNotesList();
    selectNote(data.note_uuid);
});

socket.on('note_updated', function(data) {
    // Update existing note in the list
    const noteIndex = currentNotes.findIndex(n => n.uuid === data.note_uuid);
    if (noteIndex !== -1) {
        currentNotes[noteIndex].title = data.title || 'Untitled Note';
        currentNotes[noteIndex].content = data.content || '';
        currentNotes[noteIndex].updated_at = data.updated_at || new Date().toISOString();

        renderNotesList();
        if (currentNoteId === data.note_uuid) {
            selectNote(data.note_uuid);
        }
    }
});

socket.on('note_deleted', function(data) {
    // Remove note from the list
    currentNotes = currentNotes.filter(n => n.uuid !== data.note_uuid);

    renderNotesList();
    showNotesPlaceholder();
});

socket.on('note_renamed', function(data) {
    // Update note title in the list
    const noteIndex = currentNotes.findIndex(n => n.uuid === data.note_uuid);
    if (noteIndex !== -1) {
        currentNotes[noteIndex].title = data.new_title;
        currentNotes[noteIndex].updated_at = data.updated_at;

        renderNotesList();
        if (currentNoteId === data.note_uuid) {
            selectNote(data.note_uuid);
        }
    }
});

// Set up event listeners immediately when this script loads
setupUserProfileNotesButtons();

// Make functions globally available for HTML onclick
window.createNewNote = createNewNote;
window.closeUserNotesModal = closeUserNotesModal;
window.openUserNotesModal = openUserNotesModal;
window.deleteNote = deleteNote;
window.renameNote = renameNote;
window.saveCurrentNote = saveCurrentNote;
window.deleteCurrentNote = () => deleteNote(currentNoteId);