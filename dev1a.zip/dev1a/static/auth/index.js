// Authentication system orchestrator

import { socket, state } from '../core/setup.js';
import { initializeLoginForm, initializeCreateAccountButton } from './login-form.js';

// Initialize authentication system
export function initAuth() {
    console.log('Initializing authentication system...');

    // Initialize connection handling
    initializeLogin();

    // Initialize form handlers
    initializeLoginForm();
    initializeCreateAccountButton();

    console.log('Authentication system initialized');
}

// Connection handling (extracted from original login.js)
function initializeLogin() {
    const { loginModal, appContainer, loadingSpinner } = getElements();

    if (appContainer) {
        appContainer.classList.add('hidden');
    }

    if (state.socketConnected) {
        showLoginForm();
    } else {
        showLoadingState();
        setupSocketListeners();
    }
}

function getElements() {
    return {
        loginModal: document.getElementById('login-modal'),
        appContainer: document.getElementById('app-container'),
        loadingSpinner: document.getElementById('loading-spinner')
    };
}

function showLoginForm() {
    const loadingSpinner = document.getElementById('loading-spinner');
    if (loadingSpinner) {
        loadingSpinner.style.display = 'none';
    }
    const loginModal = document.getElementById('login-modal');
    if (loginModal) {
        loginModal.classList.add('active');
    }
}

function showLoadingState() {
    const loadingSpinner = document.getElementById('loading-spinner');
    if (loadingSpinner) {
        loadingSpinner.style.display = 'block';
        loadingSpinner.textContent = 'Connecting...';
    }
}

function setupSocketListeners() {
    const handleConnected = () => {
        window.removeEventListener('socketConnected', handleConnected);
        window.removeEventListener('socketConnectionError', handleSocketError);
        showLoginForm();
    };

    const handleSocketError = (event) => {
        window.removeEventListener('socketConnected', handleConnected);
        window.removeEventListener('socketConnectionError', handleSocketError);
        showConnectionError(event.detail);
    };

    window.addEventListener('socketConnected', handleConnected);
    window.addEventListener('socketConnectionError', handleSocketError);

    // Timeout
    setTimeout(() => {
        if (!state.socketConnected) {
            window.removeEventListener('socketConnected', handleConnected);
            window.removeEventListener('socketConnectionError', handleSocketError);
            showConnectionError(new Error('Connection timeout'));
        }
    }, 10000);
}

function showConnectionError(error) {
    console.error('Socket connection failed:', error);
    const loadingSpinner = document.getElementById('loading-spinner');
    if (loadingSpinner) {
        loadingSpinner.innerHTML = `
            <div style="text-align: center;">
                <div style="color: #f44336; margin-bottom: 10px;">Connection Failed</div>
                <button onclick="retryConnection()" style="padding: 5px 10px; background: #2196F3; color: white; border: none; border-radius: 3px; cursor: pointer;">Retry Connection</button>
            </div>
        `;
    }

    const errorMsg = error.message || 'Unable to connect to server. Please check your connection and try again.';
    const errorElement = document.getElementById('error-message');
    if (errorElement) {
        errorElement.textContent = errorMsg + ' <button onclick="retryConnection()" style="background: #2196F3; color: white; border: none; padding: 2px 5px; border-radius: 2px; cursor: pointer; margin-left: 5px;">Retry</button>';
        errorElement.style.display = 'block';
        setTimeout(() => {
            errorElement.style.display = 'none';
        }, 5000);
    }
}

// Global retry function
window.retryConnection = function() {
    console.log('Retrying connection...');
    const loadingSpinner = document.getElementById('loading-spinner');
    if (loadingSpinner) {
        loadingSpinner.innerHTML = 'Retrying...';
        loadingSpinner.style.color = '#2196F3';
    }

    if (socket) {
        socket.connect();
    }

    setTimeout(() => {
        initializeLogin();
    }, 1000);
};

// DOM ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAuth);
} else {
    initAuth();
}