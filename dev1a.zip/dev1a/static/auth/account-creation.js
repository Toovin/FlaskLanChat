// Account creation wizard and steps

import { socket, state } from '../core/setup.js';
import { attemptHttpRegistration, showError, checkUsernameAvailabilitySocket } from './auth-utils.js';
import { loadDefaultAvatars, selectAvatar } from './avatar-management.js';

// Modal management
export function openAccountCreationModal() {
    const accountCreationModal = document.getElementById('account-creation-modal');
    if (accountCreationModal) {
        accountCreationModal.classList.add('active');
        loadDefaultAvatars();
    }
}

export function closeAccountCreationModal() {
    const accountCreationModal = document.getElementById('account-creation-modal');
    if (accountCreationModal) {
        accountCreationModal.classList.remove('active');
        resetAccountCreationForm();
    }
}

function resetAccountCreationForm() {
    document.getElementById('create-username-input').value = '';
    document.getElementById('create-password-input').value = '';
    document.getElementById('create-verify-password-input').value = '';
    document.getElementById('display-name-input').value = '';
    document.getElementById('custom-status-input').value = '';
    document.getElementById('custom-avatar-input').value = '';

    // Reset avatar selection
    document.querySelectorAll('.avatar-option.selected').forEach(el => el.classList.remove('selected'));
    document.querySelector('.avatar-option[data-avatar="random"]').classList.add('selected');

    // Reset username availability indicator
    const indicator = document.getElementById('username-availability-indicator');
    if (indicator) {
        indicator.textContent = '';
    }

    // Reset to step 1
    document.getElementById('account-step-1').classList.add('active');
    document.getElementById('account-step-2').classList.remove('active');
    document.getElementById('account-step-3').classList.remove('active');

    // Reset title
    const titleElement = document.getElementById('account-modal-title');
    if (titleElement) {
        titleElement.textContent = 'Create Account';
    }
}

// Step navigation
export function nextToCustomization() {
    const username = document.getElementById('create-username-input').value.trim();
    const password = document.getElementById('create-password-input').value.trim();
    const verifyPassword = document.getElementById('create-verify-password-input').value.trim();

    if (!username || username.length < 3) {
        showError('Username must be at least 3 characters.');
        return;
    }

    if (!password || password.length < 6) {
        showError('Password must be at least 6 characters.');
        return;
    }

    if (password !== verifyPassword) {
        showError('Passwords do not match.');
        return;
    }

    // Check if username availability has been confirmed
    const indicator = document.getElementById('username-availability-indicator');
    if (indicator && indicator.textContent.includes('Username is available')) {
        document.getElementById('account-step-1').classList.remove('active');
        document.getElementById('account-step-2').classList.add('active');
    } else {
        showError('Please wait for username availability check or choose a different username.');
        return;
    }
}

export function backToBasicInfo() {
    document.getElementById('account-step-2').classList.remove('active');
    document.getElementById('account-step-1').classList.add('active');
}

export function showAccountCreationSuccess() {
    document.getElementById('account-step-1').classList.remove('active');
    document.getElementById('account-step-2').classList.remove('active');
    document.getElementById('account-step-3').classList.add('active');
    // Change the modal title for success
    const titleElement = document.getElementById('account-modal-title');
    if (titleElement) {
        titleElement.textContent = 'Account Created';
    }
}

export function closeAccountCreationSuccess() {
    closeAccountCreationModal();
}

// Account creation logic
export async function createAccount() {
    const username = document.getElementById('create-username-input').value.trim();
    const password = document.getElementById('create-password-input').value.trim();
    const displayName = document.getElementById('display-name-input').value.trim();
    const customStatus = document.getElementById('custom-status-input').value.trim();

    const selectedAvatar = document.querySelector('.avatar-option.selected');
    let avatarUrl = null;

    if (selectedAvatar) {
        const avatarType = selectedAvatar.dataset.avatar;
        if (avatarType === 'random') {
            // Random default avatar
            const defaultAvatars = ['smile_1.png', 'smile_2.png', 'smile_3.png'];
            const randomAvatar = defaultAvatars[Math.floor(Math.random() * defaultAvatars.length)];
            avatarUrl = `/static/default_avatars/${randomAvatar}`;
        } else if (avatarType === 'custom') {
            // Upload custom avatar
            const customAvatarInput = document.getElementById('custom-avatar-input');
            if (customAvatarInput && customAvatarInput.files[0]) {
                const formData = new FormData();
                formData.append('avatar', customAvatarInput.files[0]);
                try {
                    // Add type and id to formData
                    formData.append('type', 'user');
                    formData.append('id', username);  // Use username as temp id since UUID not known yet

                    const response = await fetch('/upload-avatar', {
                        method: 'POST',
                        body: formData
                    });
                    if (!response.ok) throw new Error('Avatar upload failed');
                    const data = await response.json();
                    if (data.url) {
                        avatarUrl = data.url;
                    } else {
                        showError('Avatar upload failed.');
                        return;
                    }
                } catch (error) {
                    console.error('Avatar upload error:', error);
                    showError('Avatar upload failed.');
                    return;
                }
            }
        } else {
            // Specific default avatar
            avatarUrl = `/static/default_avatars/${avatarType}`;
        }
    }

    window.currentUsername = username;
    const loadingSpinner = document.getElementById('loading-spinner');
    if (loadingSpinner) loadingSpinner.style.display = 'block';

    // Try socket registration first, fallback to HTTP if socket not connected
    if (state.socketConnected) {
        socket.emit('register_user_with_password', {
            username,
            password,
            avatar_url: avatarUrl,
            display_name: displayName || null,
            custom_status: customStatus || null
        });
    } else {
        attemptHttpRegistration(username, password, avatarUrl, displayName, customStatus);
    }
}

// Username availability checking
let usernameCheckTimeout;
const usernameInput = document.getElementById('create-username-input');
const usernameAvailabilityIndicator = document.createElement('div');
usernameAvailabilityIndicator.id = 'username-availability-indicator';
usernameAvailabilityIndicator.style.cssText = `
    position: absolute;
    bottom: -20px;
    left: 0;
    font-size: 12px;
    color: #666;
    transition: color 0.3s ease;
`;

if (usernameInput) {
    usernameInput.parentElement.style.position = 'relative';
    usernameInput.parentElement.appendChild(usernameAvailabilityIndicator);

    usernameInput.addEventListener('input', (e) => {
        const username = e.target.value.trim();
        clearTimeout(usernameCheckTimeout);

        if (username.length < 3) {
            usernameAvailabilityIndicator.textContent = 'Username must be at least 3 characters';
            usernameAvailabilityIndicator.style.color = '#666';
            return;
        }

        usernameCheckTimeout = setTimeout(() => {
            checkUsernameAvailabilitySocket(username);
        }, 500); // Debounce for 500ms
    });
}

// Handle username availability response
socket.on('username_availability_result', (data) => {
    if (data.available) {
        usernameAvailabilityIndicator.textContent = '✓ Username is available';
        usernameAvailabilityIndicator.style.color = '#4CAF50';
    } else {
        usernameAvailabilityIndicator.textContent = '✗ ' + data.message;
        usernameAvailabilityIndicator.style.color = '#f44336';
    }
});

// Event listeners for account creation
document.getElementById('next-to-customization-btn').addEventListener('click', nextToCustomization);
document.getElementById('create-account-btn').addEventListener('click', createAccount);
document.getElementById('success-close-btn').addEventListener('click', closeAccountCreationSuccess);

// Avatar selection
document.addEventListener('click', (e) => {
    if (e.target.closest('.avatar-option')) {
        const avatarOption = e.target.closest('.avatar-option');
        selectAvatar(avatarOption.dataset.avatar);
    }
});

// Make functions globally available for inline onclick handlers
window.closeAccountCreationModal = closeAccountCreationModal;
window.backToBasicInfo = backToBasicInfo;
window.nextToCustomization = nextToCustomization;