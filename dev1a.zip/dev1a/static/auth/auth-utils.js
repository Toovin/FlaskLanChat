// Authentication utilities and HTTP fallbacks
// Handles shared utilities for login and registration

import { socket, state } from '../core/setup.js';

// HTTP fallback login function
export async function attemptHttpLogin(username, password) {
    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (data.success) {
            // HTTP login successful - redirect to refresh and establish socket session
            console.log('HTTP login successful, refreshing page to establish session...');
            showError('Login successful! Refreshing page...');
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        } else {
            showError(data.error || 'Login failed');
            const loadingSpinner = document.getElementById('loading-spinner');
            if (loadingSpinner) loadingSpinner.style.display = 'none';
        }
    } catch (error) {
        console.error('HTTP login error:', error);
        showError('Network error during login. Please try again.');
        const loadingSpinner = document.getElementById('loading-spinner');
        if (loadingSpinner) loadingSpinner.style.display = 'none';
    }
}

// HTTP fallback username availability check
export async function checkUsernameAvailabilityHttp(username) {
    try {
        const response = await fetch(`/api/check-username?username=${encodeURIComponent(username)}`);
        const data = await response.json();

        const indicator = document.getElementById('username-availability-indicator');
        if (!indicator) return;

        if (data.available) {
            indicator.textContent = '✓ Username is available';
            indicator.style.color = '#4CAF50';
        } else {
            indicator.textContent = '✗ ' + (data.message || 'Username is already taken');
            indicator.style.color = '#f44336';
        }
    } catch (error) {
        console.error('HTTP username check error:', error);
        const indicator = document.getElementById('username-availability-indicator');
        if (indicator) {
            indicator.textContent = 'Error checking availability';
            indicator.style.color = '#ff9800';
        }
    }
}

// HTTP fallback registration function
export async function attemptHttpRegistration(username, password, avatarUrl, displayName, customStatus) {
    try {
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username,
                password,
                avatar_url: avatarUrl,
                display_name: displayName,
                custom_status: customStatus
            })
        });

        const data = await response.json();

        if (data.success) {
            // HTTP registration successful - redirect to refresh and establish socket session
            console.log('HTTP registration successful, refreshing page to establish session...');
            showError('Account created successfully! Refreshing page...');
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        } else {
            showError(data.error || 'Registration failed');
            const loadingSpinner = document.getElementById('loading-spinner');
            if (loadingSpinner) loadingSpinner.style.display = 'none';
        }
    } catch (error) {
        console.error('HTTP registration error:', error);
        showError('Network error during registration. Please try again.');
        const loadingSpinner = document.getElementById('loading-spinner');
        if (loadingSpinner) loadingSpinner.style.display = 'none';
    }
}

// Error display function
export function showError(message) {
    const errorElement = document.getElementById('error-message');
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
        // Auto-hide after 5 seconds
        setTimeout(() => {
            errorElement.style.display = 'none';
        }, 5000);
    } else {
        console.error('Error element not found, logging error:', message);
        alert(message); // Fallback
    }
}

// Socket connection status management
export function isSocketConnected() {
    return state.socketConnected;
}

// Username availability checking via socket
export function checkUsernameAvailabilitySocket(username) {
    if (isSocketConnected()) {
        socket.emit('check_username_availability', { username });
    } else {
        checkUsernameAvailabilityHttp(username);
    }
}