// Avatar management utilities

// Load default avatars
export function loadDefaultAvatars() {
    const container = document.getElementById('default-avatars-container');
    if (!container) return;

    // Clear existing
    container.innerHTML = '';

    // Load default avatars from static/default_avatars/
    const defaultAvatars = ['smile_1.png', 'smile_2.png', 'smile_3.png'];

    defaultAvatars.forEach(avatar => {
        const avatarOption = document.createElement('div');
        avatarOption.className = 'avatar-option';
        avatarOption.dataset.avatar = avatar;
        avatarOption.innerHTML = `
            <img src="/static/default_avatars/${avatar}" alt="${avatar}" class="avatar-preview">
            <span>${avatar.replace('.png', '').replace('_', ' ')}</span>
        `;
        avatarOption.addEventListener('click', () => selectAvatar(avatar));
        container.appendChild(avatarOption);
    });
}

// Select avatar
export function selectAvatar(avatar) {
    document.querySelectorAll('.avatar-option').forEach(el => el.classList.remove('selected'));
    document.querySelector(`.avatar-option[data-avatar="${avatar}"]`).classList.add('selected');
}

// Validate avatar upload
export function validateAvatarFile(file) {
    const maxSize = 5 * 1024 * 1024; // 5MB
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];

    if (!allowedTypes.includes(file.type)) {
        throw new Error('Invalid file type. Only JPEG, PNG, and GIF are allowed.');
    }

    if (file.size > maxSize) {
        throw new Error('File too large. Maximum size is 5MB.');
    }

    return true;
}

// Preview custom avatar
export function previewCustomAvatar(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.onerror = () => reject(new Error('Failed to read file'));
        reader.readAsDataURL(file);
    });
}