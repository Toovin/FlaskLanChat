// Login form handling and validation

import { socket, state } from '../core/setup.js';
import { attemptHttpLogin, showError } from './auth-utils.js';

// Handle login form submission
export function initializeLoginForm() {
    const loginForm = document.getElementById('login-form');
    if (!loginForm) return;

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Play click sound
        if (window.soundManager) {
            window.soundManager.playClick();
        }

        const usernameInput = document.getElementById('username-input');
        const passwordInput = document.getElementById('password-input');

        if (!usernameInput || !passwordInput) {
            console.error('Username or password input not found');
            showError('Form setup error. Please refresh.');
            return;
        }

        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();

        if (!username || !password || username.length < 3 || password.length < 6) {
            showError('Username (min 3 chars) and password (min 6 chars) are required.');
            return;
        }

        window.currentUsername = username;
        const loadingSpinner = document.getElementById('loading-spinner');
        if (loadingSpinner) loadingSpinner.style.display = 'block';

        // Try socket login first, fallback to HTTP if socket not connected
        if (state.socketConnected) {
            socket.emit('login_user', { username, password });
        } else {
            attemptHttpLogin(username, password);
        }
    });
}

// Handle create account button
export function initializeCreateAccountButton() {
    const createAccountButton = document.getElementById('create-account-button');
    if (!createAccountButton) return;

    createAccountButton.addEventListener('click', () => {
        // Play click sound
        if (window.soundManager) {
            window.soundManager.playClick();
        }
        // Import and call the account creation modal opener
        import('./account-creation.js').then(module => {
            module.openAccountCreationModal();
        });
    });
}