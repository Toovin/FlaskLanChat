// ai-conversation-manager.js - AI Conversation Management System
class AIConversationManager {
    constructor(modalInstance) {
        this.modal = modalInstance;
        this.conversations = [];
        this.currentConversationId = null;
        this.deletingConversation = null; // Track ongoing delete operations
    }

    // Initialize conversation management
    init() {
        this.bindConversationEvents();
        this.loadConversations();
    }

    // Bind conversation-related events
    bindConversationEvents() {
        if (typeof socket !== 'undefined') {
            socket.on('ai_conversations_list', (data) => {
                this.loadConversations(data.conversations);
            });

            socket.on('ai_conversation_history', (data) => {
                this.loadConversationHistory(data.history);
            });

            socket.on('ai_conversation_created', (data) => {
                // Refresh conversations list
                this.loadConversations();
                // Select the new conversation if ID provided, otherwise select the last one
                if (data.conversation_id) {
                    this.selectConversation(data.conversation_id);
                } else {
                    // Select the most recent conversation
                    setTimeout(() => {
                        if (this.conversations.length > 0) {
                            const latestConversation = this.conversations[this.conversations.length - 1];
                            this.selectConversation(latestConversation.id);
                        }
                    }, 100); // Small delay to ensure conversations are loaded
                }
            });

            socket.on('ai_conversation_updated', (data) => {
                // Update the conversation in local list
                const conv = this.conversations.find(c => c.id == data.conversation_id);
                if (conv && data.updates) {
                    Object.assign(conv, data.updates);
                    this.updateConversationsUI();
                }
            });
        }
    }

    // Load conversations from server
    loadConversations(conversations = null) {
        console.log('[AI_CONVERSATION_MANAGER] loadConversations called with provided data:', conversations);

        if (conversations) {
            // Use provided conversations data
            console.log('[AI_CONVERSATION_MANAGER] Using provided conversations data, count:', conversations.length);
            this.conversations = conversations;
            this.updateConversationsUI();
        } else {
            // Request conversations from server
            console.log('[AI_CONVERSATION_MANAGER] Requesting conversations from server');
            if (typeof socket !== 'undefined') {
                socket.emit('ai_get_conversations');
            } else {
                console.error('[AI_CONVERSATION_MANAGER] Socket not available for loading conversations');
            }
        }
    }

    // Update conversations UI
    updateConversationsUI() {
        console.log('[AI_CONVERSATION_MANAGER] updateConversationsUI called, conversations count:', this.conversations?.length || 0);

        const container = document.getElementById('ai-conversations-container');
        console.log('[AI_CONVERSATION_MANAGER] Conversations container found:', !!container);

        if (!container) return;

        if (!this.conversations || this.conversations.length === 0) {
            console.log('[AI_CONVERSATION_MANAGER] No conversations, showing empty state');
            container.innerHTML = '<div class="no-conversations">No conversations yet. Start a new chat!</div>';
            return;
        }

        console.log('[AI_CONVERSATION_MANAGER] Rendering conversations:', this.conversations.map(c => ({id: c.id, title: c.title})));
        container.innerHTML = this.conversations.map(conversation => this.createConversationItem(conversation)).join('');

        // Bind click events for conversation items
        this.bindConversationItemEvents();

        // Notify character manager to refresh character conversations if needed
        if (this.modal && this.modal.modules && this.modal.modules.characterManager) {
            const charManager = this.modal.modules.characterManager;
            if (charManager.activeCharacter) {
                console.log('[AI_CONVERSATION_MANAGER] Loading character conversations for:', charManager.activeCharacter.character_name);
                charManager.loadCharacterConversations(charManager.activeCharacter.character_name);
            }
        }
    }

    // Create HTML for conversation item
    createConversationItem(conversation) {
        const isActive = conversation.id === this.currentConversationId;
        const title = conversation.title || 'Untitled Conversation';
        const timestamp = this.formatConversationTime(conversation.updated_at);
        const characterName = conversation.character_name || 'AI Assistant';
        const avatarUrl = this.getCharacterAvatar(characterName);

        // Get first few words of the conversation (would need to be passed from backend)
        const preview = conversation.preview || 'Start a new conversation...';

        return `
            <div class="conversation-item ${isActive ? 'active' : ''}" data-conversation-id="${conversation.id}">
                <div class="conversation-header">
                    <img class="conversation-avatar" src="${avatarUrl}" alt="${characterName}" onerror="this.src='/static/default_avatars/smile_1.png'">
                    <div class="conversation-info">
                        <div class="conversation-character">${this.escapeHtml(characterName)}</div>
                        <div class="conversation-time">${timestamp}</div>
                    </div>
                </div>
                <div class="conversation-preview">${this.escapeHtml(preview)}</div>
                <div class="conversation-actions">
                    <button class="conversation-edit" data-conversation-id="${conversation.id}" title="Edit conversation title">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="conversation-delete" data-conversation-id="${conversation.id}" title="Delete conversation">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `;
    }

    // Bind events for conversation items
    bindConversationItemEvents() {
        const container = document.getElementById('ai-conversations-container');
        if (!container) return;

        // Remove existing event listener to avoid duplicates
        if (container._conversationEventBound) {
            console.log('[AI_CONVERSATION_MANAGER] Events already bound, skipping');
            return;
        }

        console.log('[AI_CONVERSATION_MANAGER] Binding events for conversation items');

        // Use event delegation for better performance and to handle dynamically added elements
        container.addEventListener('click', (e) => {
            const deleteBtn = e.target.closest('.conversation-delete');
            const editBtn = e.target.closest('.conversation-edit');
            const item = e.target.closest('.conversation-item');

            if (deleteBtn) {
                e.stopPropagation();
                const conversationId = deleteBtn.dataset.conversationId;
                console.log('[AI_CONVERSATION_MANAGER] Delete button clicked for conversation:', conversationId);
                this.deleteConversation(conversationId);
            } else if (editBtn) {
                e.stopPropagation();
                const conversationId = editBtn.dataset.conversationId;
                console.log('[AI_CONVERSATION_MANAGER] Edit button clicked for conversation:', conversationId);
                this.editConversation(conversationId);
            } else if (item) {
                const conversationId = item.dataset.conversationId;
                console.log('[AI_CONVERSATION_MANAGER] Conversation item clicked, ID:', conversationId);
                this.selectConversation(conversationId);
            }
        });

        container._conversationEventBound = true;
    }

    // Get character avatar URL
    getCharacterAvatar(characterName) {
        // Try to get from character manager first
        if (this.modal && this.modal.modules && this.modal.modules.characterManager) {
            const charManager = this.modal.modules.characterManager;
            const character = charManager.characters.find(c => c.character_name === characterName);
            if (character && character.avatar_url) {
                return charManager.getCacheBustedAvatarUrl(character.avatar_url);
            }
        }

        // Fallback to default avatar
        return '/static/default_avatars/smile_1.png';
    }

    // Select a conversation
    selectConversation(conversationId) {
        console.log('[AI_CONVERSATION_MANAGER] selectConversation called with ID:', conversationId);

        const conversation = this.conversations.find(c => c.id == conversationId);
        console.log('[AI_CONVERSATION_MANAGER] Found conversation:', conversation);

        if (!conversation) {
            console.error('[AI_CONVERSATION_MANAGER] Conversation not found!');
            return;
        }

        this.currentConversationId = conversationId;
        console.log('[AI_CONVERSATION_MANAGER] Set currentConversationId to:', conversationId);

        // Update UI
        document.querySelectorAll('.conversation-item').forEach(item => {
            item.classList.toggle('active', item.dataset.conversationId == conversationId);
        });

        // Load conversation history
        if (typeof socket !== 'undefined') {
            console.log('[AI_CONVERSATION_MANAGER] Emitting ai_get_conversation_history for ID:', conversationId);
            socket.emit('ai_get_conversation_history', { conversation_id: conversationId });
        } else {
            console.error('[AI_CONVERSATION_MANAGER] Socket not available for loading history');
        }

        this.modal.updateStatus(`Loaded conversation: ${conversation.title || 'Untitled'}`);
    }

    // Load conversation history
    loadConversationHistory(history) {
        console.log('[AI_CONVERSATION_MANAGER] loadConversationHistory called with history:', history);

        const messagesContainer = document.getElementById('ai-messages');
        console.log('[AI_CONVERSATION_MANAGER] Messages container found:', !!messagesContainer);

        if (!messagesContainer) return;

        // Clear existing messages
        console.log('[AI_CONVERSATION_MANAGER] Clearing existing messages');
        messagesContainer.innerHTML = '';

        if (!history || history.length === 0) {
            console.log('[AI_CONVERSATION_MANAGER] No history, showing welcome message');
            messagesContainer.innerHTML = `
                <div class="ai-welcome">
                    <h3>Conversation Loaded</h3>
                    <p>Continue your conversation or start fresh.</p>
                </div>
            `;
            return;
        }

        console.log('[AI_CONVERSATION_MANAGER] Loading', history.length, 'messages from history');

        // Add messages to UI
        history.forEach((message, index) => {
            console.log('[AI_CONVERSATION_MANAGER] Adding message', index + 1, 'of', history.length, ':', message);
            this.addMessageToHistory(message);
        });

        // Scroll to bottom
        messagesContainer.scrollTop = messagesContainer.scrollHeight;

        this.modal.updateStatus(`Loaded ${history.length} messages`);
        console.log('[AI_CONVERSATION_MANAGER] Conversation history loaded successfully');
    }

    // Add message to conversation history UI
    addMessageToHistory(message) {
        const messagesContainer = document.getElementById('ai-messages');
        if (!messagesContainer) return;

        const role = message.role;
        const content = message.content;
        const characterName = message.character_name;
        const timestamp = message.timestamp ? this.formatMessageTime(message.timestamp) : '';

        // Remove welcome message if it exists
        const welcome = messagesContainer.querySelector('.ai-welcome');
        if (welcome) {
            welcome.remove();
        }

        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message chat-message-${role}`;

        if (role === 'user') {
            messageDiv.innerHTML = `
                <div class="chat-bubble user-bubble">
                    <div class="bubble-content">${this.formatMessageContent(content)}</div>
                    <div class="bubble-time">${timestamp}</div>
                </div>
            `;
        } else {
            const displayName = characterName || 'AI';
            const avatarUrl = this.getCharacterAvatar(characterName);
            messageDiv.innerHTML = `
                <div class="chat-bubble ai-bubble">
                    <img src="${avatarUrl}" alt="${displayName}" class="bubble-avatar" onerror="this.src='/static/default_avatars/smile_1.png'">
                    <div class="bubble-content">${this.formatMessageContent(content)}</div>
                    <div class="bubble-time">${timestamp}</div>
                </div>
            `;
        }

        messagesContainer.appendChild(messageDiv);

        // Scroll to bottom
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    // Start a new conversation
    startNewConversation() {
        console.log('[AI_CONVERSATION_MANAGER] startNewConversation called');

        // Get the active character
        const activeCharacter = this.modal.modules.characterManager.activeCharacter;
        const characterName = activeCharacter ? activeCharacter.character_name : null;
        console.log('[AI_CONVERSATION_MANAGER] Active character:', characterName);

        // Create new conversation on server
        console.log('[AI_CONVERSATION_MANAGER] Creating new conversation on server');
        this.createConversation(null, characterName);

        this.currentConversationId = null;
        console.log('[AI_CONVERSATION_MANAGER] Reset currentConversationId to null');

        // Clear conversations UI active state
        document.querySelectorAll('.conversation-item').forEach(item => {
            item.classList.remove('active');
        });

        // Clear messages and show welcome
        const messagesContainer = document.getElementById('ai-messages');
        if (messagesContainer) {
            console.log('[AI_CONVERSATION_MANAGER] Clearing messages and showing welcome');
            messagesContainer.innerHTML = `
                <div class="ai-welcome">
                    <h3>New Conversation Started</h3>
                    <p>What would you like to talk about?</p>
                </div>
            `;
        }

        this.modal.updateStatus('Ready for new conversation');
        document.getElementById('ai-message-input')?.focus();
    }

    // Create a new conversation on server
    createConversation(title = null, characterName = null) {
        console.log('[AI_CONVERSATION_MANAGER] createConversation called with title:', title, 'character:', characterName);

        if (typeof socket !== 'undefined') {
            const data = {
                title: title,
                character_name: characterName
            };
            console.log('[AI_CONVERSATION_MANAGER] Emitting ai_create_conversation with data:', data);
            socket.emit('ai_create_conversation', data);
        } else {
            console.error('[AI_CONVERSATION_MANAGER] Socket not available for creating conversation');
        }
    }

    // Delete a conversation
    deleteConversation(conversationId) {
        if (!conversationId) return;

        // Prevent multiple delete operations on the same conversation
        if (this.deletingConversation === conversationId) {
            console.log('[AI_CONVERSATION_MANAGER] Delete already in progress for conversation:', conversationId);
            return;
        }

        if (!confirm('Are you sure you want to delete this conversation? This action cannot be undone.')) {
            return;
        }

        console.log('[AI_CONVERSATION_MANAGER] Starting delete for conversation:', conversationId);
        this.deletingConversation = conversationId;

        if (typeof socket !== 'undefined') {
            socket.emit('ai_delete_conversation', { conversation_id: conversationId });

            socket.once('ai_conversation_deleted', (data) => {
                console.log('[AI_CONVERSATION_MANAGER] Delete response received for conversation:', conversationId, 'success:', data.success);
                this.deletingConversation = null; // Reset the flag

                if (data.success) {
                    // Remove from local list
                    this.conversations = this.conversations.filter(c => c.id != conversationId);
                    console.log('[AI_CONVERSATION_MANAGER] Removed conversation from local list, remaining:', this.conversations.length);

                    // If current conversation was deleted, start new one
                    if (this.currentConversationId == conversationId) {
                        console.log('[AI_CONVERSATION_MANAGER] Current conversation deleted, starting new one');
                        this.startNewConversation();
                    } else {
                        console.log('[AI_CONVERSATION_MANAGER] Updating conversations UI');
                        this.updateConversationsUI();
                    }
                } else {
                    console.error('[AI_CONVERSATION_MANAGER] Delete failed:', data.message);
                    alert(data.message || 'Failed to delete conversation');
                }
            });
        } else {
            this.deletingConversation = null;
        }
    }

    // Edit conversation title
    editConversation(conversationId) {
        const newTitle = prompt('Enter new conversation title:');
        if (newTitle && newTitle.trim()) {
            this.updateConversationTitle(conversationId, newTitle.trim());
        }
    }

    // Update conversation title
    updateConversationTitle(conversationId, newTitle) {
        if (typeof socket !== 'undefined') {
            socket.emit('ai_update_conversation', {
                conversation_id: conversationId,
                title: newTitle
            });
        }
    }

    // Format conversation timestamp
    formatConversationTime(timestamp) {
        if (!timestamp) return '';

        try {
            const date = new Date(timestamp);
            const now = new Date();
            const diff = now - date;

            // Less than 1 hour ago
            if (diff < 3600000) {
                const minutes = Math.floor(diff / 60000);
                return minutes <= 1 ? 'Just now' : `${minutes}m ago`;
            }

            // Less than 24 hours ago
            if (diff < 86400000) {
                const hours = Math.floor(diff / 3600000);
                return `${hours}h ago`;
            }

            // More than 24 hours ago
            return date.toLocaleDateString();
        } catch (e) {
            return '';
        }
    }

    // Format message timestamp
    formatMessageTime(timestamp) {
        if (!timestamp) return '';

        try {
            const date = new Date(timestamp);
            return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        } catch (e) {
            return '';
        }
    }

    // Format message content (basic HTML escaping and link detection)
    formatMessageContent(content) {
        if (!content) return '';

        // Escape HTML
        let formatted = this.escapeHtml(content);

        // Convert URLs to links
        formatted = formatted.replace(
            /(https?:\/\/[^\s]+)/g,
            '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>'
        );

        // Convert line breaks to <br>
        formatted = formatted.replace(/\n/g, '<br>');

        return formatted;
    }

    // HTML escape utility
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Get current conversation
    getCurrentConversation() {
        return this.conversations.find(c => c.id == this.currentConversationId);
    }

    // Check if conversation exists
    hasConversation(conversationId) {
        return this.conversations.some(c => c.id == conversationId);
    }

    // Get conversation count
    getConversationCount() {
        return this.conversations.length;
    }
}

// Export for use in other modules
window.AIConversationManager = AIConversationManager;