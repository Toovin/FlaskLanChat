import { socket, state } from './core/setup.js';
import { showError, escapeHtml } from './core/ui-utils.js';
import { setActiveTab } from './socket-events/utils.js';
import { addMessage, scrollMessagesToBottom } from './message-utils/main.js';

// Module-level state variables (moved from inside DOMContentLoaded for proper scoping)
let selectedFiles = [];
let previewUrls = [];
let isSending = false;
let messageHistory = [];
let historyIndex = -1;

document.addEventListener('DOMContentLoaded', () => {
    // Initialize chat input container with safety checks
    let chatInputContainer = document.querySelector('.chat-input-container');
    if (!chatInputContainer) {
        console.warn('Chat input container not found, creating it');
        chatInputContainer = document.createElement('div');
        chatInputContainer.className = 'chat-input-container';
        chatInputContainer.innerHTML = `
            <div id="typing-indicator-bar" style="display: none;">
                <span id="typing-text"></span>
            </div>
            <div class="reply-bar" style="display: none;"></div>
            <div class="input-wrapper">
                <textarea class="message-input" placeholder="Message #general"></textarea>
                <div class="input-actions">
                    <input type="file" id="chat-file-upload-input" multiple style="display: none;" accept="image/png,image/webp,image/jpeg,image/gif,application/pdf,.doc,.docx,text/plain,.md,video/mp4,video/webm,video/avi,video/quicktime">
                    <button class="action-btn send-image-btn"><i class="fas fa-paper-plane"></i></button>
                    <button class="action-btn upload-btn"><i class="fas fa-upload"></i></button>
                    <label class="auto-scroll-label">
                        <input type="checkbox" id="auto-scroll-checkbox"> Auto-Scroll
                    </label>
                </div>
            </div>
        `;
        const tabContent = document.querySelector('#tab-content-channel');
        if (tabContent) {
            tabContent.appendChild(chatInputContainer);
        } else {
            console.error('tab-content-channel not found, cannot append chat-input-container');
            showError('Chat input container could not be created. Please refresh.');
            return;
        }
    }

    // Initialize image generation modal
    const imageGenModal = document.getElementById('image-gen-modal');
    const imageGenForm = document.getElementById('image-gen-form');

    if (imageGenModal) {
        imageGenModal.classList.remove('active');
        console.log('image-gen-modal hidden on page load');

        // Handle modal close buttons
        const closeButtons = imageGenModal.querySelectorAll('.cancel-button, .close-modal');
        closeButtons.forEach(button => {
            button.addEventListener('click', () => {
                closeImageGenModal();
            });
        });

        // Close modal when clicking outside the content
        imageGenModal.addEventListener('click', (e) => {
            if (e.target === imageGenModal) {
                closeImageGenModal();
            }
        });

        // Defer form setup until login success
        socket.on('login_success', () => {
            if (!imageGenForm) return;
            if (!imageGenForm.parentNode) return;

            // Form submission handled by socket-events modules
        });
    } else {
        console.warn('image-gen-modal not found in DOM');
    }

    // Initialize chat input elements with safety checks
    const messageInput = document.querySelector('.message-input');
    const fileInput = document.getElementById('chat-file-upload-input');
    const sendButton = document.querySelector('.send-image-btn');
    const uploadButton = document.querySelector('.upload-btn');

    console.log('Chat input elements:', {
        messageInput,
        fileInput,
        sendButton,
        uploadButton,
        chatInputContainer
    });

    // Critical fix: Validate all inputs exist before use
    if (!messageInput || !fileInput || !sendButton || !uploadButton || !chatInputContainer) {
        showError('Chat input elements not found. Please refresh.');
        return;
    }

    // Check if container is visible
    const containerStyle = getComputedStyle(chatInputContainer);
    if (containerStyle.display === 'none') {
        console.warn('Chat input container is hidden');
        showError('Chat input is hidden. Please refresh or check authentication.');
        return;
    }

    // Create reply bar element
    const replyBar = document.createElement('div');
    replyBar.className = 'reply-bar';
    replyBar.style.display = 'none';

    if (messageInput.parentElement) {
        messageInput.parentElement.insertBefore(replyBar, messageInput);
    }

    // Create attachments preview element
    const attachmentsPreview = document.createElement('div');
    attachmentsPreview.className = 'attachments-preview';
    attachmentsPreview.style.display = 'none';

    // Insert preview above the input-wrapper (input-wrapper is messageInput's parent)
    const inputWrapper = messageInput.parentElement;
    if (inputWrapper && inputWrapper.parentElement) {
        inputWrapper.parentElement.insertBefore(attachmentsPreview, inputWrapper);
    }

    // State variables are now declared at module level

    // Function to show attachments preview
    function showAttachmentsPreview() {
        // Revoke previous URLs to prevent memory leaks
        previewUrls.forEach(URL.revokeObjectURL);
        previewUrls = [];

        attachmentsPreview.innerHTML = '';
        selectedFiles.forEach((file, index) => {
            const fileDiv = document.createElement('div');
            fileDiv.className = 'attachment-item';

            if (file.type.startsWith('image/')) {
                const img = document.createElement('img');
                img.src = URL.createObjectURL(file);
                img.style.maxHeight = '50px';
                previewUrls.push(img.src);
                fileDiv.appendChild(img);
            } else if (file.type.startsWith('video/')) {
                // Video preview with icon
                const videoPreview = document.createElement('div');
                videoPreview.className = 'video-preview-icon';
                const icon = document.createElement('i');
                icon.className = 'fas fa-video';
                videoPreview.appendChild(icon);
                const nameSpan = document.createElement('span');
                nameSpan.textContent = file.name.length > 15 ? file.name.substring(0, 15) + '...' : file.name;
                videoPreview.appendChild(nameSpan);
                fileDiv.appendChild(videoPreview);
            } else {
                const nameSpan = document.createElement('span');
                nameSpan.textContent = file.name;
                fileDiv.appendChild(nameSpan);
            }

            const removeBtn = document.createElement('button');
            removeBtn.textContent = 'x';
            removeBtn.addEventListener('click', () => {
                selectedFiles.splice(index, 1);
                showAttachmentsPreview();
            });
            fileDiv.appendChild(removeBtn);

            attachmentsPreview.appendChild(fileDiv);
        });

        attachmentsPreview.style.display = selectedFiles.length > 0 ? 'block' : 'none';
    }

    // Upload button event listener
    if (uploadButton) {
        uploadButton.addEventListener('click', () => {
            if (fileInput) fileInput.click();
        });
    }

    // Sticker button event listener
    const stickerButton = document.querySelector('.sticker-btn');
    if (stickerButton) {
        stickerButton.addEventListener('click', () => {
            openStickerModal();
        });
    }

    // File input initialization
    if (fileInput) {
        fileInput.multiple = true;
        fileInput.setAttribute('accept', 'image/png,image/webp,image/jpeg,image/gif,application/pdf,.doc,.docx,text/plain,.md,video/mp4,video/webm,video/avi,video/quicktime');

        fileInput.addEventListener('change', (e) => {
            if (!messageInput) return;

            const newFiles = Array.from(e.target.files);
            selectedFiles = [...selectedFiles, ...newFiles].slice(0, 8);
            showAttachmentsPreview();
            fileInput.value = ''; // Allow re-selecting the same files
        });
    }

    // Critical fix: Properly initialize sendMessage function with null checks
    async function sendMessage() {
        if (!messageInput) {
            console.error('Message input element not found');
            showError('Chat input not available. Please refresh.');
            return;
        }

        if (isSending) {
            console.log('Send already in progress, ignoring');
            return;
        }
        isSending = true;

        // Play click sound for message send
        if (window.soundManager) {
            window.soundManager.playClick();
        }

        try {
            let text = messageInput.value.trim();

            if (!text && selectedFiles.length === 0) {
                showError('Please enter a message or select files to send.');
                return;
            }

            // Update input state
            messageInput.disabled = true;
            messageInput.placeholder = `Sending...`;

            const replyTo = messageInput.dataset.replyTo || null;
            const tempMessageId = `temp-${Date.now()}`;
            const requestId = Date.now().toString();

            // Create temporary message for user feedback
            try {
                if (text.startsWith('!image')) {
                    addMessage(state.currentUsername || 'You', 'Generating image...', false, null, true, tempMessageId, replyTo, 0, null, null, null, null, null);
                } else {
                    const tempText = selectedFiles.length > 0
                        ? JSON.stringify({ text: text || 'Sending...', attachments: [] })
                        : text || 'Sending...';
                    addMessage(state.currentUsername || 'You', tempText, !!selectedFiles.length, null, true, tempMessageId, replyTo, 0, null, null, null, null, null);
                }
            } catch (tempMsgError) {
                console.error('Failed to create temporary message:', tempMsgError);
                // Continue with sending even if temp message fails
            }

            // Handle file uploads first
            let uploadedUrls = [];
            if (selectedFiles.length > 0) {
                try {
                    const formData = new FormData();
                    selectedFiles.forEach(file => formData.append('file', file));

                    const response = await fetch('/upload-file', {
                        method: 'POST',
                        body: formData,
                        headers: { 'Accept': 'application/json' }
                    });

                    if (!response.ok) {
                        throw new Error(`Upload failed: ${response.status} ${response.statusText}`);
                    }

                    const data = await response.json();
                    uploadedUrls = data.urls || [];

                    if (uploadedUrls.length === 0) {
                        throw new Error('No files were uploaded successfully');
                    }

                    console.log(`Successfully uploaded ${uploadedUrls.length} files`);
                 } catch (error) {
                     console.error('File upload error:', error);
                     showError(`Failed to upload files: ${error.message}`);

                     // Clean up temp message
                     const tempMessage = document.querySelector('.message-group.temp');
                     if (tempMessage) tempMessage.remove();

                     // Clear attachments since upload failed
                     resetInput();

                     return;
                 }
            }

            // Prepare message content
            let messageContent = text;
            let isMediaMessage = false;

            if (uploadedUrls.length > 0) {
                messageContent = JSON.stringify({
                    text: text || '',
                    attachments: uploadedUrls
                });
                isMediaMessage = true;
            }



            // Send message via socket with error handling
            try {
                const messageData = {
                    channel: state.currentChannel,
                    message: messageContent,
                    is_media: isMediaMessage,
                    reply_to: replyTo,
                    request_id: requestId
                };

                // Special handling for !image commands
                if (text && text.startsWith('!image')) {
                    const parts = text.trim().split(' ');
                    const prompt = parts.length > 1 ? parts.slice(1).join(' ').trim() : '';

                    messageData.message = '!image';
                    messageData.is_media = false;
                    messageData.initial_prompt = prompt;
                }

                console.log('Sending message:', messageData);

                // Set up timeout for message send confirmation
                const sendTimeout = setTimeout(() => {
                    console.warn('Message send timeout - no confirmation received');
                    showError('Message may not have been sent. Please check your connection.');
                }, 10000); // 10 second timeout

                // Send the message
                socket.emit('send_message', messageData);

                // Clear timeout on successful emit (socket.io handles the actual sending)
                clearTimeout(sendTimeout);

            } catch (socketError) {
                console.error('Socket send error:', socketError);
                showError('Failed to send message. Please try again.');

                // Clean up temp message
                const tempMessage = document.querySelector('.message-group.temp');
                if (tempMessage) tempMessage.remove();

                // Clear attachments since send failed
                resetInput();

                return;
            }

            // Update message history
            if (text) {
                messageHistory.push(text);
                if (messageHistory.length > 50) messageHistory.shift();
                historyIndex = -1;
            }

            // Reset input
            resetInput();

        } catch (generalError) {
            console.error('Unexpected error in sendMessage:', generalError);
            showError('An unexpected error occurred. Please try again.');

            // Clean up temp message
            const tempMessage = document.querySelector('.message-group.temp');
            if (tempMessage) tempMessage.remove();

            // Clear attachments since send failed
            resetInput();

        } finally {
            isSending = false;
            // Ensure input is re-enabled
            if (messageInput) {
                messageInput.disabled = false;
                messageInput.placeholder = `Message #${state.currentChannel}`;
            }
        }
    }

    // Critical fix: Only attach send button listener if elements exist
    if (sendButton) {
        sendButton.addEventListener('click', sendMessage);
    }

    // Input event handlers with null checks
    if (messageInput) {
        messageInput.addEventListener('keydown', (e) => {
            if (!messageInput) return;

            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            } else if (e.key === 'ArrowUp' && !e.shiftKey) {
                e.preventDefault();
                if (messageHistory.length > 0) {
                    if (historyIndex === -1) {
                        historyIndex = messageHistory.length - 1;
                    } else {
                        historyIndex = Math.max(0, historyIndex - 1);
                    }
                    messageInput.value = messageHistory[historyIndex];
                    messageInput.setSelectionRange(messageInput.value.length, messageInput.value.length);
                }
            } else if (e.key === 'ArrowDown' && !e.shiftKey) {
                e.preventDefault();
                if (historyIndex >= 0) {
                    historyIndex++;
                    if (historyIndex >= messageHistory.length) {
                        historyIndex = -1;
                        messageInput.value = '';
                    } else {
                        messageInput.value = messageHistory[historyIndex];
                        messageInput.setSelectionRange(messageInput.value.length, messageInput.value.length);
                    }
                }
            } else if (e.key === 'Escape') {
                historyIndex = -1;
                messageInput.value = '';
                selectedFiles = [];
                showAttachmentsPreview();
            }
        });
    }

    // Critical fix: Paste event handler with proper null checks
    if (messageInput) {
        messageInput.addEventListener('paste', (e) => {
            if (isSending) {
                console.log('Paste event ignored, send in progress');
                return;
            }
            try {
                const clipboardData = e.clipboardData || window.clipboardData;
                if (!clipboardData) {
                    console.error('No clipboard data available');
                    return;
                }

                const items = clipboardData.items;
                let pastedFiles = [];

                // Check for pasted content (do not preventDefault to allow text pasting)
                for (const item of items) {
                    if (item.kind === 'file' && item.type.startsWith('image/')) {
                        const file = item.getAsFile();
                        if (file) {
                            pastedFiles.push(file);
                        }
                    }
                }

                // Append pasted files to selectedFiles (limit to 8 total)
                if (pastedFiles.length > 0) {
                    selectedFiles = [...selectedFiles, ...pastedFiles].slice(0, 8);
                    showAttachmentsPreview();

                    // Show visual feedback
                    messageInput.style.backgroundColor = 'rgba(255, 255, 0, 0.1)';
                    setTimeout(() => {
                        messageInput.style.backgroundColor = '';
                    }, 1000);
                }

                // For text, default paste is allowed (appends/inserts at cursor)
                // Emit typing if value changes (handled in input event)
            } catch (error) {
                console.error('Paste handler error:', error);
            }
        });
    }

    // Input change handler with null checks
    if (messageInput) {
        messageInput.addEventListener('input', () => {
            if (!messageInput) return;

            const value = messageInput.value;

            if (value.trim()) {
                socket.emit('start_typing', { channel: state.currentChannel });
            }
        });
    }



    // Auto-scroll checkbox handler
    const autoScrollCheckbox = document.getElementById('auto-scroll-checkbox');
    if (autoScrollCheckbox) {
        autoScrollCheckbox.checked = state.autoScrollEnabled;
        autoScrollCheckbox.addEventListener('change', (e) => {
            state.autoScrollEnabled = e.target.checked;
            localStorage.setItem('autoScrollEnabled', state.autoScrollEnabled);

            if (state.autoScrollEnabled) {
                scrollMessagesToBottom(true);
                const newMessagesButton = document.getElementById('new-messages-button');
                if (newMessagesButton) newMessagesButton.style.display = 'none';
            }
        });
    }

    // Adjust messages container padding
    function adjustMessagesPadding() {
        const messagesContainer = document.getElementById('messages-container');
        const chatInputContainer = document.querySelector('.chat-input-container');

        if (!messagesContainer || !chatInputContainer) return;

        const scrollTop = messagesContainer.scrollTop;
        messagesContainer.style.paddingBottom = '10px'; // Reduced to 10px spacing
        messagesContainer.scrollTop = scrollTop;
    }

    // Initial padding adjustment
    adjustMessagesPadding();
    setTimeout(adjustMessagesPadding, 100);

    // Handle window resize
    window.addEventListener('resize', adjustMessagesPadding);

    // Handle input height changes
    if (messageInput) {
        messageInput.addEventListener('input', adjustMessagesPadding);
    }

    // Messages container scroll handling
    const messagesContainer = document.getElementById('messages-container');
    if (messagesContainer) {
        messagesContainer.addEventListener('scroll', () => {
            if (!state.autoScrollEnabled) {
                const newMessagesButton = document.getElementById('new-messages-button');
                if (newMessagesButton) {
                    const isNearBottom =
                        messagesContainer.scrollTop + messagesContainer.clientHeight >=
                        messagesContainer.scrollHeight - 10;

                    newMessagesButton.style.display = isNearBottom ? 'none' : 'flex';
                }
            }
        });
    }

    // Tab switching
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            setActiveTab(tab.dataset.tab);

            // Force scroll reflow
            const messagesContainer = document.getElementById('messages-container');
            if (messagesContainer) {
                messagesContainer.style.overflow = 'hidden';
                setTimeout(() => messagesContainer.style.overflow = 'auto', 0);
            }
        });
    });

    // Close modal handler
    const closeModal = document.getElementById('image-gen-modal')?.querySelector('.close-modal');
    if (closeModal) {
        closeModal.addEventListener('click', () => {
            document.getElementById('image-gen-modal').classList.remove('active');
        });
    }



    // Focus input on load
    if (messageInput) messageInput.focus();

    // Refocus on window focus
    window.addEventListener('focus', () => {
        const messageInput = document.querySelector('.message-input');
        if (messageInput) messageInput.focus();
    });

    console.log('Chat input system initialized successfully');
});

// Global sticker modal functions
function openStickerModal() {
    const modal = document.getElementById('sticker-modal');
    if (modal) {
        modal.classList.add('active');
        loadStickers();
    }
}

function closeStickerModal() {
    const modal = document.getElementById('sticker-modal');
    if (modal) {
        modal.classList.remove('active');
    }
}

function loadStickers() {
    const stickerGrid = document.getElementById('sticker-grid');
    if (!stickerGrid) return;

    // Clear existing stickers
    stickerGrid.innerHTML = '';

    // Fetch stickers from server
    fetch('/list-sticker-files')
        .then(response => response.json())
        .then(data => {
            if (data.files && data.files.length > 0) {
                data.files.forEach(sticker => {
                    const stickerItem = document.createElement('div');
                    stickerItem.className = 'sticker-item';
                    stickerItem.dataset.sticker = sticker.name;

                    const ext = sticker.name.split('.').pop().toLowerCase();
                    const stickerUrl = sticker.path;

                    if (ext === 'webm') {
                        // Handle video stickers
                        const video = document.createElement('video');
                        video.src = stickerUrl;
                        video.muted = true;
                        video.loop = true;
                        video.preload = 'metadata';

                        // Add hover effects
                        stickerItem.addEventListener('mouseenter', () => {
                            video.play().catch(e => console.log('Video play failed:', e));
                        });
                        stickerItem.addEventListener('mouseleave', () => {
                            video.pause();
                            video.currentTime = 0;
                        });

                        stickerItem.appendChild(video);
                    } else if (['png', 'webp', 'jpg', 'jpeg', 'svg'].includes(ext)) {
                        // Handle image stickers
                        const img = document.createElement('img');
                        img.src = stickerUrl;
                        img.alt = sticker.name;
                        img.loading = 'lazy';

                        stickerItem.appendChild(img);
                    }

                    // Handle sticker selection
                    stickerItem.addEventListener('click', () => {
                        selectSticker(sticker.name);
                    });

                    stickerGrid.appendChild(stickerItem);
                });
            } else {
                // No stickers found, show placeholder
                stickerGrid.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--text-muted);">No stickers available</div>';
            }
        })
        .catch(error => {
            console.error('Failed to load stickers:', error);
            stickerGrid.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--text-muted);">Failed to load stickers</div>';
        });
}

function selectSticker(stickerName) {
    // Send the sticker as a message
    const messageInput = document.querySelector('.message-input');
    if (!messageInput) return;

    // Create a temporary message with the sticker
    const stickerUrl = `/static/stickers/default/${stickerName}`;

    // Send as a media message
    const messageData = {
        channel: state.currentChannel,
        message: JSON.stringify({
            text: '',
            attachments: [{ url: stickerUrl, thumbnail_url: null, size: 0 }]
        }),
        is_media: true,
        reply_to: messageInput.dataset.replyTo || null,
        request_id: Date.now().toString()
    };

    // Create temporary message for sticker
    addMessage(state.currentUsername || 'You', JSON.stringify({
        text: '',
        attachments: [{ url: stickerUrl, thumbnail_url: null, size: 0 }]
    }), true, null, true, Date.now().toString(), messageInput.dataset.replyTo || null, 0, null, null, null, null, null);

    console.log('Sending sticker:', messageData);
    socket.emit('send_message', messageData);

    // Close the modal
    closeStickerModal();

    // Reset input
    resetInput();
}

function resetInput() {
    // Reset selected files
    selectedFiles = [];

    // Revoke blob URLs to prevent memory leaks
    previewUrls.forEach(URL.revokeObjectURL);
    previewUrls = [];

    // Reset file input
    const fileInput = document.getElementById('chat-file-upload-input');
    if (fileInput) fileInput.value = '';

    // Reset message input
    const messageInput = document.querySelector('.message-input');
    if (messageInput) {
        messageInput.disabled = false;
        messageInput.placeholder = `Message #${state.currentChannel}`;
        messageInput.value = '';
        delete messageInput.dataset.replyTo;

        const replyBar = document.querySelector('.reply-bar');
        if (replyBar) replyBar.style.display = 'none';

        messageInput.focus();
    }

    // Reset history index
    historyIndex = -1;

    // Hide attachments preview
    const attachmentsPreview = document.querySelector('.attachments-preview');
    if (attachmentsPreview) {
        attachmentsPreview.style.display = 'none';
        attachmentsPreview.innerHTML = '';
    }
}


// Make functions globally available for HTML onclick handlers
window.closeStickerModal = closeStickerModal;