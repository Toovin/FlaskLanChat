// ============================================================================
// Image Display - Image display and modal management
// ============================================================================

/**
 * ImageDisplay - Handles displaying images and modal management
 */
export class ImageDisplay {
    constructor(core) {
        this.core = core;

        // Make function globally available for modal handlers
        window.sendImageToImg2Img = this.sendImageToImg2Img.bind(this);
    }

    /**
     * Initialize the display module
     */
    initialize() {
        // Setup modal close handlers
        this.setupModalCloseHandlers();
    }

    /**
     * Display a single image in the results container
     */
    displayImageInModal(imageUrl, thumbnailUrl) {
        const resultsContainer = document.getElementById('image-gen-results');
        if (!resultsContainer) return;

        const imageItem = document.createElement('div');
        imageItem.className = 'image-gen-result-item';
        imageItem.style.cssText = `
            display: inline-block;
            margin: 5px;
            border: 1px solid var(--border);
            border-radius: 4px;
            overflow: hidden;
            position: relative;
        `;

        const img = document.createElement('img');
        img.src = thumbnailUrl || imageUrl;
        img.style.cssText = `
            width: 120px;
            height: 120px;
            object-fit: cover;
            display: block;
        `;

        img.addEventListener('click', () => {
            // Open the full image in the image modal
            const imageModal = document.getElementById('image-modal');
            const imageModalImg = document.querySelector('.image-modal-image');
            if (imageModal && imageModalImg) {
                imageModalImg.src = imageUrl;
                imageModal.style.display = 'block';
            }
        });

        // Add "Send to img2img" button
        const sendToImg2ImgBtn = document.createElement('button');
        sendToImg2ImgBtn.textContent = '→ img2img';
        sendToImg2ImgBtn.style.cssText = `
            position: absolute;
            bottom: 5px;
            right: 5px;
            background: rgba(0, 0, 0, 0.7);
            color: white;
            border: none;
            border-radius: 3px;
            padding: 2px 6px;
            font-size: 10px;
            cursor: pointer;
            opacity: 0;
            transition: opacity 0.2s;
        `;

        sendToImg2ImgBtn.addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent image click
            this.sendImageToImg2Img(imageUrl);
        });

        imageItem.addEventListener('mouseenter', () => {
            sendToImg2ImgBtn.style.opacity = '1';
        });

        imageItem.addEventListener('mouseleave', () => {
            sendToImg2ImgBtn.style.opacity = '0';
        });

        imageItem.appendChild(img);
        imageItem.appendChild(sendToImg2ImgBtn);
        resultsContainer.appendChild(imageItem);

        // Track image in current generation
        const currentGeneration = this.core.getCurrentGeneration();
        if (currentGeneration) {
            currentGeneration.images.push({
                url: imageUrl,
                thumbnailUrl: thumbnailUrl
            });

            // Enable share button if auto-share is disabled
            const activeTab = document.querySelector('.image-gen-tab.active').dataset.tab;
            const shareButton = document.getElementById(`${activeTab}-share-generation-btn`);
            if (shareButton && !currentGeneration.autoShare) {
                shareButton.disabled = false;
            }
        }
    }

    /**
     * Show full-size image in a modal
     */
    showFullSizeImage(imageUrl) {
        // Create overlay
        const overlay = document.createElement('div');
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10000;
            cursor: pointer;
        `;

        // Create image
        const img = document.createElement('img');
        img.src = imageUrl;
        img.style.cssText = `
            max-width: 90%;
            max-height: 90%;
            object-fit: contain;
        `;

        // Close on click
        overlay.onclick = () => {
            document.body.removeChild(overlay);
        };

        overlay.appendChild(img);
        document.body.appendChild(overlay);
    }

    /**
     * Update existing images display with checkboxes
     */
    updateExistingImagesDisplay(showCheckboxes) {
        const resultsContainer = document.getElementById('image-gen-results');
        if (!resultsContainer) return;

        const images = resultsContainer.querySelectorAll('.image-gen-result-item');
        images.forEach(item => {
            const existingCheckbox = item.querySelector('.image-checkbox');
            if (showCheckboxes && !existingCheckbox) {
                // Add checkbox
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.className = 'image-checkbox';
                checkbox.style.cssText = `
                    position: absolute;
                    top: 5px;
                    left: 5px;
                    z-index: 10;
                `;
                item.style.position = 'relative';
                item.appendChild(checkbox);
            } else if (!showCheckboxes && existingCheckbox) {
                // Remove checkbox
                existingCheckbox.remove();
            }
        });
    }

    /**
     * Clear image results
     */
    clearImageResults() {
        const resultsContainer = document.getElementById('image-gen-results');
        if (resultsContainer) {
            resultsContainer.innerHTML = '';
        }
        // Also clear the img2img preview to prevent stale image URLs
        this.clearImg2ImgPreview();
    }

    /**
     * Send image to img2img tab
     */
    sendImageToImg2Img(imageUrl) {
        console.log('sendImageToImg2Img called with imageUrl:', imageUrl);
        // First, open the image generation modal if it's not already open
        const modal = document.getElementById('image-gen-modal');
        if (modal && modal.style.display !== 'block') {
            // Use the API to open the modal properly (loads preferences, etc.)
            const api = this.core.api;
            if (api && typeof api.openImageGenModal === 'function') {
                console.log('Opening modal via API');
                api.openImageGenModal().then(() => {
                    // Wait a bit for the modal to fully render, then switch to img2img tab and load image
                    setTimeout(() => {
                        this.switchToImg2ImgTabAndLoadImage(imageUrl);
                    }, 500); // Increased timeout
                }).catch(error => {
                    console.error('Error opening modal via API:', error);
                    // Fallback: try to populate modal with defaults and show it
                    const fallbackModalData = {
                        mode: 'txt2img',
                        prompt: '',
                        batch_size: 1,
                        width: 1024,
                        height: 1024,
                        steps: 33,
                        cfg_scale: 7,
                        clip_skip: 2,
                        negative_prompt: '',
                        sampler_name: 'DPM++ 3M SDE',
                        scheduler_name: 'simple',
                        model_name: 'pixelArtDiffusionXL',
                        sampler_options: [{ value: 'DPM++ 3M SDE', label: 'DPM++ 3M SDE' }],
                        scheduler_options: [{ value: 'simple', label: 'simple' }],
                        model_options: [{ value: 'pixelArtDiffusionXL', label: 'pixelArtDiffusionXL' }]
                    };
                    this.core.forms.populateImageGenModal(fallbackModalData);
                    modal.style.display = 'block';
                    setTimeout(() => {
                        this.switchToImg2ImgTabAndLoadImage(imageUrl);
                    }, 500); // Increased timeout
                });
            } else {
                console.log('API not available, using fallback to open modal');
                // Fallback: just show the modal
                modal.style.display = 'block';
                setTimeout(() => {
                    this.switchToImg2ImgTabAndLoadImage(imageUrl);
                }, 100);
            }
        } else {
            // Modal is already open, just switch to img2img and load image
            this.switchToImg2ImgTabAndLoadImage(imageUrl);
        }
    }

    /**
     * Switch to img2img tab and load the image
     */
    switchToImg2ImgTabAndLoadImage(imageUrl) {
        console.log('switchToImg2ImgTabAndLoadImage called with imageUrl:', imageUrl);

        // Switch to img2img tab (img2img form should already be populated from modal open)
        const tabs = document.querySelectorAll('.image-gen-tab');
        const forms = document.querySelectorAll('.image-gen-form');

        tabs.forEach(tab => {
            if (tab.dataset.tab === 'img2img') {
                tab.classList.add('active');
            } else {
                tab.classList.remove('active');
            }
        });

        forms.forEach(form => {
            if (form.id === 'img2img-form') {
                form.classList.add('active');
            } else {
                form.classList.remove('active');
            }
        });

        // Load the image into the preview
        this.loadImageForImg2Img(imageUrl);

        // Clear results
        this.clearImageResults();

        // Reset current generation
        this.core.clearCurrentGeneration();
    }

    /**
     * Load image into img2img preview
     */
    async loadImageForImg2Img(imageUrl) {
        console.log('loadImageForImg2Img called with:', imageUrl);
        const modal = document.getElementById('image-gen-modal');
        console.log('Modal display state:', modal ? modal.style.display : 'modal not found');

        const previewContainer = document.getElementById('img2img-preview-container');
        const previewImage = document.getElementById('img2img-preview-image');
        const imageInput = document.getElementById('img2img-image-input');

        console.log('Preview elements found:', {
            previewContainer: !!previewContainer,
            previewImage: !!previewImage,
            imageInput: !!imageInput
        });

        // Check if img2img tab is active
        const img2imgTab = document.querySelector('.image-gen-tab[data-tab="img2img"]');
        const img2imgForm = document.getElementById('img2img-form');
        console.log('Tab/Form active state:', {
            img2imgTabActive: img2imgTab ? img2imgTab.classList.contains('active') : 'tab not found',
            img2imgFormActive: img2imgForm ? img2imgForm.classList.contains('active') : 'form not found'
        });

        if (!previewContainer || !previewImage) {
            console.warn('Img2img preview elements not found');
            return;
        }

        // Validate imageUrl - accept both relative /static/ paths and full server URLs
        if (!imageUrl || typeof imageUrl !== 'string') {
            console.error('Invalid image URL for img2img preview:', imageUrl);
            this.clearImg2ImgPreview();
            return;
        }

        // Check if it's a valid static URL (relative or absolute)
        const isValidStaticUrl = imageUrl.startsWith('/static/') ||
            (imageUrl.includes('/static/') && (imageUrl.startsWith('http://') || imageUrl.startsWith('https://')));

        if (!isValidStaticUrl) {
            console.error('Invalid static URL for img2img preview:', imageUrl);
            this.clearImg2ImgPreview();
            return;
        }

        // Use the original image for preview (thumbnails may not exist)
        // If it's a relative path, construct full URL. If it's already absolute, use as-is.
        let previewSrc;
        let serverUrl; // URL to send to server (should be relative path)
        if (imageUrl.startsWith('http://') || imageUrl.startsWith('https://')) {
            previewSrc = imageUrl;
            // Extract relative path for server
            try {
                const url = new URL(imageUrl);
                serverUrl = url.pathname; // e.g., /static/uploads/image.jpg
            } catch (e) {
                console.error('Failed to parse imageUrl:', imageUrl);
                this.clearImg2ImgPreview();
                return;
            }
        } else if (imageUrl.startsWith('/static/')) {
            // For relative static paths, use the current origin for preview
            previewSrc = window.location.origin + imageUrl;
            serverUrl = imageUrl;
        } else {
            console.error('Unexpected imageUrl format:', imageUrl);
            this.clearImg2ImgPreview();
            return;
        }
        console.log('Using previewSrc:', previewSrc);
        console.log('Current window.location.origin:', window.location.origin);

        // Show preview immediately
        previewImage.onload = () => {
            console.log('Img2img preview image loaded successfully:', previewSrc);
            console.log('Image dimensions:', previewImage.naturalWidth, 'x', previewImage.naturalHeight);
            previewContainer.style.display = 'inline-block';

            // Store dimensions for copy dimensions button
            if (this.core && this.core.forms) {
                this.core.forms.imageDimensions = {
                    width: previewImage.naturalWidth,
                    height: previewImage.naturalHeight
                };
                console.log('Stored image dimensions:', this.core.forms.imageDimensions);

                // Show copy dimensions button
                const copyDimensionsBtn = document.getElementById('img2img-copy-dimensions-btn');
                if (copyDimensionsBtn) {
                    copyDimensionsBtn.style.display = 'inline-block';
                    console.log('Copy dimensions button shown');
                }
            }

            // Dispatch event to update UI
            window.dispatchEvent(new CustomEvent('img2img-image-loaded'));
        };
        previewImage.onerror = (e) => {
            console.error('Img2img preview image failed to load:', previewSrc, e);
            console.error('Error details:', e.type, e.target, e);
            // Show placeholder instead of error message
            if (previewContainer) {
                previewImage.src = '/static/images/img2img-placeholder.svg';
                previewContainer.style.display = 'inline-block';
            }
        };

        // Set the image URL for the input (server will fetch it)
        if (imageInput) {
            imageInput.dataset.url = serverUrl; // Use relative path for server
            imageInput.removeAttribute('required'); // Remove required since we have a URL
            console.log('Set img2img input URL (server):', serverUrl);
            console.log('Preview URL:', previewSrc);
            console.log('imageInput element:', imageInput);
        }

        // Try to fetch the image first to check accessibility
        console.log('Testing image accessibility with fetch...');
        fetch(previewSrc, { method: 'HEAD' })
            .then(response => {
                console.log('Image fetch HEAD response:', response.status, response.ok, response.headers.get('content-type'));
                if (response.ok) {
                    // If fetch succeeds, set the image src
                    console.log('Setting previewImage.src to:', previewSrc);
                    previewImage.src = previewSrc;
                } else {
                    throw new Error(`HTTP ${response.status}`);
                }
            })
            .catch(error => {
                console.error('Image fetch failed:', error);
                // Show placeholder on fetch failure
                previewImage.src = '/static/images/img2img-placeholder.svg';
                previewContainer.style.display = 'inline-block';
            });
    }

    /**
     * Clear img2img preview
     */
    clearImg2ImgPreview() {
        const imageInput = document.getElementById('img2img-image-input');
        const previewContainer = document.getElementById('img2img-preview-container');
        const previewImage = document.getElementById('img2img-preview-image');
        const copyDimensionsBtn = document.getElementById('img2img-copy-dimensions-btn');

        if (imageInput) {
            imageInput.value = '';
            delete imageInput.dataset.url;
            imageInput.setAttribute('required', 'required'); // Restore required when clearing
        }
        if (previewContainer) {
            previewContainer.style.display = 'inline-block'; // Keep visible with placeholder
        }
        if (previewImage) {
            previewImage.src = '/static/images/img2img-placeholder.svg'; // Show placeholder
        }
        if (copyDimensionsBtn) {
            copyDimensionsBtn.style.display = 'none';
        }

        // Clear stored dimensions
        if (this.core && this.core.forms) {
            this.core.forms.imageDimensions = null;
        }

        // Dispatch event to update UI
        window.dispatchEvent(new CustomEvent('img2img-image-cleared'));
    }

    /**
     * Setup modal close handlers
     */
    setupModalCloseHandlers() {
        // Close modal when clicking outside
        window.addEventListener('click', (event) => {
            const modal = document.getElementById('image-gen-modal');
            if (event.target === modal) {
                this.closeImageGenModal();
            }
        });

        // Close modal with Escape key
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') {
                const modal = document.getElementById('image-gen-modal');
                if (modal && modal.style.display === 'block') {
                    this.closeImageGenModal();
                }
            }
        });
    }

    /**
     * Close the image generation modal
     */
    closeImageGenModal() {
        const modal = document.getElementById('image-gen-modal');
        if (modal) {
            modal.style.display = 'none';
            modal.classList.remove('active');
            // Clear current generation state
            this.core.clearCurrentGeneration();
            // Hide share controls
            const shareControls = document.getElementById('image-gen-share-controls');
            if (shareControls) {
                shareControls.style.display = 'none';
            }
            // Reset submission flag
            this.core.setSubmittingImageForm(false);
            // Refocus chat input
            const messageInput = document.querySelector('.message-input');
            if (messageInput) messageInput.focus();
        }
    }
}