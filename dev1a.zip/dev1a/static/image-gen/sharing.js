// ============================================================================
// Image Sharing - Image sharing functionality and controls
// ============================================================================

import { socket, state } from '../core/setup.js';

/**
 * ImageSharing - Handles sharing generated images
 */
export class ImageSharing {
    constructor(core, display) {
        this.core = core;
        this.display = display;
    }

    /**
     * Initialize the sharing module
     */
    initialize() {
        // Setup share button handlers
        this.setupShareButtonHandlers();
    }

    /**
     * Share the current generation
     */
    shareCurrentGeneration() {
        const currentGeneration = this.core.getCurrentGeneration();
        if (!currentGeneration || currentGeneration.shared || currentGeneration.images.length === 0) {
            return;
        }

        console.log('Sharing current generation:', currentGeneration);

        // Emit share event to server
        console.log('Emitting share_image_generation with:', {
            generation_id: currentGeneration.id,
            images_length: currentGeneration.images.length,
            channel: state.currentChannel
        });
        socket.emit('share_image_generation', {
            generation_id: currentGeneration.id,
            images: currentGeneration.images,
            metadata: currentGeneration.metadata || {},
            channel: state.currentChannel
        });

        // Mark as shared
        currentGeneration.shared = true;

        // Update UI
        const shareButton = document.getElementById('share-generation-btn');
        if (shareButton) {
            shareButton.textContent = 'Shared';
            shareButton.disabled = true;
        }
    }

    /**
     * Update share button state
     */
    updateShareButtonState() {
        const shareBtn = document.getElementById('image-gen-share-btn');
        const checkedBoxes = document.querySelectorAll('.image-gen-result-checkbox:checked');
        if (shareBtn) {
            shareBtn.disabled = checkedBoxes.length === 0;
            shareBtn.textContent = shareBtn.classList.contains('confirm') ? 'Confirm Share' : 'Share Selected Images';
        }
    }

    /**
     * Share selected images
     */
    shareSelectedImages() {
        const checkedBoxes = document.querySelectorAll('.image-gen-result-checkbox:checked');
        if (checkedBoxes.length === 0) {
            return;
        }

        const currentGeneration = this.core.getCurrentGeneration();
        const selectedImages = Array.from(checkedBoxes).map(checkbox => {
            const index = parseInt(checkbox.dataset.index);
            const image = { ...currentGeneration.images[index] }; // Clone to avoid modifying original

            // Update metadata to reflect correct seed for this image in the batch
            if (image.metadata && currentGeneration.metadata && currentGeneration.metadata.seed !== undefined) {
                const originalSeed = currentGeneration.metadata.seed;
                image.metadata = { ...image.metadata, seed: originalSeed + index };
            }

            return image;
        });

        console.log('Sharing selected images:', selectedImages);

        // Emit share event to server with selected images
        socket.emit('share_selected_images', {
            images: selectedImages,
            channel: state.currentChannel
        });

        // Mark as shared
        currentGeneration.shared = true;

        // Update UI
        const shareBtn = document.getElementById('image-gen-share-btn');
        const shareStatus = document.getElementById('share-status');
        if (shareBtn) {
            shareBtn.textContent = 'Shared';
            shareBtn.disabled = true;
            shareBtn.classList.remove('confirm');
        }
        if (shareStatus) {
            shareStatus.textContent = 'Images shared successfully';
        }

        // Clear the results after sharing
        setTimeout(() => {
            this.display.clearImageResults();
            const shareControls = document.getElementById('image-gen-share-controls');
            if (shareControls) {
                shareControls.style.display = 'none';
            }
            // Reset current generation
            this.core.clearCurrentGeneration();
        }, 2000);
    }

    /**
     * Update display for existing images (add/remove checkboxes for manual sharing)
     */
    updateExistingImagesDisplay(showCheckboxes) {
        const images = document.querySelectorAll('.image-gen-result-item');
        images.forEach((item, index) => {
            let checkbox = item.querySelector('.image-gen-result-checkbox');
            if (showCheckboxes && !checkbox) {
                checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.className = 'image-gen-result-checkbox';
                checkbox.dataset.index = index;
                checkbox.addEventListener('change', () => this.updateShareButtonState());
                item.appendChild(checkbox);
            } else if (!showCheckboxes && checkbox) {
                item.removeChild(checkbox);
            }
        });
    }

    /**
     * Setup share button handlers
     */
    setupShareButtonHandlers() {
        // Initialize share button
        const shareBtn = document.getElementById('image-gen-share-btn');
        if (shareBtn) {
            shareBtn.addEventListener('click', () => {
                if (shareBtn.classList.contains('confirm')) {
                    // Confirm sharing
                    this.shareSelectedImages();
                } else {
                    // First click - show confirm state
                    shareBtn.classList.add('confirm');
                    this.updateShareButtonState();
                }
            });
        }

        // Initialize clear button
        const clearBtn = document.getElementById('image-gen-clear-btn');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                this.display.clearImageResults();
                // Reset share button state
                const shareBtn = document.getElementById('image-gen-share-btn');
                const shareStatus = document.getElementById('share-status');
                if (shareBtn) {
                    shareBtn.textContent = 'Share Selected Images';
                    shareBtn.disabled = false;
                    shareBtn.classList.remove('confirm');
                }
                if (shareStatus) {
                    shareStatus.textContent = '';
                }
            });
        }
    }
}