// ============================================================================
// Image Generation Module Initialization
// ============================================================================

import { socket, state } from '../core/setup.js';
import { showError } from '../core/ui-utils.js';
import { ImageGenerationCore } from './core.js';
import { ImageDisplay } from './display.js';
import { ImageAPI } from './api.js';
import { ImageSharing } from './sharing.js';
import { ImageForms } from './forms.js';

// ============================================================================
// Initialization - Create instances and wire dependencies
// ============================================================================

// Create core instance first (no dependencies)
const core = new ImageGenerationCore();

// Create display instance (depends on core)
const display = new ImageDisplay(core);

// Create sharing instance (depends on core and display)
const sharing = new ImageSharing(core, display);

// Create forms instance (depends on core, display, sharing)
const forms = new ImageForms(core, display, sharing);

// Set forms reference in core
core.setForms(forms);

// Create API instance (depends on forms)
const api = new ImageAPI(forms);

// Set api reference in core so display can access it
core.api = api;

// Initialize all modules
core.initialize();
display.initialize();
sharing.initialize();
forms.initialize();
api.initialize();

// Expose openImageGenModal globally for HTML onclick handlers
window.openImageGenModal = () => api.openImageGenModal();

// Expose imageAPI globally for the More! buttons
window.imageAPI = api;

// Expose closeImageGenModal globally for HTML onclick handlers
window.closeImageGenModal = () => {
    console.log('closeImageGenModal called');
    const modal = document.getElementById('image-gen-modal');
    if (modal) {
        console.log('Hiding modal');
        modal.style.display = 'none';
        modal.classList.remove('active');
        // Clear current generation state
        core.clearCurrentGeneration();
        // Hide share controls
        const shareControls = document.getElementById('image-gen-share-controls');
        if (shareControls) {
            shareControls.style.display = 'none';
        }
        // Reset submission flag
        core.setSubmittingImageForm(false);
        // Clear results
        display.clearImageResults();
        // Refocus chat input
        const messageInput = document.querySelector('.message-input');
        if (messageInput) messageInput.focus();
    } else {
        console.log('Modal not found');
    }
};

// Expose core globally for socket event handlers
window.imageGenCore = core;