// ============================================================================
// Image Forms - txt2img/img2img form initialization and validation
// ============================================================================

import { socket, state } from '../core/setup.js';
import { showError } from '../core/ui-utils.js';

/**
 * ImageForms - Handles form initialization and validation for image generation
 */
export class ImageForms {
    constructor(core, display, sharing) {
        this.core = core;
        this.display = display;
        this.sharing = sharing;
    }



    /**
     * Initialize the forms module
      */
     initialize() {
         // Initialize both forms
         this.initTxt2ImgForm();
         this.initImg2ImgForm();

         // Setup tab switching
         this.setupTabSwitching();

         // Setup quick set buttons
         this.setupQuickSetButtons();
     }

    /**
     * Populate the modal with data
     */
    populateImageGenModal(modalData) {
        // Default to txt2img tab
        const activeTab = modalData.mode || 'txt2img';
        const tabs = document.querySelectorAll('.image-gen-tab');
        const forms = document.querySelectorAll('.image-gen-form');

        // Set active tab
        tabs.forEach(tab => {
            if (tab.dataset.tab === activeTab) {
                tab.classList.add('active');
            } else {
                tab.classList.remove('active');
            }
        });

        // Set active form
        forms.forEach(form => {
            if (form.id === `${activeTab}-form`) {
                form.classList.add('active');
            } else {
                form.classList.remove('active');
            }
        });

        // Populate both forms with the same data
        this.populateFormFields('txt2img', modalData);
        this.populateFormFields('img2img', modalData);
    }

    /**
     * Get current modal data from the form fields
     */
    getCurrentModalData() {
        console.log('getCurrentModalData: Extracting modal data from txt2img form');
        
        const modalData = {
            mode: 'img2img',
            prompt: '',
            batch_size: 1,
            width: 1024,
            height: 1024,
            steps: 33,
            cfg_scale: 7,
            denoising_strength: 0.75,
            seed: '',
            negative_prompt: '',
            sampler_name: 'DPM++ 3M SDE',
            scheduler_name: 'simple',
            model_name: ''  // No default model
        };

        // Get values from txt2img form (which should be populated)
        const txt2imgPromptInput = document.getElementById('txt2img-prompt-input');
        const txt2imgBatchSizeInput = document.getElementById('txt2img-batch-size-input');
        const txt2imgWidthInput = document.getElementById('txt2img-width-input');
        const txt2imgHeightInput = document.getElementById('txt2img-height-input');
        const txt2imgStepsInput = document.getElementById('txt2img-steps-input');
        const txt2imgCfgScaleInput = document.getElementById('txt2img-cfg-scale-input');
        const txt2imgSeedInput = document.getElementById('txt2img-seed-input');
        const txt2imgNegativePromptInput = document.getElementById('txt2img-negative-prompt-input');
        const txt2imgSamplerSelect = document.getElementById('txt2img-sampler-name-input');
        const txt2imgSchedulerSelect = document.getElementById('txt2img-scheduler-name-input');
        const txt2imgModelSelect = document.getElementById('txt2img-model-name-input');

        if (txt2imgPromptInput) modalData.prompt = txt2imgPromptInput.value;
        if (txt2imgBatchSizeInput) modalData.batch_size = parseInt(txt2imgBatchSizeInput.value) || 1;
        if (txt2imgWidthInput) modalData.width = parseInt(txt2imgWidthInput.value) || 1024;
        if (txt2imgHeightInput) modalData.height = parseInt(txt2imgHeightInput.value) || 1024;
        if (txt2imgStepsInput) modalData.steps = parseInt(txt2imgStepsInput.value) || 33;
        if (txt2imgCfgScaleInput) modalData.cfg_scale = parseFloat(txt2imgCfgScaleInput.value) || 7;
        if (txt2imgSeedInput) modalData.seed = txt2imgSeedInput.value;
        if (txt2imgNegativePromptInput) modalData.negative_prompt = txt2imgNegativePromptInput.value;
        if (txt2imgSamplerSelect) modalData.sampler_name = txt2imgSamplerSelect.value;
        if (txt2imgSchedulerSelect) modalData.scheduler_name = txt2imgSchedulerSelect.value;
        if (txt2imgModelSelect) {
            modalData.model_name = txt2imgModelSelect.value;
            console.log('getCurrentModalData: txt2img model select value:', txt2imgModelSelect.value);
        }

        // Get options from txt2img selects, or use fallback options
        if (txt2imgSamplerSelect && txt2imgSamplerSelect.options.length > 0) {
            console.log('Using samplers from txt2img select:', txt2imgSamplerSelect.options.length, 'options');
            modalData.sampler_options = Array.from(txt2imgSamplerSelect.options).map(option => ({
                value: option.value,
                label: option.textContent
            }));
        } else {
            console.log('Using fallback sampler options (txt2img select empty)');
            // Fallback sampler options if SD API is not available
            modalData.sampler_options = [
                { value: 'Euler a', label: 'Euler a' },
                { value: 'DPM++ 2M Karras', label: 'DPM++ 2M Karras' },
                { value: 'DPM++ SDE Karras', label: 'DPM++ SDE Karras' },
                { value: 'DPM++ 3M SDE', label: 'DPM++ 3M SDE' },
                { value: 'DPM++ 3M SDE Karras', label: 'DPM++ 3M SDE Karras' },
                { value: 'DDIM', label: 'DDIM' },
                { value: 'LMS', label: 'LMS' },
                { value: 'Heun', label: 'Heun' }
            ];
        }
        
        if (txt2imgSchedulerSelect && txt2imgSchedulerSelect.options.length > 0) {
            console.log('Using schedulers from txt2img select:', txt2imgSchedulerSelect.options.length, 'options');
            modalData.scheduler_options = Array.from(txt2imgSchedulerSelect.options).map(option => ({
                value: option.value,
                label: option.textContent
            }));
        } else {
            console.log('Using fallback scheduler options (txt2img select empty)');
            // Fallback scheduler options if SD API is not available
            modalData.scheduler_options = [
                { value: 'exponential', label: 'exponential' },
                { value: 'karras', label: 'karras' },
                { value: 'normal', label: 'normal' },
                { value: 'simple', label: 'simple' },
                { value: 'ddim_uniform', label: 'ddim_uniform' }
            ];
        }
        
        if (txt2imgModelSelect && txt2imgModelSelect.options.length > 0) {
            console.log('Using models from txt2img select:', txt2imgModelSelect.options.length, 'options');
            modalData.model_options = Array.from(txt2imgModelSelect.options).map(option => ({
                value: option.value,
                label: option.textContent
            }));
        } else {
            console.log('Using fallback model options (txt2img select empty)');
            // Fallback model options if SD API is not available
            modalData.model_options = [
                { value: 'pixelArtDiffusionXL', label: 'pixelArtDiffusionXL' },
                { value: 'juggernautXL', label: 'juggernautXL' },
                { value: 'wildcardxXLFusion', label: 'wildcardxXLFusion' },
                { value: 'sdxlUnstableDiffusers', label: 'sdxlUnstableDiffusers' },
                { value: 'realisticVisionV51_v51VAE', label: 'realisticVisionV51_v51VAE.safetensors [d68f16f125]' }
            ];
        }

        console.log('getCurrentModalData returning:', {
            samplerOptionsCount: modalData.sampler_options.length,
            schedulerOptionsCount: modalData.scheduler_options.length,
            modelOptionsCount: modalData.model_options.length
        });

        return modalData;
    }

    /**
     * Populate form fields for a specific form type
     */
    populateFormFields(formType, modalData) {
        const prefix = formType;

        // Set input values
        const fieldMappings = {
            'prompt-input': modalData.prompt || '',
            'batch-size-input': modalData.batch_size || 1,
            'width-input': modalData.width || 1024,
            'height-input': modalData.height || 1024,
            'steps-input': modalData.steps || 33,
            'cfg-scale-input': modalData.cfg_scale || 7,
            'seed-input': modalData.seed || '',
            'negative-prompt-input': modalData.negative_prompt || '',
        };

        // Add form-specific fields
        if (formType === 'txt2img') {
            fieldMappings['clip-skip-input'] = modalData.clip_skip || 2;
        } else if (formType === 'img2img') {
            fieldMappings['denoising-strength-input'] = modalData.denoising_strength || 0.75;
        }

        // Set field values
        for (const [fieldSuffix, value] of Object.entries(fieldMappings)) {
            const element = document.getElementById(`${prefix}-${fieldSuffix}`);
            if (element) element.value = value;
        }

        // Populate select fields
        this.populateSelectField(`${prefix}-sampler-name-input`, modalData.sampler_options, modalData.sampler_name);
        this.populateSelectField(`${prefix}-scheduler-name-input`, modalData.scheduler_options, modalData.scheduler_name);
        this.populateSelectField(`${prefix}-model-name-input`, modalData.model_options, modalData.model_name);
    }

    /**
     * Populate a select field with options
     */
    populateSelectField(selectId, options, selectedValue) {
        const select = document.getElementById(selectId);
        console.log('populateSelectField:', selectId, 'select found:', !!select, 'options:', options);
        if (!select || !options) {
            console.warn('populateSelectField: missing select or options', selectId, options);
            return;
        }

        select.innerHTML = '';
        options.forEach(option => {
            const opt = document.createElement('option');
            opt.value = option.value;
            opt.textContent = option.label;
            if (option.value === selectedValue) {
                opt.selected = true;
            }
            select.appendChild(opt);
        });
        console.log('populateSelectField: populated', selectId, 'with', options.length, 'options');
    }

    /**
     * Common form submission handler
     */
    async handleFormSubmission(formType, form, autoShareCheckbox, shareButton) {
        // Prevent multiple submissions
        if (this.core.isSubmittingImageForm()) {
            console.log('Already submitting image form, ignoring duplicate');
            return;
        }
        this.core.setSubmittingImageForm(true);

        const submitBtn = form.querySelector('button[type="submit"]');

        try {
            // Generate unique ID for this generation
            const generationId = this.core.generateUUID();

            // Collect form data
            const formData = new FormData(form);

            // Build args based on form type
            let args;
            if (formType === 'txt2img') {
                args = this.buildTxt2ImgArgs(formData, generationId, autoShareCheckbox);
            } else {
                args = await this.buildImg2ImgArgs(formData, generationId, autoShareCheckbox);
                if (!args) {
                    this.core.setSubmittingImageForm(false);
                    return;
                }
            }

            // Validate prompt
            if (!args.prompt.trim()) {
                showError('Reeeee, prompt is empty! Please provide a description.');
                this.core.setSubmittingImageForm(false);
                return;
            }

            console.log(`Emitting ${formType} form data to server:`, args);

            // Initialize generation state
            const generation = {
                id: generationId,
                shared: false,
                images: [],
                autoShare: args.auto_share
            };
            this.core.setCurrentGeneration(generation);

            // Show loading on button
            if (submitBtn) {
                const originalText = submitBtn.textContent;
                submitBtn.textContent = 'Generating...';
                submitBtn.disabled = true;

                // Reset button after emission
                setTimeout(() => {
                    submitBtn.textContent = originalText;
                    submitBtn.disabled = false;
                }, 500);
            }

            // Clear previous results
            this.display.clearImageResults();

            // Show/hide share button based on auto-share setting
            if (shareButton) {
                shareButton.style.display = args.auto_share ? 'none' : 'inline-block';
                shareButton.disabled = true; // Disable until generation completes
            }

            // Submit the form data
            console.log('Emitting submit_image_form with args:', args);
            socket.emit('submit_image_form', {
                command: 'image',
                args: args,
                channel: state.currentChannel || 'general'
            });

            // Set button to busy status
            if (window.updateImageGenButton) {
                window.updateImageGenButton(0, 'busy');
            }

            // Handle post-submission UI
            this.handlePostSubmission(args.auto_share);

        } catch (error) {
            console.error(`Error submitting ${formType} form:`, error);
            this.core.setSubmittingImageForm(false);
            showError(`Failed to submit ${formType} form: ${error.message}`);
        }
    }

    /**
     * Build txt2img arguments
     */
    buildTxt2ImgArgs(formData, generationId, autoShareCheckbox) {
        return {
            mode: 'txt2img',
            prompt: formData.get('prompt') || '',
            batch_size: parseInt(formData.get('batch_size')) || 1,
            width: parseInt(formData.get('width')) || 1024,
            height: parseInt(formData.get('height')) || 1024,
            steps: parseInt(formData.get('steps')) || 33,
            cfg_scale: parseFloat(formData.get('cfg_scale')) || 7,
            clip_skip: parseInt(formData.get('clip_skip')) || 2,
            seed: formData.get('seed') ? parseInt(formData.get('seed')) : -1,
            negative_prompt: formData.get('negative_prompt') || '',
            model_name: formData.get('model_name') || '',
            sampler_name: formData.get('sampler_name') || 'DPM++ 3M SDE',
            scheduler_name: formData.get('scheduler_name') || 'simple',
            generation_id: generationId,
            auto_share: autoShareCheckbox ? autoShareCheckbox.checked : true
        };
    }

    /**
     * Build img2img arguments
     */
    async buildImg2ImgArgs(formData, generationId, autoShareCheckbox) {
        // Check if image is selected
        const imageInput = document.getElementById('img2img-image-input');
        const previewImage = document.getElementById('img2img-preview-image');
        const file = imageInput.files[0];
        const url = imageInput.dataset.url;

        console.log('buildImg2ImgArgs - checking for image:', {
            file: !!file,
            url: url,
            previewSrc: previewImage ? previewImage.src : 'no preview image'
        });

        // Check if we have an image: file upload, URL, or preview image loaded
        const hasImage = file || url || (previewImage && previewImage.src && previewImage.src !== '/static/images/img2img-placeholder.svg');

        if (!hasImage) {
            alert('Please select an input image for img2img generation.');
            return null;
        }

        // Get base args
        const baseArgs = {
            mode: 'img2img',
            prompt: formData.get('prompt') || '',
            batch_size: parseInt(formData.get('batch_size')) || 1,
            width: parseInt(formData.get('width')) || 1024,
            height: parseInt(formData.get('height')) || 1024,
            steps: parseInt(formData.get('steps')) || 33,
            cfg_scale: parseFloat(formData.get('cfg_scale')) || 7,
            denoising_strength: parseFloat(formData.get('denoising_strength')) || 0.75,
            seed: formData.get('seed') ? parseInt(formData.get('seed')) : -1,
            negative_prompt: formData.get('negative_prompt') || '',
            model_name: formData.get('model_name') || '',
            sampler_name: formData.get('sampler_name') || 'DPM++ 3M SDE',
            scheduler_name: formData.get('scheduler_name') || 'simple',
            generation_id: generationId,
            auto_share: autoShareCheckbox ? autoShareCheckbox.checked : true
        };

        // Handle image data
        if (file) {
            return new Promise((resolve) => {
                const reader = new FileReader();
                reader.onload = (event) => {
                    resolve({ ...baseArgs, init_image: event.target.result });
                };
                reader.readAsDataURL(file);
            });
        } else if (url) {
            return { ...baseArgs, init_image: url };
        } else if (previewImage && previewImage.src && previewImage.src !== '/static/images/img2img-placeholder.svg') {
            // Fallback: extract relative path from preview image src
            let imagePath = previewImage.src;
            if (imagePath.startsWith(window.location.origin)) {
                imagePath = imagePath.substring(window.location.origin.length);
            }
            return { ...baseArgs, init_image: imagePath };
        } else {
            alert('No valid image source found for img2img generation.');
            return null;
        }
    }

    /**
     * Handle post-submission UI updates
     */
    handlePostSubmission(autoShare) {
        if (autoShare) {
            this.core.showToast('Image Generation Request Sent! Please hold!', 'info', 2000);

            // Close modal after a delay to allow user to see the images
            const modal = document.getElementById('image-gen-modal');
            if (modal) {
                setTimeout(() => {
                    modal.style.display = 'none';
                }, 3000);
            }
        } else {
            // Reset flag after a timeout for manual share
            setTimeout(() => {
                this.core.setSubmittingImageForm(false);
            }, 5000);
        }
    }

    /**
     * Initialize txt2img form handlers
     */
    initTxt2ImgForm() {
        const form = document.getElementById('txt2img-form');
        const autoShareCheckbox = document.getElementById('txt2img-auto-share-checkbox');
        const shareButton = document.getElementById('txt2img-share-generation-btn');

        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                const submitBtn = form.querySelector('button[type="submit"]');
                if (submitBtn && submitBtn.disabled) return;
                if (this.core.isSubmittingImageForm()) return;
                console.log('Txt2Img form submitted');
                this.handleFormSubmission('txt2img', form, autoShareCheckbox, shareButton);
            });

            // Handle auto-share checkbox changes
            if (autoShareCheckbox) {
                autoShareCheckbox.addEventListener('change', () => {
                    if (shareButton) {
                        shareButton.style.display = autoShareCheckbox.checked ? 'none' : 'inline-block';
                    }
                    // Update existing images display based on auto-share setting
                    this.sharing.updateExistingImagesDisplay(!autoShareCheckbox.checked);
                });
            }

            // Handle share generation button
            if (shareButton) {
                shareButton.addEventListener('click', (event) => {
                    const button = event.target;
                    if (button.classList.contains('confirm')) {
                        // Confirm sharing - share selected images
                        this.sharing.shareSelectedImages();
                    } else {
                        // First click - show confirm state
                        button.classList.add('confirm');
                        this.sharing.updateShareButtonState();
                    }
                });
            }
        }
    }

    /**
     * Setup cancel button functionality
     */
    setupCancelButtons() {
        const cancelButtons = document.querySelectorAll('.image-gen-modal .cancel-button');
        cancelButtons.forEach(button => {
            button.addEventListener('click', () => {
                // Close the modal
                this.display.closeImageGenModal();
            });
        });
    }

    /**
     * Setup tab switching functionality
     */
    setupTabSwitching() {
        const tabs = document.querySelectorAll('.image-gen-tab');
        const forms = document.querySelectorAll('.image-gen-form');

        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const tabName = tab.dataset.tab;

                // Update tab active states
                tabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');

                // Update form active states
                forms.forEach(form => {
                    if (form.id === `${tabName}-form`) {
                        form.classList.add('active');
                    } else {
                        form.classList.remove('active');
                    }
                });

                // If switching to img2img tab, show placeholder if no image is loaded
                if (tabName === 'img2img') {
                    const previewImage = document.getElementById('img2img-preview-image');
                    const previewContainer = document.getElementById('img2img-preview-container');
                    if (previewContainer && previewImage && !previewImage.src.includes('/static/images/img2img-placeholder.svg')) {
                        // Check if there's no actual image loaded (not just placeholder)
                        const imageInput = document.getElementById('img2img-image-input');
                        if (!imageInput || !imageInput.dataset.url) {
                            this.display.clearImg2ImgPreview();
                        }
                    }
                }
            });
        });
    }

    /**
     * Setup quick set buttons functionality
     */
    setupQuickSetButtons() {
        // Handle orientation button clicks
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('orientation-btn')) {
                const button = e.target;
                const targetPrefix = button.dataset.target;
                const orientation = button.dataset.orientation;

                if (targetPrefix && orientation) {
                    this.setOrientation(targetPrefix, orientation);
                }
            }
        });

        // Handle min edge button clicks
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('min-edge-btn')) {
                const button = e.target;
                const targetPrefix = button.dataset.target;
                const minEdge = parseInt(button.dataset.minEdge);

                if (targetPrefix && minEdge) {
                    this.setDimensionsByMinEdge(targetPrefix, minEdge);
                }
            }
        });

        // Handle other quick set buttons
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('quick-set-btn') && !e.target.classList.contains('min-edge-btn')) {
                const button = e.target;
                const targetId = button.dataset.target;
                const value = button.dataset.value;

                if (targetId && value !== undefined) {
                    const input = document.getElementById(targetId);
                    if (input) {
                        input.value = value;
                        // Trigger input event to ensure any listeners are notified
                        input.dispatchEvent(new Event('input', { bubbles: true }));
                        input.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                }
            } else if (e.target.classList.contains('clip-skip-btn')) {
                const button = e.target;
                const targetId = button.dataset.target;
                const value = button.dataset.value;

                if (targetId) {
                    const input = document.getElementById(targetId);
                    if (input) {
                        // For null/empty value, set to empty string
                        input.value = value === '' ? '' : value;
                        input.dispatchEvent(new Event('input', { bubbles: true }));
                        input.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                }
            } else if (e.target.classList.contains('seed-btn')) {
                const button = e.target;
                const targetId = button.dataset.target;
                const value = button.dataset.value;

                if (targetId && value) {
                    const input = document.getElementById(targetId);
                    if (input) {
                        input.value = value;
                        input.dispatchEvent(new Event('input', { bubbles: true }));
                        input.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                }
            }
        });
    }

    /**
     * Set orientation for a form
     */
    setOrientation(prefix, orientation) {
        // Update active state of orientation buttons
        const orientationButtons = document.querySelectorAll(`.orientation-btn[data-target="${prefix}"]`);
        orientationButtons.forEach(btn => {
            if (btn.dataset.orientation === orientation) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
    }

    /**
     * Set dimensions based on aspect ratio, orientation, and min edge
     */
    setDimensionsByMinEdge(prefix, minEdge) {
        const widthInput = document.getElementById(`${prefix}-width-input`);
        const heightInput = document.getElementById(`${prefix}-height-input`);

        if (!widthInput || !heightInput) return;

        // Get current aspect ratio and orientation
        const aspectRatio = this.getCurrentAspectRatio(prefix);
        const orientation = this.getCurrentOrientation(prefix);

        // Parse aspect ratio
        const [widthRatio, heightRatio] = aspectRatio.split(':').map(Number);

        let width, height;

        if (aspectRatio === '1:1') {
            // Square - both dimensions equal to min edge
            width = minEdge;
            height = minEdge;
        } else if (orientation === 'landscape') {
            // Landscape: width is the longer edge (min edge), height calculated
            width = minEdge;
            height = Math.round(minEdge * (heightRatio / widthRatio));
        } else {
            // Portrait: height is the longer edge (min edge), width calculated
            height = minEdge;
            width = Math.round(minEdge * (widthRatio / heightRatio));
        }

        // Set the values
        widthInput.value = width;
        heightInput.value = height;

        // Trigger change events
        widthInput.dispatchEvent(new Event('input', { bubbles: true }));
        widthInput.dispatchEvent(new Event('change', { bubbles: true }));
        heightInput.dispatchEvent(new Event('input', { bubbles: true }));
        heightInput.dispatchEvent(new Event('change', { bubbles: true }));
    }

    /**
     * Get current aspect ratio for a form
     */
    getCurrentAspectRatio(prefix) {
        const select = document.getElementById(`${prefix}-aspect-ratio`);
        return select ? select.value : '1:1';
    }

    /**
     * Get current orientation for a form
     */
    getCurrentOrientation(prefix) {
        const activeBtn = document.querySelector(`.orientation-btn[data-target="${prefix}"].active`);
        return activeBtn ? activeBtn.dataset.orientation : 'landscape';
    }

    /**
     * Initialize img2img form handlers
     */
    initImg2ImgForm() {
        const form = document.getElementById('img2img-form');
        const autoShareCheckbox = document.getElementById('img2img-auto-share-checkbox');
        const shareButton = document.getElementById('img2img-share-generation-btn');

        // Setup image preview functionality
        this.setupImg2ImgPreview();

        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                const submitBtn = form.querySelector('button[type="submit"]');
                if (submitBtn && submitBtn.disabled) return;
                if (this.core.isSubmittingImageForm()) return;
                console.log('Img2Img form submitted');
                this.handleFormSubmission('img2img', form, autoShareCheckbox, shareButton);
            });

            // Handle auto-share checkbox changes
            if (autoShareCheckbox) {
                autoShareCheckbox.addEventListener('change', () => {
                    if (shareButton) {
                        shareButton.style.display = autoShareCheckbox.checked ? 'none' : 'inline-block';
                    }
                    // Update existing images display based on auto-share setting
                    this.sharing.updateExistingImagesDisplay(!autoShareCheckbox.checked);
                });
            }

            // Handle share generation button
            if (shareButton) {
                shareButton.addEventListener('click', (event) => {
                    const button = event.target;
                    if (button.classList.contains('confirm')) {
                        // Confirm sharing - share selected images
                        this.sharing.shareSelectedImages();
                    } else {
                        // First click - show confirm state
                        button.classList.add('confirm');
                        this.sharing.updateShareButtonState();
                    }
                });
            }
        }
    }

    /**
     * Setup img2img preview functionality
     */
    setupImg2ImgPreview() {
        const imageInput = document.getElementById('img2img-image-input');
        const previewContainer = document.getElementById('img2img-preview-container');
        const previewImage = document.getElementById('img2img-preview-image');
        const removeBtn = document.getElementById('img2img-remove-preview-btn');
        const copyDimensionsBtn = document.getElementById('img2img-copy-dimensions-btn');

        if (!imageInput || !previewContainer || !previewImage || !removeBtn || !copyDimensionsBtn) {
            console.warn('Img2img preview elements not found');
            return;
        }

        // Function to update file input state
        const updateFileInputState = () => {
            const hasUrl = imageInput.dataset.url;
            const hasFile = imageInput.files && imageInput.files.length > 0;
            const helpText = document.getElementById('img2img-image-help');

            if (hasUrl) {
                // Image loaded from URL - disable file input
                imageInput.disabled = true;
                imageInput.style.opacity = '0.5';
                imageInput.style.cursor = 'not-allowed';
                imageInput.title = 'Image already selected from gallery - use Remove button to change';
                if (helpText) helpText.textContent = 'Image selected from gallery. Use the × button to select a different image.';
            } else if (hasFile) {
                // File uploaded - disable file input
                imageInput.disabled = true;
                imageInput.style.opacity = '0.5';
                imageInput.style.cursor = 'not-allowed';
                imageInput.title = 'File already uploaded - use Remove button to change';
                if (helpText) helpText.textContent = 'File uploaded. Use the × button to select a different image.';
            } else {
                // No image selected - enable file input
                imageInput.disabled = false;
                imageInput.style.opacity = '1';
                imageInput.style.cursor = 'pointer';
                imageInput.title = 'Click to select an image file';
                if (helpText) helpText.textContent = 'Upload an image to use as the base for generation';
            }
        };

        // Handle file input change
        imageInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file && file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    previewImage.src = e.target.result;
                    previewContainer.style.display = 'inline-block';

                    // Get image dimensions when loaded
                    previewImage.onload = () => {
                        this.imageDimensions = {
                            width: previewImage.naturalWidth,
                            height: previewImage.naturalHeight
                        };
                        copyDimensionsBtn.style.display = 'inline-block';
                        updateFileInputState();
                    };
                };
                reader.readAsDataURL(file);
            } else {
                this.display.clearImg2ImgPreview();
                copyDimensionsBtn.style.display = 'none';
                this.imageDimensions = null;
                updateFileInputState();
            }
        });

        // Handle remove button click
        removeBtn.addEventListener('click', () => {
            this.display.clearImg2ImgPreview();
            copyDimensionsBtn.style.display = 'none';
            this.imageDimensions = null;
            updateFileInputState();
        });

        // Listen for image loaded/cleared events from display module
        window.addEventListener('img2img-image-loaded', () => {
            updateFileInputState();
        });
        window.addEventListener('img2img-image-cleared', () => {
            updateFileInputState();
        });

        // Initialize file input state
        updateFileInputState();

        // Handle copy dimensions button click
        copyDimensionsBtn.addEventListener('click', () => {
            if (this.imageDimensions) {
                const widthInput = document.getElementById('img2img-width-input');
                const heightInput = document.getElementById('img2img-height-input');

                if (widthInput && heightInput) {
                    widthInput.value = this.imageDimensions.width;
                    heightInput.value = this.imageDimensions.height;

                    // Show a brief success indication
                    const originalText = copyDimensionsBtn.textContent;
                    copyDimensionsBtn.textContent = '✓';
                    copyDimensionsBtn.style.backgroundColor = '#4CAF50';
                    setTimeout(() => {
                        copyDimensionsBtn.textContent = originalText;
                        copyDimensionsBtn.style.backgroundColor = '';
                    }, 1000);
                }
            }
        });

        // Initialize dimensions as null
        this.imageDimensions = null;
    }
}