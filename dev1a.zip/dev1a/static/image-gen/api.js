// ============================================================================
// Image API - API calls and data fetching for image generation
// ============================================================================

/**
 * ImageAPI - Handles API calls for image generation options and user preferences
 */
export class ImageAPI {
    constructor(forms) {
        this.forms = forms;
    }

    /**
     * Initialize the API module
     */
    initialize() {
        // Nothing to initialize for now
    }

    /**
     * Open the image generation modal and fetch data
     */
    async openImageGenModal() {
        console.log('openImageGenModal called');

        // Reset submission flag when opening modal
        if (this.forms && this.forms.core) {
            this.forms.core.setSubmittingImageForm(false);
        }

        // Re-enable submit buttons when opening modal
        const txt2imgSubmitBtn = document.querySelector('#txt2img-form button[type="submit"]');
        const img2imgSubmitBtn = document.querySelector('#img2img-form button[type="submit"]');
        if (txt2imgSubmitBtn) txt2imgSubmitBtn.disabled = false;
        if (img2imgSubmitBtn) img2imgSubmitBtn.disabled = false;

        // Show modal immediately
        const modal = document.getElementById('image-gen-modal');
        if (modal) {
            console.log('Setting modal display to block');
            modal.style.display = 'block';
        } else {
            console.log('Modal element not found');
        }

        // Check if we have pending metadata from generate more or img2img more buttons
        let modalData;
        let pendingImageUrl = null;
        if (window.pendingImg2ImgMetadata) {
            console.log('Using pending img2img metadata for modal:', window.pendingImg2ImgMetadata);
            modalData = { ...window.pendingImg2ImgMetadata };
            modalData.mode = 'img2img'; // Ensure mode is set
            pendingImageUrl = modalData.init_image_url;
            delete modalData.init_image_url; // Remove from modal data
            // Clear the pending metadata
            delete window.pendingImg2ImgMetadata;
        } else if (window.pendingGenerateMoreMetadata) {
            console.log('Using pending generate more metadata for modal:', window.pendingGenerateMoreMetadata);
            modalData = { ...window.pendingGenerateMoreMetadata };
            modalData.mode = 'txt2img'; // Ensure mode is set
            // Clear the pending metadata
            delete window.pendingGenerateMoreMetadata;
        } else {
            // For button-initiated modal, fetch user preferences and SD API options
            modalData = {
                mode: 'txt2img',
                prompt: '',
                batch_size: 1,
                width: 1024,
                height: 1024,
                steps: 33,
                cfg_scale: 7,
                clip_skip: 2,
                negative_prompt: '',
                sampler_name: 'DPM++ 3M SDE',
                scheduler_name: 'Simple',
                model_name: 'pixelArtDiffusionXL'
            };
        }

        // Fetch user preferences first
        try {
            const prefsResponse = await fetch('/user-image-preferences?username=' + encodeURIComponent(window.currentUsername || ''), {
                credentials: 'include'
            });
            if (prefsResponse.ok) {
                const userPrefs = await prefsResponse.json();
                console.log('Loaded user preferences for modal:', userPrefs);
                // Override defaults with user preferences
                modalData.width = userPrefs.width || modalData.width;
                modalData.height = userPrefs.height || modalData.height;
                modalData.steps = userPrefs.steps || modalData.steps;
                modalData.cfg_scale = userPrefs.cfg_scale || modalData.cfg_scale;
                modalData.clip_skip = userPrefs.clip_skip || modalData.clip_skip;
                modalData.negative_prompt = userPrefs.negative_prompt || modalData.negative_prompt;
                modalData.sampler_name = userPrefs.sampler_name || modalData.sampler_name;
                modalData.scheduler_name = userPrefs.scheduler_name || modalData.scheduler_name;
                modalData.model_name = userPrefs.model_name || 'pixelArtDiffusionXL';
                modalData.batch_size = userPrefs.batch_size || modalData.batch_size;
            } else {
                console.log('Failed to load user preferences, using defaults. Status:', prefsResponse.status);
            }
        } catch (error) {
            console.error('Error loading user preferences:', error);
            console.log('Using default preferences');
        }

        // Fetch options from SD API
        try {

            // Fetch samplers
            const samplersResponse = await fetch('/sdapi/v1/samplers');
            if (samplersResponse.ok) {
                try {
                    const samplers = await samplersResponse.json();
                    if (Array.isArray(samplers) && samplers.length > 0) {
                        modalData.sampler_options = samplers.map(s => ({
                            value: s.name,
                            label: s.label || s.name,
                            recommended_scheduler: s.options?.scheduler
                        }));
                    } else {
                        console.warn('Samplers array is empty or invalid, using fallbacks');
                        modalData.sampler_options = [
                            { value: 'Euler', label: 'Euler' },
                            { value: 'DPM++ 3M SDE', label: 'DPM++ 3M SDE', recommended_scheduler: 'exponential' }
                        ];
                    }
                } catch (jsonError) {
                    console.error('Failed to parse samplers JSON, using fallbacks:', jsonError);
                    modalData.sampler_options = [
                        { value: 'Euler', label: 'Euler' },
                        { value: 'DPM++ 3M SDE', label: 'DPM++ 3M SDE', recommended_scheduler: 'exponential' }
                    ];
                }
            } else {
                console.error('Samplers response not ok, using fallbacks:', samplersResponse.status);
                modalData.sampler_options = [
                    { value: 'Euler', label: 'Euler' },
                    { value: 'DPM++ 3M SDE', label: 'DPM++ 3M SDE', recommended_scheduler: 'exponential' }
                ];
            }

            // Fetch schedulers
            const schedulersResponse = await fetch('/sdapi/v1/schedulers');
            if (schedulersResponse.ok) {
                try {
                    const schedulers = await schedulersResponse.json();
                    if (Array.isArray(schedulers) && schedulers.length > 0) {
                        modalData.scheduler_options = schedulers.map(s => ({
                            value: s.label,
                            label: s.label
                        }));
                    } else {
                        console.warn('Schedulers array is empty or invalid, using fallbacks');
                        modalData.scheduler_options = [
                            { value: 'Simple', label: 'Simple' },
                            { value: 'exponential', label: 'Exponential' }
                        ];
                    }
                } catch (jsonError) {
                    console.error('Failed to parse schedulers JSON, using fallbacks:', jsonError);
                    modalData.scheduler_options = [
                        { value: 'Simple', label: 'Simple' },
                        { value: 'exponential', label: 'Exponential' }
                    ];
                }
            } else {
                console.error('Schedulers response not ok, using fallbacks:', schedulersResponse.status);
                modalData.scheduler_options = [
                    { value: 'Simple', label: 'Simple' },
                    { value: 'exponential', label: 'Exponential' }
                ];
            }

            // Fetch models
            const modelsResponse = await fetch('/sdapi/v1/sd-models');
            if (modelsResponse.ok) {
                try {
                    const models = await modelsResponse.json();
                    if (Array.isArray(models) && models.length > 0) {
                        modalData.model_options = models.map(m => ({
                            value: m.model_name,
                            label: `${m.model_name}${m.sha256 ? ` [${m.sha256.substring(0, 10)}]` : ''}`,
                            hash: m.sha256
                        }));

                        // Check if user's preferred model is available, otherwise use pixelArtDiffusionXL fallback
                        const userPreferredModel = modalData.model_options.find(m => m.value === modalData.model_name);
                        if (!userPreferredModel) {
                            // User's preferred model not available, use pixelArtDiffusionXL if available, otherwise first model
                            const pixelArtModel = modalData.model_options.find(m => m.value === 'pixelArtDiffusionXL');
                            modalData.model_name = pixelArtModel?.value || modalData.model_options[0]?.value || 'pixelArtDiffusionXL';
                        }
                        // If userPreferredModel exists, modalData.model_name stays as the user's preference
                    } else {
                        console.warn('Models array is empty or invalid, using fallbacks');
                        modalData.model_options = [
                            { value: 'pixelArtDiffusionXL', label: 'pixelArtDiffusionXL [7adffa28d4]', hash: '7adffa28d4', filename: '' },
                            { value: 'juggernautXL', label: 'juggernautXL [33e58e8668]', hash: '33e58e8668', filename: '' }
                        ];
                        // Check if user's preferred model is in fallbacks, otherwise use pixelArtDiffusionXL
                        const userPreferredInFallbacks = modalData.model_options.find(m => m.value === modalData.model_name);
                        modalData.model_name = userPreferredInFallbacks?.value || 'pixelArtDiffusionXL';
                    }
                } catch (jsonError) {
                    console.error('Failed to parse models JSON, using fallbacks:', jsonError);
                    modalData.model_options = [
                        { value: 'pixelArtDiffusionXL', label: 'pixelArtDiffusionXL [7adffa28d4]', hash: '7adffa28d4', filename: '' },
                        { value: 'juggernautXL', label: 'juggernautXL [33e58e8668]', hash: '33e58e8668', filename: '' }
                    ];
                    // Check if user's preferred model is in fallbacks, otherwise use pixelArtDiffusionXL
                    const userPreferredInFallbacks = modalData.model_options.find(m => m.value === modalData.model_name);
                    modalData.model_name = userPreferredInFallbacks?.value || 'pixelArtDiffusionXL';
                }
            } else {
                console.error('Models response not ok, using fallbacks:', modelsResponse.status);
                modalData.model_options = [
                    { value: 'pixelArtDiffusionXL', label: 'pixelArtDiffusionXL [7adffa28d4]', hash: '7adffa28d4', filename: '' },
                    { value: 'juggernautXL', label: 'juggernautXL [33e58e8668]', hash: '33e58e8668', filename: '' }
                ];
                // Check if user's preferred model is in fallbacks, otherwise use pixelArtDiffusionXL
                const userPreferredInFallbacks = modalData.model_options.find(m => m.value === modalData.model_name);
                modalData.model_name = userPreferredInFallbacks?.value || 'pixelArtDiffusionXL';
            }

        } catch (apiError) {
            console.error('Error fetching SD API options, using all fallbacks:', apiError);
            // Set all fallbacks
            modalData.sampler_options = [
                { value: 'Euler', label: 'Euler' },
                { value: 'DPM++ 3M SDE', label: 'DPM++ 3M SDE', recommended_scheduler: 'exponential' }
            ];
            modalData.scheduler_options = [
                { value: 'Simple', label: 'Simple' },
                { value: 'exponential', label: 'Exponential' }
            ];
                modalData.model_options = [
                    { value: 'pixelArtDiffusionXL', label: 'pixelArtDiffusionXL [7adffa28d4]', hash: '7adffa28d4', filename: '' },
                    { value: 'juggernautXL', label: 'juggernautXL [33e58e8668]', hash: '33e58e8668', filename: '' }
                ];
                // Check if user's preferred model is in fallbacks, otherwise use pixelArtDiffusionXL
                const userPreferredInFallbacks = modalData.model_options.find(m => m.value === modalData.model_name);
                modalData.model_name = userPreferredInFallbacks?.value || 'pixelArtDiffusionXL';
        }

        this.forms.populateImageGenModal(modalData);

        // If we have a pending image URL for img2img, load it
        if (pendingImageUrl && modalData.mode === 'img2img') {
            console.log('Loading pending image for img2img:', pendingImageUrl);
            // Wait a bit for the modal to fully render, then load the image
            setTimeout(() => {
                if (this.forms && this.forms.display && typeof this.forms.display.loadImageForImg2Img === 'function') {
                    this.forms.display.loadImageForImg2Img(pendingImageUrl);
                } else {
                    console.warn('loadImageForImg2Img function not available');
                }
            }, 500);
        }

        // Clear any previous generation results when opening modal
        const resultsContainer = document.getElementById('image-gen-results');
        if (resultsContainer) {
            resultsContainer.innerHTML = '';
        }

        // Hide metadata
        const metadataContainer = document.getElementById('image-gen-metadata');
        if (metadataContainer) {
            metadataContainer.style.display = 'none';
        }

        // Reset current generation state
        // Note: This will be handled by the core module
    }
}