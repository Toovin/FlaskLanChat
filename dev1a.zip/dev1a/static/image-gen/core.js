// ============================================================================
// Image Generation Core - Global state and utilities
// ============================================================================

import { socket, state } from '../core/setup.js';
import { showError } from '../core/ui-utils.js';

/**
 * ImageGenerationCore - Core utilities and state management for image generation
 * This module should have NO dependencies on other image generation modules
 */
export class ImageGenerationCore {
    constructor() {
        // Global state for image generations
        this.currentGeneration = null;

        // Flag to prevent duplicate form submissions
        this._isSubmittingImageForm = false;

        // Module references (set by index.js after construction)
        this.forms = null;
    }

    /**
     * Initialize the core module
     */
    initialize() {
        // Expose global state for backward compatibility
        // Note: We should phase these out over time
        window.currentGeneration = this.currentGeneration;
        window.isSubmittingImageForm = this._isSubmittingImageForm;

        console.log('Image Generation Core initialized');
    }

    /**
     * Set current generation
     */
    setCurrentGeneration(generation) {
        this.currentGeneration = generation;
        // Update global for backward compatibility
        window.currentGeneration = generation;
    }

    /**
     * Get current generation
     */
    getCurrentGeneration() {
        return this.currentGeneration;
    }

    /**
     * Set forms reference
     */
    setForms(forms) {
        this.forms = forms;
    }

    /**
     * Set submission flag
     */
    setSubmittingImageForm(submitting) {
        this._isSubmittingImageForm = submitting;
        // Update global for backward compatibility
        window.isSubmittingImageForm = submitting;
    }

    /**
     * Get submission flag
     */
    isSubmittingImageForm() {
        return this._isSubmittingImageForm;
    }

    /**
     * Simple toast notification
     */
    showToast(message, type = 'info', duration = 3000) {
        const toast = document.getElementById('toast');
        if (toast) {
            toast.textContent = message;
            toast.className = `toast ${type}`;
            toast.style.display = 'block';

            // Clear any existing timeout
            if (this._toastTimeout) {
                clearTimeout(this._toastTimeout);
            }

            // Set new timeout
            this._toastTimeout = setTimeout(() => {
                toast.style.display = 'none';
                this._toastTimeout = null;
            }, duration);
        }
    }

    /**
     * Generate UUID
     */
    generateUUID() {
        // Use crypto API if available for better randomness
        if (typeof crypto !== 'undefined' && crypto.randomUUID) {
            return crypto.randomUUID();
        }

        // Fallback to manual generation
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    /**
     * Clear current generation state
     */
    clearCurrentGeneration() {
        this.currentGeneration = null;
        // Update global for backward compatibility
        window.currentGeneration = null;
    }

    /**
     * Check if there's an active generation
     */
    hasActiveGeneration() {
        return this.currentGeneration !== null &&
               this.currentGeneration.images &&
               this.currentGeneration.images.length > 0;
    }

    /**
     * Get generation statistics
     */
    getGenerationStats() {
        if (!this.currentGeneration) {
            return { hasGeneration: false };
        }

        return {
            hasGeneration: true,
            id: this.currentGeneration.id,
            imageCount: this.currentGeneration.images ? this.currentGeneration.images.length : 0,
            shared: this.currentGeneration.shared || false,
            autoShare: this.currentGeneration.autoShare || false
        };
    }
}