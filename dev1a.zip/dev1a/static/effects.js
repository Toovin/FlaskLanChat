// Dynamic effect loading to avoid circular dependencies
let effectMap = new Map();
let effectsLoaded = false;

async function loadEffects() {
    if (effectsLoaded) return;

    try {
        // Import particle settings bridge first
        await import('./particle_effect_logic/particle-settings-bridge.js');

        // Import centralized color manager
        await import('./particle_effect_logic/particle-color-manager.js');

        // Import effects dynamically to avoid circular dependencies
        const modules = await Promise.all([
            import('./particle_effect_logic/particle-effect-orbiting.js'),
            import('./particle_effect_logic/particle-effect-falling.js'),
            import('./particle_effect_logic/particle-effect-spiral.js'),
            import('./particle_effect_logic/particle-effect-comet.js'),
            import('./particle_effect_logic/particle-effect-firework.js'),
            import('./particle_effect_logic/particle-effect-ripple.js'),
            import('./particle_effect_logic/particle-effect-bubbles.js')
        ]);

        effectMap.set('orbiting', validateEffect(modules[0].OrbitingEffect, 'orbiting'));
        effectMap.set('falling', validateEffect(modules[1].FallingEffect, 'falling'));
        effectMap.set('spiral', validateEffect(modules[2].SpiralEffect, 'spiral'));
        effectMap.set('comet', validateEffect(modules[3].CometEffect, 'comet'));
        effectMap.set('firework', validateEffect(modules[4].FireworkEffect, 'firework'));
        effectMap.set('ripple', validateEffect(modules[5].RippleEffect, 'ripple'));
        effectMap.set('bubbles', validateEffect(modules[6].BubblesEffect, 'bubbles'));

        effectsLoaded = true;
        console.log('🎆 Effects loaded successfully:', Array.from(effectMap.keys()));
    } catch (error) {
        console.error('🎆 Failed to load effects:', error);
    }
}

function validateEffect(effect, name) {
    if (!effect || typeof effect !== 'object') {
        console.warn(`Effect "${name}" is invalid or missing.`);
        return null;
    }
    if (!effect.sparkles || typeof effect.update !== 'function' || typeof effect.spawn !== 'function') {
        console.warn(`Effect "${name}" is missing required properties (sparkles, update, spawn).`);
        return null;
    }
    return effect;
}

// === CURSOR EFFECTS ===
export let x = 0, y = 0, ox = 0, oy = 0;
export let swide = 800, shigh = 600, sleft = 0, sdown = 0;
export let currentTempMessageId = null; // Track temporary message ID

export const tiny = [], star = [], starv = [], starx = [], stary = [], tinyx = [], tinyy = [], tinyv = [];
export const starRotation = [], tinyRotation = [];
export const starVelocityX = [], starVelocityY = [], tinyVelocityX = [], tinyVelocityY = [];
export const starOpacity = [], tinyOpacity = [];
export const starOrbitAngle = [], starOrbitRadius = [], starOrbitSpeed = []; // Orbiting properties
export const starBrightness = [], tinyBrightness = []; // Brightness/flicker effects
export const starPulsePhase = [], tinyPulsePhase = []; // Pulsing animation phases

// Performance optimization variables
export let lastMouseX = 0, lastMouseY = 0;
export let lastMouseMoveTime = Date.now();
export let mouseOnScreen = true;
export let pastasPaused = false;
export let mouseDown = false;
export let mouseDownTime = 0; // Track when mouse was pressed
export let chargeLevel = 0; // Accumulate charge while holding

let currentCursorEffect = 'orbiting'; // Current effect type
let currentEffectObj = null;

// Timing for deltaTime calculation
let lastUpdateTime = Date.now();

const DEFAULT_CURSOR_PATH = '/static/images/default_cursors/cursor2.png';

const defaultSettings = {
    cursor_effect: 'orbiting',
    particle_style: 'theme',
    cursor_particle: DEFAULT_CURSOR_PATH,
    particle_size: 1.0,
    auto_hide_particles: false,
    auto_hide_timeout: 10,
    cursor_glow: false
};

export function getUserSettings() {
    if (window.unifiedSettingsManager) {
        return window.unifiedSettingsManager.getSettings();
    }
    return { ...defaultSettings, ...window.currentUserSettings };
}

export function getSparkles() {
    return currentEffectObj ? currentEffectObj.sparkles : 0;
}

function set_width() {
    let sw_min = 999999, sh_min = 999999;
    if (document.documentElement && document.documentElement.clientWidth) {
        if (document.documentElement.clientWidth > 0) sw_min = document.documentElement.clientWidth;
        if (document.documentElement.clientHeight > 0) sh_min = document.documentElement.clientHeight;
    }
    if (typeof(self.innerWidth) === 'number' && self.innerWidth) {
        if (self.innerWidth > 0 && self.innerWidth < sw_min) sw_min = self.innerWidth;
        if (self.innerHeight > 0 && self.innerHeight < sh_min) sh_min = self.innerHeight;
    }
    if (document.body.clientWidth) {
        if (document.body.clientWidth > 0 && document.body.clientWidth < sw_min) sw_min = document.body.clientWidth;
        if (document.body.clientHeight > 0 && document.body.clientHeight < sh_min) sh_min = document.body.clientHeight;
    }
    swide = sw_min === 999999 ? 800 : sw_min;
    shigh = sh_min === 999999 ? 600 : sh_min;
}

// Theme accent colors for cursor effect tinting (matching cursor theming)
const cursorEffectThemeColors = {
    'dobo': '#8b4513',      // Saddle brown
    'cabo': '#666600',      // Dark yellow
    'dark': '#ff6b35',      // Orange
    'blue': '#1da1f2',      // Twitter blue
    'purple': '#a855f7',    // Purple
    'retro-green': '#00ff00', // Bright green
    'ice-blue': '#29b6f6',  // Bright blue
    'pika-yellow': '#ffff00', // Bright yellow
    'nature': '#66bb6a',    // Bright green
    'hpos10i': '#ff4444'    // Bright red
};

// Particle styling options
const particleStyles = {
    'theme': 'theme',       // Use theme colors
    'random': 'random',     // Random color per particle
    'rainbow': 'rainbow',   // Cycling rainbow colors
    'neon': 'neon'          // Bright neon colors
};

// Neon color palette for vibrant effects
const neonColors = [
    '#ff0080', // Hot pink
    '#00ffff', // Cyan
    '#ff8000', // Orange
    '#8000ff', // Purple
    '#00ff80', // Lime green
    '#ff4040', // Red
    '#4080ff', // Blue
    '#ffff00'  // Yellow
];

// Rainbow color cycle
const rainbowColors = [
    '#ff0000', // Red
    '#ff8000', // Orange
    '#ffff00', // Yellow
    '#00ff00', // Green
    '#0080ff', // Blue
    '#8000ff', // Indigo
    '#ff00ff'  // Violet
];

// ParticleThemer utility for centralized theming logic
const ParticleThemer = {
    getThemedGifSrc: function(originalSrc, theme) {
        // Convert original GIF path to themed variant
        // e.g., /static/images/default_particles/music_notes_1.gif
        // -> /static/images/default_particles/themes/dobo/music_notes_1.gif
        const basePath = '/static/images/default_particles/';
        const themesPath = basePath + 'themes/' + theme + '/';

        if (originalSrc.startsWith(basePath) && !originalSrc.includes('/themes/')) {
            const filename = originalSrc.split('/').pop();
            return themesPath + filename;
        }
        return originalSrc;
    },

    getOriginalGifSrc: function(currentSrc) {
        // Convert themed GIF path back to original
        // e.g., /static/images/default_particles/themes/dobo/music_notes_1.gif
        // -> /static/images/default_particles/music_notes_1.gif
        const themesPath = '/static/images/default_particles/themes/';
        if (currentSrc.includes(themesPath)) {
            const parts = currentSrc.split(themesPath);
            const filename = parts[1].split('/').pop();
            return '/static/images/default_particles/' + filename;
        }
        return currentSrc;
    },

    applyStyle: function(imgOrCanvas, style, theme, effect = null) {
        const particleStyle = style || 'theme';
        const isGif = imgOrCanvas.src && imgOrCanvas.src.toLowerCase().endsWith('.gif');
        const isSvg = imgOrCanvas.src && imgOrCanvas.src.toLowerCase().endsWith('.svg');

        if (isGif) {
            return this.applyGifStyle(imgOrCanvas, particleStyle, theme, effect);
        } else if (isSvg) {
            return this.applySvgStyle(imgOrCanvas, particleStyle, theme, effect);
        } else {
            return this.applyCanvasStyle(imgOrCanvas, particleStyle, theme, effect);
        }
    },

    applyGifStyle: function(img, particleStyle, theme, effect) {
        // For GIFs, use pre-colored variants instead of CSS filters
        if (particleStyle === 'theme') {
            // Change src to themed GIF variant
            const themedSrc = this.getThemedGifSrc(img.src, theme);
            if (themedSrc !== img.src) {
                img.src = themedSrc;
            }
            img.style.filter = ''; // Clear any existing filters
        } else if (particleStyle === 'none') {
            // Use original GIF without theme
            const originalSrc = this.getOriginalGifSrc(img.src);
            if (originalSrc !== img.src) {
                img.src = originalSrc;
            }
            img.style.filter = '';
        } else {
            // For random, rainbow, neon: use original GIF with CSS filters
            const originalSrc = this.getOriginalGifSrc(img.src);
            if (originalSrc !== img.src) {
                img.src = originalSrc;
            }

            let filterString = '';
            if (particleStyle === 'random') {
                const randomHue = Math.floor(Math.random() * 360);
                filterString = `hue-rotate(${randomHue}deg) saturate(1.5) brightness(1.2)`;
            } else if (particleStyle === 'rainbow') {
                const rainbowHue = Math.floor(Math.random() * 360);
                filterString = `hue-rotate(${rainbowHue}deg) saturate(2) brightness(1.3)`;
            } else if (particleStyle === 'neon') {
                const neonHue = Math.floor(Math.random() * 360);
                filterString = `hue-rotate(${neonHue}deg) saturate(3) brightness(1.5)`;
            }

            if (filterString) {
                img.style.filter = filterString.trim();
            } else {
                img.style.filter = '';
            }
        }

        return img;
    },

    applySvgStyle: function(img, particleStyle, theme, effect) {
        let filterString = '';

        if (particleStyle === 'random') {
            const randomHue = Math.floor(Math.random() * 360);
            filterString = `hue-rotate(${randomHue}deg) saturate(1.5) brightness(1.2)`;
        } else if (particleStyle === 'rainbow') {
            const rainbowHue = Math.floor(Math.random() * 360);
            filterString = `hue-rotate(${rainbowHue}deg) saturate(2) brightness(1.3)`;
        } else if (particleStyle === 'neon') {
            const randomHue = Math.floor(Math.random() * 360);
            filterString = `hue-rotate(${randomHue}deg) saturate(3) brightness(1.5)`;
        } else {
            const accentColor = cursorEffectThemeColors[theme] || cursorEffectThemeColors['dobo'];
            const r = parseInt(accentColor.slice(1, 3), 16);
            const g = parseInt(accentColor.slice(3, 5), 16);
            const b = parseInt(accentColor.slice(5, 7), 16);
            const max = Math.max(r, g, b);
            const min = Math.min(r, g, b);
            let hue = 0;
            if (max !== min) {
                if (max === r) hue = ((g - b) / (max - min)) * 60;
                else if (max === g) hue = (2 + (b - r) / (max - min)) * 60;
                else hue = (4 + (r - g) / (max - min)) * 60;
                if (hue < 0) hue += 360;
            }
            filterString = `hue-rotate(${Math.round(hue)}deg) saturate(1.8) brightness(1.1)`;
        }

        img.style.filter = filterString.trim();
        return img;
    },

    applyCanvasStyle: function(canvas, particleStyle, theme, effect) {
        const ctx = canvas.getContext('2d');
        const img = new Image();

        return new Promise((resolve) => {
            img.onload = function() {
                canvas.width = img.width;
                canvas.height = img.height;
                ctx.drawImage(img, 0, 0);

                if (particleStyle === 'none') {
                    // Do not apply any tinting
                } else if (particleStyle === 'random') {
                    const randomColor = neonColors[Math.floor(Math.random() * neonColors.length)];
                    ctx.globalCompositeOperation = 'source-atop';
                    const alpha = 0.8;
                    const r = parseInt(randomColor.slice(1, 3), 16);
                    const g = parseInt(randomColor.slice(3, 5), 16);
                    const b = parseInt(randomColor.slice(5, 7), 16);
                    ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${alpha})`;
                    ctx.fillRect(0, 0, canvas.width, canvas.height);
                } else if (particleStyle === 'rainbow') {
                    const rainbowColor = rainbowColors[Math.floor(Math.random() * rainbowColors.length)];
                    ctx.globalCompositeOperation = 'source-atop';
                    const alpha = 0.7;
                    const r = parseInt(rainbowColor.slice(1, 3), 16);
                    const g = parseInt(rainbowColor.slice(3, 5), 16);
                    const b = parseInt(rainbowColor.slice(5, 7), 16);
                    ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${alpha})`;
                    ctx.fillRect(0, 0, canvas.width, canvas.height);
                } else if (particleStyle === 'neon') {
                    const neonColor = neonColors[Math.floor(Math.random() * neonColors.length)];
                    ctx.globalCompositeOperation = 'source-atop';
                    const alpha = 0.9;
                    const r = parseInt(neonColor.slice(1, 3), 16);
                    const g = parseInt(neonColor.slice(3, 5), 16);
                    const b = parseInt(neonColor.slice(5, 7), 16);
                    ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${alpha})`;
                    ctx.fillRect(0, 0, canvas.width, canvas.height);
                } else {
                    const accentColor = cursorEffectThemeColors[theme] || cursorEffectThemeColors['dobo'];
                    ctx.globalCompositeOperation = 'source-atop';
                    const alpha = 0.6;
                    const r = parseInt(accentColor.slice(1, 3), 16);
                    const g = parseInt(accentColor.slice(3, 5), 16);
                    const b = parseInt(accentColor.slice(5, 7), 16);
                    ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${alpha})`;
                    ctx.fillRect(0, 0, canvas.width, canvas.height);
                }

                ctx.globalCompositeOperation = 'source-over';
                resolve(canvas);
            };

            img.onerror = function() {
                console.warn(`Failed to load canvas image: ${canvas.dataset.src || canvas.src}`);
                resolve(canvas); // Return canvas as-is on error
            };

            img.src = canvas.dataset.src || canvas.src || DEFAULT_CURSOR_PATH;
        });
    }
};

function getCurrentTheme() {
    const themeClasses = Array.from(document.documentElement.classList);
    const themeClass = themeClasses.find(cls => cls.startsWith('theme-'));
    return themeClass ? themeClass.replace('theme-', '') : 'dobo';
}

function getCurrentCursorEffect() {
    return getUserSettings().cursor_effect || 'orbiting';
}

function getCurrentParticleSize() {
    return getUserSettings().particle_size || 1.0;
}

function updateParticleSizes() {
    const particleSize = getCurrentParticleSize();
    for (let i = 0; i < star.length; i++) {
        if (star[i]) {
            star[i].style.width = (16 * particleSize) + 'px';
            star[i].style.height = (16 * particleSize) + 'px';
        }
        if (tiny[i]) {
            tiny[i].style.width = (8 * particleSize) + 'px';
            tiny[i].style.height = (8 * particleSize) + 'px';
        }
    }
}

window.updateParticleSizes = updateParticleSizes;

let updateCursorEffectTimeout = null;

async function updateCursorEffect() {
    // Throttle updates to prevent spam
    if (updateCursorEffectTimeout) {
        clearTimeout(updateCursorEffectTimeout);
    }

    updateCursorEffectTimeout = setTimeout(async () => {
        await loadEffects();

        const newEffect = getCurrentCursorEffect();
        const effectChanged = newEffect !== currentCursorEffect;

        // Skip if effect is "none" and hasn't changed
        if (newEffect === 'none' && !effectChanged) {
            return;
        }

    if (effectChanged && currentEffectObj && typeof currentEffectObj.cleanup === 'function') {
        currentEffectObj.cleanup();
    }

    currentCursorEffect = newEffect;
    if (newEffect === 'none') {
        currentEffectObj = null;  // Explicitly disable effects for 'none'
    } else {
        currentEffectObj = effectMap.get(newEffect) || null;
        if (!currentEffectObj) {
            console.warn(`Effect "${newEffect}" not found in effectMap. Falling back to default.`);
            currentCursorEffect = 'orbiting';
            currentEffectObj = effectMap.get(currentCursorEffect) || null;
        }
    }

    if (effectChanged) {
        console.log('🎆 Effect changed to:', newEffect, 'Object:', !!currentEffectObj, 'Sparkles:', getSparkles());
    }

    const newSparkles = getSparkles();

    const particleSize = getCurrentParticleSize();
    while (newSparkles > star.length) {
        const i = star.length;
        const pastaStar = await createPasta(16 * particleSize, 16 * particleSize, currentEffectObj);
        pastaStar.style.visibility = 'hidden';
        document.body.appendChild(star[i] = pastaStar);

        if (currentEffectObj?.usesTinies) {
            const pastaTiny = await createPasta(8 * particleSize, 8 * particleSize, currentEffectObj);
            pastaTiny.style.visibility = 'hidden';
            document.body.appendChild(tiny[i] = pastaTiny);
        } else {
            tiny[i] = null;
        }

        starv[i] = 0;
        starx[i] = 0;
        stary[i] = 0;
        starRotation[i] = 0;
        starVelocityX[i] = 0;
        starVelocityY[i] = 0;
        starOpacity[i] = 1;
        starOrbitAngle[i] = 0;
        starOrbitRadius[i] = 0;
        starOrbitSpeed[i] = 0;
        starBrightness[i] = 1;
        starPulsePhase[i] = 0;

        if (currentEffectObj?.usesTinies) {
            tinyv[i] = 0;
            tinyx[i] = 0;
            tinyy[i] = 0;
            tinyRotation[i] = 0;
            tinyVelocityX[i] = 0;
            tinyVelocityY[i] = 0;
            tinyOpacity[i] = 1;
            tinyBrightness[i] = 1;
            tinyPulsePhase[i] = 0;
        }
    }

    if (newSparkles < star.length) {
        for (let i = newSparkles; i < star.length; i++) {
            if (star[i]) star[i].remove();
            if (tiny[i]) tiny[i].remove();
        }
        star.length = newSparkles;
        tiny.length = newSparkles;
        starv.length = newSparkles;
        starx.length = newSparkles;
        stary.length = newSparkles;
        starRotation.length = newSparkles;
        starVelocityX.length = newSparkles;
        starVelocityY.length = newSparkles;
        starOpacity.length = newSparkles;
        starOrbitAngle.length = newSparkles;
        starOrbitRadius.length = newSparkles;
        starOrbitSpeed.length = newSparkles;
        starBrightness.length = newSparkles;
        starPulsePhase.length = newSparkles;
        tinyv.length = newSparkles;
        tinyx.length = newSparkles;
        tinyy.length = newSparkles;
        tinyRotation.length = newSparkles;
        tinyVelocityX.length = newSparkles;
        tinyVelocityY.length = newSparkles;
        tinyOpacity.length = newSparkles;
        tinyBrightness.length = newSparkles;
        tinyPulsePhase.length = newSparkles;
    }

    if (effectChanged) {
        console.log('🎆 Adjusted to', newSparkles, 'particle pairs for effect:', currentCursorEffect);
    }

    if (effectChanged) {
        for (let i = 0; i < star.length; i++) {
            if (star[i]) {
                star[i].style.visibility = 'hidden';
                starv[i] = 0;
            }
            if (tiny[i]) {
                tiny[i].style.visibility = 'hidden';
                tinyv[i] = 0;
            }
        }

        if (currentEffectObj && typeof currentEffectObj.init === 'function') {
            currentEffectObj.init();
        }

        console.log('Cursor effect changed to:', newEffect, 'sparkles:', newSparkles);
    }

    if (!currentEffectObj?.usesTinies) {
        for (let i = 0; i < tiny.length; i++) {
            if (tiny[i]) tiny[i].style.visibility = 'hidden';
        }
    }
    }, 100); // 100ms throttle
}

async function createThemedPasta(height, width, effect = null) {
    const userSettings = getUserSettings();
    const particleStyle = userSettings.particle_style || 'theme';

    let iconPath;
    if (particleStyle.startsWith('/static/')) {
        iconPath = particleStyle;
    } else {
        const cursorParticle = userSettings.cursor_particle;
        iconPath = cursorParticle && cursorParticle !== 'default' ? cursorParticle : DEFAULT_CURSOR_PATH;
    }

    const isGif = iconPath.toLowerCase().endsWith('.gif');
    const isSvg = iconPath.toLowerCase().endsWith('.svg');

    const theme = getCurrentTheme();

    if (isGif) {
        const pastaImg = document.createElement('img');
        pastaImg.src = iconPath;
        pastaImg.className = 'pasta-img pasta-gif';
        pastaImg.style.position = 'absolute';
        pastaImg.style.height = height + 'px';
        pastaImg.style.width = width + 'px';
        pastaImg.style.pointerEvents = 'none';
        pastaImg.style.zIndex = '999';
        pastaImg.style.opacity = '1';

        ParticleThemer.applyGifStyle(pastaImg, 'none', theme, effect);
        return pastaImg;
    } else if (isSvg) {
        const pastaImg = document.createElement('img');
        pastaImg.src = iconPath;
        pastaImg.className = 'pasta-img';
        pastaImg.style.position = 'absolute';
        pastaImg.style.height = height + 'px';
        pastaImg.style.width = width + 'px';
        pastaImg.style.pointerEvents = 'none';
        pastaImg.style.zIndex = '999';
        pastaImg.style.opacity = '1';

        ParticleThemer.applySvgStyle(pastaImg, 'none', theme, effect);
        return pastaImg;
    }

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();

    return new Promise((resolve) => {
        img.onload = async function() {
            canvas.width = img.width;
            canvas.height = img.height;
            ctx.drawImage(img, 0, 0);

            canvas.dataset.src = iconPath;
            await ParticleThemer.applyCanvasStyle(canvas, 'none', theme, effect);

            const pastaImg = document.createElement('img');
            pastaImg.src = canvas.toDataURL();
            pastaImg.className = 'pasta-img';
            pastaImg.style.position = 'absolute';
            pastaImg.style.height = height + 'px';
            pastaImg.style.width = width + 'px';
            pastaImg.style.pointerEvents = 'none';
            pastaImg.style.zIndex = '999';
            pastaImg.style.opacity = '1';

            resolve(pastaImg);
        };

        img.onerror = function() {
            console.warn(`Failed to load image: ${iconPath}`);
            const pastaImg = document.createElement('img');
            pastaImg.src = DEFAULT_CURSOR_PATH;
            pastaImg.className = 'pasta-img';
            pastaImg.style.position = 'absolute';
            pastaImg.style.height = height + 'px';
            pastaImg.style.width = width + 'px';
            pastaImg.style.pointerEvents = 'none';
            pastaImg.style.zIndex = '999';
            pastaImg.style.opacity = '1';
            ParticleThemer.applyStyle(pastaImg, 'none', theme, effect);
            resolve(pastaImg);
        };

        img.src = iconPath;
    });
}

async function createPasta(height, width, effect) {
    return await createThemedPasta(height, width, effect);
}

async function sparkle() {
    requestAnimationFrame(async () => {
        if (star.length === 0) {
            await updateCursorEffect();
        }

        if (!star[0] || !star[0].style || !currentEffectObj) {
            setTimeout(sparkle, 40);
            return;
        }

        if (currentCursorEffect === 'none') {
            setTimeout(sparkle, 40);
            return;
        }

        const userSettings = getUserSettings();
        if (currentCursorEffect !== 'none' && userSettings.auto_hide_particles) {
            const timeoutMs = (userSettings.auto_hide_timeout || 10) * 1000;
            const timeSinceLastMove = Date.now() - lastMouseMoveTime;
            if (!mouseOnScreen || timeSinceLastMove > timeoutMs) {
                if (!pastasPaused) {
                    pastasPaused = true;
                    for (let c = 0; c < getSparkles(); c++) {
                        if (star[c]) star[c].style.visibility = 'hidden';
                        if (tiny[c]) tiny[c].style.visibility = 'hidden';
                    }
                }
                setTimeout(sparkle, 200);
                return;
            }
        }

        if (pastasPaused) {
            pastasPaused = false;
            for (let c = 0; c < getSparkles(); c++) {
                if (star[c] && starv[c]) star[c].style.visibility = 'visible';
            }
        }

        if (currentEffectObj) {
            try {
                const particleSize = getCurrentParticleSize();
                const mutations = currentEffectObj.spawn({ x, y, screenBounds: { width: swide, height: shigh }, star, starv, particleSize });
                if (Array.isArray(mutations)) {
                    mutations.forEach(mutation => {
                        const i = mutation.index;
                        if (i >= 0 && i < star.length && star[i]) {
                            if (mutation.x !== undefined) {
                                starx[i] = mutation.x;
                                star[i].style.left = mutation.x + 'px';
                            }
                            if (mutation.y !== undefined) {
                                stary[i] = mutation.y;
                                star[i].style.top = mutation.y + 'px';
                            }
                            if (mutation.width !== undefined) star[i].style.width = mutation.width;
                            if (mutation.height !== undefined) star[i].style.height = mutation.height;
                            if (mutation.visibility !== undefined) star[i].style.visibility = mutation.visibility;
                            if (mutation.opacity !== undefined) star[i].style.opacity = mutation.opacity;
                            if (mutation.starv !== undefined) starv[i] = mutation.starv;
                            if (mutation.rotation !== undefined) starRotation[i] = mutation.rotation;
                            if (mutation.orbitAngle !== undefined) starOrbitAngle[i] = mutation.orbitAngle;
                            if (mutation.orbitRadius !== undefined) starOrbitRadius[i] = mutation.orbitRadius;
                            if (mutation.orbitSpeed !== undefined) starOrbitSpeed[i] = mutation.orbitSpeed;
                             if (mutation.velocityX !== undefined) starVelocityX[i] = mutation.velocityX;
                             if (mutation.velocityY !== undefined) starVelocityY[i] = mutation.velocityY;
                             if (mutation.particleOpacity !== undefined) starOpacity[i] = mutation.particleOpacity;
                             if (mutation.dataset) {
                                 Object.keys(mutation.dataset).forEach(key => {
                                     star[i].dataset[key] = mutation.dataset[key];
                                 });
                             }
                        }
                    });
                }
            } catch (error) {
                console.error('🎆 Error in effect spawn:', error);
            }
        }

        const currentTime = Date.now();
        const deltaTime = (currentTime - lastUpdateTime) / 1000;
        lastUpdateTime = currentTime;

        for (let c = 0; c < getSparkles(); c++) {
            if (starv[c] && star[c] && currentEffectObj) {
                const context = {
                    starv, star, starx, stary, starVelocityX, starVelocityY, starRotation, starOpacity, starBrightness, starPulsePhase,
                    sparkles: getSparkles(), x, y, pastasPaused, mouseDown, sleft, swide, shigh, sdown,
                    currentUserSettings: getUserSettings(), mouseDownTime, chargeLevel, deltaTime
                };

                try {
                    currentEffectObj.update(c, context);
                } catch (error) {
                    console.error('🎆 Error in effect update:', error);
                }
            }
            if (tinyv[c] && tiny[c] && currentEffectObj?.usesTinies) update_tiny(c);
        }
        setTimeout(sparkle, 40);
    });
}

function update_tiny(i) {
    tiny[i].style.visibility = 'hidden';
    tinyv[i] = 0;
}

function explode(clickX, clickY) {
    if (currentEffectObj && typeof currentEffectObj.explode === 'function') {
        currentEffectObj.explode(clickX, clickY);
        return;
    }
    
    const numExplosions = 10;
    let spawned = 0;
    for (let c = 0; c < getSparkles() && spawned < numExplosions; c++) {
        if (!starv[c] && star[c]) {
            star[c].style.left = (starx[c] = clickX) + 'px';
            star[c].style.top = (stary[c] = clickY) + 'px';
            star[c].style.width = '24px';
            star[c].style.height = '24px';
            star[c].style.visibility = 'visible';
            starv[c] = 20;
            starRotation[c] = Math.random() * 360;
            const angle = Math.random() * 2 * Math.PI;
            const speed = 2 + Math.random() * 3;
            starVelocityX[c] = Math.cos(angle) * speed;
            starVelocityY[c] = Math.sin(angle) * speed;
            starOpacity[c] = Math.random() < 0.5 ? 1 : 0.8;
            spawned++;
        }
    }
}

function mouse(e) {
    y = e ? e.pageY : event.y + sdown;
    x = e ? e.pageX : event.x + sleft;

    if (x !== lastMouseX || y !== lastMouseY) {
        lastMouseX = x;
        lastMouseY = y;
        lastMouseMoveTime = Date.now();
        pastasPaused = false;
    }

    const wasOnScreen = mouseOnScreen;
    mouseOnScreen = x >= 0 && x <= swide + sleft && y >= 0 && y <= shigh + sdown;

    if (wasOnScreen && !mouseOnScreen) {
        pastasPaused = true;
    }

    if (!wasOnScreen && mouseOnScreen && pastasPaused) {
        pastasPaused = false;
        if (currentEffectObj && currentEffectObj.resetOnScreenEnter) {
            const context = {
                starv, star, starx, stary, starVelocityX, starVelocityY, starRotation, starOpacity, starBrightness, starPulsePhase,
                sparkles: getSparkles(), x, y, pastasPaused, mouseDown, sleft, swide, shigh, sdown,
                currentUserSettings: getUserSettings(), chargeLevel
            };
            try {
                currentEffectObj.resetOnScreenEnter(context);
            } catch (error) {
                console.error('🎆 Error in resetOnScreenEnter:', error);
            }
        }
    }
}

function handleMouseDown(e) {
    mouseDown = true;
    mouseDownTime = Date.now();
    chargeLevel = 0;
}

function handleMouseUp(e) {
    mouseDown = false;
    const releaseX = e ? e.pageX : event.x + sleft;
    const releaseY = e ? e.pageY : event.y + sdown;

    const maxForce = 80 + chargeLevel * 120;
    for (let i = 0; i < getSparkles(); i++) {
        if (starv[i] && star[i]) {
            const dx = starx[i] - releaseX;
            const dy = stary[i] - releaseY;
            const distance = Math.sqrt(dx * dx + dy * dy);
            if (distance > 0) {
                const force = Math.min(maxForce / (distance + 5), maxForce / 2);
                const dirX = dx / distance;
                const dirY = dy / distance;
                starVelocityX[i] += dirX * force;
                starVelocityY[i] += dirY * force;
            }
        }
    }

    explode(releaseX, releaseY);
    chargeLevel = 0;
}

function set_scroll() {
    sdown = typeof(self.pageYOffset) === 'number' ? self.pageYOffset :
            document.body && (document.body.scrollTop || document.body.scrollLeft) ? document.body.scrollTop :
            document.documentElement && document.documentElement.scrollTop ? document.documentElement.scrollTop : 0;
    sleft = typeof(self.pageXOffset) === 'number' ? self.pageXOffset :
            document.body && document.body.scrollLeft ? document.body.scrollLeft :
            document.documentElement && document.documentElement.scrollLeft ? document.documentElement.scrollLeft : 0;
}

async function initPastaElements() {
    // Initialize arrays but don't create DOM elements yet
}

function updateCursorEffectGlow() {
    const userSettings = getUserSettings();
    const glowEnabled = userSettings.cursor_glow || false;
    
    for (let i = 0; i < getSparkles(); i++) {
        if (star[i]) {
            if (glowEnabled) {
                const existingFilter = star[i].style.filter || '';
                if (!existingFilter.includes('drop-shadow')) {
                    star[i].style.filter = existingFilter + ' drop-shadow(0 0 5px rgba(255, 255, 255, 0.8))';
                }
            } else {
                star[i].style.filter = (star[i].style.filter || '').replace(/ ?drop-shadow\(0 0 5px rgba\(255, 255, 255, 0\.8\)\)/, '');
            }
        }
        
        if (tiny[i]) {
            if (glowEnabled) {
                const existingFilter = tiny[i].style.filter || '';
                if (!existingFilter.includes('drop-shadow')) {
                    tiny[i].style.filter = existingFilter + ' drop-shadow(0 0 5px rgba(255, 255, 255, 0.8))';
                }
            } else {
                tiny[i].style.filter = (tiny[i].style.filter || '').replace(/ ?drop-shadow\(0 0 5px rgba\(255, 255, 255, 0\.8\)\)/, '');
            }
        }
    }
}

async function updateCursorEffectTheme() {
    const userSettings = getUserSettings();
    const particleStyle = userSettings.particle_style || 'theme';
    const theme = getCurrentTheme();
    const cursorParticle = userSettings.cursor_particle;
    const iconPath = cursorParticle && cursorParticle !== 'default' ? cursorParticle : DEFAULT_CURSOR_PATH;

    const isGif = iconPath.toLowerCase().endsWith('.gif');
    const isSvg = iconPath.toLowerCase().endsWith('.svg');

    for (let i = 0; i < getSparkles(); i++) {
        if (star[i]) {
            try {
                if (isGif) {
                    ParticleThemer.applyGifStyle(star[i], particleStyle, theme, currentEffectObj);
                } else if (isSvg) {
                    ParticleThemer.applySvgStyle(star[i], particleStyle, theme, currentEffectObj);
                } else {
                    const canvas = document.createElement('canvas');
                    const ctx = canvas.getContext('2d');
                    const img = new Image();

                    await new Promise((resolve, reject) => {
                        img.onload = resolve;
                        img.onerror = reject;
                        img.src = iconPath;
                    });

                    canvas.width = img.width;
                    canvas.height = img.height;
                    ctx.drawImage(img, 0, 0);

                    canvas.dataset.src = iconPath;
                    await ParticleThemer.applyCanvasStyle(canvas, particleStyle, theme, currentEffectObj);
                    star[i].src = canvas.toDataURL();
                }
            } catch (error) {
                console.warn('Failed to update cursor effect theme for star', i, error);
            }
        }

        if (tiny[i]) {
            try {
                if (isGif) {
                    ParticleThemer.applyGifStyle(tiny[i], particleStyle, theme, currentEffectObj);
                } else if (isSvg) {
                    ParticleThemer.applySvgStyle(tiny[i], particleStyle, theme, currentEffectObj);
                } else {
                    const canvas = document.createElement('canvas');
                    const ctx = canvas.getContext('2d');
                    const img = new Image();

                    await new Promise((resolve, reject) => {
                        img.onload = resolve;
                        img.onerror = reject;
                        img.src = iconPath;
                    });

                    canvas.width = img.width;
                    canvas.height = img.height;
                    ctx.drawImage(img, 0, 0);

                    canvas.dataset.src = iconPath;
                    await ParticleThemer.applyCanvasStyle(canvas, particleStyle, theme, currentEffectObj);
                    tiny[i].src = canvas.toDataURL();
                }
            } catch (error) {
                console.warn('Failed to update cursor effect theme for tiny', i, error);
            }
        }
    }

    updateCursorEffectGlow();
}

async function updateCursorEffectIcon() {
    const userSettings = getUserSettings();
    const cursorParticle = userSettings.cursor_particle;
    const iconPath = cursorParticle && cursorParticle !== 'default' ? cursorParticle : DEFAULT_CURSOR_PATH;

    const isGif = iconPath.toLowerCase().endsWith('.gif');
    const isSvg = iconPath.toLowerCase().endsWith('.svg');

    for (let i = 0; i < getSparkles(); i++) {
        if (star[i]) {
            try {
                if (isGif || isSvg) {
                    star[i].src = iconPath;
    } else {
        // For PNG and other image types, create img element directly
        const pastaImg = document.createElement('img');
        pastaImg.src = iconPath;
        pastaImg.className = 'pasta-img';
        pastaImg.style.position = 'absolute';
        pastaImg.style.height = height + 'px';
        pastaImg.style.width = width + 'px';
        pastaImg.style.pointerEvents = 'none';
        pastaImg.style.zIndex = '999';
        pastaImg.style.opacity = '1';

        // Apply theming synchronously for img elements
        ParticleThemer.applyStyle(pastaImg, 'none', theme, effect);
        return pastaImg;
    }

                if (userSettings.cursor_glow) {
                    star[i].style.filter = (star[i].style.filter || '') + ' drop-shadow(0 0 5px rgba(255, 255, 255, 0.8))';
                } else {
                    star[i].style.filter = star[i].style.filter.replace(/ drop-shadow\(0 0 5px rgba\(255, 255, 255, 0.8\)\)/, '');
                }
            } catch (error) {
                console.warn('Failed to update cursor effect icon for star', i, error);
            }
        }

        if (tiny[i]) {
            try {
                if (isGif || isSvg) {
                    tiny[i].src = iconPath;
                } else {
                    const canvas = document.createElement('canvas');
                    const ctx = canvas.getContext('2d');
                    const img = new Image();

                    await new Promise((resolve, reject) => {
                        img.onload = resolve;
                        img.onerror = reject;
                        img.src = iconPath;
                    });

                    canvas.width = img.width;
                    canvas.height = img.height;
                    ctx.drawImage(img, 0, 0);

                    await ParticleThemer.applyCanvasStyle(canvas, 'none', getCurrentTheme(), currentEffectObj);
                    tiny[i].src = canvas.toDataURL();
                }

                if (userSettings.cursor_glow) {
                    tiny[i].style.filter = (tiny[i].style.filter || '') + ' drop-shadow(0 0 5px rgba(255, 255, 255, 0.8))';
                } else {
                    tiny[i].style.filter = tiny[i].style.filter.replace(/ drop-shadow\(0 0 5px rgba\(255, 255, 255, 0.8\)\)/, '');
                }
            } catch (error) {
                console.warn('Failed to update cursor effect icon for tiny', i, error);
            }
        }
    }
}

window.updateCursorEffect = updateCursorEffect;
window.updateCursorEffectTheme = updateCursorEffectTheme;
window.updateCursorEffectIcon = updateCursorEffectIcon;
window.updateCursorEffectGlow = updateCursorEffectGlow;

function debounce(func, wait) {
    let timeout;
    return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}

function cleanupEventListeners() {
    window.removeEventListener('mousemove', mouse);
    window.removeEventListener('mousedown', handleMouseDown);
    window.removeEventListener('mouseup', handleMouseUp);
    window.removeEventListener('scroll', debouncedSetScroll);
    window.removeEventListener('resize', debouncedSetWidth);
    focusableInputs.forEach(selector => {
        const elements = document.querySelectorAll(selector);
        elements.forEach(el => {
            el.removeEventListener('focus', focusHandler);
            el.removeEventListener('select', focusHandler);
            el.removeEventListener('blur', blurHandler);
        });
    });
}

const focusableInputs = [
    '.message-input',
    '#username-input',
    '#password-input',
    '#prompt',
    '#width',
    '#height',
    '#steps',
    '#cfg_scale',
    '#clip_skip',
    '#negative_prompt'
];

const focusHandler = function() {
    this.style.cursor = `url(${DEFAULT_CURSOR_PATH}), auto`;
};

const blurHandler = function() {
    this.style.cursor = 'default';
};

console.log('🎆 Initializing particle effects system...');
initPastaElements();

if (window.currentUserSettings && window.currentUserSettings.cursor_effect) {
    console.log('🎆 Initializing with user cursor effect:', window.currentUserSettings.cursor_effect);
    updateCursorEffect();
} else {
    console.log('🎆 Initializing with default cursor effect');
    updateCursorEffect();
}

setTimeout(() => {
    const userSettings = getUserSettings();
    if (!userSettings.auto_hide_particles) {
        let visibleCount = 0;
        for (let c = 0; c < getSparkles(); c++) {
            if (star[c]) {
                star[c].style.visibility = 'visible';
                visibleCount++;
            }
            if (tiny[c]) {
                tiny[c].style.visibility = 'visible';
                visibleCount++;
            }
        }
        console.log('🎆 Made', visibleCount, 'particles visible initially');
    }
}, 100);

focusableInputs.forEach(selector => {
    const elements = document.querySelectorAll(selector);
    elements.forEach(el => {
        el.addEventListener('focus', focusHandler);
        el.addEventListener('select', focusHandler);
        el.addEventListener('blur', blurHandler);
    });
});

set_width();
lastMouseX = x;
lastMouseY = y;
lastMouseMoveTime = Date.now();
mouseOnScreen = true;
pastasPaused = false;

// Initialize mouse position to center of screen
x = window.innerWidth / 2;
y = window.innerHeight / 2;

const debouncedSetWidth = debounce(set_width, 100);
const debouncedSetScroll = debounce(set_scroll, 100);

sparkle();
window.addEventListener('mousemove', mouse);
window.addEventListener('mousedown', handleMouseDown);
window.addEventListener('mouseup', handleMouseUp);
window.addEventListener('scroll', debouncedSetScroll);
window.addEventListener('resize', debouncedSetWidth);

function clearAllParticles() {
    for (let i = 0; i < star.length; i++) {
        if (star[i]) {
            star[i].style.visibility = 'hidden';
            starv[i] = 0;
        }
        if (tiny[i]) {
            tiny[i].style.visibility = 'hidden';
            tinyv[i] = 0;
        }
    }
}

window.cleanupCursorEffects = cleanupEventListeners;
window.clearAllParticles = clearAllParticles;
