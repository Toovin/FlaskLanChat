import { star, starv, starx, stary, starVelocityX, starVelocityY, starOrbitAngle, starOrbitRadius, starRotation, starPulsePhase, pastasPaused } from '../effects.js';

export const RippleEffect = {
    sparkles: 12,
    init: function() {
        // Initialize any needed arrays if not already (but assuming global arrays are set)
    },
    spawn: function() {
        // No continuous spawning; ripples triggered via explode on click
        return [];
    },
    update: function(i, context) {
        const { deltaTime } = context || {};
        if (starv[i] && star[i]) {
            if (pastasPaused) {
                star[i].style.visibility = 'hidden';
                return;
            }
            const dt = deltaTime || 0.04; // ~25fps
            // Increment lifetime (in seconds)
            starOrbitRadius[i] += dt; // Repurpose orbitRadius as time alive (starts at 0)
            const lifetime = 2; // 2 second lifetime
            const normalizedTime = starOrbitRadius[i] / lifetime;
            if (normalizedTime >= 1) {
                star[i].style.visibility = 'hidden';
                starv[i] = 0;
                return;
            }
            // Expand position outwards from spawn point
            const expansionSpeed = 100; // px/second
            const radius = expansionSpeed * starOrbitRadius[i];
            starx[i] = starVelocityX[i] + Math.cos(starOrbitAngle[i]) * radius;
            stary[i] = starVelocityY[i] + Math.sin(starOrbitAngle[i]) * radius;
            // Sinewave for scale and opacity (in sync: larger scale = higher opacity)
            starPulsePhase[i] += 4 * Math.PI * dt; // Frequency: ~2 cycles per second (4π rad/s)
            const atten = 1 - normalizedTime; // Linear attenuation over lifetime
            const ampScale = 5 * atten; // Max ±5px, attenuating
            const ampOpacity = 0.5 * atten; // Max ±0.5, attenuating
            const sine = Math.sin(starPulsePhase[i]);
            const particleSize = window.currentUserSettings?.particle_size || 1.0;
            const baseScale = 10 * particleSize;
            const scale = baseScale + sine * ampScale;
            const baseOpacity = atten; // Overall fade
            const opacity = baseOpacity + sine * ampOpacity; // In sync with scale
            star[i].style.width = scale + 'px';
            star[i].style.height = scale + 'px';
            // Update rotation (optional gentle spin)
            starRotation[i] += 10 * dt; // 10 deg/second
            // Apply centralized ripple color effects
            const particleStyle = window.currentUserSettings?.particle_style || 'theme';

            window.ParticleColorManager.applyRippleColor(star[i], {}, particleStyle, sine, atten);
            // Update position and style
            star[i].style.left = starx[i] + 'px';
            star[i].style.top = stary[i] + 'px';
            star[i].style.transform = `rotate(${starRotation[i]}deg)`;
            star[i].style.visibility = 'visible';
        }
    },
    explode: function(clickX, clickY) {
        // Spawn 12 particles in a circle on click
        const batchSize = 12;
        let spawned = 0;
        for (let c = 0; c < this.sparkles && spawned < batchSize; c++) {
            if (!starv[c] && star[c]) {
                const angle = (spawned / batchSize) * 2 * Math.PI + Math.random() * 0.1; // Slight random for organic feel
                starOrbitAngle[c] = angle;
                starOrbitRadius[c] = 0; // Start time at 0
                starVelocityX[c] = clickX; // Store spawn point
                starVelocityY[c] = clickY;
                starx[c] = clickX;
                stary[c] = clickY;
                star[c].style.left = starx[c] + 'px';
                star[c].style.top = stary[c] + 'px';
                const particleSize = window.currentUserSettings?.particle_size || 1.0;
                const baseSize = 10 * particleSize;
                star[c].style.width = baseSize + 'px';
                star[c].style.height = baseSize + 'px';
                star[c].style.visibility = 'visible';
                star[c].style.opacity = '1';
                starv[c] = 9999; // Persistent until lifetime end
                starRotation[c] = Math.random() * 360;
                starPulsePhase[c] = Math.random() * Math.PI * 2; // Random phase
                spawned++;
            }
        }
    },
    resetOnScreenEnter: function() {
        // Clean up all ripples on screen re-enter
        for (let c = 0; c < this.sparkles; c++) {
            if (star[c] && starv[c]) {
                star[c].style.visibility = 'hidden';
                starv[c] = 0;
            }
        }
    },
    usesTinies: false // No tiny particles for ripple
};