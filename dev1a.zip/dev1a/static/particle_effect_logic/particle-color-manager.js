/**
 * Centralized particle color management system
 * Handles dynamic color effects for all cursor particle effects
 */

export const ParticleColorManager = {
    /**
     * Apply dynamic color effects to a particle based on style and animation state
     * @param {HTMLElement} star - The particle element
     * @param {Object} context - Animation context containing brightness, flicker, etc.
     * @param {string} particleStyle - The particle style ('none', 'neon', 'rainbow', 'theme', 'random')
     * @param {string} theme - Current theme name
     * @param {number} i - Particle index (for rainbow hue variation)
     */
    applyDynamicColor: function(star, context, particleStyle = 'theme', theme = 'dobo', i = 0) {
        const {
            starBrightness = 1,
            starPulsePhase = 0,
            flicker = 0,
            sine = 0,
            atten = 1
        } = context;

        let finalOpacity = star.style.opacity || 1;
        let brightnessFilter = '';
        let hueFilter = '';

        if (particleStyle === 'none') {
            // Dim particles over time for 'none' style
            if (Math.random() < 0.02) {
                starBrightness[i] = Math.random() * 0.5 + 0.5;
            } else {
                starBrightness[i] = Math.max(starBrightness[i] - 0.02, 0.7);
            }
            finalOpacity *= starBrightness[i];
        } else if (particleStyle === 'neon') {
            // Neon: bright pulsing effect
            starPulsePhase[i] += 0.1;
            const pulse = Math.sin(starPulsePhase[i]) * 0.3 + 0.7;
            finalOpacity *= pulse;
            starBrightness[i] = pulse;
            brightnessFilter = `brightness(${1 + pulse * 0.5})`;
        } else if (particleStyle === 'rainbow') {
            // Rainbow: rotating hues with brightness variation
            starPulsePhase[i] += 0.05;
            const pulse = Math.sin(starPulsePhase[i]) * 0.2 + 0.8;
            finalOpacity *= pulse;
            starBrightness[i] = pulse;

            if (!star.classList.contains('pasta-gif')) {
                const rainbowHue = (Date.now() * 0.05 + i * 60) % 360;
                hueFilter = `hue-rotate(${rainbowHue}deg) saturate(2) brightness(${1 + starBrightness[i] * 0.3})`;
            }
        } else {
            // Theme/Random: subtle brightness variation
            if (Math.random() < 0.02) {
                starBrightness[i] = Math.random() * 0.5 + 0.5;
            } else {
                starBrightness[i] = Math.max(starBrightness[i] - 0.02, 0.7);
            }
            finalOpacity *= starBrightness[i];
        }

        // Apply opacity
        star.style.opacity = finalOpacity;

        // Apply combined filters
        const combinedFilter = [hueFilter, brightnessFilter].filter(f => f).join(' ');
        if (!star.classList.contains('pasta-gif')) {
            star.style.filter = combinedFilter || '';
        }
    },

    /**
     * Apply ripple-specific color effects (sine-wave brightness syncing)
     * @param {HTMLElement} star - The particle element
     * @param {Object} context - Animation context
     * @param {string} particleStyle - The particle style
     * @param {number} sine - Sine wave value for ripple effect
     * @param {number} atten - Attenuation factor
     */
    applyRippleColor: function(star, context, particleStyle = 'theme', sine = 0, atten = 1) {
        const { starBrightness = 1 } = context;

        let brightnessFilter = '';

        if (particleStyle === 'neon') {
            brightnessFilter = `brightness(${1 + sine * 0.5 * atten})`;
        } else if (particleStyle === 'rainbow') {
            if (!star.classList.contains('pasta-gif')) {
                const rainbowHue = (Date.now() * 0.05) % 360;
                star.style.filter = `hue-rotate(${rainbowHue}deg) saturate(2) brightness(${1 + (sine * 0.15 + 0.85)})`;
            }
            return; // Rainbow handled completely here
        } else if (particleStyle !== 'none') {
            // Theme/random: subtle brightness sync
            brightnessFilter = `brightness(${1 + sine * 0.2 * atten})`;
        }

        if (brightnessFilter && !star.classList.contains('pasta-gif')) {
            star.style.filter = brightnessFilter;
        }
    },

    /**
     * Apply bubbles-specific color effects (pulsing opacity with style-based brightness)
     * @param {HTMLElement} star - The particle element
     * @param {Object} context - Animation context containing starPulsePhase
     * @param {string} particleStyle - The particle style
     * @param {number} i - Particle index
     */
    applyBubblesColor: function(star, context, particleStyle = 'theme', i = 0) {
        const { starPulsePhase, starBrightness } = context;

        // Calculate pulsing opacity (bubbles-specific)
        const finalOpacity = 0.5 + Math.sin(starPulsePhase[i] * 0.5) * 0.2;
        starBrightness[i] = finalOpacity;
        star.style.opacity = finalOpacity;

        // Apply style-based filter
        if (!star.classList.contains('pasta-gif')) {
            if (particleStyle === 'rainbow') {
                const rainbowHue = (Date.now() * 0.05 + i * 60) % 360;
                star.style.filter = `hue-rotate(${rainbowHue}deg) saturate(2) brightness(${1 + starBrightness[i] * 0.3})`;
            } else if (particleStyle === 'neon') {
                star.style.filter = `brightness(${1 + starBrightness[i] * 0.5})`;
            } else {
                star.style.filter = `brightness(${1 + starBrightness[i] * 0.2})`;
            }
        }
    },

    /**
     * Get the current particle style from user settings
     * @returns {string} The particle style
     */
    getCurrentParticleStyle: function() {
        return window.currentUserSettings?.particle_style || 'theme';
    },

    /**
     * Get the current theme
     * @returns {string} The theme name
     */
    getCurrentTheme: function() {
        const themeClasses = Array.from(document.documentElement.classList);
        const themeClass = themeClasses.find(cls => cls.startsWith('theme-'));
        return themeClass ? themeClass.replace('theme-', '') : 'dobo';
    }
};

// Legacy support - expose globally
window.ParticleColorManager = ParticleColorManager;