import { star, starv, starx, stary, starVelocityX, starVelocityY, starRotation, starOpacity, starBrightness, starPulsePhase, pastasPaused, swide, shigh, sleft, sdown } from '../effects.js';

export const FireworkEffect = {
    sparkles: 30,
    spawnTimer: 0,
    lastX: 0,
    lastY: 0,
    init: function() {
        this.spawnTimer = 0;
        this.lastX = 0;
        this.lastY = 0;
    },
    spawn: function(context) {
        return [];
    },
    update: function(i, context) {
        const { deltaTime } = context || {};
        if (starv[i] && star[i]) {
            if (pastasPaused) {
                star[i].style.visibility = 'hidden';
                return;
            }
            const dt = deltaTime || 0.04;
            // Apply gravity (adjusted for dt)
            starVelocityY[i] += 0.3 * (dt / 0.04);
            // Update position (scaled by dt)
            starx[i] += starVelocityX[i] * (dt / 0.04);
            stary[i] += starVelocityY[i] * (dt / 0.04);
            // Fade out quickly (fireworks are short-lived)
            starOpacity[i] = Math.max(starOpacity[i] - 0.015 * (dt / 0.04), 0);
            // Update rotation
            starRotation[i] += 15 * (dt / 0.04); // ~15 deg/frame
            // Apply centralized color effects
            const particleStyle = window.currentUserSettings?.particle_style || 'theme';
            const theme = window.ParticleColorManager.getCurrentTheme();

            window.ParticleColorManager.applyDynamicColor(star[i], {
                starBrightness,
                starPulsePhase,
                i
            }, particleStyle, theme, i);
            // Check for expiration or off-screen
            const currentOpacity = parseFloat(star[i].style.opacity) || 1;
            if (currentOpacity <= 0 || starx[i] < sleft - 50 || starx[i] > swide + sleft + 50 || stary[i] < -50 || stary[i] > shigh + sdown + 50) {
                star[i].style.visibility = 'hidden';
                starv[i] = 0;
            } else {
                star[i].style.left = starx[i] + 'px';
                star[i].style.top = stary[i] + 'px';
                star[i].style.transform = `rotate(${starRotation[i]}deg)`;
                star[i].style.visibility = 'visible';
            }
        }
    },
    explode: function(clickX, clickY) {
        let spawned = 0;
        const numBursts = 30;
        for (let c = 0; c < this.sparkles && spawned < numBursts; c++) {
            if (!starv[c] && star[c]) {
                starx[c] = clickX;
                stary[c] = clickY;
                star[c].style.left = clickX + 'px';
                star[c].style.top = clickY + 'px';
                star[c].style.width = '20px';
                star[c].style.height = '20px';
                star[c].style.visibility = 'visible';
                starv[c] = 1;
                starRotation[c] = Math.random() * 360;
                const angle = Math.random() * 2 * Math.PI;
                const speed = 8 + Math.random() * 12;
                starVelocityX[c] = Math.cos(angle) * speed;
                starVelocityY[c] = Math.sin(angle) * speed - 3;
                starOpacity[c] = 1;
                starBrightness[c] = 1;
                starPulsePhase[c] = Math.random() * Math.PI * 2;
                spawned++;
            }
        }
    },
    resetOnScreenEnter: function() {
        // Clean up all particles on screen re-enter to prevent leftovers
        for (let c = 0; c < this.sparkles; c++) {
            if (star[c] && starv[c]) {
                star[c].style.visibility = 'hidden';
                starv[c] = 0;
            }
        }
    },
    usesTinies: false
};