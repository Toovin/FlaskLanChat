export const OrbitingEffect = {
    sparkles: 5,
    spawn: function(context) {
        const { x: mouseX, y: mouseY, screenBounds, star, starv, particleSize = 1.0 } = context;
        const mutations = [];

        for (let c = 0; c < this.sparkles; c++) {
            if (!starv[c] && star[c]) {
                const angle = (c / this.sparkles) * 2 * Math.PI;
                const radius = 75 + Math.random() * 30;
                const speed = 0.02 + Math.random() * 0.01;

                const newX = mouseX + Math.cos(angle) * radius;
                const newY = mouseY + Math.sin(angle) * radius;

                const baseSize = 20 * particleSize;
                mutations.push({
                    index: c,
                    x: newX,
                    y: newY,
                    width: baseSize + 'px',
                    height: baseSize + 'px',
                    visibility: 'visible',
                    opacity: '0.8',
                    starv: 1,
                    rotation: angle * (180 / Math.PI),
                    orbitAngle: angle,
                    orbitRadius: radius,
                    orbitSpeed: speed,
                    velocityX: -Math.sin(angle) * speed * 50,
                    velocityY: Math.cos(angle) * speed * 50,
                    particleOpacity: 0.8
                });
            }
        }

        return mutations;
    },
    update: function(i, context) {
        const { starv, star, starx, stary, starVelocityX, starVelocityY, starRotation, starOpacity, starBrightness, starPulsePhase, sparkles, x, y, pastasPaused, mouseDown, sleft, swide, shigh, sdown, currentUserSettings, mouseDownTime, chargeLevel, deltaTime } = context;

        if (starv[i] && star[i]) {
            if (pastasPaused) {
                star[i].style.visibility = 'hidden';
                return;
            }

            const mouseDx = x - starx[i];
            const mouseDy = y - stary[i];
            const mouseDistance = Math.sqrt(mouseDx * mouseDx + mouseDy * mouseDy);
            let mouseAccelX = 0;
            let mouseAccelY = 0;
            if (mouseDistance > 0) {
                const mouseForce = Math.min(mouseDistance * 0.01, 2);
                mouseAccelX = (mouseDx / mouseDistance) * mouseForce;
                mouseAccelY = (mouseDy / mouseDistance) * mouseForce;
            }

            let repelAccelX = 0;
            let repelAccelY = 0;
            for (let j = 0; j < sparkles; j++) {
                if (i !== j && starv[j]) {
                    const dx = starx[i] - starx[j];
                    const dy = stary[i] - stary[j];
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    if (distance > 0 && distance < 40) {
                        const force = (40 - distance) * 0.02;
                        repelAccelX += (dx / distance) * force;
                        repelAccelY += (dy / distance) * force;
                    }
                }
            }

            starVelocityX[i] += (mouseAccelX + repelAccelX) * deltaTime;
            starVelocityY[i] += (mouseAccelY + repelAccelY) * deltaTime;

            if (mouseDown) {
                const dx = starx[i] - x;
                const dy = stary[i] - y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                if (distance > 0) {
                    const outwardForce = 2 * (1 + chargeLevel * 2) * deltaTime;
                    starVelocityX[i] += (dx / distance) * outwardForce;
                    starVelocityY[i] += (dy / distance) * outwardForce;

                    const perpDx = -dy;
                    const perpDy = dx;
                    const perpDistance = Math.sqrt(perpDx * perpDx + perpDy * perpDy);
                    if (perpDistance > 0) {
                        const swirlForce = 1.5 * (1 + chargeLevel) * deltaTime;
                        starVelocityX[i] += (perpDx / perpDistance) * swirlForce;
                        starVelocityY[i] += (perpDy / perpDistance) * swirlForce;
                    }
                }
            }

            const damping = mouseDown ? 0.99 : 0.98;
            starVelocityX[i] *= Math.pow(damping, deltaTime * 60);
            starVelocityY[i] *= Math.pow(damping, deltaTime * 60);

            starx[i] += starVelocityX[i] * deltaTime * 60;
            stary[i] += starVelocityY[i] * deltaTime * 60;

            const speed = Math.sqrt(starVelocityX[i] * starVelocityX[i] + starVelocityY[i] * starVelocityY[i]);
            const rotationMultiplier = mouseDown ? 30 * (1 + chargeLevel) : 10;
            starRotation[i] += speed * rotationMultiplier * deltaTime;

            // Apply centralized color effects
            const particleStyle = currentUserSettings?.particle_style || 'theme';
            const theme = window.ParticleColorManager.getCurrentTheme();

            window.ParticleColorManager.applyDynamicColor(star[i], {
                starBrightness,
                starPulsePhase,
                i
            }, particleStyle, theme, i);

            starOpacity[i] = 0.8;

            if (starx[i] < sleft) {
                starx[i] = sleft;
                starVelocityX[i] *= -1;
            } else if (starx[i] > swide + sleft) {
                starx[i] = swide + sleft;
                starVelocityX[i] *= -1;
            }
            if (stary[i] < sdown) {
                stary[i] = sdown;
                starVelocityY[i] *= -1;
            } else if (stary[i] > shigh + sdown) {
                stary[i] = shigh + sdown;
                starVelocityY[i] *= -1;
            }

            star[i].style.left = starx[i] + 'px';
            star[i].style.top = stary[i] + 'px';
            star[i].style.transform = `rotate(${starRotation[i]}deg)`;
            star[i].style.visibility = 'visible';
        }
    },
    resetOnScreenEnter: function(context) {
        const { star, starv, starx, stary, starVelocityX, starVelocityY, x, y } = context;
        for (let c = 0; c < this.sparkles; c++) {
            if (star[c] && starv[c]) {
                starx[c] = x + (Math.random() - 0.5) * 100;
                stary[c] = y + (Math.random() - 0.5) * 100;
                starVelocityX[c] = 0;
                starVelocityY[c] = 0;
                star[c].style.left = starx[c] + 'px';
                star[c].style.top = stary[c] + 'px';
                star[c].style.visibility = 'visible';
            }
        }
    }
};