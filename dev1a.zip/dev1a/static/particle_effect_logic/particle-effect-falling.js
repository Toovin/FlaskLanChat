import { tiny, star, tinyv, starv, tinyx, tinyy, starx, stary, tinyVelocityX, tinyVelocityY, starVelocityX, starVelocityY, tinyRotation, starRotation, tinyOpacity, starOpacity, pastasPaused, x, y, swide, shigh, sleft, sdown } from '../effects.js';

export const FallingEffect = {
    sparkles: 99,
    usesTinies: true,
    lastX: 0,
    lastY: 0,
    spawn: function() {
        if (Math.abs(x - this.lastX) > 1 || Math.abs(y - this.lastY) > 1) {
            this.lastX = x;
            this.lastY = y;
            const particleSize = window.currentUserSettings?.particle_size || 1.0;
            const baseSize = 24 * particleSize;
            for (let c = 0; c < this.sparkles; c++) {
                if (!starv[c] && star[c]) {
                    star[c].style.left = (starx[c] = x) + 'px';
                    star[c].style.top = (stary[c] = y + 1) + 'px';
                    star[c].style.width = baseSize + 'px';
                    star[c].style.height = baseSize + 'px';
                    star[c].style.visibility = 'visible';
                    star[c].style.opacity = '1';
                    starv[c] = 20;
                    starRotation[c] = 0;
                    starVelocityX[c] = 0;
                    starVelocityY[c] = 0;
                    starOpacity[c] = 1;
                    break;
                }
            }
        }
    },
    update: function(i, context) {
        if (starv[i] && star[i]) {
            if (pastasPaused) {
                star[i].style.visibility = 'hidden';
                return;
            }

            // Original falling behavior
            if (--starv[i] === 10) {
                const particleSize = window.currentUserSettings?.particle_size || 1.0;
                const baseSize = 12 * particleSize;
                star[i].style.width = baseSize + 'px';
                star[i].style.height = baseSize + 'px';
            }
            if (starv[i]) {
                stary[i] += starVelocityY[i] || (1 + Math.random() * 4);
                starx[i] += starVelocityX[i] || ((i % 5 - 2) / 4);
                starRotation[i] += 10;
                starOpacity[i] = starOpacity[i] !== undefined ? Math.max(starOpacity[i] - 0.05, 0) : 1;
                if (stary[i] < shigh + sdown && starx[i] < swide + sleft && starx[i] > 0 && starOpacity[i] > 0) {
                    star[i].style.top = stary[i] + 'px';
                    star[i].style.left = starx[i] + 'px';
                    star[i].style.transform = `rotate(${starRotation[i]}deg)`;
                    star[i].style.opacity = starOpacity[i];
                    // Skip additional filter application for GIF particles to preserve animation
                    // (falling effect doesn't apply filters, so no change needed here)
                } else {
                    star[i].style.visibility = 'hidden';
                    starv[i] = 0;
                }
                if (starOpacity[i] <= 0) {
                    star[i].style.visibility = 'hidden';
                    starv[i] = 0;
                }
            } else {
                if (tiny[i]) {
                    tinyv[i] = 15;
                    tiny[i].style.top = (tinyy[i] = stary[i]) + 'px';
                    tiny[i].style.left = (tinyx[i] = starx[i]) + 'px';
                    const particleSize = window.currentUserSettings?.particle_size || 1.0;
                    const tinySize = 8 * particleSize;
                    tiny[i].style.width = tinySize + 'px';
                    tiny[i].style.height = tinySize + 'px';
                    tinyRotation[i] = starRotation[i];
                    tinyVelocityX[i] = starVelocityX[i];
                    tinyVelocityY[i] = starVelocityY[i];
                    tinyOpacity[i] = starOpacity[i];
                    tiny[i].style.visibility = 'visible';
                }
                star[i].style.visibility = 'hidden';
            }
        }
    }
};