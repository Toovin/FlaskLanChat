import { star, starv, starx, stary, starRotation, starOpacity, starBrightness, starPulsePhase, pastasPaused, mouseDown, x, y, chargeLevel } from '../effects.js';

export const CometEffect = {
    sparkles: 10,
    spawn: function(context) {
        const { x: mouseX, y: mouseY, particleSize = 1.0 } = context;
        const mutations = [];
        // Initialize comet tail particles if not already active
        for (let c = 0; c < this.sparkles; c++) {
            if (!starv[c] && star[c]) {
                const newX = mouseX;
                const newY = mouseY;
                const baseSize = 16 * particleSize;
                mutations.push({
                    index: c,
                    x: newX,
                    y: newY,
                    width: baseSize + 'px',
                    height: baseSize + 'px',
                    visibility: 'visible',
                    opacity: '1',
                    starv: 9999,
                    rotation: 0,
                    particleOpacity: 1
                });
            }
        }
        return mutations;
    },
    update: function(i, context) {
        const { deltaTime } = context || {};
        if (starv[i] && star[i]) {
            if (pastasPaused) {
                star[i].style.visibility = 'hidden';
                return;
            }
            const dt = deltaTime || 0.04;
            // Comet tail: each particle lags behind the previous one
            let targetX = x;
            let targetY = y;
            if (i > 0 && starv[i-1]) {
                // Follow the previous particle for chain effect
                targetX = starx[i-1];
                targetY = stary[i-1];
            }
            // Alpha lag: higher index = more lag (stretchier tail)
            const alpha = 0.97 - i * 0.03; // 0.97 for first (very close to cursor), down to ~0.70 for last
            starx[i] = starx[i] * alpha + targetX * (1 - alpha);
            stary[i] = stary[i] * alpha + targetY * (1 - alpha);
            // Gentle rotation and fade/size for tail
            starRotation[i] += 5 * dt; // Slow spin
            let tailOpacity = 1 - (i / this.sparkles) * 0.7; // Fade out towards end of tail
            let tailSize = 16 - (i / this.sparkles) * 8; // Slight size decrease for tapering tail (16px to ~8px)
            if (mouseDown) {
                tailOpacity *= (1 - chargeLevel * 0.5); // Dim during charge
                tailSize += chargeLevel * 4; // Slight swell during charge
            }
            star[i].style.width = tailSize + 'px';
            star[i].style.height = tailSize + 'px';
            // Apply centralized color effects
            const particleStyle = window.currentUserSettings?.particle_style || 'theme';
            const theme = window.ParticleColorManager.getCurrentTheme();

            window.ParticleColorManager.applyDynamicColor(star[i], {
                starBrightness,
                starPulsePhase,
                i
            }, particleStyle, theme, i);

            // Keep base opacity
            starOpacity[i] = tailOpacity;
            // Update position and style
            star[i].style.left = starx[i] + 'px';
            star[i].style.top = stary[i] + 'px';
            star[i].style.transform = `rotate(${starRotation[i]}deg)`;
            star[i].style.visibility = 'visible';
        }
    },
    resetOnScreenEnter: function() {
        // Reset comet particles to cursor position
        for (let c = 0; c < this.sparkles; c++) {
            if (star[c] && starv[c]) {
                starx[c] = x;
                stary[c] = y;
                star[c].style.left = starx[c] + 'px';
                star[c].style.top = stary[c] + 'px';
                star[c].style.visibility = 'visible';
            }
        }
    },
    usesTinies: false // No tiny particles for comet
};