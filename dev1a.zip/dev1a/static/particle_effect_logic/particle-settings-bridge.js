export function getParticleSettings() {
    if (window.unifiedSettingsManager) {
        const settings = window.unifiedSettingsManager.getSettings();
        return {
            particle_style: settings.particle_style || 'theme',
            particle_size: settings.particle_size || 1.0,
            cursor_glow: settings.cursor_glow || false,
            auto_hide_particles: settings.auto_hide_particles || false,
            auto_hide_timeout: settings.auto_hide_timeout || 10,
            cursor_effect: settings.cursor_effect || 'orbiting'
        };
    }
    
    if (window.currentUserSettings) {
        return {
            particle_style: window.currentUserSettings.particle_style || 'theme',
            particle_size: window.currentUserSettings.particle_size || 1.0,
            cursor_glow: window.currentUserSettings.cursor_glow || false,
            auto_hide_particles: window.currentUserSettings.auto_hide_particles || false,
            auto_hide_timeout: window.currentUserSettings.auto_hide_timeout || 10,
            cursor_effect: window.currentUserSettings.cursor_effect || 'orbiting'
        };
    }
    
    return {
        particle_style: 'theme',
        particle_size: 1.0,
        cursor_glow: false,
        auto_hide_particles: false,
        auto_hide_timeout: 10,
        cursor_effect: 'orbiting'
    };
}

export function applyParticleSize(element, baseSize, settings = null) {
    if (!element) return;
    
    const particleSettings = settings || getParticleSettings();
    const scaledSize = baseSize * particleSettings.particle_size;
    
    element.style.width = `${scaledSize}px`;
    element.style.height = `${scaledSize}px`;
}

export function applyParticleStyle(element, settings = null) {
    if (!element) return;
    
    const particleSettings = settings || getParticleSettings();
    
    if (particleSettings.cursor_glow) {
        const existingFilter = element.style.filter || '';
        if (!existingFilter.includes('drop-shadow')) {
            element.style.filter = existingFilter + ' drop-shadow(0 0 5px rgba(255, 255, 255, 0.8))';
        }
    } else {
        element.style.filter = (element.style.filter || '').replace(/ ?drop-shadow\(0 0 5px rgba\(255, 255, 255, 0\.8\)\)/, '');
    }
}

export function getScaledSize(baseSize, settings = null) {
    const particleSettings = settings || getParticleSettings();
    return baseSize * particleSettings.particle_size;
}

window.getParticleSettings = getParticleSettings;
window.applyParticleSize = applyParticleSize;
window.applyParticleStyle = applyParticleStyle;
window.getScaledSize = getScaledSize;
