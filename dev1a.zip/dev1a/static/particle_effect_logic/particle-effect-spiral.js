import { star, starv, starx, stary, starOrbitAngle, starOrbitRadius, starRotation, starOpacity, starBrightness, starPulsePhase, pastasPaused, mouseDown, x, y, chargeLevel } from '../effects.js';

export const SpiralEffect = {
    sparkles: 9,
    globalAngle: 0, // Initialized in init
    init: function() {
        this.globalAngle = 0;
    },
    spawn: function(context) {
        const { x: mouseX, y: mouseY, particleSize = 1.0 } = context;
        const mutations = [];
        const numArms = 3;
        const particlesPerArm = 3;
        // Initialize spiral arm particles if not already active
        for (let c = 0; c < this.sparkles; c++) {
            if (!starv[c] && star[c]) {
                const arm = Math.floor(c / particlesPerArm);
                const posInArm = c % particlesPerArm;
                // Spiral configuration: base arm angle + twist for bendy arm
                const twist = posInArm * (Math.PI / 2);
                const angle = (arm / numArms) * 2 * Math.PI + twist;
                const radius = 30 + posInArm * 35 + Math.random() * 15;
                const newX = mouseX + Math.cos(angle) * radius;
                const newY = mouseY + Math.sin(angle) * radius;
                const baseSize = 16 * particleSize;
                mutations.push({
                    index: c,
                    x: newX,
                    y: newY,
                    width: baseSize + 'px',
                    height: baseSize + 'px',
                    visibility: 'visible',
                    opacity: '1',
                    starv: 9999,
                    rotation: 0,
                    orbitAngle: angle,
                    orbitRadius: radius,
                    particleOpacity: 1
                });
            }
        }
        return mutations;
    },
    update: function(i, context) {
        const { deltaTime } = context || {};
        if (starv[i] && star[i]) {
            if (pastasPaused) {
                star[i].style.visibility = 'hidden';
                return;
            }
            const dt = deltaTime || 0.04;
            this.globalAngle += 0.1 * dt; // Spin speed adjustment (0.1 rad/frame)
            const particlesPerArm = 3;
            const arm = Math.floor(i / particlesPerArm);
            const posInArm = i % particlesPerArm;
            const alpha = 0.9 + posInArm * 0.03; // Higher alpha for outer particles = more lag/stretch
            let radius = starOrbitRadius[i];
            if (mouseDown) {
                radius += chargeLevel * 50; // Outward push during charge
                this.globalAngle += 0.2 * dt * (1 + chargeLevel); // Faster spin during charge
            }
            const target_angle = this.globalAngle + (arm / 3) * 2 * Math.PI + posInArm * (Math.PI / 2);
            const target_x = x + Math.cos(target_angle) * radius;
            const target_y = y + Math.sin(target_angle) * radius;
            starx[i] = starx[i] * alpha + target_x * (1 - alpha);
            stary[i] = stary[i] * alpha + target_y * (1 - alpha);
            starRotation[i] += 10 * dt; // Gentle individual rotation
            // Apply centralized color effects
            const particleStyle = window.currentUserSettings?.particle_style || 'theme';
            const theme = window.ParticleColorManager.getCurrentTheme();

            window.ParticleColorManager.applyDynamicColor(star[i], {
                starBrightness,
                starPulsePhase,
                i
            }, particleStyle, theme, i);

            // Keep opacity high for spiral particles
            starOpacity[i] = 1;
            // Update position and style
            star[i].style.left = starx[i] + 'px';
            star[i].style.top = stary[i] + 'px';
            star[i].style.transform = `rotate(${starRotation[i]}deg)`;
            star[i].style.visibility = 'visible';
        }
    },
    resetOnScreenEnter: function() {
        // Reset spiral particles near mouse position
        for (let c = 0; c < this.sparkles; c++) {
            if (star[c] && starv[c]) {
                const angle = Math.random() * 2 * Math.PI;
                const radius = 40 + Math.random() * 40;
                starx[c] = x + Math.cos(angle) * radius;
                stary[c] = y + Math.sin(angle) * radius;
                star[c].style.left = starx[c] + 'px';
                star[c].style.top = stary[c] + 'px';
                star[c].style.visibility = 'visible';
            }
        }
    },
    usesTinies: false // No tiny particles for spiral
};