import { star, starv, starx, stary, starVelocityX, starVelocityY, starRotation, starOpacity, starBrightness, starPulsePhase, pastasPaused, x, y, swide, shigh, sleft, sdown, mouseDown } from '../effects.js';

export const BubblesEffect = {
    sparkles: 50,
    spawnTimer: 0,
    floatyTimer: 0,
    init: function() {
        this.spawnTimer = 0;
        this.floatyTimer = 0;
    },
    spawn: function(context) {
        const { x: mouseX, y: mouseY, particleSize = 1.0 } = context;
        const mutations = [];

        // Main bubble spawning (from bottom)
        this.spawnTimer--;
        if (this.spawnTimer <= 0) {
            let activeCount = 0;
            for (let c = 0; c < this.sparkles; c++) {
                if (starv[c]) activeCount++;
            }

            if (activeCount < this.sparkles) {
                for (let c = 0; c < this.sparkles; c++) {
                    if (!starv[c] && star[c]) {
                        const spawnX = sleft + Math.random() * swide;
                        const spawnY = shigh + sdown;
                        const bubbleSize = (30 + Math.random() * 20) * particleSize;
                        const upwardSpeed = -(1.5 + Math.random() * 1.5);

                        mutations.push({
                            index: c,
                            x: spawnX,
                            y: spawnY,
                            width: bubbleSize + 'px',
                            height: bubbleSize + 'px',
                            visibility: 'visible',
                            opacity: 0.6,
                            starv: 9999,
                            rotation: 0,
                            velocityX: (Math.random() - 0.5) * 1.5,
                            velocityY: upwardSpeed,
                            particleOpacity: 0.6,
                            pulsePhase: Math.random() * Math.PI * 2,
                            isFloaty: false, // Mark as main bubble
                            dataset: { isFloaty: 'false' }
                        });

                        this.spawnTimer = 10 + Math.floor(Math.random() * 20);
                        break;
                    }
                }
            }
        }

        // Floaty spawning (when mouse down, smaller bubbles from cursor)
        if (mouseDown) {
            this.floatyTimer--;
            if (this.floatyTimer <= 0) {
                let activeCount = 0;
                for (let c = 0; c < this.sparkles; c++) {
                    if (starv[c]) activeCount++;
                }

                if (activeCount < this.sparkles) {
                    for (let c = 0; c < this.sparkles; c++) {
                        if (!starv[c] && star[c]) {
                            const spawnX = mouseX + (Math.random() - 0.5) * 20;
                            const spawnY = mouseY + (Math.random() - 0.5) * 20;
                            const floatySize = (8 + Math.random() * 8) * particleSize;
                            const upwardSpeed = -(0.8 + Math.random() * 0.8);

                            mutations.push({
                                index: c,
                                x: spawnX,
                                y: spawnY,
                                width: floatySize + 'px',
                                height: floatySize + 'px',
                                visibility: 'visible',
                                opacity: 0.4,
                                starv: 9999,
                                rotation: 0,
                                velocityX: (Math.random() - 0.5) * 2,
                                velocityY: upwardSpeed,
                                particleOpacity: 0.4,
                                pulsePhase: Math.random() * Math.PI * 2,
                                isFloaty: true, // Mark as floaty
                                dataset: { isFloaty: 'true' }
                            });

                            this.floatyTimer = 15; // ~0.5 seconds at 30fps
                            break;
                        }
                    }
                }
            }
        } else {
            // Reset floaty timer when mouse is not down
            this.floatyTimer = 0;
        }

        return mutations;
    },
    update: function(i, context) {
        const { deltaTime } = context || {};
        if (starv[i] && star[i]) {
            if (pastasPaused) {
                star[i].style.visibility = 'hidden';
                return;
            }

            const dt = deltaTime || 0.04;
            const isFloaty = star[i].dataset.isFloaty === 'true';

            starVelocityX[i] += (Math.random() - 0.5) * 0.3 * dt * 60;
            starVelocityX[i] *= Math.pow(0.98, dt * 60);

            starx[i] += starVelocityX[i] * dt * 60;
            stary[i] += starVelocityY[i] * dt * 60;

            if (starx[i] < sleft) {
                starx[i] = sleft;
                starVelocityX[i] *= -0.8;
            } else if (starx[i] > swide + sleft) {
                starx[i] = swide + sleft;
                starVelocityX[i] *= -0.8;
            }

            if (stary[i] < sdown - 50) {
                star[i].style.visibility = 'hidden';
                starv[i] = 0;
                return;
            }

            // Different scaling for floaties vs main bubbles
            const scaleMultiplier = isFloaty ? 0.1 : 0.15;
            const scale = 1 + Math.sin(starPulsePhase[i]) * scaleMultiplier;
            starPulsePhase[i] += 0.05 * dt * 60;

            // Apply centralized bubbles color effects
            const particleStyle = window.currentUserSettings?.particle_style || 'theme';

            window.ParticleColorManager.applyBubblesColor(star[i], {
                starPulsePhase,
                starBrightness,
                i
            }, particleStyle, i);

            star[i].style.left = starx[i] + 'px';
            star[i].style.top = stary[i] + 'px';
            star[i].style.transform = `scale(${scale}) rotate(${starRotation[i]}deg)`;

            star[i].style.visibility = 'visible';
        }
    },
    resetOnScreenEnter: function() {
        for (let c = 0; c < this.sparkles; c++) {
            if (star[c] && starv[c]) {
                star[c].style.visibility = 'hidden';
                starv[c] = 0;
            }
        }
    },
    usesTinies: false
};
