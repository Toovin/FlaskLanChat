// ai-settings-modal.js - AI Settings Modal Management
class AISettingsModal {
    constructor(modalInstance) {
        this.modal = modalInstance;
        this.currentSettings = null;
    }

    // Initialize settings modal
    init() {
        // Settings modal initialization - events are bound by orchestrator
        return Promise.resolve();
    }

    // Show the settings modal
    show() {
        // Check if settings modal already exists
        const existingModal = document.getElementById('ai-settings-modal');
        const isNewModal = !existingModal;

        if (isNewModal) {
            // Create settings modal HTML
            const settingsHTML = `
                <div id="ai-settings-modal" class="modal">
                    <div class="modal-content ai-settings-modal-content">
                        <div class="modal-header">
                            <h2>AI Settings</h2>
                            <span class="close-modal">&times;</span>
                        </div>

                        <style>
                            .settings-tabs {
                                display: flex;
                                border-bottom: 1px solid #ddd;
                                margin-bottom: 20px;
                            }
                            .tab-button {
                                background: none;
                                border: none;
                                padding: 10px 20px;
                                cursor: pointer;
                                border-bottom: 2px solid transparent;
                                transition: border-color 0.3s;
                            }
                            .tab-button.active {
                                border-bottom-color: #007bff;
                                color: #007bff;
                            }
                            .tab-content {
                                display: none;
                            }
                            .tab-content.active {
                                display: block;
                            }
                            .channel-setting-item {
                                border: 1px solid #ddd;
                                padding: 15px;
                                margin-bottom: 10px;
                                border-radius: 5px;
                            }
                            .channel-setting-item h4 {
                                margin-top: 0;
                                color: #333;
                            }
                        </style>

                        <div class="ai-settings-content">
                             <!-- Tab Navigation -->
                             <div class="settings-tabs">
                                 <button class="tab-button active" data-tab="ai-behavior">AI Behavior</button>
                                 <button class="tab-button" data-tab="channels">Channels</button>
                                 <button class="tab-button" data-tab="system">System</button>
                             </div>

                             <form id="ai-settings-form">
                                 <!-- AI Behavior Tab -->
                                  <div class="tab-content active" id="ai-behavior-tab">
                                      <div class="settings-section">
                                          <h3>AI Behavior</h3>

                                          <div class="form-group">
                                              <label for="ai-custom-instructions">Custom Instructions (when no character selected):</label>
                                              <textarea id="ai-custom-instructions" name="ai_custom_instructions"
                                                        placeholder="Add specific instructions for how the AI should behave when using default settings..."
                                                        rows="3"></textarea>
                                              <small style="color: #666;">Persistent issues? Try refreshing the page after saving.</small>
                                          </div>

                                         <div class="form-group">
                                             <label for="ai-system-prompt">System Prompt (when no character selected):</label>
                                             <textarea id="ai-system-prompt" name="ai_system_prompt"
                                                       placeholder="Override the default system prompt when using default settings..."
                                                       rows="2"></textarea>
                                         </div>
                                     </div>

                                     <div class="settings-section">
                                         <h3>Context Management</h3>

                                         <div class="form-group">
                                             <label for="ai-context-management-mode">Context Management Mode:</label>
                                             <select id="ai-context-management-mode" name="ai_context_management_mode">
                                                 <option value="client">Client-side Context (Default)</option>
                                                 <option value="api">API-side Context (LM Studio)</option>
                                             </select>
                                             <small>Client-side: App manages conversation history. API-side: LM Studio manages context (more efficient for long conversations)</small>
                                         </div>

                                         <div class="form-group">
                                             <label for="ai-api-debug">
                                                 <input type="checkbox" id="ai-api-debug" name="ai_api_debug">
                                                 Enable API Debug Logging
                                             </label>
                                             <small>Log detailed API requests and responses to server console (can be verbose)</small>
                                         </div>

                                          <div class="form-group">
                                              <label for="ai-history-limit">Global Context Limit:</label>
                                              <input type="number" id="ai-history-limit" name="ai_history_limit"
                                                      min="1" max="100" value="50">
                                              <small>Maximum number of messages to include in context for modal/DM conversations</small>
                                          </div>

                                          <div class="form-group">
                                              <label for="ai-modal-memory-enabled">
                                                  <input type="checkbox" id="ai-modal-memory-enabled" name="ai_modal_memory_enabled" checked>
                                                  Enable Modal Memory
                                              </label>
                                              <small>Include conversation history in modal AI chat responses</small>
                                          </div>

                                          <div class="form-group" id="modal-memory-limit-group">
                                              <label for="ai-modal-memory-limit">Modal Memory Messages:</label>
                                              <input type="number" id="ai-modal-memory-limit" name="ai_modal_memory_limit"
                                                      min="1" max="50" value="15">
                                              <small>Number of recent messages to include in modal AI context</small>
                                          </div>

                                          <div class="form-group">
                                              <label for="ai-channel-memory-enabled">
                                                  <input type="checkbox" id="ai-channel-memory-enabled" name="ai_channel_memory_enabled">
                                                  Enable Channel Memory
                                              </label>
                                              <small>Allow AI to remember recent channel messages for context when mentioned</small>
                                          </div>

                                          <div class="form-group" id="channel-memory-limit-group" style="display: none;">
                                              <label for="ai-channel-memory-limit">Channel Context Limit:</label>
                                              <input type="number" id="ai-channel-memory-limit" name="ai_channel_memory_limit"
                                                      min="0" max="50" value="10">
                                              <small>Number of recent text messages to include for channel AI conversations</small>
                                          </div>
                                      </div>

                                      <div class="settings-section">
                                          <h3>Advanced Customization</h3>

                                          <div class="form-group">
                                              <label for="ai-system-prepend">System Prompt Prepend:</label>
                                              <textarea id="ai-system-prepend" name="ai_system_prepend"
                                                        placeholder="Text to prepend to all system prompts (added before character/system instructions)..."
                                                        rows="2"></textarea>
                                              <small>Advanced: Add custom instructions that will be prepended to every system prompt</small>
                                          </div>

                                          <div class="form-group">
                                              <label for="ai-user-prepend">User Message Prepend:</label>
                                              <textarea id="ai-user-prepend" name="ai_user_prepend"
                                                        placeholder="Text to prepend to all user messages..."
                                                        rows="2"></textarea>
                                              <small>Advanced: Add custom formatting or instructions to every user message</small>
                                          </div>
                                      </div>

                                      <div class="settings-section">
                                          <h3>AI Parameters</h3>

                                         <div class="form-group">
                                             <label for="ai-max-tokens">Max Tokens (Response Length):</label>
                                             <input type="number" id="ai-max-tokens" name="ai_max_tokens"
                                                    min="100" max="4096" value="2048">
                                         </div>

                                         <div class="form-group">
                                             <label for="ai-temperature">Temperature (Creativity):</label>
                                             <input type="number" id="ai-temperature" name="ai_temperature"
                                                    min="0" max="2" step="0.1" value="0.7">
                                             <small>Lower = more focused, Higher = more creative (0.0-2.0)</small>
                                         </div>

                                         <div class="form-group">
                                             <label for="ai-model">AI Model:</label>
                                             <select id="ai-model" name="ai_model">
                                                 <option value="default">Default Model</option>
                                                 <!-- Models will be loaded dynamically -->
                                             </select>
                                             <small>Note: Changing models may affect server performance</small>
                                         </div>
                                     </div>
                                 </div>

                                 <!-- Channels Tab -->
                                 <div class="tab-content" id="channels-tab">
                                     <div class="settings-section">
                                         <h3>Channel AI Settings</h3>
                                         <p>Configure AI behavior for each channel you have access to.</p>
                                         <div id="channel-settings-list">
                                             <!-- Channel settings will be loaded here -->
                                         </div>
                                     </div>
                                 </div>

                                 <!-- System Tab -->
                                 <div class="tab-content" id="system-tab">
                                     <div class="settings-section">
                                         <h3>System Settings</h3>
                                         <p>Global system configuration.</p>
                                         <div id="system-settings-list">
                                             <!-- System settings will be loaded here -->
                                         </div>
                                     </div>
                                 </div>
                             </form>

                            <div class="settings-actions">
                                <button type="button" id="ai-settings-save" class="btn btn-primary">Save Settings</button>
                                <button type="button" id="ai-settings-reset" class="btn btn-secondary">Reset to Defaults</button>
                                <button type="button" id="ai-settings-close" class="btn btn-secondary">Close</button>
                            </div>

                        </div>
                    </div>
                </div>
            `;

            document.body.insertAdjacentHTML('beforeend', settingsHTML);
        }

        // Always run when modal is shown (whether new or existing)
        const settingsModal = existingModal || document.getElementById('ai-settings-modal');
        settingsModal.style.display = 'block';

        // Bind events (always, in case modal was recreated or events were lost)
        const form = document.getElementById('ai-settings-form');

        // Bind events
        settingsModal.querySelector('.close-modal').addEventListener('click', () => {
            settingsModal.remove();
        });

        settingsModal.addEventListener('click', (e) => {
            if (e.target === settingsModal) {
                settingsModal.remove();
            }
        });

        // Prevent form submission on enter key
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveAISettings();
        });

        // Tab switching
        const tabButtons = settingsModal.querySelectorAll('.tab-button');
        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                const tabName = button.getAttribute('data-tab');
                this.switchTab(tabName);
            });
        });

        // Modal memory toggle
        const modalMemoryEnabled = document.getElementById('ai-modal-memory-enabled');
        const modalMemoryLimitGroup = document.getElementById('modal-memory-limit-group');
        if (modalMemoryEnabled && modalMemoryLimitGroup) {
            const updateModalMemoryVisibility = () => {
                modalMemoryLimitGroup.style.display = modalMemoryEnabled.checked ? 'block' : 'none';
            };
            modalMemoryEnabled.addEventListener('input', updateModalMemoryVisibility);
            // Set initial state
            updateModalMemoryVisibility();
        }

        // Channel memory toggle
        const memoryEnabled = document.getElementById('ai-channel-memory-enabled');
        const memoryLimitGroup = document.getElementById('channel-memory-limit-group');
        if (memoryEnabled && memoryLimitGroup) {
            const updateChannelMemoryVisibility = () => {
                memoryLimitGroup.style.display = memoryEnabled.checked ? 'block' : 'none';
            };
            memoryEnabled.addEventListener('input', updateChannelMemoryVisibility);
            // Set initial state
            updateChannelMemoryVisibility();
        }



        // Save settings
        document.getElementById('ai-settings-save')?.addEventListener('click', () => {
            this.saveAISettings();
        });

        // Reset to defaults
        document.getElementById('ai-settings-reset')?.addEventListener('click', () => {
            if (confirm('Reset all AI settings to defaults?')) {
                this.resetAISettings();
            }
        });

        // Close button
        document.getElementById('ai-settings-close')?.addEventListener('click', () => {
            settingsModal.remove();
        });







        // Load settings first, then show modal
        if (!this.currentSettings) {
            this.loadAISettings().then(() => {
                // Ensure characters are loaded and populate UI
                if (this.modal.modules.characterManager.characters && this.modal.modules.characterManager.characters.length > 0) {
                    this.modal.modules.characterManager.updateCharacterSelectOptions(this.modal.modules.characterManager.characters);
                    this.modal.modules.characterManager.updateCharacterList(this.modal.modules.characterManager.characters);
                } else {
                    // Characters not loaded yet, request them
                    this.modal.modules.characterManager.loadCharacters();
                }

                // If there's an active character, populate form with its settings
                if (this.modal.modules.characterManager.activeCharacter) {
                    this.handleAICharacterLoaded({ character: this.modal.modules.characterManager.activeCharacter });
                }
            });
        } else {
            this.handleAISettingsLoaded({ settings: this.currentSettings });
            // Ensure characters are loaded and populate UI
            if (this.modal.modules.characterManager.characters && this.modal.modules.characterManager.characters.length > 0) {
                this.modal.modules.characterManager.updateCharacterSelectOptions(this.modal.modules.characterManager.characters);
                this.modal.modules.characterManager.updateCharacterList(this.modal.modules.characterManager.characters);
            } else {
                // Characters not loaded yet, request them
                this.modal.modules.characterManager.loadCharacters();
            }

            // If there's an active character, populate form with its settings
            if (this.modal.modules.characterManager.activeCharacter) {
                this.handleAICharacterLoaded({ character: this.modal.modules.characterManager.activeCharacter });
            }
        }
    }

    async loadAISettings() {
        try {
            const response = await fetch('/api/settings');
            if (response.ok) {
                const data = await response.json();
                this.handleAISettingsLoaded({ settings: data });
                return data;
            } else {
                console.error('Failed to load settings');
                this.showToast('Failed to load settings', 'error');
                return null;
            }
        } catch (error) {
            console.error('Error loading settings:', error);
            this.showToast('Error loading settings', 'error');
            return null;
        }
    }

    loadAvailableModels() {
        if (typeof socket !== 'undefined') {
            socket.emit('ai_get_available_models');
        }
    }

    async saveAISettings() {
        const form = document.getElementById('ai-settings-form');
        if (!form) return;

        const settings = {};

        // Get all AI form elements to handle checkboxes and numbers properly
        const formElements = form.querySelectorAll('input[name^="ai_"], select[name^="ai_"], textarea[name^="ai_"]');
        formElements.forEach(element => {
            const key = element.name;
            if (element.type === 'checkbox') {
                settings[key] = element.checked;
            } else if (element.type === 'number') {
                settings[key] = parseFloat(element.value) || parseInt(element.value) || element.value;
            } else {
                settings[key] = element.value;
            }
        });

        // Send settings via socket
        if (typeof socket !== 'undefined') {
            socket.emit('ai_update_user_settings', { settings: settings });
            this.showToast('Settings saved successfully!', 'success');
        } else {
            this.showToast('Unable to save settings - socket not available', 'error');
        }
    }

    async resetAISettings() {
        const defaultSettings = {
            ai_active_character: '',
            ai_temperature: 0.7,
            ai_max_tokens: 2048
        };

        // Apply default settings to form
        this.handleAISettingsLoaded({ settings: { ai_settings: defaultSettings } });

        // Save the default settings
        if (typeof socket !== 'undefined') {
            socket.emit('ai_update_user_settings', { settings: defaultSettings });
            this.showToast('Settings reset to defaults!', 'success');
        } else {
            this.showToast('Unable to reset settings - socket not available', 'error');
        }
    }

    showSettingsStatus(message, type = 'info') {
        const statusEl = document.getElementById('ai-settings-status');
        if (statusEl) {
            statusEl.textContent = message;
            statusEl.className = `settings-status ${type}`;
            statusEl.style.display = 'block';

            // Set color based on type
            if (type === 'success') {
                statusEl.style.backgroundColor = '#d4edda';
                statusEl.style.color = '#155724';
                statusEl.style.border = '1px solid #c3e6cb';
            } else if (type === 'error') {
                statusEl.style.backgroundColor = '#f8d7da';
                statusEl.style.color = '#721c24';
                statusEl.style.border = '1px solid #f5c6cb';
            } else {
                statusEl.style.backgroundColor = '#d1ecf1';
                statusEl.style.color = '#0c5460';
                statusEl.style.border = '1px solid #bee5eb';
            }

            // Auto-hide after 3 seconds
            setTimeout(() => {
                statusEl.style.display = 'none';
            }, 3000);
        }
    }

    showToast(message, type = 'info') {
        // Use existing toast element if available
        let toast = document.getElementById('toast');
        if (!toast) {
            // Create toast element if it doesn't exist
            toast = document.createElement('div');
            toast.id = 'toast';
            toast.className = 'toast';
            document.body.appendChild(toast);
        }

        toast.textContent = message;
        toast.className = `toast ${type}`;
        toast.style.display = 'block';

        // Trigger show animation
        setTimeout(() => toast.classList.add('show'), 10);

        // Auto-hide after 3 seconds
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                toast.style.display = 'none';
            }, 300);
        }, 3000);
    }

    switchTab(tabName) {
        // Update tab buttons
        const tabButtons = document.querySelectorAll('.tab-button');
        tabButtons.forEach(button => {
            button.classList.remove('active');
        });
        const activeButton = document.querySelector(`[data-tab="${tabName}"]`);
        if (activeButton) {
            activeButton.classList.add('active');
        }

        // Update tab content
        const tabContents = document.querySelectorAll('.tab-content');
        tabContents.forEach(content => {
            content.classList.remove('active');
        });
        const activeContent = document.getElementById(`${tabName}-tab`);
        if (activeContent) {
            activeContent.classList.add('active');
        }
    }



    handleAISettingsLoaded(data) {
        const settings = data.settings;
        this.currentSettings = settings; // Store settings
        const form = document.getElementById('ai-settings-form');

        if (!form) return;

        // Populate AI settings
        const aiSettings = settings.ai_settings || settings || {};
        Object.keys(aiSettings).forEach(key => {
            const element = form.querySelector(`[name="${key}"]`);
            if (element) {
                if (element.type === 'checkbox') {
                    element.checked = aiSettings[key] || false;
                } else {
                    element.value = aiSettings[key] || element.defaultValue;
                }
            }
        });


    }

    populateChannelSettings(channels) {
        const channelList = document.getElementById('channel-settings-list');
        if (!channelList) return;

        channelList.innerHTML = '';

        if (channels.length === 0) {
            channelList.innerHTML = '<p>No channels available or you have no access to channels.</p>';
            return;
        }

        channels.forEach(channel => {
            const channelDiv = document.createElement('div');
            channelDiv.className = 'channel-setting-item';
            channelDiv.setAttribute('data-channel-id', channel.id);
            channelDiv.innerHTML = `
                <h4>${channel.name}</h4>
                <div class="form-group">
                    <label>
                        <input type="checkbox" name="channel_ai_enabled" ${channel.ai_enabled ? 'checked' : ''}>
                        Enable AI in this channel
                    </label>
                </div>
                <div class="form-group">
                    <label>Memory Limit:</label>
                    <input type="number" name="channel_ai_memory_limit" min="0" max="50" value="${channel.ai_memory_limit || 10}">
                    <small>Number of recent messages to include in context</small>
                </div>
                <div class="form-group">
                    <label>AI Model:</label>
                    <select name="channel_ai_model">
                        <option value="default" ${channel.ai_model === 'default' ? 'selected' : ''}>Default Model</option>
                        <!-- Additional models can be added here -->
                    </select>
                </div>
                <div class="form-group">
                    <label>Temperature:</label>
                    <input type="number" name="channel_ai_temperature" min="0" max="2" step="0.1" value="${channel.ai_temperature || 0.7}">
                </div>
            `;
            channelList.appendChild(channelDiv);
        });
    }

    populateSystemSettings(systemSettings) {
        const systemList = document.getElementById('system-settings-list');
        if (!systemList) return;

        // Check if user is admin (this would need to be passed from server or checked)
        // For now, show basic system settings, admin check can be added later
        systemList.innerHTML = `
                                         <div class="form-group">
                                             <label for="system-debug-mode">
                                                 <input type="checkbox" id="system-debug-mode" name="system_debug_mode" ${systemSettings.debug_mode ? 'checked' : ''}>
                                                 Enable Debug Mode
                                             </label>
                                             <small>Enable detailed logging</small>
                                         </div>
                                         <div class="form-group">
                                             <label for="system-max-users">Max Users:</label>
                                             <input type="number" id="system-max-users" name="system_max_users" min="1" value="${systemSettings.max_users || 100}">
                                             <small>Maximum number of users allowed</small>
                                         </div>
                                         <div class="form-group">
                                             <label for="system-ai-endpoint">AI Endpoint URL:</label>
                                              <input type="text" id="system-ai-endpoint" name="system_ai_endpoint_url" value="${systemSettings.ai_endpoint_url || 'https://127.0.0.1:6969'}">
                                             <small>LM Studio API endpoint</small>
                                         </div>
        `;
    }

    // Handle character data loaded
    handleAICharacterLoaded(data) {
        const character = data.character;
        const form = document.getElementById('ai-settings-form');

        if (!form || !character) return;

        // Populate form with character settings
        const fieldsToUpdate = {
            'ai-temperature': character.ai_temperature,
            'ai-max-tokens': character.ai_max_tokens,
            'ai-system-prompt': character.ai_system_prompt,
            'ai-custom-instructions': character.ai_custom_instructions
        };

        Object.keys(fieldsToUpdate).forEach(fieldName => {
            const element = form.querySelector(`[name="${fieldName}"]`);
            if (element && fieldsToUpdate[fieldName] !== undefined && fieldsToUpdate[fieldName] !== null) {
                element.value = fieldsToUpdate[fieldName];
            }
        });
    }
}

// Export for use in other modules
window.AISettingsModal = AISettingsModal;