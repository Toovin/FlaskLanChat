// socket-events/image-generation.js
import { socket } from '../core/setup.js';
import { showToast } from './utils.js';
import { ImageSharing } from '../image-gen/sharing.js';
import { ImageGenerationCore } from '../image-gen/core.js';
import { openImageViewer } from '../viewers.js';

// Lazy initialize sharing when needed
let sharing;

// Global state for image generation
let currentGenerationStatus = 'idle'; // idle, busy, offline

// Update the ImageGen button status
function updateImageGenButton(progress, status = null) {
    const button = document.getElementById('imagegen-btn');
    const progressOverlay = document.getElementById('imagegen-progress-overlay');
    const statusSpan = document.getElementById('imagegen-status');

    if (!button || !progressOverlay || !statusSpan) return;

    // Update status if provided
    if (status) {
        currentGenerationStatus = status;
    }

    // Update button appearance based on status
    if (currentGenerationStatus === 'busy') {
        // Show indeterminate progress
        progressOverlay.style.width = '100%';
        progressOverlay.style.animation = 'pulse 1.5s ease-in-out infinite';
        statusSpan.textContent = 'Generating...';
        button.classList.add('generating');
    } else if (currentGenerationStatus === 'offline') {
        progressOverlay.style.width = '0%';
        progressOverlay.style.animation = 'none';
        statusSpan.textContent = 'Offline';
        button.classList.remove('generating');
    } else {
        // idle
        progressOverlay.style.width = '0%';
        progressOverlay.style.animation = 'none';
        statusSpan.textContent = 'ImageGen';
        button.classList.remove('generating');
    }
}

// Display generation metadata
function displayGenerationMetadata(metadata) {
    const metadataContainer = document.getElementById('image-gen-metadata');
    const contentContainer = document.getElementById('metadata-content');

    if (!metadataContainer || !contentContainer) return;

    contentContainer.innerHTML = '';

    // Define the order and labels for metadata
    const metadataOrder = [
        { key: 'model', label: 'Model' },
        { key: 'seed', label: 'Seed' },
        { key: 'subseed', label: 'Subseed' },
        { key: 'steps', label: 'Steps' },
        { key: 'sampler', label: 'Sampler' },
        { key: 'scheduler', label: 'Scheduler' },
        { key: 'cfg_scale', label: 'CFG Scale' },
        { key: 'width', label: 'Width' },
        { key: 'height', label: 'Height' },
        { key: 'clip_skip', label: 'Clip Skip' },
        { key: 'denoising_strength', label: 'Denoising Strength' }
    ];

    metadataOrder.forEach(({ key, label }) => {
        if (metadata[key] !== undefined && metadata[key] !== null) {
            const item = document.createElement('div');
            item.className = 'metadata-item';

            const labelSpan = document.createElement('span');
            labelSpan.className = 'metadata-label';
            labelSpan.textContent = label + ':';

            const valueSpan = document.createElement('span');
            valueSpan.className = 'metadata-value';
            valueSpan.textContent = metadata[key];

            item.appendChild(labelSpan);
            item.appendChild(valueSpan);
            contentContainer.appendChild(item);
        }
    });

    // Display prompts separately if they exist
    if (metadata.prompt) {
        const promptItem = document.createElement('div');
        promptItem.className = 'metadata-item';
        promptItem.style.gridColumn = '1 / -1'; // Span full width

        const promptLabel = document.createElement('span');
        promptLabel.className = 'metadata-label';
        promptLabel.textContent = 'Prompt:';

        const promptValue = document.createElement('span');
        promptValue.className = 'metadata-value';
        promptValue.textContent = metadata.prompt;
        promptValue.style.wordBreak = 'break-word';

        promptItem.appendChild(promptLabel);
        promptItem.appendChild(promptValue);
        contentContainer.appendChild(promptItem);
    }

    if (metadata.negative_prompt) {
        const negPromptItem = document.createElement('div');
        negPromptItem.className = 'metadata-item';
        negPromptItem.style.gridColumn = '1 / -1'; // Span full width

        const negPromptLabel = document.createElement('span');
        negPromptLabel.className = 'metadata-label';
        negPromptLabel.textContent = 'Negative Prompt:';

        const negPromptValue = document.createElement('span');
        negPromptValue.className = 'metadata-value';
        negPromptValue.textContent = metadata.negative_prompt;
        negPromptValue.style.wordBreak = 'break-word';

        negPromptItem.appendChild(negPromptLabel);
        negPromptItem.appendChild(negPromptValue);
        contentContainer.appendChild(negPromptItem);
    }

    metadataContainer.style.display = 'block';
}

// Make functions globally available
window.updateImageGenButton = updateImageGenButton;
window.displayGenerationMetadata = displayGenerationMetadata;

// Socket event handlers - image generation
socket.on('image_generation_progress', (data) => {
    console.log('Image generation status:', data.status);

    // Update button status
    updateImageGenButton(0, data.status);

    // Update modal status
    const progressContainer = document.getElementById('image-gen-progress');
    if (progressContainer) {
        if (data.status === 'busy') {
            progressContainer.style.display = 'block';
            progressContainer.innerHTML = `
                <div style="text-align: center; margin: 10px 0;">
                    <div style="margin-bottom: 5px;">Generating images...</div>
                    <div style="width: 100%; height: 8px; background: #2f3136; border-radius: 4px; overflow: hidden;">
                        <div style="width: 50%; height: 100%; background: #7289da; animation: pulse 1.5s ease-in-out infinite;"></div>
                    </div>
                </div>
            `;
        } else if (data.status === 'idle') {
            // Hide progress when idle
            progressContainer.style.display = 'none';
        }
    }
});

socket.on('image_generation_result', (data) => {
    // Get core from window and initialize sharing if needed
    const core = window.imageGenCore;
    if (!core) {
        console.error('imageGenCore not available for image generation result');
        return;
    }
    if (!sharing) {
        sharing = new ImageSharing(core, null);
    }

    console.log('Image generation result received:', data);
    console.log(`Received ${data.images ? data.images.length : 0} images from server`);
    if (data.images) {
        console.log('Image URLs:', data.images.map(img => ({ url: img.url, thumbnail_url: img.thumbnail_url })));
    }

    if (data.images && Array.isArray(data.images)) {
        const resultsContainer = document.getElementById('image-gen-results');
        if (resultsContainer) {
            resultsContainer.innerHTML = '';
        }

        const maxImages = Math.min(data.images.length, 8);
        const limitedImages = data.images.slice(0, maxImages);
        console.log(`Displaying ${limitedImages.length} images in modal (limited from ${data.images.length})`);

        if (data.auto_share) {
            limitedImages.forEach((image, index) => {
                displayImageInModal(image.url, image.thumbnail_url);
            });
            const shareControls = document.getElementById('image-gen-share-controls');
            if (shareControls) {
                shareControls.style.display = 'none';
            }
        } else {
            limitedImages.forEach((image, index) => {
                displayImageWithCheckbox(image.url, image.thumbnail_url, index);
            });
            const shareControls = document.getElementById('image-gen-share-controls');
            if (shareControls) {
                shareControls.style.display = 'flex';
            }
        }

        if (window.imageGenCore) {
            window.imageGenCore.setCurrentGeneration({
                id: data.generation_id,
                shared: false,
                images: limitedImages, // Now includes individual metadata per image
                autoShare: data.auto_share,
                metadata: data.metadata || {} // Keep for backward compatibility
            });
        }

        // Display generation metadata if available
        if (data.metadata && Object.keys(data.metadata).length > 0) {
            displayGenerationMetadata(data.metadata);
        }

        if (data.auto_share) {
            sharing.shareCurrentGeneration();
        } else {
            updateShareButtonState();
        }
    }

    // Reset submission flag
    if (window.imageGenCore) {
        window.imageGenCore.setSubmittingImageForm(false);
    }

    // Reset button to idle state immediately since generation is complete
    updateImageGenButton(0, 'idle');

    // Hide modal progress after a short delay
    const progressContainer = document.getElementById('image-gen-progress');
    if (progressContainer) {
        setTimeout(() => {
            progressContainer.style.display = 'none';
        }, 2000);
    }
});

socket.on('share_success', (data) => {
    console.log('Share success:', data);
    const shareStatus = document.getElementById('share-status');
    if (shareStatus) {
        shareStatus.textContent = data.message || 'Images shared successfully';
        shareStatus.style.color = 'green';
    }
});

function displayImageInModal(imageUrl, thumbnailUrl) {
    const resultsContainer = document.getElementById('image-gen-results');
    if (!resultsContainer) return;

    const imageItem = document.createElement('div');
    imageItem.className = 'image-gen-result-item';
    imageItem.style.cssText = `
        display: inline-block;
        margin: 5px;
        border: 1px solid var(--border);
        border-radius: 4px;
        overflow: hidden;
        cursor: pointer;
    `;

    const img = document.createElement('img');
    img.src = thumbnailUrl || imageUrl;
    img.style.cssText = `
        width: 120px;
        height: 120px;
        object-fit: cover;
        display: block;
    `;

    img.addEventListener('click', () => {
        const imageModal = document.getElementById('image-modal');
        const imageModalImg = document.querySelector('.image-modal-image');
        if (imageModal && imageModalImg) {
            imageModalImg.src = imageUrl;
            imageModal.style.display = 'block';
        }
    });

    imageItem.appendChild(img);
    resultsContainer.appendChild(imageItem);
}

function displayImageWithCheckbox(imageUrl, thumbnailUrl, index) {
    const resultsContainer = document.getElementById('image-gen-results');
    if (!resultsContainer) return;

    const imageItem = document.createElement('div');
    imageItem.className = 'image-gen-result-item';
    imageItem.dataset.index = index;
    imageItem.style.position = 'relative';

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'image-gen-result-checkbox';
    checkbox.checked = false;
    checkbox.dataset.index = index;
    checkbox.addEventListener('change', updateShareButtonState);

    const img = document.createElement('img');
    img.src = thumbnailUrl || imageUrl;
    img.style.cssText = `
        width: 120px;
        height: 120px;
        object-fit: cover;
        display: block;
    `;

    img.addEventListener('click', (e) => {
        e.stopPropagation();
        // Open image viewer modal
        if (typeof openImageViewer === 'function') {
            openImageViewer([imageUrl], 0);
        }
    });

    const buttonsOverlay = document.createElement('div');
    buttonsOverlay.className = 'image-gen-buttons-overlay';
    buttonsOverlay.style.cssText = `
        position: absolute;
        top: 0;
        right: 0;
        display: flex;
        flex-direction: column;
        gap: 2px;
        padding: 4px;
        opacity: 0;
        transition: opacity 0.2s;
    `;

    const viewBtn = document.createElement('button');
    viewBtn.innerHTML = '<i class="fas fa-eye"></i>';
    viewBtn.title = 'View full size';
    viewBtn.className = 'image-gen-btn';
    viewBtn.style.cssText = `
        background: rgba(0,0,0,0.7);
        color: white;
        border: none;
        border-radius: 3px;
        width: 24px;
        height: 24px;
        cursor: pointer;
        font-size: 12px;
    `;
    viewBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        openImageViewer(imageUrl);
    });

    const img2imgBtn = document.createElement('button');
    img2imgBtn.innerHTML = '<i class="fas fa-arrow-right"></i>';
    img2imgBtn.title = 'Send to Image to Image';
    img2imgBtn.className = 'image-gen-btn';
    img2imgBtn.style.cssText = `
        background: rgba(0,0,0,0.7);
        color: white;
        border: none;
        border-radius: 3px;
        width: 24px;
        height: 24px;
        cursor: pointer;
        font-size: 12px;
    `;
    img2imgBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        sendToImg2Img(imageUrl);
    });

    buttonsOverlay.appendChild(viewBtn);
    buttonsOverlay.appendChild(img2imgBtn);

    imageItem.appendChild(img);
    imageItem.appendChild(buttonsOverlay);
    imageItem.appendChild(checkbox);

    resultsContainer.appendChild(imageItem);
}

function updateShareButtonState() {
    const checkboxes = document.querySelectorAll('.image-gen-result-checkbox');
    const checkedBoxes = document.querySelectorAll('.image-gen-result-checkbox:checked');
    const shareBtn = document.getElementById('image-gen-share-btn');
    const shareStatus = document.getElementById('share-status');

    if (!shareBtn || !shareStatus) return;

    const totalImages = checkboxes.length;
    const selectedImages = checkedBoxes.length;

    if (selectedImages === 0) {
        shareBtn.disabled = true;
        shareBtn.textContent = 'Share Selected Images';
        shareStatus.textContent = 'Select at least one image to share';
    } else {
        shareBtn.disabled = false;
        if (shareBtn.classList.contains('confirm')) {
            shareBtn.textContent = `Confirm Sharing ${selectedImages} Image${selectedImages > 1 ? 's' : ''}`;
        } else {
            shareBtn.textContent = `Share ${selectedImages} Image${selectedImages > 1 ? 's' : ''}`;
        }
        shareStatus.textContent = `${selectedImages} of ${totalImages} selected`;
    }
}

// Helper functions that might be needed
function sendToImg2Img(imageUrl) {
    // This function might be defined elsewhere, for now just log
    console.log('sendToImg2Img called with:', imageUrl);
    // Implementation would go here
}