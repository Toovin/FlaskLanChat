// socket-events/messaging.js
import { socket, state, elements } from '../core/setup.js';
import { showError, escapeHtml } from '../core/ui-utils.js';
import { addMessage, updateReactions, scrollMessagesToBottom } from '../message-utils/main.js';
import { typingSet, updateStatuses, parseMessageData } from './utils.js';

// Global variables for messaging
let isLoadingMessages = false;
let currentLoadRequestId = null;

// Socket event handlers - messaging
socket.on('channel_history', (data) => {
    try {
        const messagesContainer = document.getElementById('messages-container');
        if (!messagesContainer) {
            console.error('messages-container not found in DOM');
            showError('Messages container not found. Please refresh.');
            return;
        }

        if (!data.messages || !Array.isArray(data.messages)) {
            console.error('Invalid channel_history data: missing or invalid messages array', data);
            showError('Received invalid channel history data.');
            return;
        }

        if (!data.is_load_more) {
            messagesContainer.innerHTML = '';
        }

        data.messages.forEach(msg => {
            if (!msg.id || (typeof msg.id !== 'string' && typeof msg.id !== 'number')) {
                console.error('Invalid message in history: missing or invalid id', msg);
                return;
            }
            if (!msg.sender || typeof msg.sender !== 'string') {
                console.error('Invalid message in history: missing or invalid sender', msg);
                return;
            }
            if (!msg.timestamp || (typeof msg.timestamp !== 'number' && typeof msg.timestamp !== 'string')) {
                console.error('Invalid message in history: missing or invalid timestamp', msg);
                return;
            }
            if (msg.is_media !== undefined && typeof msg.is_media !== 'boolean' && typeof msg.is_media !== 'number') {
                console.error('Invalid message in history: invalid is_media type', msg);
                return;
            }
            if (msg.is_media && msg.image_url && typeof msg.image_url !== 'string') {
                console.error('Invalid media message in history: invalid image_url', msg);
                return;
            }
            if (msg.thumbnail_url !== null && msg.thumbnail_url !== undefined && typeof msg.thumbnail_url !== 'string') {
                console.error('Invalid media message in history: invalid thumbnail_url', msg);
                return;
            }

            let sanitizedMessage = msg.message;
            if (typeof sanitizedMessage === 'string') {
                sanitizedMessage = escapeHtml(sanitizedMessage);
            }

            addMessage(
                msg.sender,
                sanitizedMessage,
                msg.is_media,
                msg.timestamp,
                false,
                msg.id,
                msg.replied_to,
                msg.replies_count || 0,
                msg.image_url,
                msg.thumbnail_url,
                msg.replied_sender,
                msg.replied_text,
                msg.avatar_url
            );
        });

        scrollMessagesToBottom(true);

        const computedStyle = getComputedStyle(messagesContainer);
        if (computedStyle.display === 'none' || computedStyle.opacity === '0') {
            console.warn('Messages container is hidden:', { display: computedStyle.display, opacity: computedStyle.opacity });
            showError('Messages container is hidden. Please refresh.');
        }
    } catch (error) {
        console.error('Error in channel_history handler:', error);
        showError('An error occurred while loading channel history.');
    }
});

socket.on('receive_message', (data) => {
    try {
        console.log('Received receive_message:', data.message ? data.message.substring(0, 50) + '...' : 'media message', 'from', data.sender, 'channel', data.channel);
        if (data.channel === state.currentChannel) {
            if (!data.id || (typeof data.id !== 'string' && typeof data.id !== 'number')) {
                console.error('Invalid message data: missing or invalid id', data);
                showError('Received invalid message data.');
                return;
            }
            if (!data.sender || typeof data.sender !== 'string') {
                console.error('Invalid message data: missing or invalid sender', data);
                showError('Received invalid message data.');
                return;
            }
            if (!data.timestamp || (typeof data.timestamp !== 'number' && typeof data.timestamp !== 'string')) {
                console.error('Invalid message data: missing or invalid timestamp', data);
                showError('Received invalid message data.');
                return;
            }
            if (data.is_media !== undefined && typeof data.is_media !== 'boolean' && typeof data.is_media !== 'number') {
                console.error('Invalid message data: invalid is_media type', data);
                showError('Received invalid message data.');
                return;
            }
            if (data.is_media && data.image_url && typeof data.image_url !== 'string') {
                console.error('Invalid media message data: invalid image_url', data);
                showError('Received invalid media message.');
                return;
            }
            if (data.thumbnail_url !== null && data.thumbnail_url !== undefined && typeof data.thumbnail_url !== 'string') {
                console.error('Invalid media message data: invalid thumbnail_url', data);
                showError('Received invalid media message.');
                return;
            }

            if (data.message.startsWith('Reeeee,')) {
                showError(data.message);
                return;
            }

            if (data.is_media && data.generation_id) {
                return;
            }

            const tempMessage = document.querySelector(`.message-group.temp[data-message-id="${data.id}"]`) || document.querySelector('.message-group.temp');
            if (tempMessage) tempMessage.remove();

            let messageData;
            try {
                messageData = parseMessageData(data);
            } catch (e) {
                console.error('Failed to parse message data:', e.message, data);
                showError('Received invalid message data.');
                return;
            }

            if (typeof messageData === 'string') {
                messageData = escapeHtml(messageData);
            } else if (messageData && typeof messageData.message === 'string') {
                messageData.message = escapeHtml(messageData.message);
            }

            addMessage(
                data.sender,
                messageData,
                data.is_media,
                data.timestamp,
                false,
                data.id,
                data.replied_to,
                data.replies_count || 0,
                data.image_url,
                data.thumbnail_url,
                data.replied_sender,
                data.replied_text,
                data.avatar_url
            );

            // Play message sound only for messages from other users (not self)
            if (window.soundManager && data.sender !== (window.currentUsername || state.currentUsername)) {
                window.soundManager.playMessage();
            }

            if (data.reactions && data.reactions.length > 0) {
                updateReactions(data.id, data.reactions);
            }

            if (state.autoScrollEnabled) {
                scrollMessagesToBottom();
            } else {
                const messagesContainer = document.getElementById('messages-container');
                if (messagesContainer) {
                    const isNearBottom = messagesContainer.scrollTop + messagesContainer.clientHeight >= messagesContainer.scrollHeight - 10;
                    const newMessagesButton = document.getElementById('new-messages-button');
                    if (newMessagesButton && !isNearBottom) {
                        newMessagesButton.style.display = 'flex';
                    }
                }
            }
        } else {
            // Message is for a different channel, increment unread count
            if (window.incrementChannelUnreadCount) {
                window.incrementChannelUnreadCount(data.channel);
            }
        }
    } catch (error) {
        console.error('Error in receive_message handler:', error);
        showError('An error occurred while receiving a message.');
    }
});

socket.on('message_deleted', (data) => {
    try {
        if (data.channel === state.currentChannel) {
            const messageGroup = document.querySelector(`.message-group[data-message-id="${data.message_id}"]`);
            if (messageGroup) {
                messageGroup.remove();
                // Play Blip_2 sound when message is deleted
                if (window.soundManager) {
                    window.soundManager.playNotification();
                }
            }
        }
    } catch (error) {
        console.error('Error in message_deleted handler:', error);
        showError('An error occurred while deleting a message.');
    }
});

socket.on('typing', (data) => {
    try {
        typingSet.clear();
        (data.users || []).forEach(user => typingSet.add(user));
        updateStatuses();
    } catch (error) {
        console.error('Error in typing handler:', error);
    }
});

socket.on('receive_reactions', (data) => {
    try {
        console.log('Received receive_reactions:', data);

        // Check if this message belongs to the current user and if reactions increased
        const messageGroup = document.querySelector(`.message-group[data-message-id="${data.message_id}"]`);
        if (messageGroup) {
            const senderElement = messageGroup.querySelector('.username');
            if (senderElement) {
                const messageSender = senderElement.textContent?.trim();
                const currentUsername = window.currentUsername || state.currentUsername;

                console.log('Reaction check:', { messageSender, currentUsername, soundManager: !!window.soundManager, soundEnabled: window.soundManager?.enabled });

                // Check if this message is from the current user
                if (messageSender === currentUsername) {
                    console.log('Message is from current user, checking reaction counts');
                    // Get previous reaction count
                    const reactionsContainer = messageGroup.querySelector('.reactions-container');
                    const previousReactionCount = reactionsContainer ? reactionsContainer.children.length : 0;
                    const newReactionCount = data.reactions ? data.reactions.length : 0;

                    console.log('Reaction counts:', { previousReactionCount, newReactionCount });

                    // Only play sound if reactions increased (new reaction added)
                    if (newReactionCount > previousReactionCount) {
                        if (window.soundManager) {
                            console.log('Playing reaction sound for owned message');
                            window.soundManager.playClick(); // Play pop sound for emoji added to user's message
                        } else {
                            console.warn('Sound manager not available for reaction sound');
                        }
                    }
                }
            }
        }

        updateReactions(data.message_id, data.reactions);
    } catch (error) {
        console.error('Error in receive_reactions handler:', error);
        showError('An error occurred while updating reactions.');
    }
});

socket.on('register_error', (data) => {
    try {
        console.error('Register error:', data.msg);
        showError(data.msg);
        if (elements.loadingSpinner) elements.loadingSpinner.style.display = 'none';

        const loginModal = document.getElementById('login-modal');
        if (loginModal) {
            loginModal.classList.add('shake', 'flash-red');
            setTimeout(() => {
                loginModal.classList.remove('shake', 'flash-red');
            }, 500);
        }
    } catch (error) {
        console.error('Error in register_error handler:', error);
    }
});

socket.on('login_error', (data) => {
    try {
        console.error('Login error:', data.msg);
        showError(data.msg);
        if (elements.loadingSpinner) elements.loadingSpinner.style.display = 'none';

        const loginModal = document.getElementById('login-modal');
        if (loginModal) {
            loginModal.classList.add('shake', 'flash-red');
            setTimeout(() => {
                loginModal.classList.remove('shake', 'flash-red');
            }, 500);
        }
    } catch (error) {
        console.error('Error in login_error handler:', error);
    }
});

socket.on('connect_error', (error) => {
    try {
        console.error('Socket.IO connect error:', error);
        showError('Failed to connect to server. Please try again.');
        if (elements.loadingSpinner) elements.loadingSpinner.style.display = 'none';
    } catch (err) {
        console.error('Error in connect_error handler:', err);
    }
});

socket.on('message_send_failed', (data) => {
    try {
        console.error('Message send failed:', data);
        showError(data.msg || 'Failed to send message. Please try again.');

        const tempMessages = document.querySelectorAll('.message-group.temp');
        tempMessages.forEach(msg => msg.remove());

        const messageInput = document.querySelector('.message-input');
        if (messageInput && messageInput.disabled) {
            messageInput.disabled = false;
            messageInput.placeholder = `Message #${state.currentChannel}`;
        }
    } catch (error) {
        console.error('Error in message_send_failed handler:', error);
    }
});

socket.on('show_modal', (data) => {
    try {
        if (!window.currentUsername || !state.isAuthenticated) {
            return;
        }

        const modal = document.getElementById('image-gen-modal');
        if (!modal || !data.modal_data) {
            console.error('Modal or modal_data missing:', { modal, modal_data: data.modal_data });
            showError('Failed to open image generation modal.');
            return;
        }

        const activeTab = modal.querySelector('.image-gen-tab.active');
        const activeTabType = activeTab ? activeTab.getAttribute('data-tab') : 'txt2img';

        const form = modal.querySelector(`#${activeTabType}-form`);
        if (!form) {
            console.error(`Image generation form not found for tab: ${activeTabType}`);
            showError('Image generation form not found.');
            return;
        }

        const fields = {
            prompt: data.modal_data.prompt || '',
            batch_size: parseInt(data.modal_data.batch_size) || 1,
            width: parseInt(data.modal_data.width) || 1024,
            height: parseInt(data.modal_data.height) || 1024,
            steps: parseInt(data.modal_data.steps) || 33,
            cfg_scale: parseFloat(data.modal_data.cfg_scale) || 7,
            clip_skip: parseInt(data.modal_data.clip_skip) || 1,
            negative_prompt: data.modal_data.negative_prompt || '',
            sampler_name: data.modal_data.sampler_name || 'DPM++ 3M SDE',
            scheduler_name: data.modal_data.scheduler_name || 'Simple',
            model_name: data.modal_data.model_name || 'pixelArtDiffusionXL'
        };

        const fieldIdMap = {
            prompt: `${activeTabType}-prompt-input`,
            batch_size: `${activeTabType}-batch-size-input`,
            width: `${activeTabType}-width-input`,
            height: `${activeTabType}-height-input`,
            steps: `${activeTabType}-steps-input`,
            cfg_scale: `${activeTabType}-cfg-scale-input`,
            clip_skip: `${activeTabType}-clip-skip-input`,
            negative_prompt: `${activeTabType}-negative-prompt-input`,
            sampler_name: `${activeTabType}-sampler-name-input`,
            scheduler_name: `${activeTabType}-scheduler-name-input`,
            model_name: `${activeTabType}-model-name-input`
        };

        for (const [name, value] of Object.entries(fields)) {
            const inputId = fieldIdMap[name];
            const input = form.querySelector(`#${inputId}`);
            if (input) {
                input.value = value;
            } else {
                console.warn(`Form field #${inputId} not found.`);
            }
        }

        const samplerSelect = form.querySelector(`#${activeTabType}-sampler-name-input`);
        const schedulerSelect = form.querySelector(`#${activeTabType}-scheduler-name-input`);
        const modelSelect = form.querySelector(`#${activeTabType}-model-name-input`);

        if (samplerSelect && data.modal_data.sampler_options) {
            samplerSelect.innerHTML = '';
            const options = data.modal_data.sampler_options.length > 0 ? data.modal_data.sampler_options : [
                { value: 'Euler', label: 'Euler' },
                { value: 'DPM++ 3M SDE', label: 'DPM++ 3M SDE', recommended_scheduler: 'exponential' }
            ];

            options.forEach(opt => {
                const option = document.createElement('option');
                option.value = opt.value;
                option.textContent = opt.label || opt.value;
                samplerSelect.appendChild(option);
            });
        } else if (samplerSelect) {
            console.warn('No sampler options provided, using fallback.');
            samplerSelect.innerHTML = `
                <option value="Euler">Euler</option>
                <option value="DPM++ 3M SDE">DPM++ 3M SDE</option>
            `;
        }

        if (schedulerSelect && data.modal_data.scheduler_options) {
            schedulerSelect.innerHTML = '';
            const options = data.modal_data.scheduler_options.length > 0 ? data.modal_data.scheduler_options : [
                { value: 'Simple', label: 'Simple' },
                { value: 'exponential', label: 'Exponential' }
            ];

            options.forEach(opt => {
                const option = document.createElement('option');
                option.value = opt.value;
                option.textContent = opt.label || opt.value;
                schedulerSelect.appendChild(option);
            });
        } else if (schedulerSelect) {
            console.warn('No scheduler options provided, using fallback.');
            schedulerSelect.innerHTML = `
                <option value="Simple">Simple</option>
                <option value="exponential">Exponential</option>
            `;
        }

        if (modelSelect && data.modal_data.model_options) {
            modelSelect.innerHTML = '';
            const options = data.modal_data.model_options.length > 0 ? data.modal_data.model_options : [
                { value: 'pixelArtDiffusionXL', label: 'pixelArtDiffusionXL [7adffa28d4]' }
            ];

            options.forEach(opt => {
                const option = document.createElement('option');
                option.value = opt.value;
                option.textContent = opt.label || opt.value;
                modelSelect.appendChild(option);
            });

            if (data.modal_data.model_name) {
                modelSelect.value = data.modal_data.model_name;
            }
        } else if (modelSelect) {
            console.warn('No model options provided, using fallback.');
            modelSelect.innerHTML = `
                <option value="pixelArtDiffusionXL">pixelArtDiffusionXL.safetensors [7adffa28d4]</option>
            `;

            if (data.modal_data.model_name) {
                modelSelect.value = data.modal_data.model_name;
            }
        }

        modal.classList.add('active');

        const cancelButton = form.querySelector('.cancel-button');
        if (cancelButton) {
            cancelButton.addEventListener('click', () => {
                modal.classList.remove('active');
                const messageInput = document.querySelector('.message-input');
                if (messageInput) messageInput.focus();
            });
        }

        const handleFormSubmit = (e) => {
            e.preventDefault();

            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn.disabled) {
                return;
            }

            const formData = new FormData(form);
            const args = Object.fromEntries(formData.entries());

            args.width = parseInt(args.width) || 1024;
            args.height = parseInt(args.height) || 1024;
            args.steps = parseInt(args.steps) || 35;
            args.cfg_scale = parseFloat(args.cfg_scale) || 7;
            args.clip_skip = parseInt(args.clip_skip) || 2;
            args.batch_size = Math.max(1, Math.min(parseInt(args.batch_size) || 1, 8));

            socket.emit('submit_image_form', {
                command: 'image',
                args: args,
                channel: state.currentChannel,
                sender: window.currentUsername
            });

            modal.classList.remove('active');
            const messageInput = document.querySelector('.message-input');
            if (messageInput) messageInput.focus();

            setTimeout(() => {
                submitBtn.disabled = false;
            }, 1000);
        };

        form.removeEventListener('submit', handleFormSubmit);
        form.addEventListener('submit', handleFormSubmit);
    } catch (error) {
        console.error('Error in show_modal handler:', error);
        showError('An error occurred while opening the image generation modal.');
    }
});
