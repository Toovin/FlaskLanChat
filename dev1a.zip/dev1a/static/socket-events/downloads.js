// socket-events/downloads.js
import { socket } from '../core/setup.js';

// Socket event handlers - downloads
socket.on('download_progress', (data) => {
    updateDownloadProgress(data);
});

function updateDownloadProgress(data) {
    const progressContainer = document.getElementById('download-progress-container');
    const progressFill = document.getElementById('download-progress-fill');
    const filenameElement = document.getElementById('download-filename');
    const statusElement = document.getElementById('download-status');
    const speedElement = document.getElementById('download-speed');
    const etaElement = document.getElementById('download-eta');

    if (progressContainer && progressFill && filenameElement && statusElement && speedElement && etaElement) {
        progressContainer.style.display = 'block';

        if (data.filename) {
            filenameElement.textContent = data.filename;
        }

        if (typeof data.progress === 'number') {
            progressFill.style.width = data.progress + '%';
            statusElement.textContent = Math.round(data.progress) + '%';
        }

        if (data.speed && data.speed > 0) {
            const speedKB = (data.speed / 1024).toFixed(1);
            speedElement.textContent = `Speed: ${speedKB} KB/s`;
        } else {
            speedElement.textContent = 'Speed: --';
        }

        if (data.eta && data.eta > 0) {
            const etaMinutes = Math.floor(data.eta / 60);
            const etaSeconds = Math.floor(data.eta % 60);
            etaElement.textContent = `ETA: ${etaMinutes}:${etaSeconds.toString().padStart(2, '0')}`;
        } else {
            etaElement.textContent = 'ETA: --';
        }

        if (data.status === 'finished' || data.status === 'completed') {
            statusElement.textContent = 'Completed';
            speedElement.textContent = 'Speed: --';
            etaElement.textContent = 'ETA: --';

            setTimeout(() => {
                progressContainer.style.display = 'none';
            }, 3000);
        } else if (data.status === 'error') {
            statusElement.textContent = 'Error';
            statusElement.style.color = '#dc3545';
            speedElement.textContent = 'Speed: --';
            etaElement.textContent = 'ETA: --';

            setTimeout(() => {
                progressContainer.style.display = 'none';
                statusElement.style.color = '';
            }, 5000);
        }
    }

    const cinemaProgressContainer = document.getElementById('cinema-download-progress-container');
    const cinemaProgressFill = document.getElementById('cinema-download-progress-fill');
    const cinemaFilenameElement = document.getElementById('cinema-download-filename');
    const cinemaStatusElement = document.getElementById('cinema-download-status');
    const cinemaSpeedElement = document.getElementById('cinema-download-speed');
    const cinemaEtaElement = document.getElementById('cinema-download-eta');

    if (cinemaProgressContainer && cinemaProgressFill && cinemaFilenameElement && cinemaStatusElement && cinemaSpeedElement && cinemaEtaElement) {
        cinemaProgressContainer.style.display = 'block';

        if (data.filename) {
            cinemaFilenameElement.textContent = data.filename;
        }

        if (typeof data.progress === 'number') {
            cinemaProgressFill.style.width = data.progress + '%';
            cinemaStatusElement.textContent = Math.round(data.progress) + '%';
        }

        if (data.speed && data.speed > 0) {
            const speedKB = (data.speed / 1024).toFixed(1);
            cinemaSpeedElement.textContent = `Speed: ${speedKB} KB/s`;
        } else {
            cinemaSpeedElement.textContent = 'Speed: --';
        }

        if (data.eta && data.eta > 0) {
            const etaMinutes = Math.floor(data.eta / 60);
            const etaSeconds = Math.floor(data.eta % 60);
            cinemaEtaElement.textContent = `ETA: ${etaMinutes}:${etaSeconds.toString().padStart(2, '0')}`;
        } else {
            cinemaEtaElement.textContent = 'ETA: --';
        }

        if (data.status === 'finished' || data.status === 'completed') {
            cinemaStatusElement.textContent = 'Completed';
            cinemaSpeedElement.textContent = 'Speed: --';
            cinemaEtaElement.textContent = 'ETA: --';

            setTimeout(() => {
                cinemaProgressContainer.style.display = 'none';
            }, 3000);
        } else if (data.status === 'error') {
            cinemaStatusElement.textContent = 'Error';
            cinemaStatusElement.style.color = '#dc3545';
            cinemaSpeedElement.textContent = 'Speed: --';
            cinemaEtaElement.textContent = 'ETA: --';

            setTimeout(() => {
                cinemaProgressContainer.style.display = 'none';
                cinemaStatusElement.style.color = '';
            }, 5000);
        }
    }
}