// socket-events/user-management.js
import { socket, state, elements } from '../core/setup.js';
import { showError } from '../core/ui-utils.js';
import { updateUserInfo, updateGeneralMemberList } from '../core/member-list.js';
import { updateChannelHeader } from '../core/tab-management.js';
import { setActiveTab } from './utils.js';

// Socket event handlers - user management
socket.on('user_registered', (data) => {
    state.currentUserUuid = data.uuid;
    state.isAuthenticated = true;
    state.currentChannel = 'general';  // Ensure currentChannel is set
    socket.emit('join_channel', { channel: 'general' });

    if (data && data.uuid) {
        window.currentUserUuid = data.uuid;
    }

    const usernameInput = document.getElementById('username-input');
    const passwordInput = document.getElementById('password-input');
    const avatarInput = document.getElementById('avatar-input');

    if (usernameInput) usernameInput.value = '';
    if (passwordInput) passwordInput.value = '';
    if (avatarInput) avatarInput.value = '';

    if (elements.loginModal) elements.loginModal.style.display = 'none';
    const securityWarning = document.getElementById('security-warning');
    if (securityWarning) securityWarning.style.display = 'none';

    if (elements.appContainer) {
        elements.appContainer.classList.add('visible');
    }

    if (elements.loadingSpinner) elements.loadingSpinner.style.display = 'none';

    updateUserInfo();
    setActiveTab('channel');

    setTimeout(() => {
        setActiveTab('channel'); // Redundantly enable chat tab
        const messageInput = document.querySelector('.message-input');
        if (messageInput) messageInput.focus();
    }, 100);

    if (typeof closeAccountCreationModal === 'function') {
        closeAccountCreationModal();
    }

    if (typeof setupUserInfoSection === 'function') {
        setupUserInfoSection('main-user-info');
    }

    socket.emit('get_user_settings');

    setTimeout(() => {
        if (typeof closeAccountCreationModal === 'function') {
            closeAccountCreationModal();
        }
    }, 3000);
});

socket.on('update_users', (data) => {
    // console.log('Received users data:', data);
    const oldUsersDb = state.users_db || {};
    state.users_db = data.users || {};
    window.users_db = state.users_db; // Also set window.users_db for consistency
    // Set currentUsername if not set yet
    if (state.currentUserUuid && !state.currentUsername) {
        const currentUser = state.users_db[state.currentUserUuid];
        if (currentUser) {
            state.currentUsername = currentUser.username;
        }
    }
    // console.log('Users database updated:', Object.keys(state.users_db));

    // Update any existing media members with new user data
    if (window.webrtcManager) {
        const mediaMembers = document.querySelectorAll('.media-member');
        mediaMembers.forEach(member => {
            const userId = member.getAttribute('data-user-id');
            if (userId) {
                window.webrtcManager.updateExistingMediaMember(userId);
            }
        });
    }

    // Update member list with registered users
    updateGeneralMemberList();

    // Update main user info section
    if (typeof setupUserInfoSection === 'function') {
        setupUserInfoSection('main-user-info');
    }

    // Update user info display
    updateUserInfo();

    // Also update media members list to remove logged off users
    const mediaMembersList = document.getElementById('media-members-list');
    if (mediaMembersList) {
        const mediaMembers = mediaMembersList.querySelectorAll('.member');
        mediaMembers.forEach(member => {
            const nameSpan = member.querySelector('.member-name');
            if (nameSpan) {
                const name = nameSpan.textContent;
                if (!state.onlineUsers.includes(name)) {
                    member.remove();
                }
            }
        });
    }
});


socket.on('current_user', (data) => {
    state.currentUserUuid = data.uuid;
});

socket.on('update_online_users', (data) => {
    // Server now sends usernames directly
    state.onlineUsers = data.online_users || [];
    window.onlineUsers = state.onlineUsers;

    // Update status dots for existing members
    const membersList = document.getElementById('chat-members-list');
    if (membersList) {
        const memberElements = membersList.querySelectorAll('.member');
        memberElements.forEach(member => {
            const nameSpan = member.querySelector('.member-name');
            if (nameSpan) {
                const name = nameSpan.textContent;
                const statusDot = member.querySelector('.status-dot');
                const statusSpan = member.querySelector('.member-status');
                const isOnline = state.onlineUsers.includes(name);
                const avatarImg = member.querySelector('.member-avatar img');
            if (isOnline) {
                const user = Object.values(state.users_db).find(u => u.display_name === name);
                if (statusDot) statusDot.className = 'status-dot ' + (user ? (user.status || 'online') : 'online');
                if (avatarImg) avatarImg.classList.remove('offline');
                member.classList.add('online');
            } else {
                if (statusDot) statusDot.className = 'status-dot offline';
                if (statusDot) statusDot.className = 'status-dot offline';
                if (avatarImg) avatarImg.classList.add('offline');
                member.classList.remove('online');
            }
            }
        });
    }

    // Re-sort the general member list since online status changed
    if (window.updateGeneralMemberList) {
        window.updateGeneralMemberList();
    }

    // Also update media members list to remove logged off users
    const mediaMembersList = document.getElementById('media-members-list');
    if (mediaMembersList) {
        const mediaMembers = mediaMembersList.querySelectorAll('.member');
        mediaMembers.forEach(member => {
            const nameSpan = member.querySelector('.member-name');
            if (nameSpan) {
                const name = nameSpan.textContent;
                if (!state.onlineUsers.includes(name)) {
                    member.remove();
                }
            }
        });
    }
});