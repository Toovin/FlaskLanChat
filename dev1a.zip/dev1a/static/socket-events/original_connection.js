// socket-events/connection.js
import { socket, state } from '../core/setup.js';
import { showError } from '../core/ui-utils.js';

// Connection recovery mechanism
let connectionRecoveryAttempts = 0;
const maxRecoveryAttempts = 5;

// Heartbeat functionality
let heartbeatInterval;

function startHeartbeat() {
    stopHeartbeat();
    heartbeatInterval = setInterval(() => {
        if (socket.connected) {
            socket.emit('ping');
        }
    }, 30000); // Ping every 30 seconds
}

function stopHeartbeat() {
    if (heartbeatInterval) {
        clearInterval(heartbeatInterval);
        heartbeatInterval = null;
    }
}

function attemptConnectionRecovery() {
    if (connectionRecoveryAttempts >= maxRecoveryAttempts) {
        console.error('Max connection recovery attempts reached');
        showError('Unable to reconnect to server. Please refresh the page.');
        return;
    }

    connectionRecoveryAttempts++;
    const delay = Math.min(1000 * Math.pow(2, connectionRecoveryAttempts), 30000);

    console.log(`Attempting connection recovery ${connectionRecoveryAttempts}/${maxRecoveryAttempts} in ${delay}ms`);

    setTimeout(() => {
        if (!socket.connected) {
            socket.connect();
        }
    }, delay);
}

// Socket event handlers - connection related
socket.on('connect', () => {
    console.log('Socket.IO connected');
    socket.emit('test_event', { msg: 'Hello server' });

    // Start heartbeat ping
    startHeartbeat();
});

socket.on('reconnect', () => {
    console.log('Reconnected, querying active calls');
    socket.emit('get_active_calls');
    // Rejoin current channel after reconnect
    if (state.currentChannel) {
        socket.emit('join_channel', { channel: state.currentChannel });
    }
});

socket.on('active_calls', (data) => {
    if (data.calls && data.calls.length > 0) {
        data.calls.forEach(call => {
            console.log('Ending stale call:', call.call_id);
            socket.emit('end_call', { call_id: call.call_id });
        });
    }
});

socket.on('disconnect', (reason) => {
    console.log('Socket.IO disconnected:', reason);
    stopHeartbeat();

    // Reset private call state on disconnect to allow new calls after reconnect
    if (typeof window.resetPrivateCallState === 'function') {
        window.resetPrivateCallState();
    }

    if (reason === 'io server disconnect') {
        connectionRecoveryAttempts = 0;
        attemptConnectionRecovery();
    } else if (reason === 'io client disconnect') {
        console.log('Client disconnected normally');
    } else {
        connectionRecoveryAttempts = 0;
        attemptConnectionRecovery();
    }
});

socket.on('reconnect_error', (error) => {
    console.error('Socket.IO reconnect error:', error);
});

socket.on('reconnect_failed', () => {
    console.error('Socket.IO reconnect failed');
    showError('Failed to reconnect to server. Please refresh the page.');
});

socket.on('connection_status', (data) => {
    console.log('Connection status:', data);
    if (data.status === 'connected' && data.user_uuid) {
        state.isAuthenticated = true;
        console.log('User authenticated via connection status');
    }
});

socket.on('pong', () => {
    console.log('Received pong from server');
});

socket.on('test_response', (data) => {
    console.log('Test response:', data);
});

// Export functions that might be needed elsewhere
export { startHeartbeat, stopHeartbeat };