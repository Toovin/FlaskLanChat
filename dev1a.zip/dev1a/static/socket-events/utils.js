// socket-events/utils.js
import { state } from '../core/setup.js';
import { showError } from '../core/ui-utils.js';
import { updateChannelHeader } from '../core/tab-management.js';

// Global variables that were in socketEvents.js
export let typingSet = new Set();

// Helper function to check if string is UUID
export function isUUID(str) {
    return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(str);
}

// Toast notification function
export function showToast(message, type = 'info') {
    // Remove existing toast
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
        existingToast.remove();
    }

    // Create new toast
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;

    // Add to body
    document.body.appendChild(toast);

    // Show toast
    setTimeout(() => toast.classList.add('show'), 10);

    // Hide after 3 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Helper function to parse message data consistently
export function parseMessageData(data) {
    if (!data.is_media) {
        return data.message;
    }

    // For media messages, try to parse JSON attachments first
    if (typeof data.message === 'string') {
        try {
            const parsed = JSON.parse(data.message);
            if (parsed.attachments && Array.isArray(parsed.attachments) && parsed.attachments.length > 0) {
                if (parsed.attachments.length > 1) {
                    // Multiple attachments - keep JSON for carousel
                    return data.message;
                } else {
                    // Single attachment - extract for backward compatibility
                    const attachment = parsed.attachments[0];
                    if (!attachment.url || typeof attachment.url !== 'string') {
                        throw new Error('Invalid attachment URL');
                    }
                    return {
                        message: parsed.message || parsed.text || '',
                        image_url: attachment.url,
                        thumbnail_url: attachment.thumbnail_url || null,
                        metadata: parsed.metadata || {}
                    };
                }
            }
        } catch (e) {
            // Not valid JSON or invalid structure, fall back to direct fields
        }
    }

    // Fallback to direct media fields
    if (!data.image_url || typeof data.image_url !== 'string') {
        throw new Error('Invalid media message: missing or invalid image_url');
    }
    if (data.thumbnail_url !== null && data.thumbnail_url !== undefined && typeof data.thumbnail_url !== 'string') {
        throw new Error('Invalid media message: invalid thumbnail_url');
    }

    return {
        message: data.message || '',
        image_url: data.image_url,
        thumbnail_url: data.thumbnail_url
    };
}

export const tabRegistry = {
    'channel': {
        render: () => {
            const content = document.getElementById('tab-content-channel');
            if (content) {
                content.style.display = 'block';
                if (typeof handleChatInput === 'function') handleChatInput();
                const messageInput = document.querySelector('.message-input');
                if (messageInput) messageInput.focus();
            } else {
                showError('Channel tab content not found. Please refresh.');
            }
        }
    },
    'file-share': {
        render: () => {
            const content = document.getElementById('tab-content-file-share');
            if (content) {
                content.style.display = 'block';
            } else {
                console.error('File share tab content not found');
                showError('File share tab content not found. Please refresh.');
            }
            loadFileShareContent();
        }
    },
    'media': {
        render: () => {
            const content = document.getElementById('tab-content-media');
            if (content) {
                content.style.display = 'block';
            } else {
                console.error('Media tab content not found');
                showError('Media tab content not found. Please refresh.');
            }
            if (typeof loadMediaContent === 'function') {
                loadMediaContent();
            }
        }
    },
    'adventure': {
        render: () => {
            const content = document.getElementById('tab-content-adventure');
            if (content) {
                content.style.display = 'block';
            } else {
                console.error('Adventure tab content not found');
                showError('Adventure tab content not found. Please refresh.');
            }
            if (typeof activateAdventureTab === 'function') {
                activateAdventureTab();
            }
        }
    },
    'voice': {
        render: () => {
            const content = document.getElementById('tab-content-voice');
            if (content) {
                content.style.visibility = 'visible';
                content.style.position = 'fixed';
                content.style.top = '50%';
                content.style.left = '50%';
                content.style.transform = 'translate(-50%, -50%)';
                content.style.width = 'min(1200px, 80vw)';
                content.style.height = '80vh';
                content.style.zIndex = '9999';
                content.style.opacity = '1';
                content.style.pointerEvents = 'auto';
            } else {
                console.error('Voice tab content not found');
                showError('Voice tab content not found. Please refresh.');
            }
        }
    }
};

export function setActiveTab(tabName) {
    console.log('setActiveTab called with:', tabName);
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        tab.classList.toggle('active', tab.dataset.tab === tabName);
    });

    document.querySelectorAll('.tab-content').forEach(content => {
        if (content.id === 'tab-content-voice') {
            content.style.display = 'block';
            content.style.visibility = 'hidden';
            content.style.position = 'absolute';
            content.style.top = '-10000px';
            content.style.left = '-10000px';
        } else if (content.id === 'tab-content-' + tabName) {
            content.style.display = 'flex';
        } else {
            content.style.display = 'none';
        }
    });

    const mainUserInfo = document.getElementById('main-user-info');
    if (mainUserInfo) {
        mainUserInfo.style.display = 'block'; // Always show main user info
    }

    if (tabRegistry[tabName] && tabRegistry[tabName].render) {
        tabRegistry[tabName].render();
    }

    if (tabName === 'channel') {
        updateChannelHeader(state.currentChannel);
    }
}

export function updateStatuses() {
    document.querySelectorAll('.member').forEach(member => {
        const nameSpan = member.querySelector('.member-name');
        const statusSpan = member.querySelector('.member-status');

        if (nameSpan && statusSpan) {
            const displayName = nameSpan.textContent;

            // Find the user in the users_db to get their actual username and custom status
            const user = Object.values(state.users_db || {}).find(u =>
                u.display_name === displayName || u.username === displayName
            );

            // Check if user is online
            const isOnline = state.onlineUsers && state.onlineUsers.includes(displayName);

            // Only show typing for online users if typing indicators are enabled
            const showTyping = window.currentUserSettings?.typing_indicators !== false;
            const isTyping = showTyping && typingSet.has(displayName) && isOnline;

            // Determine what status text to show
            let statusText = '';

            if (isOnline) {
                if (isTyping) {
                    statusText = 'Typing...';
                } else if (user && user.custom_status && user.custom_status.trim() !== '') {
                    // Show custom status if set
                    statusText = user.custom_status;
                } else {
                    // Default to "Online" if no custom status
                    statusText = 'Online';
                }
            } else {
                // For offline users, show custom status if available, otherwise empty
                if (user && user.custom_status && user.custom_status.trim() !== '') {
                    statusText = user.custom_status;
                } else {
                    statusText = '';
                }
            }

            statusSpan.textContent = statusText;
        }
    });
}