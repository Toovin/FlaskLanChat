// socket-events/private-calls.js
import { socket, state } from '../core/setup.js';
import { showToast } from './utils.js';

// ============================================================================
// CALL STATE MANAGEMENT - Single Source of Truth
// ============================================================================

class CallStateManager {
    constructor() {
        this.state = 'idle'; // idle, ringing, negotiating, connected, ending
        this.callId = null;
        this.targetUserId = null;
        this.roomName = null;
        this.isCaller = false;
        this.ringingTimeout = null;
        this.audioElement = null;
    }

    // Check if we can start a new action
    canStartNewCall() {
        return this.state === 'idle';
    }

    canAcceptCall() {
        return this.state === 'ringing' && !this.isCaller;
    }

    canEndCall() {
        return this.state !== 'idle' && this.state !== 'ending';
    }

    // State transitions with logging
    transitionTo(newState, context = {}) {
        const oldState = this.state;
        this.state = newState;

        console.log(`[CALL_STATE] ${context.action || 'transition'}: ${oldState} -> ${newState}`, {
            callId: this.callId,
            targetUserId: this.targetUserId,
            isCaller: this.isCaller,
            ...context
        });

        return oldState;
    }

    // Initialize a new call
    startCall(targetUserId, isCaller) {
        this.targetUserId = targetUserId;
        this.isCaller = isCaller;
        this.transitionTo('ringing', { action: 'startCall', isCaller });
    }

    // Set call ID when server responds
    setCallId(callId) {
        this.callId = callId;
    }

    // Set room name
    setRoomName(roomName) {
        this.roomName = roomName;
    }

    // Clear timeout safely
    clearRingingTimeout() {
        if (this.ringingTimeout) {
            clearTimeout(this.ringingTimeout);
            this.ringingTimeout = null;
        }
    }

    // Stop and cleanup audio
    stopAudio() {
        if (this.audioElement) {
            try {
                this.audioElement.pause();
                this.audioElement.currentTime = 0;
                this.audioElement.src = '';
                this.audioElement = null;
                console.log('[AUDIO] Audio stopped and cleaned up');
            } catch (error) {
                console.warn('[AUDIO] Error stopping audio:', error);
                this.audioElement = null;
            }
        }
    }

    // Play sound and store reference
    playAudio(filename, loop = false) {
        this.stopAudio();

        try {
            this.audioElement = new Audio(`/static/sounds/${filename}`);
            this.audioElement.loop = loop;
            this.audioElement.volume = 0.5;

            this.audioElement.onerror = (error) => {
                console.warn(`[AUDIO] Audio error for ${filename}:`, error);
                this.stopAudio();
            };

            const playPromise = this.audioElement.play();
            if (playPromise !== undefined) {
                playPromise
                    .then(() => console.log(`[AUDIO] Playing: ${filename}`))
                    .catch(error => {
                        console.warn(`[AUDIO] Failed to play ${filename}:`, error);
                        this.stopAudio();
                    });
            }
        } catch (error) {
            console.error(`[AUDIO] Error creating audio for ${filename}:`, error);
            this.stopAudio();
        }
    }

    // Full reset - use this for any termination scenario
    reset(reason = 'unknown') {
        const oldState = this.transitionTo('idle', { action: 'reset', reason });

        this.clearRingingTimeout();
        this.stopAudio();

        this.callId = null;
        this.targetUserId = null;
        this.roomName = null;
        this.isCaller = false;

        return oldState;
    }

    // Force reset with cleanup - used when state gets out of sync
    forceReset(reason = 'force') {
        console.warn(`[CALL_STATE] FORCE RESET - reason: ${reason}, previous state: ${this.state}`);

        // Close any active modals
        const privateCallModal = document.getElementById('private-call-modal');
        const incomingCallModal = document.getElementById('incoming-call-modal');

        if (privateCallModal) privateCallModal.style.display = 'none';
        if (incomingCallModal) incomingCallModal.style.display = 'none';

        // Leave WebRTC room
        if (window.webrtcManager) {
            window.webrtcManager.leaveRoom();
        }

        return this.reset(reason);
    }
}

// Create singleton instance
const callState = new CallStateManager();

// Expose for external access (e.g., WebRTC cleanup)
window.callStateManager = callState;

// ============================================================================
// SOCKET EVENT HANDLERS
// ============================================================================

// Outgoing call initiated by server
socket.on('call_initiated', (data) => {
    if (!callState.canStartNewCall() && callState.state !== 'ringing') {
        console.warn('[CALL] call_initiated received but state is not idle/ringing:', callState.state);
        return;
    }

    callState.setCallId(data.call_id);
    callState.setRoomName(data.room);

    if (window.webrtcManager) {
        window.webrtcManager.joinRoom(data.room, window.currentUserUuid);
        openPrivateCallModal(callState.targetUserId);
        updatePrivateCallStatus('Calling (outgoing)');
    } else {
        showToast('WebRTC not available', 'error');
        callState.reset('webrtc_unavailable');
    }
});

// Incoming call notification
socket.on('incoming_call', (data) => {
    // Force reset if we're not in a clean state
    if (!callState.canStartNewCall()) {
        callState.forceReset('incoming_call_conflict');
    }

    callState.startCall(data.caller_id, false);
    callState.setCallId(data.call_id);

    // Play ringing sound
    callState.playAudio('Incoming_Call_Ringing.mp3', true);

    // Set timeout for auto-decline
    callState.ringingTimeout = setTimeout(() => {
        if (callState.state === 'ringing' && !callState.isCaller) {
            console.log('[CALL] Incoming call timeout - auto-declining');
            callState.stopAudio();
            socket.emit('decline_call', { call_id: callState.callId });
            callState.reset('timeout');
        }
    }, 15000);

    showIncomingCallModal(data.caller_name, data.call_id);
});

// Call accepted by other party
socket.on('call_accepted', (data) => {
    if (callState.state !== 'ringing') {
        console.warn('[CALL] call_accepted received but not in ringing state:', callState.state);
        return;
    }

    callState.transitionTo('negotiating', { action: 'call_accepted' });
    callState.clearRingingTimeout();
    callState.stopAudio();

    openPrivateCallModal(callState.targetUserId);
    updatePrivateCallStatus('Negotiating connection...');

    // Join WebRTC room if not already joined
    if (window.webrtcManager && !window.webrtcManager.currentRoom) {
        window.webrtcManager.joinRoom(data.room, window.currentUserUuid);
    }

    // Transition to connected after negotiation period
    setTimeout(() => {
        if (callState.state === 'negotiating') {
            callState.transitionTo('connected', { action: 'negotiation_complete' });
            updatePrivateCallStatus('Call Established');
            showToast('Call connected!', 'success');
        }
    }, 3000);
});

// Call declined by other party
socket.on('call_declined', (data) => {
    console.log('[CALL] Call declined by:', data.callee);

    callState.clearRingingTimeout();
    callState.stopAudio();

    const wasInCall = callState.state !== 'idle';
    callState.reset('declined');

    // Close modal and cleanup WebRTC
    const modal = document.getElementById('private-call-modal');
    if (modal && modal.style.display === 'flex') {
        modal.style.display = 'none';
        if (window.webrtcManager) {
            window.webrtcManager.leaveRoom();
        }
    }

    if (wasInCall) {
        showToast('Call declined', 'info');
    }
});

// Call ended by either party
socket.on('call_ended', (data) => {
    console.log('[CALL] Call ended:', data);

    if (callState.state === 'idle') {
        console.log('[CALL] Already idle, ignoring call_ended');
        return;
    }

    callState.transitionTo('ending', { action: 'call_ended' });
    callState.clearRingingTimeout();
    callState.stopAudio();

    updatePrivateCallStatus('Ending call...');

    // Brief delay for UX
    setTimeout(() => {
        if (window.webrtcManager) {
            window.webrtcManager.leaveRoom();
        }

        callState.reset('ended');
        closePrivateCallModal();
        showToast('Call Ended', 'info');
    }, 500);
});

// ============================================================================
// PUBLIC API FUNCTIONS
// ============================================================================

function startPrivateCall(targetUserId) {
    if (!window.currentUserUuid) {
        showToast('You must be logged in to make calls', 'error');
        return;
    }

    // Force reset if not idle
    if (!callState.canStartNewCall()) {
        callState.forceReset('new_call_request');
    }

    callState.startCall(targetUserId, true);

    // Play outgoing ringing sound
    callState.playAudio('Ringing_Calling_Other.mp3', true);

    // Set timeout for call initiation
    callState.ringingTimeout = setTimeout(() => {
        if (callState.state === 'ringing' && callState.isCaller) {
            console.log('[CALL] Outgoing call timeout');
            callState.stopAudio();
        }
    }, 15000);

    socket.emit('initiate_call', { target: targetUserId });
    console.log(`[CALL] Initiating private call with ${targetUserId}`);
}

function acceptCall() {
    if (!callState.canAcceptCall()) {
        console.error('[CALL] Cannot accept call in current state:', callState.state);
        return;
    }

    socket.emit('accept_call', { call_id: callState.callId });

    callState.stopAudio();
    callState.playAudio('Blip_1.mp3');

    showToast('Call accepted!', 'success');
    hideIncomingCallModal();
}

function declineCall() {
    if (callState.state !== 'ringing') {
        console.warn('[CALL] Cannot decline call in current state:', callState.state);
        return;
    }

    callState.stopAudio();
    callState.playAudio('Blip_2.mp3');

    socket.emit('decline_call', { call_id: callState.callId });

    callState.reset('user_declined');
    hideIncomingCallModal();
}

function endPrivateCall() {
    if (!callState.canEndCall()) {
        console.warn('[CALL] No active call to end');
        return;
    }

    console.log('[CALL] User ending call');

    if (callState.callId) {
        socket.emit('end_call', { call_id: callState.callId });
    }

    callState.transitionTo('ending', { action: 'user_ended' });
    callState.clearRingingTimeout();
    callState.stopAudio();

    if (window.webrtcManager) {
        window.webrtcManager.leaveRoom();
    }

    callState.reset('user_ended');
    closePrivateCallModal();
    showToast('Call Ended', 'info');
}

// Global function for WebRTC to reset state on peer close
window.resetPrivateCallState = function() {
    if (callState.state === 'idle') {
        console.log('[CALL] resetPrivateCallState called but already idle');
        return;
    }

    console.log('[CALL] resetPrivateCallState called by WebRTC');

    const wasConnected = callState.state === 'connected';
    callState.reset('peer_disconnect');

    closePrivateCallModal();

    if (wasConnected) {
        showToast('Call Ended', 'info');
    }
};

// ============================================================================
// UI HELPER FUNCTIONS
// ============================================================================

function updatePrivateCallStatus(status) {
    const statusElement = document.getElementById('private-call-status');
    if (statusElement) {
        statusElement.textContent = status;
    }
    const placeholder = document.getElementById('private-call-placeholder');
    if (placeholder) {
        placeholder.textContent = status;
    }
}

function showIncomingCallModal(callerUsername, callId) {
    const callerUser = Object.values(window.users_db).find(u => u.username === callerUsername);
    const displayName = callerUser ? (callerUser.display_name || callerUsername) : callerUsername;
    const avatarUrl = callerUser ? (callerUser.avatar_url || '/static/default_avatars/smile_1.png') : '/static/default_avatars/smile_1.png';

    document.getElementById('incoming-call-name').textContent = displayName;
    document.getElementById('incoming-call-avatar').src = avatarUrl;

    const modal = document.getElementById('incoming-call-modal');
    modal.style.display = 'flex';

    // Remove old event listeners by cloning
    const acceptBtn = document.getElementById('accept-call-btn');
    const declineBtn = document.getElementById('decline-call-btn');
    const newAcceptBtn = acceptBtn.cloneNode(true);
    const newDeclineBtn = declineBtn.cloneNode(true);
    acceptBtn.replaceWith(newAcceptBtn);
    declineBtn.replaceWith(newDeclineBtn);

    newAcceptBtn.addEventListener('click', acceptCall);
    newDeclineBtn.addEventListener('click', declineCall);
}

function hideIncomingCallModal() {
    const modal = document.getElementById('incoming-call-modal');
    if (modal) {
        modal.style.display = 'none';
    }
}

function openPrivateCallModal(targetUserId) {
    const userData = window.users_db[targetUserId];
    const displayName = userData ? (userData.display_name || userData.username) : 'User';
    const avatarUrl = userData ? userData.avatar_url : '/static/default_avatars/smile_1.png';

    const modal = document.getElementById('private-call-modal');
    if (!modal) {
        console.error('Private call modal not found');
        return;
    }

    // Reset modal position and state
    modal.style.left = '';
    modal.style.top = '';
    modal.style.transform = '';
    modal.classList.remove('minimized');

    const titleElement = document.getElementById('private-call-title');
    const avatarElement = document.getElementById('private-call-avatar');

    if (titleElement) titleElement.textContent = `Private Call with: ${displayName}`;
    if (avatarElement) avatarElement.src = avatarUrl;

    // Reset media buttons
    const voiceBtn = document.getElementById('private-voice-btn');
    const videoBtn = document.getElementById('private-video-btn');
    const screenshareBtn = document.getElementById('private-screenshare-btn');

    if (voiceBtn) voiceBtn.classList.remove('active');
    if (videoBtn) videoBtn.classList.remove('active');
    if (screenshareBtn) screenshareBtn.classList.remove('active');

    modal.style.display = 'flex';

    // Setup dragging
    setupModalDragging(modal);

    // Setup control buttons
    setupModalControls(modal);

    // Update video if stream exists
    if (window.webrtcManager?.peers?.[targetUserId]?.stream) {
        updatePrivateCallVideo(window.webrtcManager.peers[targetUserId].stream);
    }
}

function closePrivateCallModal() {
    const modal = document.getElementById('private-call-modal');
    if (!modal) return;

    // Reset modal state
    modal.style.left = '';
    modal.style.top = '';
    modal.style.transform = '';
    modal.classList.remove('minimized');

    // Reset video
    const video = document.getElementById('private-call-video');
    const placeholder = document.getElementById('private-call-placeholder');
    if (video) {
        video.style.display = 'none';
        video.srcObject = null;
    }
    if (placeholder) {
        placeholder.style.display = 'flex';
    }

    modal.style.display = 'none';
}

function setupModalDragging(modal) {
    const header = modal.querySelector('.private-call-header');
    if (!header) return;

    let isDragging = false;
    let dragStartX, dragStartY, initialX, initialY;

    // Clone to remove old listeners
    const newHeader = header.cloneNode(true);
    header.replaceWith(newHeader);

    newHeader.addEventListener('mousedown', (e) => {
        isDragging = true;
        dragStartX = e.clientX;
        dragStartY = e.clientY;
        const rect = modal.getBoundingClientRect();
        initialX = rect.left;
        initialY = rect.top;
    });

    document.addEventListener('mousemove', (e) => {
        if (isDragging) {
            const dx = e.clientX - dragStartX;
            const dy = e.clientY - dragStartY;
            modal.style.left = (initialX + dx) + 'px';
            modal.style.top = (initialY + dy) + 'px';
            modal.style.transform = 'none';
        }
    });

    document.addEventListener('mouseup', () => {
        isDragging = false;
    });
}

function setupModalControls(modal) {
    // Clone all buttons to remove old listeners
    const buttonIds = [
        'private-voice-btn', 'private-video-btn', 'private-screenshare-btn',
        'private-call-minimize-btn', 'private-call-close-btn', 'private-hangup-btn'
    ];

    buttonIds.forEach(btnId => {
        const btn = document.getElementById(btnId);
        if (btn) {
            const newBtn = btn.cloneNode(true);
            btn.replaceWith(newBtn);
        }
    });

    // Setup new event listeners
    const voiceBtn = document.getElementById('private-voice-btn');
    const videoBtn = document.getElementById('private-video-btn');
    const screenshareBtn = document.getElementById('private-screenshare-btn');
    const minimizeBtn = document.getElementById('private-call-minimize-btn');
    const closeBtn = document.getElementById('private-call-close-btn');
    const hangupBtn = document.getElementById('private-hangup-btn');

    if (voiceBtn) {
        voiceBtn.addEventListener('click', () => {
            if (!window.webrtcManager) return;

            if (window.webrtcManager.activeMediaTypes.has('audio')) {
                window.webrtcManager.mediaManager.stopVoice();
                voiceBtn.classList.remove('active');
            } else {
                window.webrtcManager.mediaManager.startVoice().catch(err => {
                    console.error('Error starting voice:', err);
                });
                voiceBtn.classList.add('active');
            }
        });
    }

    if (videoBtn) {
        videoBtn.addEventListener('click', () => {
            if (!window.webrtcManager) return;

            if (window.webrtcManager.activeMediaTypes.has('video')) {
                window.webrtcManager.mediaManager.stopVideo();
                videoBtn.classList.remove('active');
            } else {
                window.webrtcManager.mediaManager.startVideo().catch(err => {
                    console.error('Error starting video:', err);
                });
                videoBtn.classList.add('active');
            }
        });
    }

    if (screenshareBtn) {
        screenshareBtn.addEventListener('click', () => {
            if (!window.webrtcManager) return;

            if (window.webrtcManager.activeMediaTypes.has('screenshare')) {
                window.webrtcManager.mediaManager.stopScreenshare();
                screenshareBtn.classList.remove('active');
            } else {
                window.webrtcManager.mediaManager.startScreenshare().catch(err => {
                    console.error('Error starting screenshare:', err);
                });
                screenshareBtn.classList.add('active');
            }
        });
    }

    if (minimizeBtn) {
        minimizeBtn.addEventListener('click', () => {
            const modalContent = modal.querySelector('.private-call-modal-content');
            if (modalContent.classList.contains('minimized')) {
                modalContent.classList.remove('minimized');
                minimizeBtn.innerHTML = '−';
                minimizeBtn.title = 'Minimize';
            } else {
                modalContent.classList.add('minimized');
                minimizeBtn.innerHTML = '□';
                minimizeBtn.title = 'Restore';
            }
        });
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', endPrivateCall);
    }

    if (hangupBtn) {
        hangupBtn.addEventListener('click', endPrivateCall);
    }
}

function updatePrivateCallVideo(stream) {
    const video = document.getElementById('private-call-video');
    const placeholder = document.getElementById('private-call-placeholder');

    if (video && stream) {
        video.srcObject = stream;
        video.style.display = 'block';
        if (placeholder) placeholder.style.display = 'none';
    }
}

// Make globally accessible for WebRTC utils
window.updatePrivateCallVideo = updatePrivateCallVideo;

// Legacy functions for backward compatibility (not used in refactored code)
function showCallControls(username) {
    const member = document.querySelector(`.member[data-username="${username}"]`);
    if (member) {
        const controls = member.querySelector('.member-call-controls');
        if (controls) {
            controls.style.display = 'flex';
        }
    }
}

function hideCallControls(username) {
    const member = document.querySelector(`.member[data-username="${username}"]`);
    if (member) {
        const controls = member.querySelector('.member-call-controls');
        if (controls) {
            controls.style.display = 'none';
        }
    }
}

// ============================================================================
// EXPORTS
// ============================================================================

export {
    startPrivateCall,
    acceptCall,
    declineCall,
    showCallControls,
    hideCallControls,
    updatePrivateCallVideo
};