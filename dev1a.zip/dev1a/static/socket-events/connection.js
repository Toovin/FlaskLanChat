// socket-events/connection.js
import { socket, state } from '../core/setup.js';
import { showError } from '../core/ui-utils.js';
import { typingSet, updateStatuses } from './utils.js';

// Connection recovery mechanism
let connectionRecoveryAttempts = 0;
const maxRecoveryAttempts = 5;
let recoveryTimeout = null;

// Heartbeat functionality
let heartbeatInterval;
let heartbeatTimeout;
let missedHeartbeats = 0;
const maxMissedHeartbeats = 5;

// Connection quality tracking
let connectionQuality = 'good'; // 'good', 'unstable', 'poor'
let lastPingTime = 0;
let pingLatencies = [];
const maxLatencySamples = 10;
let currentLatency = null; // Current ping in ms

// Initialize global ping
window.currentLatency = null;

function updateConnectionQuality(latency) {
    // Keep a rolling average of latencies
    pingLatencies.push(latency);
    if (pingLatencies.length > maxLatencySamples) {
        pingLatencies.shift();
    }

    const avgLatency = pingLatencies.reduce((a, b) => a + b, 0) / pingLatencies.length;
    currentLatency = Math.round(avgLatency);

    // Determine connection quality
    if (avgLatency < 100) {
        connectionQuality = 'good';
    } else if (avgLatency < 300) {
        connectionQuality = 'unstable';
    } else {
        connectionQuality = 'poor';
    }

    // Emit connection quality event for UI updates if needed
    window.dispatchEvent(new CustomEvent('connectionQualityChanged', {
        detail: { quality: connectionQuality, latency: currentLatency }
    }));

    // Update global ping display
    window.currentLatency = currentLatency;
}

function startHeartbeat() {
    stopHeartbeat();
    missedHeartbeats = 0;

    heartbeatInterval = setInterval(() => {
        if (socket.connected) {
            lastPingTime = Date.now();
            socket.emit('ping');

            // Set timeout for pong response
            heartbeatTimeout = setTimeout(() => {
                missedHeartbeats++;
                console.warn(`Missed heartbeat ${missedHeartbeats}/${maxMissedHeartbeats}`);

                if (missedHeartbeats >= maxMissedHeartbeats) {
                    console.error('Too many missed heartbeats, assuming connection lost');
                    // Force reconnection
                    socket.disconnect();
                    socket.connect();
                }
            }, 30000); // Expect pong within 30 seconds (more generous)
        }
    }, 10000); // Ping every 10 seconds (for testing)
}

function stopHeartbeat() {
    if (heartbeatInterval) {
        clearInterval(heartbeatInterval);
        heartbeatInterval = null;
    }
    if (heartbeatTimeout) {
        clearTimeout(heartbeatTimeout);
        heartbeatTimeout = null;
    }
    missedHeartbeats = 0;
}

function clearRecoveryTimeout() {
    if (recoveryTimeout) {
        clearTimeout(recoveryTimeout);
        recoveryTimeout = null;
    }
}

function attemptConnectionRecovery() {
    if (connectionRecoveryAttempts >= maxRecoveryAttempts) {
        console.error('Max connection recovery attempts reached');
        showError('Unable to reconnect to server. Please refresh the page.');
        clearRecoveryTimeout();
        return;
    }

    connectionRecoveryAttempts++;
    const delay = Math.min(1000 * Math.pow(2, connectionRecoveryAttempts), 30000);

    console.log(`Attempting connection recovery ${connectionRecoveryAttempts}/${maxRecoveryAttempts} in ${delay}ms`);

    // Update UI to show reconnecting status
    window.dispatchEvent(new CustomEvent('connectionStatusChanged', {
        detail: { status: 'reconnecting', attempt: connectionRecoveryAttempts, maxAttempts: maxRecoveryAttempts }
    }));

    clearRecoveryTimeout();
    recoveryTimeout = setTimeout(() => {
        if (!socket.connected) {
            socket.connect();
        }
    }, delay);
}

// Socket event handlers - connection related
socket.on('connect', () => {
    console.log('Socket.IO connected');

    // Reset recovery state
    connectionRecoveryAttempts = 0;
    clearRecoveryTimeout();

    // Update connection status
    window.dispatchEvent(new CustomEvent('connectionStatusChanged', {
        detail: { status: 'connected' }
    }));

     socket.emit('test_event', { msg: 'Hello server' });

     // Start heartbeat ping
     startHeartbeat();

    // Re-authenticate if we have stored credentials
    if (state.currentUserUuid && !state.isAuthenticated) {
        console.log('Attempting to re-authenticate after reconnection');
        // You might want to emit a re-authentication event here
        // socket.emit('reauth', { uuid: state.currentUserUuid });
    }
});

socket.on('reconnect', () => {
    console.log('Reconnected successfully');

    // Clear any connection error messages
    const errorMessages = document.querySelectorAll('.connection-error');
    errorMessages.forEach(msg => msg.remove());

    // Query active calls
    socket.emit('get_active_calls');

    // Rejoin current channel after reconnect
    if (state.currentChannel) {
        console.log(`Rejoining channel: ${state.currentChannel}`);
        socket.emit('join_channel', { channel: state.currentChannel });

        // Request channel history to ensure we're up to date
        socket.emit('get_channel_history', { channel: state.currentChannel });
    }

    // Re-establish any active voice connections
    if (window.voiceManager?.isInVoiceChannel) {
        console.log('Re-establishing voice connection');
        socket.emit('rejoin_voice', { channel: window.voiceManager.currentVoiceChannel });
    }

    // Request updated user list
    socket.emit('get_online_users');

    // Update connection quality
    connectionQuality = 'good';
    pingLatencies = [];
});

socket.on('active_calls', (data) => {
    if (data.calls && data.calls.length > 0) {
        data.calls.forEach(call => {
            console.log('Ending stale call:', call.call_id);
            socket.emit('end_call', { call_id: call.call_id });
        });
    }
});

socket.on('disconnect', (reason) => {
    console.log('Socket.IO disconnected:', reason);
    stopHeartbeat();
    currentLatency = null; // Reset latency on disconnect
    window.currentLatency = null;

    // Update connection status
    window.dispatchEvent(new CustomEvent('connectionStatusChanged', {
        detail: { status: 'disconnected', reason }
    }));

    // Reset private call state on disconnect to allow new calls after reconnect
    if (typeof window.resetPrivateCallState === 'function') {
        window.resetPrivateCallState();
    }

    // Clear typing indicators since we're disconnected
    typingSet.clear();
    updateStatuses();

    // Handle different disconnect reasons
    switch (reason) {
        case 'io server disconnect':
            // Server explicitly disconnected us
            console.log('Server disconnected the client');
            connectionRecoveryAttempts = 0;
            attemptConnectionRecovery();
            break;

        case 'io client disconnect':
            // We disconnected intentionally
            console.log('Client disconnected normally');
            break;

        case 'ping timeout':
            // Heartbeat timeout
            console.log('Connection lost due to ping timeout');
            connectionRecoveryAttempts = 0;
            attemptConnectionRecovery();
            break;

        case 'transport close':
        case 'transport error':
            // Network issues
            console.log('Connection lost due to network issues');
            connectionRecoveryAttempts = 0;
            attemptConnectionRecovery();
            break;

        default:
            // Unknown reason, attempt recovery
            console.log('Connection lost for unknown reason');
            connectionRecoveryAttempts = 0;
            attemptConnectionRecovery();
    }
});

socket.on('reconnect_attempt', (attemptNumber) => {
    console.log(`Reconnection attempt ${attemptNumber}`);
    window.dispatchEvent(new CustomEvent('connectionStatusChanged', {
        detail: { status: 'reconnecting', attempt: attemptNumber }
    }));
});

socket.on('reconnect_error', (error) => {
    console.error('Socket.IO reconnect error:', error);

    // Don't show error on every attempt, only after a few
    if (connectionRecoveryAttempts >= 3) {
        showError('Having trouble reconnecting. Will keep trying...');
    }
});

socket.on('reconnect_failed', () => {
    console.error('Socket.IO reconnect failed');
    showError('Failed to reconnect to server. Please refresh the page.');

    window.dispatchEvent(new CustomEvent('connectionStatusChanged', {
        detail: { status: 'failed' }
    }));
});

socket.on('connection_status', (data) => {
    console.log('Connection status:', data);
    if (data.status === 'connected' && data.user_uuid) {
        state.isAuthenticated = true;
        state.currentUserUuid = data.user_uuid;
        console.log('User authenticated via connection status');

        // Request fresh data after authentication
        socket.emit('get_user_data');
        socket.emit('get_online_users');
    }
});

socket.on('pong', () => {
    // Clear the heartbeat timeout
    if (heartbeatTimeout) {
        clearTimeout(heartbeatTimeout);
        heartbeatTimeout = null;
    }

    // Reset missed heartbeats counter
    missedHeartbeats = 0;

    // Calculate latency
    const latency = Date.now() - lastPingTime;
    updateConnectionQuality(latency);

    console.log(`Received pong (latency: ${latency}ms, quality: ${connectionQuality})`);
});

socket.on('test_response', (data) => {
    console.log('Test response:', data);
});

socket.on('error', (error) => {
    console.error('Socket.IO error:', error);

    // Handle specific error types
    if (error.type === 'TransportError') {
        showError('Connection error. Attempting to reconnect...');
    } else if (error.message && error.message.includes('auth')) {
        showError('Authentication error. Please log in again.');
        // Could trigger re-authentication flow here
    }
});

// Clean up on page unload
window.addEventListener('beforeunload', () => {
    stopHeartbeat();
    clearRecoveryTimeout();
    socket.disconnect();
});

// Export functions that might be needed elsewhere
export {
    startHeartbeat,
    stopHeartbeat,
    attemptConnectionRecovery,
    connectionQuality
};