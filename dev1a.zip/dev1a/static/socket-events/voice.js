// socket-events/voice.js
import { state } from '../core/setup.js';

// Voice settings and call controls
function loadVoiceSettings() {
    let voiceUrl = window.currentUserSettings.voice_server_url;
    if (!voiceUrl) {
        voiceUrl = 'https://192.168.193.10:3000'; // Default for testing
    }

    const iframe = document.getElementById('voice-iframe');
    const fallback = document.getElementById('voice-fallback');

    if (voiceUrl && iframe) {
        iframe.src = voiceUrl;
        iframe.style.display = 'block';
        if (fallback) fallback.style.display = 'none';
    } else {
        if (iframe) iframe.style.display = 'none';
        if (fallback) fallback.style.display = 'block';
    }
}

// Update the members list in the sidebar
function updateVoiceMemberList() {
    const membersList = document.getElementById('members-list');
    if (!membersList) return;

    // Clear existing members
    membersList.innerHTML = '';

    // Get online users
    const onlineUsers = state.onlineUsers || [];

    // Add each online user
    onlineUsers.forEach(username => {
        const userData = window.users_db[username];
        if (!userData) return;

        const memberDiv = document.createElement('div');
        memberDiv.className = 'member';
        memberDiv.setAttribute('data-username', username);

        // Avatar
        const avatar = document.createElement('img');
        avatar.className = 'member-avatar';
        avatar.src = userData.avatar_url || '/static/default_avatars/smile_1.png';
        avatar.alt = username;

        // Name and status
        const memberInfo = document.createElement('div');
        memberInfo.className = 'member-info';

        const displayName = document.createElement('div');
        displayName.className = 'member-name';
        displayName.textContent = userData.display_name || userData.username || username;

        const status = document.createElement('div');
        status.className = 'member-status';
        status.textContent = userData.custom_status || 'Online';

        memberInfo.appendChild(displayName);
        memberInfo.appendChild(status);

        // Call controls (initially hidden)
        const callControls = document.createElement('div');
        callControls.className = 'member-call-controls';
        callControls.style.display = 'none';

        // Call button (for initiating calls)
        const callBtn = document.createElement('button');
        callBtn.className = 'member-call-btn';
        callBtn.innerHTML = '<i class="fas fa-phone"></i>';
        callBtn.title = 'Call User';
        // callBtn.onclick will be set up in the calls module

        memberDiv.appendChild(avatar);
        memberDiv.appendChild(memberInfo);
        memberDiv.appendChild(callControls);
        memberDiv.appendChild(callBtn);

        membersList.appendChild(memberDiv);
    });
}

// Export functions
export { loadVoiceSettings, updateVoiceMemberList };