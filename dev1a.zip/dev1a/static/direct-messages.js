// Direct Messages UI Logic
console.log('DM JS loaded');

// Soundboard Manager Class
class SoundboardManager {
    constructor() {
        this.soundEmojis = {};
        this.init();
    }

    async init() {
        console.log('Initializing SoundboardManager...');
        await this.loadSoundEmojis();
        setTimeout(() => {
            this.createSoundboardUI();
            this.bindEvents();
        }, 100);
    }

    async loadSoundEmojis() {
        try {
            const response = await fetch('/static/sounds/sound_board/sound_emojis.json');
            this.soundEmojis = await response.json();
            console.log('Sound emojis loaded:', this.soundEmojis);
        } catch (error) {
            console.error('Failed to load sound emojis:', error);
            this.soundEmojis = {};
        }
    }

    createSoundboardUI() {
        console.log('Creating soundboard UI...');
        const channelsContainer = document.querySelector('.channels-container');
        if (!channelsContainer) {
            console.error('Channels container not found for soundboard!');
            return;
        }

        // Check if soundboard already exists
        if (document.querySelector('.soundboard-sidebar-section')) {
            console.log('Soundboard UI already exists');
            return;
        }

        const soundboardSection = document.createElement('div');
        soundboardSection.className = 'soundboard-sidebar-section';
        soundboardSection.innerHTML = `
            <h3>Soundboard</h3>
            <div class="soundboard-grid" id="soundboard-grid">
                <!-- Sound buttons will be populated here -->
            </div>
        `;

        // Append to channels container (below voice channels)
        channelsContainer.appendChild(soundboardSection);

        this.populateSoundboard();
    }

    populateSoundboard() {
        const grid = document.getElementById('soundboard-grid');
        if (!grid) return;

        grid.innerHTML = '';

        Object.keys(this.soundEmojis).forEach(soundFile => {
            const emoji = this.soundEmojis[soundFile];
            const button = document.createElement('button');
            button.className = 'soundboard-button';
            button.dataset.soundFile = soundFile;
            button.title = soundFile.replace('.mp3', '').replace(/_/g, ' ');
            button.innerHTML = emoji;
            grid.appendChild(button);
        });
    }

    bindEvents() {
        // Soundboard button clicks
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('soundboard-button')) {
                const soundFile = e.target.dataset.soundFile;
                this.playSound(soundFile);
            }
        });

        // Socket listener for remote sounds
        if (window.socket) {
            console.log('Setting up soundboard socket listener');
            window.socket.on('soundboard_sound_played', (data) => {
                this.handleSoundboardSound(data);
            });
        } else {
            console.log('Socket not available for soundboard listener');
        }
    }

    playSound(soundFile) {
        if (!soundFile) return;

        // Play locally first
        if (window.soundManager) {
            window.soundManager.playSoundboard(soundFile);
        }

        // Emit to server for broadcasting
        if (window.socket && window.socket.connected) {
            window.socket.emit('play_soundboard_sound', { sound_file: soundFile });
        }
    }

    handleSoundboardSound(data) {
        console.log('Received soundboard_sound_played:', data);
        if (!data.sound_file) {
            console.log('No sound_file in data');
            return;
        }

        // Don't play if it's from the current user (they already played it locally)
        if (data.played_by === window.currentUsername) {
            console.log('Sound from self, skipping');
            return;
        }

        // Play the sound locally (other clients will handle their own settings)
        if (window.soundManager) {
            console.log('Calling soundManager.playSoundboard with:', data.sound_file);
            window.soundManager.playSoundboard(data.sound_file);
        } else {
            console.log('soundManager not available');
        }
    }
}

// Make SoundboardManager globally available
window.soundboardManager = new SoundboardManager();

class DirectMessagesManager {
    constructor() {
        this.activeTab = 'open';
        this.activeDM = null;
        this.dmUsers = new Map(); // user_id -> {username, avatar, lastMessage, timestamp, unreadCount}
        this.init();
    }

    init() {
        this.createDMUI();
        this.bindEvents();
        this.loadDMData();
    }

    createDMUI() {
        console.log('Creating DM UI...');
        // Note: Sidebar section replaced with soundboard - only creating DM modal

        // Create DM modal (initially hidden)
        const dmModal = document.createElement('div');
        dmModal.className = 'dm-modal hidden';
        dmModal.id = 'dm-modal';
        dmModal.innerHTML = `
            <div class="dm-modal-content">
                <div class="dm-modal-header">
                    <img class="avatar" src="/static/default_avatars/smile_1.png" alt="User">
                     <div class="user-info">
                         <h3>Loading...</h3>
                         <div class="status">Offline</div>
                     </div>
                     <div class="dm-header-buttons">
                         <button class="dm-delete-btn" title="Delete chat history"><i class="fas fa-trash"></i></button>
                         <button class="close-btn">&times;</button>
                     </div>
                </div>
                <div class="dm-messages-container" id="dm-messages-container">
                    <!-- Messages will be loaded here -->
                </div>
                <div class="dm-message-input-area">
                    <div class="dm-input-container">
                        <textarea class="dm-message-input" placeholder="Type your message..." rows="1"></textarea>
                         <div class="dm-input-buttons">
                             <button class="dm-send-btn" title="Send message"><i class="fas fa-paper-plane"></i></button>
                             <button class="dm-attach-btn" title="Attach file">📎</button>
                             <button class="dm-sticker-btn" title="Add sticker">😊</button>
                         </div>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(dmModal);
        console.log('DM modal created and appended to body');
        console.log('DM send button exists:', document.querySelector('.dm-send-btn'));
    }

    bindEvents() {
        // Tab switching
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('dm-tab')) {
                console.log('DM tab clicked:', e.target.dataset.tab);
                this.switchTab(e.target.dataset.tab);
            }
        });

        // New message button
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('dm-new-message-btn')) {
                console.log('New message button clicked');
                this.showNewMessageDialog();
            }
        });

        // DM item click
        document.addEventListener('click', (e) => {
            if (e.target.closest('.dm-bar-item')) {
                const item = e.target.closest('.dm-bar-item');
                const userId = item.dataset.userId;
                console.log('DM item clicked:', userId);
                this.openDM(userId);
            }
        });

        // Modal close
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('close-btn') || e.target.classList.contains('dm-modal')) {
                this.closeDMModal();
            }
        });

        // Delete chat history
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('dm-delete-btn') || e.target.closest('.dm-delete-btn')) {
                this.confirmDeleteChatHistory();
            }
        });

        // Message input
        document.addEventListener('keydown', (e) => {
            if (e.target.classList.contains('dm-message-input')) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendDMMessage();
                }
            }
        });

        // Auto-resize textarea
        document.addEventListener('input', (e) => {
            if (e.target.classList.contains('dm-message-input')) {
                this.autoResizeTextarea(e.target);
            }
        });

        // DM input buttons
        document.addEventListener('click', (e) => {
            console.log('Click event:', e.target.className, e.target);
            if (e.target.classList.contains('dm-send-btn') || e.target.closest('.dm-send-btn')) {
                console.log('DM send button clicked');
                this.sendDMMessage();
            } else if (e.target.classList.contains('dm-attach-btn')) {
                this.handleDMAttach();
            } else if (e.target.classList.contains('dm-sticker-btn')) {
                this.handleDMSticker();
            }
        });

        // Socket event listeners for DMs
        if (window.socket) {
            window.socket.on('dm_conversations_loaded', (data) => {
                this.handleDMConversationsLoaded(data.conversations);
            });

            window.socket.on('dm_messages_loaded', (data) => {
                this.handleDMMessagesLoaded(data.other_username, data.messages, data.is_load_more);
            });

            window.socket.on('dm_message_received', (data) => {
                this.handleDMMessageReceived(data);
            });

            window.socket.on('dm_message_sent', (data) => {
                // Message sent successfully
                console.log('DM sent:', data);
            });

            window.socket.on('dm_chat_history_deleted', (data) => {
                this.handleDMChatHistoryDeleted(data.other_username, data.deleted_count);
            });

            // Update DM avatar status when online users change
            window.socket.on('update_online_users', (data) => {
                this.updateDMAvatarStatus();
            });
        }
    }

    switchTab(tabName) {
        // Update active tab
        document.querySelectorAll('.dm-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        const tabElement = document.querySelector(`.dm-tab[data-tab="${tabName}"]`);
        if (tabElement) {
            tabElement.classList.add('active');
        }

        // Show corresponding content
        document.querySelectorAll('.dm-tab-content').forEach(content => {
            content.style.display = 'none';
        });
        const contentElement = document.querySelector(`.dm-tab-content[data-tab="${tabName}"]`);
        if (contentElement) {
            contentElement.style.display = 'block';
        }

        this.activeTab = tabName;
        this.updateTabContent(tabName);
    }

    updateTabContent(tabName) {
        const content = document.querySelector(`.dm-tab-content[data-tab="${tabName}"]`);
        if (!content) return;

        content.innerHTML = '';

        switch (tabName) {
            case 'open':
                this.renderOpenDMs(content);
                break;
            case 'new':
                content.innerHTML = '<button class="dm-new-message-btn">Start New Conversation</button>';
                break;
        }
    }



    renderOpenDMs(container) {
        if (this.dmUsers.size === 0) {
            container.innerHTML = '<div style="padding: 20px; text-align: center; color: var(--text-secondary);">No open conversations</div>';
            return;
        }

        Array.from(this.dmUsers.values()).forEach(user => {
            const item = this.createDMBarItem(user);
            container.appendChild(item);
        });
    }

    createDMBarItem(userData) {
        const item = document.createElement('div');
        item.className = 'dm-bar-item';
        item.dataset.userId = userData.userId;

        if (this.activeDM === userData.userId) {
            item.classList.add('active');
        }

        item.innerHTML = `
            <img class="avatar" src="${userData.avatar || '/static/default_avatars/smile_1.png'}" alt="${userData.username}">
            <div class="user-info">
                <div class="username">${userData.username}</div>
                <div class="last-message">${userData.lastMessage || 'No messages yet'}</div>
            </div>
            <div class="timestamp">${this.formatTimestamp(userData.timestamp)}</div>
            ${userData.unreadCount > 0 ? `<div class="notification-count">${userData.unreadCount}</div>` : ''}
        `;

        return item;
    }

    showNewMessageDialog() {
        console.log('Showing new message dialog');
        // For now, just show an alert. In a real implementation, this would open a user selector
        const recipient = prompt('Enter username to message:');
        console.log('Recipient entered:', recipient);
        if (recipient && recipient.trim()) {
            this.startNewDM(recipient.trim());
        }
    }

    startNewDM(username) {
        console.log('Starting new DM with:', username);

        // Close profile modal if open
        const profileModal = document.getElementById('user-profile-modal');
        if (profileModal) {
            profileModal.style.display = 'none';
        }

        // Check if DM already exists
        const existingUser = Array.from(this.dmUsers.values()).find(u => u.username === username);
        if (existingUser) {
            console.log('DM already exists, opening:', existingUser.userId);
            this.openDM(existingUser.userId);
            return;
        }

        // For new conversations, we need to create a temporary entry and load messages
        // In real implementation, this would check if user exists
        const userId = `dm_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

        // Get user avatar from users_db if available
        const userFromDb = window.users_db ? Object.values(window.users_db).find(u => u.username === username) : null;
        const userAvatar = userFromDb && userFromDb.avatar_url ? userFromDb.avatar_url : '/static/default_avatars/smile_1.png';

        const userData = {
            userId: userId,
            username: username,
            avatar: userAvatar,
            lastMessage: '',
            timestamp: Date.now(),
            unreadCount: 0,
            messages: []
        };

        this.dmUsers.set(userId, userData);
        console.log('Opening new DM:', userId);
        this.openDM(userId);
    }

    openDM(userId) {
        console.log('Opening DM for user:', userId);
        const userData = this.dmUsers.get(userId);
        if (!userData) {
            console.error('User data not found for:', userId);
            return;
        }

        this.activeDM = userId;
        userData.unreadCount = 0;

        // Update UI
        document.querySelectorAll('.dm-bar-item').forEach(item => {
            item.classList.remove('active');
        });
        const barItem = document.querySelector(`[data-user-id="${userId}"]`);
        if (barItem) {
            barItem.classList.add('active');
        }

        // Show modal
        const modal = document.getElementById('dm-modal');
        console.log('DM modal element:', modal);
        if (!modal) {
            console.error('DM modal not found!');
            return;
        }
        console.log('Showing DM modal');
        const header = modal.querySelector('.dm-modal-header');
        const avatar = header.querySelector('.avatar');
        const userInfo = header.querySelector('.user-info h3');
        const status = header.querySelector('.status');

        avatar.src = userData.avatar;
        userInfo.textContent = userData.username;

        // Update avatar status (online/offline styling)
        this.updateDMAvatarStatus();

        // Load messages from server
        if (window.socket && window.socket.connected) {
            console.log('Loading DM messages for:', userData.username);
            window.socket.emit('load_dm_messages', { other_username: userData.username });
        } else {
            console.log('Socket not ready for loading messages, using local data');
            // Fallback to local messages if available
            this.loadDMMessages(userId);
        }

        modal.classList.remove('hidden');
        console.log('DM modal shown, button should be visible:', document.querySelector('.dm-send-btn'));
    }

    closeDMModal() {
        const modal = document.getElementById('dm-modal');
        modal.classList.add('hidden');
        this.activeDM = null;

        // Remove active state from sidebar items
        document.querySelectorAll('.dm-bar-item').forEach(item => {
            item.classList.remove('active');
        });
    }

    updateDMAvatarStatus() {
        if (!this.activeDM) return;

        const modal = document.getElementById('dm-modal');
        if (!modal || modal.classList.contains('hidden')) return;

        const userData = this.dmUsers.get(this.activeDM);
        if (!userData) return;

        const avatar = modal.querySelector('.dm-modal-header .avatar');
        if (!avatar) return;

        const isOnline = window.onlineUsers.includes(userData.username);
        const status = modal.querySelector('.dm-modal-header .status');
        if (status) {
            status.textContent = isOnline ? 'Online' : 'Offline';
        }

        // Apply grey out effect to avatar when user is offline
        if (isOnline) {
            avatar.classList.remove('offline');
        } else {
            avatar.classList.add('offline');
        }
    }

    loadDMMessages(userId) {
        const container = document.getElementById('dm-messages-container');
        const userData = this.dmUsers.get(userId);

        if (!userData || !userData.messages) {
            container.innerHTML = '<div style="padding: 20px; text-align: center; color: var(--text-secondary);">No messages yet. Start the conversation!</div>';
            return;
        }

        container.innerHTML = '';

        // Add load more button if we have 50 messages (indicating there might be more)
        if (userData.messages.length >= 50) {
            const loadMoreBtn = document.createElement('button');
            loadMoreBtn.className = 'dm-load-more-btn';
            loadMoreBtn.innerHTML = 'Load Earlier Messages';
            loadMoreBtn.onclick = () => this.loadMoreDMMessages(userId);
            container.appendChild(loadMoreBtn);
        }

        userData.messages.forEach(message => {
            const messageElement = this.createMessageElement(message);
            container.appendChild(messageElement);
        });

        // Scroll to bottom
        container.scrollTop = container.scrollHeight;
    }

    createMessageElement(message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${message.isMine ? 'message-own' : 'message-other'}`;

        // Use existing message rendering logic if available
        // For now, simple implementation
        messageDiv.innerHTML = `
            <div class="message-content">
                <div class="message-text">${this.escapeHtml(message.text)}</div>
                <div class="message-time">${this.formatTimestamp(message.timestamp)}</div>
            </div>
        `;

        return messageDiv;
    }

    sendDMMessage() {
        console.log('sendDMMessage called');
        const input = document.querySelector('.dm-message-input');
        const message = input.value.trim();
        console.log('Message:', message, 'Active DM:', this.activeDM);
        if (!message || !this.activeDM) {
            console.log('Missing message or active DM, returning');
            return;
        }

        const userData = this.dmUsers.get(this.activeDM);
        if (!userData) {
            console.log('User data not found');
            return;
        }

        // Send via socket
        if (window.socket && window.socket.connected) {
            console.log('Sending DM to:', userData.username);
            console.log('Socket connected:', window.socket.connected);
            if (userData.username === 'AI Assistant') {
                window.socket.emit('ai_dm_message', {
                    message: message
                });
                console.log('AI DM message emitted');
            } else {
                window.socket.emit('send_dm_message', {
                    recipient_username: userData.username,
                    message: message,
                    is_media: 0
                });
                console.log('DM message emitted');
            }

            // Optimistically add to local messages
            const messageObj = {
                text: message,
                timestamp: Date.now(),
                isMine: true,
                sender: window.currentUsername || 'You'
            };

            if (!userData.messages) userData.messages = [];
            userData.messages.push(messageObj);
            userData.lastMessage = message;
            userData.timestamp = Date.now();

            // Update UI
            this.loadDMMessages(this.activeDM);
            this.updateTabContent(this.activeTab);

            // Clear input
            input.value = '';
            this.autoResizeTextarea(input);
        } else {
            console.error('Socket not available for sending DM');
        }
    }

    loadDMData() {
        // Load DM conversations from server
        console.log('loadDMData called, socket:', window.socket, 'connected:', window.socket?.connected);
        if (window.socket && window.socket.connected) {
            console.log('Loading DM conversations...');
            window.socket.emit('load_dm_conversations');
        } else {
            console.log('Socket not ready, waiting...');
            // Wait for socket to be ready
            this.waitForSocket();
        }
    }

    waitForSocket() {
        if (window.socket && window.socket.connected) {
            console.log('Socket now ready, loading DM conversations');
            this.loadDMData();
        } else {
            setTimeout(() => this.waitForSocket(), 500);
        }
    }



    autoResizeTextarea(textarea) {
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
    }

    formatTimestamp(timestamp) {
        if (!timestamp) return '';

        const now = Date.now();
        const diff = now - timestamp;
        const minutes = Math.floor(diff / 60000);
        const hours = Math.floor(diff / 3600000);
        const days = Math.floor(diff / 86400000);

        if (minutes < 1) return new Date(timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        if (minutes < 60) return `${minutes}m`;
        if (hours < 24) return `${hours}h`;
        if (days < 7) return `${days}d`;

        return new Date(timestamp).toLocaleDateString();
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    autoResizeTextarea(textarea) {
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
    }

    handleDMAttach() {
        // TODO: Implement file attachment for DMs
        console.log('DM attach clicked');
        alert('File attachment for DMs not yet implemented');
    }

    handleDMSticker() {
        // TODO: Implement sticker picker for DMs
        console.log('DM sticker clicked');
        alert('Sticker picker for DMs not yet implemented');
    }

    handleDMConversationsLoaded(conversations) {
        console.log('DM conversations loaded:', conversations);
        this.dmUsers.clear();

        conversations.forEach(conv => {
            this.dmUsers.set(conv.user_uuid, {
                userId: conv.user_uuid,
                username: conv.username,
                avatar: conv.avatar_url || '/static/default_avatars/smile_1.png',
                displayName: conv.display_name,
                lastMessage: conv.last_message,
                timestamp: new Date(conv.last_timestamp).getTime(),
                unreadCount: conv.unread_count,
                messages: [] // Will be loaded when opened
            });
        });

        this.updateTabContent(this.activeTab);
    }

    handleDMMessagesLoaded(otherUsername, messages, isLoadMore = false) {
        console.log('DM messages loaded for', otherUsername, messages, 'isLoadMore:', isLoadMore);

        // Find the conversation
        const conversation = Array.from(this.dmUsers.values()).find(u => u.username === otherUsername);
        if (conversation) {
            const newMessages = messages.map(msg => ({
                text: msg.message,
                timestamp: new Date(msg.timestamp).getTime(),
                isMine: msg.is_mine,
                sender: msg.is_mine ? 'You' : otherUsername,
                id: msg.id
            }));

            if (isLoadMore) {
                // Append older messages to the beginning
                conversation.messages.unshift(...newMessages);
            } else {
                // Replace messages for initial load
                conversation.messages = newMessages;
            }

            // Update last message if needed (only for initial load or if we have newer messages)
            if (!isLoadMore && messages.length > 0) {
                const lastMsg = messages[messages.length - 1];
                conversation.lastMessage = lastMsg.message;
                conversation.timestamp = new Date(lastMsg.timestamp).getTime();
            }

            // If this conversation is currently open, update the messages
            if (this.activeDM === conversation.userId) {
                const container = document.getElementById('dm-messages-container');
                const wasAtBottom = container && (container.scrollTop + container.clientHeight >= container.scrollHeight - 10);

                this.loadDMMessages(conversation.userId);

                // If we were at the bottom before loading more, scroll back to bottom
                if (!isLoadMore && wasAtBottom) {
                    setTimeout(() => {
                        if (container) container.scrollTop = container.scrollHeight;
                    }, 100);
                }
            }

            this.updateTabContent(this.activeTab);
        }
    }

    handleDMMessageReceived(data) {
        console.log('DM received:', data);

        // Find or create conversation
        let conversation = Array.from(this.dmUsers.values()).find(u => u.username === data.sender_username);
        if (!conversation) {
            // New conversation
            const userId = `dm_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

            // Get user avatar from users_db if available
            const userFromDb = window.users_db ? Object.values(window.users_db).find(u => u.username === data.sender_username) : null;
            const userAvatar = userFromDb && userFromDb.avatar_url ? userFromDb.avatar_url : '/static/default_avatars/smile_1.png';

            conversation = {
                userId: userId,
                username: data.sender_username,
                avatar: userAvatar,
                lastMessage: data.message,
                timestamp: Date.now(),
                unreadCount: 1,
                messages: []
            };
            this.dmUsers.set(userId, conversation);
        } else {
            conversation.unreadCount++;
            conversation.lastMessage = data.message;
            conversation.timestamp = Date.now();
        }

        // Add message to conversation
        conversation.messages.push({
            text: data.message,
            timestamp: Date.now(),
            isMine: false,
            sender: data.sender_username
        });

        // Update UI
        this.updateTabContent(this.activeTab);

        // If conversation is open, update messages
        if (this.activeDM === conversation.userId) {
            this.loadDMMessages(conversation.userId);
        }
    }

    handleDMChatHistoryDeleted(otherUsername, deletedCount) {
        console.log(`Chat history deleted with ${otherUsername}, ${deletedCount} messages removed`);

        // Find the conversation
        const conversation = Array.from(this.dmUsers.values()).find(u => u.username === otherUsername);
        if (conversation) {
            // Clear messages
            conversation.messages = [];
            conversation.lastMessage = '';
            conversation.timestamp = Date.now();

            // If conversation is open, update the display
            if (this.activeDM === conversation.userId) {
                this.loadDMMessages(conversation.userId);
            }

            this.updateTabContent(this.activeTab);
        }
    }

    confirmDeleteChatHistory() {
        if (!this.activeDM) return;

        const userData = this.dmUsers.get(this.activeDM);
        if (!userData) return;

        const confirmed = confirm(`Are you sure you want to delete the entire chat history with ${userData.username}? This action cannot be undone and will delete messages for both users.`);
        if (confirmed) {
            this.deleteChatHistory(userData.username);
        }
    }

    deleteChatHistory(otherUsername) {
        if (!window.socket) {
            console.error('Socket not available');
            return;
        }

        window.socket.emit('delete_dm_chat_history', {
            other_username: otherUsername
        });
    }

    loadMoreDMMessages(userId) {
        const userData = this.dmUsers.get(userId);
        if (!userData || !userData.messages || userData.messages.length === 0) return;

        // Get the oldest message ID for pagination
        const oldestMessage = userData.messages[0]; // messages are in chronological order
        const beforeMessageId = oldestMessage.id;

        if (!window.socket) {
            console.error('Socket not available');
            return;
        }

        window.socket.emit('load_more_dm_messages', {
            other_username: userData.username,
            before_message_id: beforeMessageId
        });
    }
}

// Initialize after a short delay to ensure DOM is ready
setTimeout(() => {
    console.log('Initializing DM Manager...');
    window.dmManager = new DirectMessagesManager();
    console.log('DM Manager initialized');
}, 1000);

// DirectMessagesManager is available as window.dmManager