// static/webrtc/ui.js - WebRTC UI management for media members and status indicators
import { socket } from '../core/setup.js';

export class WebRTCUIManager {
    constructor(manager) {
        this.manager = manager;
        this.currentStreamViewers = {};
    }

    updateMediaIcon() {
        const voiceIcon = document.getElementById('voice-icon');
        if (voiceIcon) {
            if (this.manager.activeMediaTypes.has('audio')) {
                voiceIcon.className = 'fas fa-microphone media-icon active';
            } else {
                voiceIcon.className = 'fas fa-microphone-slash media-icon';
            }
        }

        const videoIcon = document.getElementById('webcam-icon');
        if (videoIcon) {
            if (this.manager.activeMediaTypes.has('video')) {
                videoIcon.className = 'fas fa-video media-icon active';
            } else {
                videoIcon.className = 'fas fa-video-slash media-icon';
            }
        }

        const screenshareIcon = document.getElementById('screenshare-icon');
        if (screenshareIcon) {
            if (this.manager.activeMediaTypes.has('screenshare')) {
                screenshareIcon.className = 'fas fa-desktop media-icon active';
            } else {
                screenshareIcon.className = 'fas fa-desktop media-icon';
            }
        }
    }

    updateMediaMembersList(participants) {
        const mediaMembersList = document.getElementById('media-members-list');
        if (!mediaMembersList) return;

        // Clear existing list
        mediaMembersList.innerHTML = '';

        // Add all participants, marking current user appropriately
        participants.forEach(participant => {
            const isCurrentUser = (participant.id === this.manager.userName);
            this.addMediaMemberToUI(participant.id, isCurrentUser, participant.name);
        });

        this.updateMediaMembersCount();
    }

    addMediaMember(userId) {
        // Only add if not already in the list
        const existingMember = document.querySelector(`.media-member[data-user-id="${userId}"]`);
        if (!existingMember) {
            console.log(`Adding media member: ${userId}`);
            this.addMediaMemberToUI(userId, false);
            this.updateMediaMembersCount();
        } else {
            console.log(`Media member ${userId} already exists, updating`);
            // Update existing member in case username became available
            this.updateExistingMediaMember(userId);
        }
    }

    updateExistingMediaMember(userId) {
        const memberElement = document.querySelector(`.media-member[data-user-id="${userId}"]`);
        if (memberElement) {
            // Get updated user info using unified logic
            let displayName = 'Guest';
            let avatarUrl = '/static/default_avatars/smile_1.png';

            if (window.users_db && typeof window.users_db === 'object') {
                let userData = null;
                if (this.isUUID(userId)) {
                    console.log(`[VOICE] UUID lookup for ${userId}`);
                    userData = window.users_db[userId];  // Direct object access by UUID key
                } else {
                    console.log(`[VOICE] Username lookup for ${userId}`);
                    userData = Object.values(window.users_db).find(u => u.username === userId || u.display_name === userId);
                }

                if (userData) {
                    avatarUrl = userData.avatar_url || avatarUrl;
                    displayName = userData.display_name || userData.username || userId;
                    console.log(`[VOICE] Found userData: ${JSON.stringify(userData)}, displayName: ${displayName}`);
                } else {
                    displayName = userId;  // Fallback to userId if no match
                    console.log(`[VOICE] No userData found for ${this.isUUID(userId) ? 'UUID' : 'username'} ${userId}, using ${displayName}`);
                }
            } else {
                console.log(`[VOICE] window.users_db not available or corrupted, using ${displayName}`);
            }

            // Update the name display
            const nameElement = memberElement.querySelector('.member-name');
            if (nameElement && nameElement.textContent !== displayName) {
                nameElement.textContent = displayName;
                console.log(`Updated username for ${userId} to ${displayName}`);
            }

            // Update avatar if needed
            const avatarElement = memberElement.querySelector('.member-avatar img');
            if (avatarElement && avatarElement.src !== avatarUrl) {
                avatarElement.src = avatarUrl;
            }
        }
    }

    removeMediaMember(userId) {
        const memberElement = document.querySelector(`.media-member[data-user-id="${userId}"]`);
        if (memberElement) {
            memberElement.remove();
            this.updateMediaMembersCount();
        }
    }

    addMediaMemberToUI(userId, isCurrentUser = false, participantName = null) {
        const mediaMembersList = document.getElementById('media-members-list');
        if (!mediaMembersList) return;

        const memberElement = document.createElement('div');
        memberElement.className = `member media-member${isCurrentUser ? ' current-user' : ''}`;
        memberElement.setAttribute('data-user-id', userId);

        // Get user avatar and name from global users_db if available
        let avatarUrl = '/static/default_avatars/smile_1.png';
        let displayName = participantName || 'Guest';  // Use provided name as fallback

        if (window.users_db && typeof window.users_db === 'object') {
            let userData = null;
            if (this.isUUID(userId)) {
                console.log(`[VOICE] UUID lookup for ${userId}`);
                userData = window.users_db[userId];  // Direct object access by UUID key
            } else {
                console.log(`[VOICE] Username lookup for ${userId}`);
                userData = Object.values(window.users_db).find(u => u.username === userId || u.display_name === userId);
            }

            if (userData) {
                avatarUrl = userData.avatar_url || avatarUrl;
                displayName = userData.display_name || userData.username || participantName || userId;
                console.log(`[VOICE] Found userData: ${JSON.stringify(userData)}, displayName: ${displayName}`);
            } else {
                displayName = participantName || userId;  // Fallback to provided name or userId
                console.log(`[VOICE] No userData found for ${this.isUUID(userId) ? 'UUID' : 'username'} ${userId}, using ${displayName}`);
            }
        } else {
            console.log(`[VOICE] window.users_db not available or corrupted, using ${displayName}`);
        }

        memberElement.innerHTML = `
            <div class="member-avatar">
                <img src="${avatarUrl}" alt="Avatar">
                <div class="status-dot media-status"></div>
                <div class="media-indicators">
                    <i class="fas fa-video media-indicator video-indicator" style="display: none;" title="Sharing video"></i>
                    <i class="fas fa-microphone media-indicator mic-indicator" style="display: none;" title="Microphone active"></i>
                    <i class="fas fa-microphone-slash media-indicator mic-muted-indicator" style="display: none;" title="Microphone muted"></i>
                    <i class="fas fa-desktop media-indicator screenshare-indicator" style="display: none;" title="Sharing screen"></i>
                </div>
            </div>
            <div class="member-info">
                <span class="member-name">${displayName}</span>
                <span class="member-status">In media</span>
            </div>
        `;

        // Add click handler to view stream (only for other users)
        if (!isCurrentUser) {
            memberElement.style.cursor = 'pointer';
            memberElement.title = `Click to view ${displayName}'s stream`;
            memberElement.addEventListener('click', () => {
                this.requestAndViewStream(userId);
            });

            // Add hover tooltip with media status
            memberElement.addEventListener('mouseenter', () => {
                const tooltip = this.getMediaStatusTooltip(userId, displayName);
                this.showTooltip(memberElement, tooltip);
            });
            memberElement.addEventListener('mouseleave', () => {
                this.hideTooltip();
            });
        }

        mediaMembersList.appendChild(memberElement);
    }

    updateUniversalVoiceMembersList(voiceMembers) {
        console.log('[VOICE] Updating universal voice members list with:', voiceMembers);
        const voiceMembersList = document.getElementById('media-members-list');
        if (!voiceMembersList) {
            console.log('[VOICE] media-members-list element not found');
            return;
        }

        console.log('[VOICE] Current users_db:', window.users_db);
        console.log('[VOICE] Current userName:', this.manager.userName);

        // Clear existing list
        voiceMembersList.innerHTML = '';

        // Count total voice members across all channels
        let totalMembers = 0;

        // Group members by channel and create UI
        for (const [channelName, members] of Object.entries(voiceMembers)) {
            if (members && members.length > 0) {
                // Create channel header
                const channelHeader = document.createElement('div');
                channelHeader.className = 'voice-channel-header';
                channelHeader.innerHTML = `
                    <div class="channel-name">${channelName}</div>
                    <div class="channel-count">${members.length}</div>
                `;
                channelHeader.style.cursor = 'pointer';
                channelHeader.title = `👁️ Click to open voice viewer for ${channelName}`;
                channelHeader.addEventListener('click', () => {
                    if (window.openVoiceChat) {
                        window.openVoiceChat(channelName);
                    }
                });
                voiceMembersList.appendChild(channelHeader);

                // Add members for this channel
                members.forEach(member => {
                    const memberElement = document.createElement('div');
                    memberElement.className = 'member voice-member';
                    memberElement.setAttribute('data-user-id', member.id);
                    memberElement.setAttribute('data-channel', channelName);

                    // Get user info
                    let displayName = member.name || 'Guest';
                    let avatarUrl = '/static/default_avatars/smile_1.png';

                    if (window.users_db && typeof window.users_db === 'object') {
                        let userData = null;
                        if (this.isUUID(member.id)) {
                            userData = window.users_db[member.id];
                        } else {
                            userData = Object.values(window.users_db).find(u => u.username === member.id || u.display_name === member.id);
                        }

                        if (userData) {
                            avatarUrl = userData.avatar_url || avatarUrl;
                            displayName = userData.display_name || userData.username || member.name || member.id;
                        }
                    }

                    memberElement.innerHTML = `
                        <div class="member-avatar">
                            <img src="${avatarUrl}" alt="Avatar">
                            <div class="status-dot voice-status"></div>
                            <div class="voice-indicators">
                                <i class="fas fa-microphone voice-indicator mic-indicator" style="display: ${member.audio_active ? 'block' : 'none'};" title="Voice active"></i>
                                <i class="fas fa-video voice-indicator video-indicator" style="display: ${member.video_active ? 'block' : 'none'};" title="Video active"></i>
                                <i class="fas fa-desktop voice-indicator screenshare-indicator" style="display: ${member.screenshare_active ? 'block' : 'none'};" title="Screenshare active"></i>
                                <i class="fas fa-microphone-slash voice-indicator mic-muted-indicator" style="display: ${member.muted ? 'block' : 'none'};" title="Muted"></i>
                            </div>
                        </div>
                        <div class="member-info">
                            <span class="member-name">${displayName}</span>
                            <span class="member-status">In voice</span>
                        </div>
                    `;

                    // Add click handler for non-current user members
                    if (member.id !== this.manager.userName) {
                        memberElement.style.cursor = 'pointer';
                        memberElement.title = `Click to view ${displayName}'s stream`;
                        memberElement.addEventListener('click', () => {
                            this.requestAndViewStream(member.id);
                        });
                    }

                    voiceMembersList.appendChild(memberElement);
                });

                totalMembers += members.length;
            }
        }

        // Update header count
        const header = document.querySelector('.media-members-section .member-header h3');
        if (header) {
            header.textContent = `VOICE MEMBERS - ${totalMembers}`;
        }

        console.log(`[VOICE] Updated voice members list with ${totalMembers} total members across ${Object.keys(voiceMembers).length} channels`);
    }

    updateMediaMembersCount() {
        // This method is now replaced by updateUniversalVoiceMembersList
        // Keeping for backward compatibility
        const mediaMembersList = document.getElementById('media-members-list');
        const header = document.querySelector('.media-members-section .member-header h3');
        if (mediaMembersList && header) {
            const count = mediaMembersList.children.length;
            header.textContent = `VOICE MEMBERS - ${count}`;
        }
    }

    updateMemberMediaStatus(userId, mediaType, active) {
        const memberElement = document.querySelector(`.media-member[data-user-id="${userId}"]`);
        if (memberElement) {
            let indicatorClass;
            switch (mediaType) {
                case 'voice':
                case 'audio':
                    indicatorClass = 'mic-indicator';
                    break;
                case 'video':
                    indicatorClass = 'video-indicator';
                    break;
                case 'screenshare':
                    indicatorClass = 'screenshare-indicator';
                    break;
                case 'mic-muted':
                    indicatorClass = 'mic-muted-indicator';
                    break;
                case 'mic-indicator':
                    indicatorClass = 'mic-indicator';
                    break;
                default:
                    indicatorClass = `${mediaType}-indicator`;
            }

            const indicator = memberElement.querySelector(`.${indicatorClass}`);
            if (indicator) {
                indicator.style.display = active ? 'block' : 'none';
            }
        }
    }

    requestAndViewStream(userId) {
        const peer = this.manager.peerManager.getPeer(userId);
        if (peer && peer.stream) {
            const stream = peer.stream;
            const videoTracks = stream.getVideoTracks();
            if (videoTracks.length === 0) {
                console.log(`No video tracks available for ${userId}`);
                if (typeof showError === 'function') {
                    showError('No video stream available for this user');
                }
                return;
            }

            videoTracks.forEach((track, index) => {
                const videoStream = new MediaStream([track]);
                const label = track.label || `Stream ${index + 1}`;
                this.openStreamViewer(videoStream, userId, label);
            });
        } else {
            console.log(`No active stream found for ${userId}`);
        }
    }

    openStreamViewer(stream, userId, label = '') {
        const viewerId = `stream-viewer-${userId}-${Date.now()}`; // Unique ID
        const viewer = document.createElement('div');
        viewer.className = 'stream-viewer';
        viewer.id = viewerId;
        viewer.style.position = 'fixed';
        viewer.style.top = '100px';
        viewer.style.left = '50%';
        viewer.style.transform = 'translateX(-50%)';
        viewer.style.width = '500px';
        viewer.style.height = '400px';
        viewer.style.backgroundColor = 'rgba(0, 0, 0, 0.9)';
        viewer.style.border = '2px solid #ccc';
        viewer.style.borderRadius = '8px';
        viewer.style.display = 'flex';
        viewer.style.flexDirection = 'column';
        viewer.style.zIndex = '2000';
        viewer.style.resize = 'both';
        viewer.style.overflow = 'hidden';

        const header = document.createElement('div');
        header.style.display = 'flex';
        header.style.justifyContent = 'space-between';
        header.style.alignItems = 'center';
        header.style.padding = '10px';
        header.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
        header.style.cursor = 'move';
        header.style.userSelect = 'none';

        const title = document.createElement('span');
        title.textContent = `Stream from ${userId} ${label ? `(${label})` : ''}`;
        title.style.color = 'white';
        title.style.fontSize = '14px';

        const buttons = document.createElement('div');
        buttons.style.display = 'flex';
        buttons.style.gap = '10px';

        const pipBtn = document.createElement('button');
        pipBtn.innerHTML = '📺';
        pipBtn.title = 'Picture-in-Picture';
        pipBtn.style.background = 'none';
        pipBtn.style.border = 'none';
        pipBtn.style.color = 'white';
        pipBtn.style.cursor = 'pointer';
        pipBtn.style.fontSize = '16px';
        pipBtn.addEventListener('click', async () => {
            try {
                if (document.pictureInPictureElement) {
                    await document.exitPictureInPicture();
                } else if (video.requestPictureInPicture) {
                    await video.requestPictureInPicture();
                }
            } catch (error) {
                console.error('Picture-in-Picture error:', error);
            }
        });

        const closeBtn = document.createElement('button');
        closeBtn.innerHTML = '&times;';
        closeBtn.style.background = 'none';
        closeBtn.style.border = 'none';
        closeBtn.style.color = 'white';
        closeBtn.style.cursor = 'pointer';
        closeBtn.style.fontSize = '20px';
        closeBtn.addEventListener('click', () => {
            this.closeStreamViewer(userId);
        });

        buttons.appendChild(pipBtn);
        buttons.appendChild(closeBtn);
        header.appendChild(title);
        header.appendChild(buttons);

        const video = document.createElement('video');
        video.srcObject = stream;
        video.autoplay = true;
        video.controls = true;
        video.muted = true; // Mute to avoid duplicate audio, since audio is handled separately
        video.style.flex = '1';
        video.style.width = '100%';
        video.style.height = '100%';
        video.style.objectFit = 'contain';

        // Dragging functionality
        let isDragging = false;
        let dragStartX, dragStartY, initialX, initialY;

        const handleMouseDown = (e) => {
            isDragging = true;
            dragStartX = e.clientX;
            dragStartY = e.clientY;
            const rect = viewer.getBoundingClientRect();
            initialX = rect.left;
            initialY = rect.top;
            viewer.style.transform = 'none';
            viewer.style.left = initialX + 'px';
            viewer.style.top = initialY + 'px';
        };

        const handleMouseMove = (e) => {
            if (isDragging) {
                const dx = e.clientX - dragStartX;
                const dy = e.clientY - dragStartY;
                viewer.style.left = (initialX + dx) + 'px';
                viewer.style.top = (initialY + dy) + 'px';
            }
        };

        const handleMouseUp = () => {
            isDragging = false;
        };

        header.addEventListener('mousedown', handleMouseDown);
        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);

        // Keyboard navigation
        const handleKeydown = (e) => {
            if (e.key === 'Escape') {
                this.closeStreamViewer(userId);
            }
        };
        document.addEventListener('keydown', handleKeydown);

        // Clean up listeners when closing
        const cleanup = () => {
            document.removeEventListener('keydown', handleKeydown);
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        };
        closeBtn.addEventListener('click', cleanup, { once: true });

        viewer.appendChild(header);
        viewer.appendChild(video);
        document.body.appendChild(viewer);

        this.currentStreamViewers[userId] = this.currentStreamViewers[userId] || [];
        this.currentStreamViewers[userId].push({ viewer, track: stream.getTracks()[0] }); // Associate track for cleanup
    }

    closeStreamViewer(userId) {
        if (this.currentStreamViewers && this.currentStreamViewers[userId]) {
            this.currentStreamViewers[userId].forEach(({ viewer }) => {
                const video = viewer.querySelector('video');
                if (video) {
                    video.pause();
                    video.srcObject = null;
                }
                if (document.body.contains(viewer)) document.body.removeChild(viewer);
            });
            delete this.currentStreamViewers[userId];
        }
    }

    closeStreamViewerByTrack(userId, track) {
        if (this.currentStreamViewers && this.currentStreamViewers[userId]) {
            this.currentStreamViewers[userId] = this.currentStreamViewers[userId].filter(({ viewer, track: viewerTrack }) => {
                if (viewerTrack === track) {
                    const video = viewer.querySelector('video');
                    if (video) {
                        video.pause();
                        video.srcObject = null;
                    }
                    if (document.body.contains(viewer)) document.body.removeChild(viewer);
                    return false;
                }
                return true;
            });
            if (this.currentStreamViewers[userId].length === 0) {
                delete this.currentStreamViewers[userId];
            }
        }
    }

    getMediaStatusTooltip(userId, displayName) {
        const memberElement = document.querySelector(`.media-member[data-user-id="${userId}"]`);
        if (!memberElement) return `${displayName} - In media`;

        const indicators = memberElement.querySelectorAll('.media-indicator');
        const activeMedia = [];
        let isMuted = false;

        indicators.forEach(indicator => {
            if (indicator.style.display !== 'none') {
                const title = indicator.getAttribute('title');
                if (title) {
                    if (indicator.classList.contains('mic-muted-indicator')) {
                        isMuted = true;
                    } else if (indicator.classList.contains('mic-indicator')) {
                        activeMedia.push(title.toLowerCase());
                    } else {
                        activeMedia.push(title.toLowerCase());
                    }
                }
            }
        });

        if (activeMedia.length === 0) {
            return `${displayName} - In media${isMuted ? ' (muted)' : ''}`;
        }

        const status = activeMedia.join(', ');
        return `${displayName} - ${status}${isMuted ? ' (muted)' : ''}`;
    }

    showTooltip(element, text) {
        // Remove existing tooltip
        this.hideTooltip();

        const tooltip = document.createElement('div');
        tooltip.className = 'media-tooltip';
        tooltip.textContent = text;
        tooltip.style.position = 'fixed';
        tooltip.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
        tooltip.style.color = 'white';
        tooltip.style.padding = '4px 8px';
        tooltip.style.borderRadius = '4px';
        tooltip.style.fontSize = '12px';
        tooltip.style.pointerEvents = 'none';
        tooltip.style.zIndex = '3000';
        tooltip.style.whiteSpace = 'nowrap';

        document.body.appendChild(tooltip);

        // Position tooltip
        const rect = element.getBoundingClientRect();
        tooltip.style.left = `${rect.right + 10}px`;
        tooltip.style.top = `${rect.top + (rect.height / 2) - (tooltip.offsetHeight / 2)}px`;

        this.currentTooltip = tooltip;
    }

    hideTooltip() {
        if (this.currentTooltip) {
            this.currentTooltip.remove();
            this.currentTooltip = null;
        }
    }

    isUUID(str) {
        // Simple UUID check - can be improved
        return str && str.length > 20 && str.includes('-');
    }
}