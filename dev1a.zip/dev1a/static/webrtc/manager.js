// static/webrtc/manager.js - Main WebRTC manager that orchestrates all modules
import { socket } from '../core/setup.js';
import { WebRTCPeerManager } from './peer.js';
import { WebRTCMediaManager } from './media.js';
import { WebRTCUIManager } from './ui.js';
import { WebRTCUtils } from './utils.js';
import { initVoiceChat } from './voice-chat.js';

export class WebRTCManager {
    constructor() {
        this.socket = socket;
        this.localStream = null;
        this.roomName = null;
        this.userName = null;
        this.activeMediaTypes = new Set(); // Track active media: 'audio', 'video', 'screenshare'
        this.isConnected = false;
        this.audioContext = null;
        this.localGainNode = null;
        this.localVolume = 1.0; // Default volume
        this.stunConfig = {
            iceServers: [] // Will be populated by server config
        };
        this.lastActivity = Date.now();
        this.heartbeatInterval = null;
        this.wasAutoMuted = false;

        // Initialize sub-managers
        this.peerManager = new WebRTCPeerManager(this);
        this.mediaManager = new WebRTCMediaManager(this);
        this.uiManager = new WebRTCUIManager(this);
        this.utils = new WebRTCUtils(this);
        this.voiceChatManager = initVoiceChat(this);

        this.initSocket();
    }

    initSocket() {
        console.log('Using main socket for voice functionality');

        this.socket.on('connect', () => {
            console.log('Connected to voice server');
            // Rejoin room if we were in one before disconnect
            if (this.roomName && this.userName) {
                console.log(`Rejoining room ${this.roomName} as ${this.userName} after reconnect`);
                this.socket.emit('join-room', { room: this.roomName, userName: this.userName });
            }
        });

        this.socket.on('disconnect', () => {
            console.log('Disconnected from voice server');
            // Leave room and clean up WebRTC state to prevent stale state interfering with new calls
            this.leaveRoom();
            // Clear media members on disconnect to prevent leftover members
            const mediaMembersList = document.getElementById('media-members-list');
            if (mediaMembersList) {
                mediaMembersList.innerHTML = '';
                this.uiManager.updateMediaMembersCount();
            }
        });

        this.socket.on('connect_error', (error) => {
            console.error('Voice server connection error:', error);
        });

        // Request STUN config from server
        this.socket.emit('request_webrtc_config');

        this.socket.on('webrtc_config', (config) => {
            console.log('Received WebRTC config:', config);
            // For LAN-only use, use provided iceServers or empty array for direct connections
            this.stunConfig = { iceServers: config.iceServers || [] };
            console.log('WebRTC config updated:', this.stunConfig);
        });

        this.socket.on('room-participants', (data) => {
            console.log('Room participants:', data.participants);
            this.handleRoomParticipants(data.participants);
        });

        this.socket.on('user-joined', (data) => {
            console.log('User joined:', data.userId);
            this.peerManager.createPeer(data.userId);
            this.uiManager.addMediaMember(data.userId);
            // Update the media members count after adding
            this.uiManager.updateMediaMembersCount();

            // Update voice chat modal if open
            if (this.voiceChatManager && this.voiceChatManager.currentChannel) {
                // Add the new participant to the voice chat
                this.voiceChatManager.addParticipant(data.userId);
            }
        });

        this.socket.on('user-left', (data) => {
            console.log('User left:', data.userId);
            this.peerManager.removePeer(data.userId);
            this.uiManager.removeMediaMember(data.userId);
            // Update the media members count after removing
            this.uiManager.updateMediaMembersCount();

            // Update voice chat modal if open
            if (this.voiceChatManager && this.voiceChatManager.currentChannel) {
                // Remove the participant from the voice chat
                this.voiceChatManager.removeParticipant(data.userId);
            }
        });

        this.socket.on('signal', (data) => {
            this.peerManager.handleSignal(data);
        });

        // Add handlers for new voice server events
        this.socket.on('audio-status', (data) => {
            console.log('Audio status update:', data);
        });

        this.socket.on('voice-disconnect', (data) => {
            console.log('Voice disconnect update:', data);
        });

        this.socket.on('chat-message', (data) => {
            console.log('Voice chat message:', data);
        });

        this.socket.on('sound-board', (data) => {
            console.log('Sound board played:', data);
        });

        this.socket.on('video-request', (data) => {
            console.log('Video request received:', data);
        });

        this.socket.on('voice-start', (data) => {
            this.utils.handleMediaStart(data.userId, 'voice');
        });

        this.socket.on('voice-stop', (data) => {
            this.utils.handleMediaStop(data.userId, 'voice');
        });

        this.socket.on('video-start', (data) => {
            this.utils.handleMediaStart(data.userId, 'video');
        });

        this.socket.on('video-stop', (data) => {
            this.utils.handleMediaStop(data.userId, 'video');
        });

        this.socket.on('screenshare-start', (data) => {
            this.utils.handleMediaStart(data.userId, 'screenshare');
        });

        this.socket.on('screenshare-stop', (data) => {
            this.utils.handleMediaStop(data.userId, 'screenshare');
        });

        this.socket.on('mute', (data) => {
            console.log('Mute event received:', data);
            this.utils.handleMute(data.userId);
        });

        this.socket.on('unmute', (data) => {
            console.log('Unmute event received:', data);
            this.utils.handleUnmute(data.userId);
        });

        // Handle universal voice members updates
        this.socket.on('voice-members-update', (data) => {
            console.log('[VOICE] Voice members update received:', data.voice_members);
            this.utils.handleVoiceMembersUpdate(data.voice_members);
        });
    }

    joinRoom(roomName, userName) {
        if (this.roomName === roomName) return;

        this.leaveRoom();
        this.roomName = roomName;
        this.userName = userName;
        this.lastActivity = Date.now();

        console.log(`Joining room: ${roomName} as ${userName}`);

        if (!this.socket.connected) {
            this.socket.connect();
        } else {
            this.socket.emit('join-room', { room: this.roomName, userName: this.userName });
        }

        // Start heartbeat for voice connections
        this.startHeartbeat();
    }

    leaveRoom() {
        if (!this.roomName) return;

        console.log(`Leaving room: ${this.roomName}`);

        // Stop heartbeat
        this.stopHeartbeat();

        // Stop all active media
        this.mediaManager.stopAllMedia();

        // Stop ringing sound
        if (typeof stopRingingSound === 'function') {
            stopRingingSound();
        }

        // Close all peers
        this.peerManager.destroyAllPeers();

        // Clear media members list
        const mediaMembersList = document.getElementById('media-members-list');
        if (mediaMembersList) {
            mediaMembersList.innerHTML = '';
            this.uiManager.updateMediaMembersCount();
        }

        this.socket.emit('leave-room', { room: this.roomName, userName: this.userName });
        this.roomName = null;
        this.userName = null;
        this.isConnected = false;
    }

    handleRoomParticipants(participants) {
        console.log('Handling room participants:', participants);
        participants.forEach(participant => {
            const userId = participant.id;
            if (userId !== this.userName) {
                this.peerManager.createPeer(userId);
            }
        });

        // Update universal voice members list for channel-based display
        // Convert participants format to voice-members format
        const voiceMembers = {
            [this.roomName || 'general']: participants.map(p => ({
                id: p.id,
                name: p.name,
                audio_active: false, // Will be updated by socket events
                video_active: false,
                screenshare_active: false,
                muted: false
            }))
        };
        this.uiManager.updateUniversalVoiceMembersList(voiceMembers);

        // Update voice chat modal participants if modal is open
        if (this.voiceChatManager && this.voiceChatManager.currentChannel) {
            this.voiceChatManager.updateParticipants(participants);
        }
    }

    handleRemoteTrack(userId, track, stream) {
        this.utils.handleRemoteTrack(userId, track, stream);
    }

    removeRemoteStream(userId) {
        this.utils.removeRemoteStream(userId);
    }

    startHeartbeat() {
        this.stopHeartbeat(); // Clear any existing heartbeat
        this.heartbeatInterval = setInterval(() => {
            if (this.roomName && this.socket.connected) {
                this.lastActivity = Date.now();
                // Send a simple ping to keep the connection alive
                this.socket.emit('ping');
            }
        }, 10000); // Ping every 10 seconds
    }

    stopHeartbeat() {
        if (this.heartbeatInterval) {
            clearInterval(this.heartbeatInterval);
            this.heartbeatInterval = null;
        }
    }

    setLocalVolume(volume) {
        this.utils.setLocalVolume(volume);
    }
}

// Global instance
window.webrtcManager = new WebRTCManager();

// Make utility functions globally available for HTML onclick handlers
import {
    toggleVoice,
    toggleWebcam,
    openScreenShareModal,
    startScreenShare,
    stopScreenShare,
    closeScreenShareModal,
    toggleMute
} from './utils.js';

window.toggleVoice = toggleVoice;
window.toggleWebcam = toggleWebcam;
window.openScreenShareModal = openScreenShareModal;
window.startScreenShare = startScreenShare;
window.stopScreenShare = stopScreenShare;
window.closeScreenShareModal = closeScreenShareModal;
window.toggleMute = toggleMute;