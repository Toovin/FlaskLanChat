// static/webrtc/voice-chat.js - Voice chat modal and grid management
import { socket } from '../core/setup.js';

export class VoiceChatManager {
    constructor(webrtcManager) {
        this.webrtcManager = webrtcManager;
        this.currentChannel = null;
        this.participants = new Map();
        this.modal = null;
        this.grid = null;
        this.isMinimized = false;

        this.init();
    }

    init() {
        this.modal = document.getElementById('voice-chat-modal');
        this.grid = document.getElementById('voice-chat-grid');

        if (!this.modal || !this.grid) {
            console.error('Voice chat modal elements not found');
            return;
        }

        this.setupEventListeners();
    }

    setupEventListeners() {
        // Modal controls
        const minimizeBtn = document.getElementById('voice-chat-minimize-btn');
        const closeBtn = document.getElementById('voice-chat-close-btn');
        const leaveBtn = document.getElementById('voice-chat-leave-btn');

        if (minimizeBtn) {
            minimizeBtn.addEventListener('click', () => this.toggleMinimize());
        }

        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.hideModal());
        }

        if (leaveBtn) {
            leaveBtn.addEventListener('click', () => this.closeVoiceChat());
        }

        // Control buttons
        const voiceBtn = document.getElementById('voice-chat-voice-btn');
        const videoBtn = document.getElementById('voice-chat-video-btn');
        const cycleCameraBtn = document.getElementById('cycle-camera-btn');
        const screenshareBtn = document.getElementById('voice-chat-screenshare-btn');

        if (voiceBtn) {
            voiceBtn.addEventListener('click', () => this.toggleVoice());
        }

        if (videoBtn) {
            videoBtn.addEventListener('click', () => this.toggleVideo());
        }

        if (cycleCameraBtn) {
            cycleCameraBtn.addEventListener('click', () => this.cycleCamera());
        }

        if (screenshareBtn) {
            screenshareBtn.addEventListener('click', () => this.toggleScreenshare());
        }

        // Make modal draggable
        this.makeDraggable();

        // Make minimized bar clickable to maximize (but not interfere with dragging)
        this.modal.addEventListener('click', (e) => {
            if (this.isMinimized && !e.target.closest('button')) {
                this.toggleMinimize();
            }
        });
    }

    openVoiceChat(channelName) {
        if (!this.modal) return;

        this.currentChannel = channelName;
        this.updateTitle(channelName);

        // Clear existing participants
        this.participants.clear();
        this.grid.innerHTML = '';

        // Always add self first (position 0)
        this.addParticipant(this.webrtcManager.userName, true);

        // Add all existing peers as participants (positions 1+)
        const allPeers = this.webrtcManager.peerManager.getAllPeers();
        Object.keys(allPeers).forEach(userId => {
            if (userId !== this.webrtcManager.userName) {
                this.addParticipant(userId, false);
                // Update status if peer is connected
                const peer = allPeers[userId];
                if (peer && peer.connected) {
                    const participant = this.participants.get(userId);
                    if (participant && participant.element) {
                        const statusElement = participant.element.querySelector('.voice-chat-participant-status');
                        if (statusElement) {
                            statusElement.textContent = 'Connected';
                        }
                    }
                }
            }
        });

        // Fill grid with placeholders
        this.updateGridLayout();

        this.modal.style.display = 'flex';
        this.isMinimized = false;
        this.updateMinimizeButton();
    }

    closeVoiceChat() {
        if (!this.modal) return;

        this.modal.style.display = 'none';
        this.currentChannel = null;
        this.participants.clear();

        // Leave voice if connected
        if (this.webrtcManager.roomName) {
            this.webrtcManager.leaveRoom();
            // Prevent immediate rejoin
            this.canRejoin = false;
            setTimeout(() => {
                this.canRejoin = true;
            }, 2000);
        }
    }

    hideModal() {
        if (!this.modal) return;

        this.modal.style.display = 'none';
        this.isMinimized = false;
        this.updateMinimizeButton();
    }

    toggleMinimize() {
        this.isMinimized = !this.isMinimized;

        if (this.isMinimized) {
            this.modal.classList.add('minimized');
        } else {
            this.modal.classList.remove('minimized');
        }

        this.updateMinimizeButton();
    }

    updateMinimizeButton() {
        const minimizeBtn = document.getElementById('voice-chat-minimize-btn');
        if (minimizeBtn) {
            minimizeBtn.textContent = this.isMinimized ? '⬜' : '−';
            minimizeBtn.title = this.isMinimized ? 'Maximize' : 'Minimize to bar';
        }
    }

    updateTitle(channelName) {
        const titleElement = document.getElementById('voice-chat-title');
        const statusElement = document.getElementById('voice-chat-status');
        if (titleElement) {
            titleElement.textContent = this.isMinimized ? channelName : `Voice Chat - ${channelName}`;
        }
        if (statusElement && !this.isMinimized) {
            statusElement.textContent = `${this.participants.size} participant${this.participants.size !== 1 ? 's' : ''}`;
        }
    }

    addParticipant(userId, isCurrentUser = false) {
        if (this.participants.has(userId)) return;

        const participant = {
            userId,
            isCurrentUser,
            element: null,
            stream: null,
            videoElement: null
        };

        this.participants.set(userId, participant);
        this.createParticipantElement(participant);

        // For self, set initial video state without triggering updates
        if (isCurrentUser) {
            this.initializeSelfVideoState(participant);
        }

        this.updateGridLayout();
        this.updateTitle(this.currentChannel);
    }

    removeParticipant(userId) {
        const participant = this.participants.get(userId);
        if (!participant) return;

        if (participant.element && this.grid.contains(participant.element)) {
            this.grid.removeChild(participant.element);
        }

        this.participants.delete(userId);
        this.updateGridLayout();
        this.updateTitle(this.currentChannel);
    }

    updateGridLayout() {
        // Update grid class based on participant count for square grids
        const participantCount = this.participants.size;
        this.grid.className = 'voice-chat-grid';

        // Calculate grid size: 2x2 (4), 3x3 (9), 4x4 (16)
        let gridSize = 2; // 2x2 minimum
        if (participantCount > 4) gridSize = 3; // 3x3 for 5-9 participants
        if (participantCount > 9) gridSize = 4; // 4x4 for 10+ participants

        const totalSlots = gridSize * gridSize;
        this.grid.style.gridTemplateColumns = `repeat(${gridSize}, 1fr)`;

        // Reorder participants: self first, then others
        this.reorderParticipants();

        // Remove existing placeholders
        const placeholders = this.grid.querySelectorAll('.placeholder');
        placeholders.forEach(placeholder => placeholder.remove());

        // Add placeholders to fill the grid
        const currentElements = this.grid.children.length;
        const placeholdersNeeded = Math.max(0, totalSlots - currentElements);

        for (let i = 0; i < placeholdersNeeded; i++) {
            this.addPlaceholder();
        }

        // Update modal size based on grid
        this.updateModalSize(gridSize);
    }

    reorderParticipants() {
        // Create ordered list: self first, then others alphabetically by userId
        const orderedParticipants = [];
        const selfId = this.webrtcManager.userName;

        // Add self first
        if (this.participants.has(selfId)) {
            orderedParticipants.push(this.participants.get(selfId));
        }

        // Add others
        Array.from(this.participants.entries())
            .filter(([userId]) => userId !== selfId)
            .sort(([a], [b]) => a.localeCompare(b))
            .forEach(([, participant]) => {
                orderedParticipants.push(participant);
            });

        // Reorder DOM elements
        orderedParticipants.forEach(participant => {
            if (participant.element && this.grid.contains(participant.element)) {
                this.grid.appendChild(participant.element);
            }
        });
    }

    updateModalSize(gridSize) {
        const baseWidth = 180; // Base width per participant
        const baseHeight = 135; // Base height per participant
        const padding = 120; // Header/footer padding
        const minWidth = 400; // Minimum modal width
        const minHeight = 300; // Minimum modal height
        const maxWidth = Math.min(1000, window.innerWidth - 40); // Maximum modal width (viewport aware)
        const maxHeight = Math.min(800, window.innerHeight - 120); // Maximum modal height (viewport aware)

        const calculatedWidth = Math.max(minWidth, Math.min((gridSize * baseWidth) + 60, maxWidth));
        const calculatedHeight = Math.max(minHeight, Math.min((gridSize * baseHeight) + padding, maxHeight));

        this.modal.style.width = `${calculatedWidth}px`;
        this.modal.style.height = `${calculatedHeight}px`;
    }

    addPlaceholder() {
        const placeholder = document.createElement('div');
        placeholder.className = 'voice-chat-participant placeholder';

        placeholder.innerHTML = `
            <div class="voice-chat-avatar-overlay">
                <img src="/static/default_avatars/smile_1.png" alt="Placeholder">
            </div>
        `;

        this.grid.appendChild(placeholder);
    }

    createParticipantElement(participant) {
        const { userId, isCurrentUser } = participant;

        // Get user data
        let displayName = 'Guest';
        let avatarUrl = '/static/default_avatars/smile_1.png';

        if (window.users_db && window.users_db[userId]) {
            const userData = window.users_db[userId];
            displayName = userData.display_name || userData.username || userId;
            avatarUrl = userData.avatar_url || avatarUrl;
        }

        // Create participant element
        const element = document.createElement('div');
        element.className = `voice-chat-participant${isCurrentUser ? ' current-user' : ''}`;
        element.setAttribute('data-user-id', userId);

        element.innerHTML = `
            <div class="voice-chat-avatar-overlay">
                <img src="${avatarUrl}" alt="${displayName}">
            </div>
            <div class="voice-chat-participant-info">
                <div class="voice-chat-participant-name">${displayName}</div>
                <div class="voice-chat-participant-status">Connecting...</div>
            </div>
            <div class="voice-chat-indicators">
                <div class="voice-chat-indicator mic-active" style="display: none;">
                    <i class="fas fa-microphone"></i>
                </div>
                <div class="voice-chat-indicator mic-muted" style="display: none;">
                    <i class="fas fa-microphone-slash"></i>
                </div>
                <div class="voice-chat-indicator video-active" style="display: none;">
                    <i class="fas fa-video"></i>
                </div>
                <div class="voice-chat-indicator screenshare-active" style="display: none;">
                    <i class="fas fa-desktop"></i>
                </div>
            </div>
            ${isCurrentUser ? '<button class="self-preview-toggle" title="Toggle self preview" style="display: none;">👁️</button>' : ''}
        `;

        // Add click handler to open individual stream viewer
        element.addEventListener('click', () => {
            if (!isCurrentUser) {
                this.openIndividualStream(userId);
            }
        });

        // Add self preview toggle handler
        if (isCurrentUser) {
            const toggleBtn = element.querySelector('.self-preview-toggle');
            if (toggleBtn) {
                toggleBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.toggleSelfPreview(participant);
                });
            }
        }

        this.grid.appendChild(element);
        participant.element = element;

        // Check if we have an active stream for this user
        this.updateParticipantStream(participant);
    }

    updateParticipantStream(participant) {
        // For self, use local stream
        if (participant.isCurrentUser) {
            this.updateSelfVideoStream(participant);
        } else {
            // For others, use peer stream
            const peer = this.webrtcManager.peerManager.getPeer(participant.userId);
            if (peer && peer.stream) {
                this.setParticipantStream(participant, peer.stream);
            }
        }
    }

    initializeSelfVideoState(participant) {
        if (!participant.isCurrentUser) return;

        // Check if self has video or screenshare active
        if (this.webrtcManager.localStream && (this.webrtcManager.activeMediaTypes.has('video') || this.webrtcManager.activeMediaTypes.has('screenshare'))) {
            this.setParticipantStream(participant, this.webrtcManager.localStream);
            return;
        }

        // If no video, make sure avatar is visible (don't call clearParticipantStream to avoid loops)
        const avatarOverlay = participant.element.querySelector('.voice-chat-avatar-overlay');
        if (avatarOverlay) {
            avatarOverlay.style.display = 'flex';
        }

        const statusElement = participant.element.querySelector('.voice-chat-participant-status');
        if (statusElement) {
            statusElement.textContent = 'You';
        }
    }

    updateSelfVideoStream(participant) {
        if (!participant.isCurrentUser) return;

        // Check if self has video or screenshare active
        if (this.webrtcManager.localStream && (this.webrtcManager.activeMediaTypes.has('video') || this.webrtcManager.activeMediaTypes.has('screenshare'))) {
            this.setParticipantStream(participant, this.webrtcManager.localStream);
            return;
        }

        // If no video, make sure avatar is visible
        this.clearParticipantStream(participant);
    }

    clearParticipantStream(participant) {
        if (participant.videoElement) {
            participant.videoElement.remove();
            participant.videoElement = null;
        }
        participant.stream = null;

        // Show avatar overlay
        const avatarOverlay = participant.element.querySelector('.voice-chat-avatar-overlay');
        if (avatarOverlay) {
            avatarOverlay.style.display = 'flex';
        }

        // Update status
        const statusElement = participant.element.querySelector('.voice-chat-participant-status');
        if (statusElement) {
            statusElement.textContent = participant.isCurrentUser ? 'You' : 'Connected';
        }

        // Hide self preview toggle if current user
        if (participant.isCurrentUser) {
            const toggleBtn = participant.element.querySelector('.self-preview-toggle');
            if (toggleBtn) toggleBtn.style.display = 'none';
        }
    }

    setParticipantStream(participant, stream) {
        participant.stream = stream;

        // Remove avatar overlay and show video
        const avatarOverlay = participant.element.querySelector('.voice-chat-avatar-overlay');
        if (avatarOverlay) {
            avatarOverlay.style.display = 'none';
        }

        // Create or update video element
        let videoElement = participant.element.querySelector('.voice-chat-video');
        if (!videoElement) {
            videoElement = document.createElement('video');
            videoElement.className = 'voice-chat-video';
            videoElement.autoplay = true;
            videoElement.muted = true; // Muted to avoid feedback
            participant.element.insertBefore(videoElement, participant.element.firstChild);
        }

        videoElement.srcObject = stream;
        participant.videoElement = videoElement;

        // Ensure video plays
        videoElement.play().catch(err => console.error('Video play failed:', err));

        // Update status
        const statusElement = participant.element.querySelector('.voice-chat-participant-status');
        if (statusElement) {
            statusElement.textContent = 'Connected';
        }

        // Show self preview toggle if current user
        if (participant.isCurrentUser) {
            const toggleBtn = participant.element.querySelector('.self-preview-toggle');
            if (toggleBtn) toggleBtn.style.display = 'block';
        }
    }

    updateParticipantStatus(userId, statusType, active) {
        const participant = this.participants.get(userId);
        if (!participant) return;

        const indicator = participant.element.querySelector(`.voice-chat-indicator.${statusType}`);
        if (indicator) {
            indicator.style.display = active ? 'flex' : 'none';
        }

        // Update status text
        const statusElement = participant.element.querySelector('.voice-chat-participant-status');
        if (statusElement) {
            const activeStatuses = [];
            const indicators = participant.element.querySelectorAll('.voice-chat-indicator');

            indicators.forEach(ind => {
                if (ind.style.display !== 'none') {
                    const statusClass = Array.from(ind.classList).find(cls => cls !== 'voice-chat-indicator');
                    if (statusClass === 'mic-active') activeStatuses.push('Voice');
                    else if (statusClass === 'video-active') activeStatuses.push('Video');
                    else if (statusClass === 'screenshare-active') activeStatuses.push('Screenshare');
                }
            });

            if (activeStatuses.length > 0) {
                statusElement.textContent = activeStatuses.join(', ');
            } else {
                statusElement.textContent = 'Connected';
            }
        }
    }

    openIndividualStream(userId) {
        // Use existing stream viewer functionality
        this.webrtcManager.uiManager.requestAndViewStream(userId);
    }

    toggleVoice() {
        const btn = document.getElementById('voice-chat-voice-btn');
        if (window.toggleVoice) {
            window.toggleVoice();
            // Update button state
            setTimeout(() => {
                if (btn) {
                    btn.classList.toggle('active', this.webrtcManager.activeMediaTypes.has('audio'));
                }
            }, 100);
        }
    }

    toggleVideo() {
        const btn = document.getElementById('voice-chat-video-btn');
        if (window.toggleWebcam) {
            window.toggleWebcam();
            // Update button state
            setTimeout(() => {
                if (btn) {
                    btn.classList.toggle('active', this.webrtcManager.activeMediaTypes.has('video'));
                }
            }, 100);
        }
    }

    async cycleCamera() {
        try {
            await this.webrtcManager.mediaManager.cycleCamera();
        } catch (err) {
            console.error('Error cycling camera:', err);
        }
    }

    toggleScreenshare() {
        const btn = document.getElementById('voice-chat-screenshare-btn');
        if (this.webrtcManager.activeMediaTypes.has('screenshare')) {
            if (window.stopScreenShare) {
                window.stopScreenShare();
            }
        } else {
            if (window.startScreenShare) {
                window.startScreenShare();
            }
        }
        // Update button state
        setTimeout(() => {
            if (btn) {
                btn.classList.toggle('active', this.webrtcManager.activeMediaTypes.has('screenshare'));
            }
        }, 100);
    }



    makeDraggable() {
        const header = this.modal.querySelector('.voice-chat-header');
        if (!header) return;

        let isDragging = false;
        let dragStartX, dragStartY, initialX, initialY;

        const handleMouseDown = (e) => {
            // Don't drag if clicking on buttons
            if (e.target.tagName === 'BUTTON') return;

            isDragging = true;
            dragStartX = e.clientX;
            dragStartY = e.clientY;
            const rect = this.modal.getBoundingClientRect();
            initialX = rect.left;
            initialY = rect.top;

            // Prevent text selection during drag
            e.preventDefault();
        };

        const handleMouseMove = (e) => {
            if (isDragging) {
                const dx = e.clientX - dragStartX;
                const dy = e.clientY - dragStartY;
                this.modal.style.left = (initialX + dx) + 'px';
                this.modal.style.top = (initialY + dy) + 'px';
                this.modal.style.transform = 'none';
            }
        };

        const handleMouseUp = () => {
            isDragging = false;
        };

        header.addEventListener('mousedown', handleMouseDown);
        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);
    }

    // Public methods for external use
    updateParticipants(participants) {
        // Clear existing participants
        this.participants.clear();
        this.grid.innerHTML = '';

        // Add all participants
        participants.forEach(participant => {
            this.addParticipant(participant.id, participant.id === this.webrtcManager.userName);
        });

        this.updateGridLayout();
    }

    // Called when local video stream changes
    onLocalVideoChanged() {
        const selfParticipant = this.participants.get(this.webrtcManager.userName);
        if (selfParticipant) {
            this.updateSelfVideoStream(selfParticipant);
        }
    }

    toggleSelfPreview(participant) {
        if (!participant.isCurrentUser) return;

        const avatarOverlay = participant.element.querySelector('.voice-chat-avatar-overlay');
        const videoElement = participant.element.querySelector('.voice-chat-video');

        if (videoElement && videoElement.style.display !== 'none') {
            // Hide video, show avatar
            videoElement.style.display = 'none';
            avatarOverlay.style.display = 'flex';
        } else if (participant.stream) {
            // Show video if stream exists
            if (videoElement) videoElement.style.display = 'block';
            avatarOverlay.style.display = 'none';
        }
    }

    showVoiceChat(channelName) {
        this.openVoiceChat(channelName);
    }

    hideVoiceChat() {
        this.closeVoiceChat();
    }
}

// Global instance
let voiceChatManager = null;

export function initVoiceChat(webrtcManager) {
    if (!voiceChatManager) {
        voiceChatManager = new VoiceChatManager(webrtcManager);
    }
    return voiceChatManager;
}

export function getVoiceChatManager() {
    return voiceChatManager;
}

// Global functions for HTML onclick handlers
window.openVoiceChat = function(channelName) {
    if (voiceChatManager) {
        voiceChatManager.showVoiceChat(channelName);
    }
};

window.closeVoiceChat = function() {
    if (voiceChatManager) {
        voiceChatManager.hideVoiceChat();
    }
};