// static/webrtc/peer.js - WebRTC peer connection and signaling logic
import { socket } from '../core/setup.js';

export class WebRTCPeerManager {
    constructor(manager) {
        this.manager = manager;
        this.peers = {};
    }

    createPeer(userId, initiator = null) {
        if (this.peers[userId]) {
            console.log(`Peer already exists for ${userId}`);
            return;
        }

        // Determine initiator based on user ID comparison to ensure only one peer initiates
        const shouldInitiate = initiator !== null ? initiator : (typeof this.manager.userName === 'string' && typeof userId === 'string' && this.manager.userName < userId);
        console.log(`Creating peer for ${userId}, initiator: ${shouldInitiate}`);

        const peer = new SimplePeer({
            initiator: shouldInitiate,
            trickle: false,
            config: this.manager.stunConfig
        });

        peer.userId = userId;

        peer.on('signal', (data) => {
            console.log(`Sending signal to ${userId}:`, data.type);
            socket.emit('signal', {
                targetUserId: userId,
                signal: data
            });
        });

        peer.on('connect', () => {
            console.log(`Peer connected: ${userId}`);
            this.manager.isConnected = true;
            this.manager.uiManager.updateMediaIcon();

            // Update voice chat participant status if modal is open
            if (this.manager.voiceChatManager && this.manager.voiceChatManager.currentChannel) {
                // Set status to connected (no specific media active yet)
                const statusElement = this.manager.voiceChatManager.participants.get(userId)?.element?.querySelector('.voice-chat-participant-status');
                if (statusElement) {
                    statusElement.textContent = 'Connected';
                }
            }
            // Stop ringing sound when call connects
            if (typeof stopRingingSound === 'function') {
                stopRingingSound();
            }
            // Update call status
            if (typeof updatePrivateCallStatus === 'function') {
                updatePrivateCallStatus('Connected');
            }
        });

        peer.on('track', (track, stream) => {
            console.log(`Received track from ${userId}: ${track.kind}`);
            this.manager.handleRemoteTrack(userId, track, stream);
        });

        peer.on('stream', (stream) => {
            console.log(`Received stream from ${userId}`);
            this.peers[userId].stream = stream;
        });

        peer.on('close', () => {
            console.log(`Peer closed: ${userId}`);
            this.removePeer(userId);

            // If this is a private call, reset call state to ensure UI updates
            if (this.manager.roomName && this.manager.roomName.startsWith('private-')) {
                if (typeof window.resetPrivateCallState === 'function') {
                    window.resetPrivateCallState();
                }
            }
        });

        peer.on('error', (err) => {
            console.error(`Peer error for ${userId}:`, err);
            this.removePeer(userId);
            // Stop ringing sound on error
            if (typeof stopRingingSound === 'function') {
                stopRingingSound();
            }
        });

        this.peers[userId] = peer;

        // Add existing local stream if available
        if (this.manager.localStream) {
            this.manager.localStream.getTracks().forEach(track => {
                peer.addTrack(track, this.manager.localStream);
            });
        }

        return peer;
    }

    handleSignal(data) {
        console.log('Received signal data:', data);
        const { from, signal } = data;
        const peer = this.peers[from];

        if (peer) {
            console.log(`Received signal from ${from}:`, signal.type);
            // Prevent setting remote description if already stable (avoids InvalidStateError)
            if (signal.type === 'answer' && peer._pc && peer._pc.signalingState === 'stable') {
                console.log('Ignoring duplicate answer signal, peer already stable');
                return;
            }
            try {
                peer.signal(signal);
                console.log(`Successfully processed signal from ${from}`);
            } catch (error) {
                console.error(`Error processing signal from ${from}:`, error);
            }
        } else {
            console.warn(`No peer found for ${from}. Available peers:`, Object.keys(this.peers));
        }
    }

    removePeer(userId) {
        const peer = this.peers[userId];
        if (peer) {
            console.log(`Removing peer: ${userId}`);
            peer.destroy();
            delete this.peers[userId];
            this.manager.removeRemoteStream(userId);
        }
    }

    getPeer(userId) {
        return this.peers[userId];
    }

    getAllPeers() {
        return this.peers;
    }

    destroyAllPeers() {
        Object.keys(this.peers).forEach(userId => {
            this.removePeer(userId);
        });
    }
}