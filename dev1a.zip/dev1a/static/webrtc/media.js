// static/webrtc/media.js - WebRTC media stream handling (voice, video, screenshare)
import { socket } from '../core/setup.js';

export class WebRTCMediaManager {
    constructor(manager) {
        this.manager = manager;
        this.currentDeviceIndex = 0;
        this.availableVideoDevices = [];
    }

    async getVideoDevices() {
        try {
            const devices = await navigator.mediaDevices.enumerateDevices();
            this.availableVideoDevices = devices.filter(device => device.kind === 'videoinput');
            return this.availableVideoDevices;
        } catch (err) {
            console.error('Error enumerating video devices:', err);
            return [];
        }
    }

    async startVoice() {
        if (this.manager.activeMediaTypes.has('audio')) {
            console.log('Audio already active');
            return;
        }

        try {
            console.log('Requesting microphone access');
            const stream = await navigator.mediaDevices.getUserMedia({
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true
                },
                video: false
            });

            // Initialize localStream if not exists
            if (!this.manager.localStream) {
                this.manager.localStream = new MediaStream();
            }

            // Add audio tracks directly from the stream
            stream.getAudioTracks().forEach(track => {
                track.mediaType = 'audio'; // Mark track type for later removal
                this.manager.localStream.addTrack(track);
                Object.values(this.manager.peerManager.getAllPeers()).forEach(peer => {
                    peer.addTrack(track, this.manager.localStream);
                });
            });

            this.manager.activeMediaTypes.add('audio');

            // Notify others
            socket.emit('stream-update', {
                mediaType: 'audio',
                action: 'start'
            });
            // Send initial unmute status
            socket.emit('unmute');

            console.log('Voice started');
            this.manager.uiManager.updateMediaIcon();

        } catch (err) {
            console.error('Error starting voice:', err);
            if (typeof showError === 'function') {
                showError('Failed to access microphone');
            }
        }
    }

    stopVoice() {
        if (!this.manager.activeMediaTypes.has('audio')) return;

        console.log('Stopping voice');

        // Get and remove all audio tracks from the stream
        this.manager.localStream.getTracks().filter(track => track.mediaType === 'audio').forEach(track => {
            this.manager.localStream.removeTrack(track);
            Object.values(this.manager.peerManager.getAllPeers()).forEach(peer => {
                peer.removeTrack(track, this.manager.localStream);
            });
            track.stop();
        });

        this.manager.activeMediaTypes.delete('audio');

        // If no more media types active, clear the stream
        if (this.manager.activeMediaTypes.size === 0) {
            this.manager.localStream = null;
        }

        // Notify others
        socket.emit('stream-update', {
            mediaType: 'audio',
            action: 'stop'
        });

        this.manager.uiManager.updateMediaIcon();
    }

    async startVideo(deviceId = null) {
        if (this.manager.activeMediaTypes.has('video')) {
            console.log('Video already active');
            return;
        }

        // Stop screenshare if active (mutually exclusive)
        if (this.manager.activeMediaTypes.has('screenshare')) {
            this.stopScreenshare();
        }

        try {
            console.log('Requesting camera access');
            const videoConstraints = deviceId ?
                { deviceId: { exact: deviceId }, width: 640, height: 480 } :
                { width: 640, height: 480 };
            const stream = await navigator.mediaDevices.getUserMedia({
                audio: false,
                video: videoConstraints
            });

            // Initialize localStream if not exists
            if (!this.manager.localStream) {
                this.manager.localStream = new MediaStream();
            }

            // Add video tracks directly from the stream
            stream.getVideoTracks().forEach(track => {
                track.mediaType = 'video'; // Mark track type for later removal
                this.manager.localStream.addTrack(track);
                Object.values(this.manager.peerManager.getAllPeers()).forEach(peer => {
                    peer.addTrack(track, this.manager.localStream);
                });
            });

            this.manager.activeMediaTypes.add('video');

            // Notify others
            socket.emit('stream-update', {
                mediaType: 'video',
                action: 'start',
                videoType: 'webcam'
            });

            console.log('Video started');
            this.manager.uiManager.updateMediaIcon();

            // Update camera cycle button visibility
            await this.updateCameraCycleButton();

            // Update voice chat self preview
            if (this.manager.voiceChatManager) {
                this.manager.voiceChatManager.onLocalVideoChanged();
            }

        } catch (err) {
            console.error('Error starting video:', err);
            if (typeof showError === 'function') {
                showError('Failed to access camera');
            }
        }
    }

    async stopVideo() {
        if (!this.manager.activeMediaTypes.has('video')) return;

        console.log('Stopping video');

        // Get and remove all video tracks from the stream
        this.manager.localStream.getTracks().filter(track => track.mediaType === 'video').forEach(track => {
            this.manager.localStream.removeTrack(track);
            Object.values(this.manager.peerManager.getAllPeers()).forEach(peer => {
                peer.removeTrack(track, this.manager.localStream);
            });
            track.stop();
        });

        this.manager.activeMediaTypes.delete('video');

        // If no more media types active, clear the stream
        if (this.manager.activeMediaTypes.size === 0) {
            this.manager.localStream = null;
        }

        // Notify others
        socket.emit('stream-update', {
            mediaType: 'video',
            action: 'stop'
        });

        this.manager.uiManager.updateMediaIcon();

        // Update camera cycle button visibility
        await this.updateCameraCycleButton();
    }

    async cycleCamera() {
        if (!this.manager.activeMediaTypes.has('video')) {
            console.log('Video not active, cannot cycle camera');
            return;
        }

        // Ensure we have device list
        if (this.availableVideoDevices.length === 0) {
            await this.getVideoDevices();
        }

        if (this.availableVideoDevices.length <= 1) {
            console.log('Only one or no video devices available');
            return;
        }

        // Cycle to next device
        this.currentDeviceIndex = (this.currentDeviceIndex + 1) % this.availableVideoDevices.length;
        const nextDevice = this.availableVideoDevices[this.currentDeviceIndex];

        console.log(`Switching to camera: ${nextDevice.label || nextDevice.deviceId}`);

        // Stop current video and restart with new device
        this.stopVideo();
        await this.startVideo(nextDevice.deviceId);
    }

    async updateCameraCycleButton() {
        const cycleBtn = document.getElementById('cycle-camera-btn');
        if (!cycleBtn) return;

        // Get devices if not already done
        if (this.availableVideoDevices.length === 0) {
            await this.getVideoDevices();
        }

        // Show button only if video is active and multiple devices available
        const shouldShow = this.manager.activeMediaTypes.has('video') && this.availableVideoDevices.length > 1;
        cycleBtn.style.display = shouldShow ? 'inline-block' : 'none';
    }

    async startScreenshare(providedStream = null) {
        if (this.manager.activeMediaTypes.has('screenshare')) {
            console.log('Screenshare already active');
            return;
        }

        // Stop video if active (mutually exclusive)
        if (this.manager.activeMediaTypes.has('video')) {
            this.stopVideo();
        }

        try {
            let stream;
            if (providedStream) {
                console.log('Using provided screen share stream');
                stream = providedStream;
            } else {
                console.log('Requesting screen access');
                stream = await navigator.mediaDevices.getDisplayMedia({
                    video: { cursor: 'always' },
                    audio: {
                        echoCancellation: false,
                        noiseSuppression: false,
                        autoGainControl: false
                    }
                });
            }

            // Initialize localStream if not exists
            if (!this.manager.localStream) {
                this.manager.localStream = new MediaStream();
            }

            // Add screenshare tracks (including audio if captured)
            stream.getTracks().forEach(track => {
                track.mediaType = 'screenshare'; // Mark track type for later removal
                this.manager.localStream.addTrack(track);
                Object.values(this.manager.peerManager.getAllPeers()).forEach(peer => {
                    peer.addTrack(track, this.manager.localStream);
                });
            });

            this.manager.activeMediaTypes.add('screenshare');

            // Auto-mute mic if screenshare has audio and voice is active to prevent echo
            if (stream.getAudioTracks().length > 0 && this.manager.activeMediaTypes.has('audio')) {
                this.autoMuteMicForScreenshare();
            }

            // Notify others
            socket.emit('stream-update', {
                mediaType: 'screenshare',
                action: 'start'
            });

            console.log('Screenshare started');
            this.manager.uiManager.updateMediaIcon();

        } catch (err) {
            console.error('Error starting screenshare:', err);
            if (typeof showError === 'function') {
                showError('Failed to access screen');
            }
        }
    }

    stopScreenshare() {
        if (!this.manager.activeMediaTypes.has('screenshare')) return;

        console.log('Stopping screenshare');

        // Get and remove all screenshare tracks from the stream
        this.manager.localStream.getTracks().filter(track => track.mediaType === 'screenshare').forEach(track => {
            this.manager.localStream.removeTrack(track);
            Object.values(this.manager.peerManager.getAllPeers()).forEach(peer => {
                peer.removeTrack(track, this.manager.localStream);
            });
            track.stop();
        });

        // Restore mic if it was auto-muted
        if (this.manager.wasAutoMuted) {
            this.restoreMicAfterScreenshare();
        }

        this.manager.activeMediaTypes.delete('screenshare');

        // If no more media types active, clear the stream
        if (this.manager.activeMediaTypes.size === 0) {
            this.manager.localStream = null;
        }

        // Notify others
        socket.emit('stream-update', {
            mediaType: 'screenshare',
            action: 'stop'
        });

        this.manager.uiManager.updateMediaIcon();
    }

    autoMuteMicForScreenshare() {
        // Mute all audio tracks in the stream
        this.manager.localStream.getTracks().filter(track => track.mediaType === 'audio').forEach(track => {
            track.enabled = false;
        });
        this.manager.wasAutoMuted = true;
        socket.emit('mute');
        console.log('Auto-muted mic for screenshare audio to prevent echo');
    }

    restoreMicAfterScreenshare() {
        // Restore all audio tracks in the stream
        this.manager.localStream.getTracks().filter(track => track.mediaType === 'audio').forEach(track => {
            track.enabled = true;
        });
        this.manager.wasAutoMuted = false;
        socket.emit('unmute');
        console.log('Restored mic after screenshare');
    }

    mute() {
        if (this.manager.activeMediaTypes.has('audio') && this.manager.localStream) {
            console.log('Muting microphone');
            this.manager.localStream.getAudioTracks().forEach(track => {
                track.enabled = false;
            });
            socket.emit('mute');
        }
    }

    unmute() {
        if (this.manager.activeMediaTypes.has('audio') && this.manager.localStream) {
            console.log('Unmuting microphone');
            this.manager.localStream.getAudioTracks().forEach(track => {
                track.enabled = true;
            });
            socket.emit('unmute');
        }
    }

    stopAllMedia() {
        // Stop all active media types
        if (this.manager.activeMediaTypes.has('audio')) {
            this.stopVoice();
        }
        if (this.manager.activeMediaTypes.has('video')) {
            this.stopVideo();
        }
        if (this.manager.activeMediaTypes.has('screenshare')) {
            this.stopScreenshare();
        }
    }
}