// static/webrtc/utils.js - WebRTC utility functions and global exports

export class WebRTCUtils {
    constructor(manager) {
        this.manager = manager;
    }

    // Volume control methods
    setRemoteVolume(volume) {
        // Set volume for all remote audio elements
        Object.keys(this.manager.peerManager.getAllPeers()).forEach(userId => {
            const audioElement = document.getElementById(`remote-${userId}`);
            if (audioElement && audioElement.tagName === 'AUDIO') {
                audioElement.volume = volume;
            }
        });
    }

    setLocalVolume(volume) {
        this.manager.localVolume = volume;
        // Note: Local volume control removed to fix audio issues
        // Volume control for sent audio is not implemented
        console.log(`Local volume set to: ${volume} (not applied to sent audio)`);
    }

    muteRemoteAudio(muted) {
        Object.keys(this.manager.peerManager.getAllPeers()).forEach(userId => {
            const audioElement = document.getElementById(`remote-${userId}`);
            if (audioElement && audioElement.tagName === 'AUDIO') {
                audioElement.muted = muted;
            }
        });
    }

    handleRemoteTrack(userId, track, stream) {
        console.log(`Handling remote track from ${userId}: ${track.kind}`);

        if (track.kind === 'video') {
            // Update UI for video or screenshare based on active status
            // But since we don't auto-open, just update indicators (handled via socket events)
            this.manager.uiManager.updateMemberMediaStatus(userId, 'video', true); // Generic video update, specific via events

            // Update voice chat manager if it exists
            if (this.manager.voiceChatManager) {
                const participant = this.manager.voiceChatManager.participants.get(userId);
                if (participant) {
                    this.manager.voiceChatManager.setParticipantStream(participant, stream);
                }
            }

            // If private call modal is open, update the video
            const modal = document.getElementById('private-call-modal');
            if (modal && modal.style.display !== 'none') {
                if (typeof updatePrivateCallVideo === 'function') {
                    updatePrivateCallVideo(stream);
                }
            }
        } else if (track.kind === 'audio') {
            const audioStream = new MediaStream([track]);
            this.setupAudioElement(userId, audioStream);
            this.manager.uiManager.updateMemberMediaStatus(userId, 'audio', true);
        }

        // Listen for track end to clean up
        track.onended = () => {
            console.log(`Track ended: ${track.kind} from ${userId}`);
            if (track.kind === 'audio') {
                const audioElement = document.getElementById(`remote-${userId}`);
                if (audioElement) audioElement.remove();
            } else if (track.kind === 'video') {
                this.manager.uiManager.closeStreamViewerByTrack(userId, track);
                // Reset private call modal to placeholder if video ends
                const video = document.getElementById('private-call-video');
                const placeholder = document.getElementById('private-call-placeholder');
                if (video && placeholder) {
                    video.style.display = 'none';
                    placeholder.style.display = 'flex';
                }
            }
        };
    }

    setupAudioElement(userId, stream) {
        const existingElement = document.getElementById(`remote-${userId}`);
        let mediaElement;

        if (!existingElement || existingElement.tagName !== 'AUDIO') {
            if (existingElement) existingElement.remove();
            mediaElement = document.createElement('audio');
            mediaElement.id = `remote-${userId}`;
            mediaElement.autoplay = true;
            mediaElement.volume = 1.0;
            mediaElement.muted = false;

            // Style to be invisible but functional
            mediaElement.style.position = 'absolute';
            mediaElement.style.left = '-9999px';
            mediaElement.style.width = '1px';
            mediaElement.style.height = '1px';
            mediaElement.style.opacity = '0';

            document.body.appendChild(mediaElement);

            // Try to play and handle autoplay restrictions
            const playPromise = mediaElement.play();
            if (playPromise !== undefined) {
                playPromise.then(() => {
                    console.log(`Audio for ${userId} started playing`);
                }).catch(error => {
                    console.warn(`Autoplay blocked for ${userId}:`, error);
                    const playOnInteraction = () => {
                        mediaElement.play().catch(e => console.error('Failed to play on interaction:', e));
                        document.removeEventListener('click', playOnInteraction);
                        document.removeEventListener('keydown', playOnInteraction);
                    };
                    document.addEventListener('click', playOnInteraction);
                    document.addEventListener('keydown', playOnInteraction);
                });
            }
        } else {
            mediaElement = existingElement;
        }

        mediaElement.srcObject = stream;
    }

    removeRemoteStream(userId) {
        // Remove audio element if it exists
        const audioElement = document.getElementById(`remote-${userId}`);
        if (audioElement) {
            audioElement.remove();
        }
        // Close all stream viewer modals for this user
        this.manager.uiManager.closeStreamViewer(userId);

        // Clear media status indicators
        this.manager.uiManager.updateMemberMediaStatus(userId, 'voice', false);
        this.manager.uiManager.updateMemberMediaStatus(userId, 'video', false);
        this.manager.uiManager.updateMemberMediaStatus(userId, 'screenshare', false);
        this.manager.uiManager.updateMemberMediaStatus(userId, 'audio', false);
    }

    handleMediaStart(userId, mediaType) {
        console.log(`${mediaType} started by ${userId}`);
        this.manager.uiManager.updateMemberMediaStatus(userId, mediaType, true);
        // Also update voice chat manager if it exists
        if (this.manager.voiceChatManager) {
            let statusType = mediaType;
            if (mediaType === 'audio') statusType = 'mic-active';
            else if (mediaType === 'video') statusType = 'video-active';
            else if (mediaType === 'screenshare') statusType = 'screenshare-active';
            this.manager.voiceChatManager.updateParticipantStatus(userId, statusType, true);
        }
    }

    handleMediaStop(userId, mediaType) {
        console.log(`${mediaType} stopped by ${userId}`);
        this.manager.uiManager.updateMemberMediaStatus(userId, mediaType, false);
        // Also update voice chat manager if it exists
        if (this.manager.voiceChatManager) {
            let statusType = mediaType;
            if (mediaType === 'audio') statusType = 'mic-active';
            else if (mediaType === 'video') statusType = 'video-active';
            else if (mediaType === 'screenshare') statusType = 'screenshare-active';
            this.manager.voiceChatManager.updateParticipantStatus(userId, statusType, false);
        }
    }

    handleMute(userId) {
        console.log(`User ${userId} muted`);
        this.manager.uiManager.updateMemberMediaStatus(userId, 'mic-muted', true);
        this.manager.uiManager.updateMemberMediaStatus(userId, 'mic-indicator', false);
        // Also update voice chat manager if it exists
        if (this.manager.voiceChatManager) {
            this.manager.voiceChatManager.updateParticipantStatus(userId, 'mic-muted', true);
            this.manager.voiceChatManager.updateParticipantStatus(userId, 'mic-active', false);
        }
    }

    handleUnmute(userId) {
        console.log(`User ${userId} unmuted`);
        this.manager.uiManager.updateMemberMediaStatus(userId, 'mic-muted', false);
        this.manager.uiManager.updateMemberMediaStatus(userId, 'mic-indicator', true);
        // Also update voice chat manager if it exists
        if (this.manager.voiceChatManager) {
            this.manager.voiceChatManager.updateParticipantStatus(userId, 'mic-muted', false);
            this.manager.voiceChatManager.updateParticipantStatus(userId, 'mic-active', true);
        }
    }

    handleVoiceMembersUpdate(voiceMembers) {
        console.log('[VOICE] Handling voice members update:', voiceMembers);
        this.manager.uiManager.updateUniversalVoiceMembersList(voiceMembers);
    }
}

// Global functions for HTML onclick handlers
export function toggleVoice() {
    if (!window.webrtcManager) {
        console.error('WebRTC manager not initialized');
        return;
    }
    if (window.webrtcManager.activeMediaTypes.has('audio')) {
        window.webrtcManager.mediaManager.stopVoice();
    } else {
        window.webrtcManager.mediaManager.startVoice().catch(err => {
            console.error('Error starting voice:', err);
        });
    }
}

export function toggleWebcam() {
    if (!window.webrtcManager) {
        console.error('WebRTC manager not initialized');
        return;
    }
    if (window.webrtcManager.activeMediaTypes.has('video')) {
        window.webrtcManager.mediaManager.stopVideo();
    } else {
        window.webrtcManager.mediaManager.startVideo().catch(err => {
            console.error('Error starting video:', err);
        });
    }
}

export function openScreenShareModal() {
    // Skip modal and directly start screen share since browser handles selection
    startScreenShare();
}

export function startScreenShare(type) {
    window.webrtcManager.mediaManager.startScreenshare();
}

export function stopScreenShare() {
    if (window.webrtcManager.activeMediaTypes.has('screenshare')) {
        window.webrtcManager.mediaManager.stopScreenshare();
    }
}

export function closeScreenShareModal() {
    const modal = document.getElementById('screen-share-modal');
    if (modal) {
        modal.style.display = 'none';
    }
}

export function toggleMute() {
    const muteBtn = document.getElementById('mute-btn');
    if (!muteBtn) return;

    const icon = muteBtn.querySelector('i');
    if (!icon) return;

    if (icon.classList.contains('fa-volume-up')) {
        // Currently unmuted, mute
        window.webrtcManager.mediaManager.mute();
        icon.classList.remove('fa-volume-up');
        icon.classList.add('fa-volume-mute');
        muteBtn.title = 'Unmute';
    } else {
        // Currently muted, unmute
        window.webrtcManager.mediaManager.unmute();
        icon.classList.remove('fa-volume-mute');
        icon.classList.add('fa-volume-up');
        muteBtn.title = 'Mute';
    }
}