// Media library file browsing, search, and management

import { showError, escapeHtml } from '../core/ui-utils.js';
import { getFileIcon, formatFileSize } from './media-types.js';

// Library state
let allMediaFiles = [];
let currentSearchTerm = '';
let currentSortOption = 'name';

// Load media files from server
export async function loadMediaFiles() {
    const filesContainer = document.querySelector('#tab-content-media .media-directory-content');
    if (!filesContainer) {
        console.error('Media directory content not found');
        showError('Media directory content not found. Please refresh.');
        return;
    }

    try {
        const response = await fetch('/files?storage_dir=media_downloaded');
        if (!response.ok) throw new Error('Failed to fetch media files');
        const data = await response.json();
        allMediaFiles = data.files || [];
        filterAndSortMediaFiles();
    } catch (error) {
        console.error('Error fetching media files:', error);
        showError('Failed to load media files: ' + error.message);
    }
}

// Filter and sort media files
export function filterAndSortMediaFiles() {
    const filesContainer = document.querySelector('#tab-content-media .media-directory-content');
    const searchInput = document.getElementById('media-search-input');
    const sortSelect = document.getElementById('media-sort-select');

    if (!filesContainer) return;

    let filteredFiles = [...allMediaFiles];

    // Apply search filter
    if (searchInput && searchInput.value.trim()) {
        currentSearchTerm = searchInput.value.toLowerCase().trim();
        filteredFiles = filteredFiles.filter(file =>
            file.name.toLowerCase().includes(currentSearchTerm)
        );
    } else {
        currentSearchTerm = '';
    }

    // Apply sorting
    if (sortSelect && sortSelect.value) {
        currentSortOption = sortSelect.value;
        filteredFiles.sort((a, b) => {
            switch (currentSortOption) {
                case 'name':
                    return a.name.localeCompare(b.name);
                case 'size':
                    return b.size - a.size;
                case 'date':
                    return new Date(b.mtime) - new Date(a.mtime);
                case 'type':
                    const aExt = a.name.split('.').pop().toLowerCase();
                    const bExt = b.name.split('.').pop().toLowerCase();
                    return aExt.localeCompare(bExt);
                default:
                    return 0;
            }
        });
    }

    // Render filtered and sorted files
    renderMediaFiles(filteredFiles);
}

// Render media files
export function renderMediaFiles(files) {
    renderMediaFileList(files);
}

// Render file list
function renderMediaFileList(files) {
    const filesContainer = document.querySelector('#tab-content-media .media-directory-content');
    if (!filesContainer) return;

    // Clear existing content
    filesContainer.innerHTML = '';

    if (files.length === 0) {
        filesContainer.innerHTML = '<div class="no-files">No media files found in this folder</div>';
        return;
    }

    // Create container based on view mode
    const currentViewMode = getCurrentViewMode();
    let container;
    if (currentViewMode === 'list') {
        container = document.createElement('div');
        container.className = 'media-files-list';
    } else {
        container = document.createElement('div');
        container.className = 'media-files-grid';
        const currentGridSize = getCurrentGridSize();
        container.style.gridTemplateColumns = 'repeat(auto-fill, minmax(' + currentGridSize + 'px, 1fr))';
    }

    files.forEach(file => {
        const fileItem = document.createElement('div');
        fileItem.className = `media-file-item ${currentViewMode === 'list' ? 'list-view' : ''}`;
        const sizeMB = formatFileSize(file.size);

        if (currentViewMode === 'list') {
            fileItem.innerHTML = `
                <i class="fas ${getFileIcon(file.name)}"></i>
                <div class="file-info">
                    <div class="file-name">${escapeHtml(file.name)}</div>
                    <div class="file-size">${sizeMB}</div>
                </div>
                <div class="media-file-actions">
                    <button class="rename-btn" title="Rename file"><i class="fas fa-edit"></i></button>
                    <button class="delete-btn" title="Delete file"><i class="fas fa-trash"></i></button>
                </div>
            `;
        } else {
            fileItem.innerHTML = `
                <i class="fas ${getFileIcon(file.name)}"></i>
                <div class="file-name">${escapeHtml(file.name)}</div>
                <div class="file-size">${sizeMB}</div>
                <div class="media-file-actions">
                    <button class="rename-btn" title="Rename file"><i class="fas fa-edit"></i></button>
                    <button class="delete-btn" title="Delete file"><i class="fas fa-trash"></i></button>
                </div>
            `;
        }

        // Store file data
        fileItem.dataset.lazyUrl = file.lazy_url;
        fileItem.dataset.fileName = file.name;

        // Main click handler for selecting file
        fileItem.addEventListener('click', (e) => {
            // Don't select if clicking on action buttons
            if (e.target.closest('.media-file-actions')) {
                return;
            }
            // Load content on demand using lazy URL
            loadMediaOnDemand(fileItem, file.lazy_url, file.name);
        });

        // Double-click to add to queue
        fileItem.addEventListener('dblclick', (e) => {
            e.preventDefault();
            addToQueue(file);
        });

        // Rename button handler
        const renameBtn = fileItem.querySelector('.rename-btn');
        renameBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            showRenameDialog(file.name, fileItem);
        });

        // Delete button handler
        const deleteBtn = fileItem.querySelector('.delete-btn');
        deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            showDeleteDialog(file.name, fileItem);
        });

        container.appendChild(fileItem);
    });

    filesContainer.appendChild(container);
}

// File management functions
async function renameMediaFile(oldName, newName, fileItem) {
    try {
        const response = await fetch('/rename-media', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                old_name: oldName,
                new_name: newName,
                storage_dir: 'media_downloaded'
            })
        });

        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        const data = await response.json();

        if (data.error) throw new Error(data.error);

        // Update the UI
        const fileNameElement = fileItem.querySelector('.file-name');
        fileNameElement.textContent = escapeHtml(newName);

        // Update the selected file reference if this was the selected file
        const selectedFileItem = getSelectedFileItem();
        if (selectedFileItem === fileItem) {
            loadMediaIntoPlayer(data.new_url, newName);
        }

        console.log('File renamed successfully:', data);
    } catch (error) {
        console.error('Rename error:', error);
        showError('Failed to rename file: ' + error.message);
    }
}

async function deleteMediaFile(filename, fileItem) {
    try {
        const response = await fetch('/delete-media', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                filename: filename,
                storage_dir: 'media_downloaded'
            })
        });

        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        const data = await response.json();

        if (data.error) throw new Error(data.error);

        // Remove from UI
        const selectedFileItem = getSelectedFileItem();
        if (selectedFileItem === fileItem) {
            // If this was the selected file, clear selection and stop playback
            clearSelection();
            stopPlayback();
        }

        fileItem.remove();
        console.log('File deleted successfully:', filename);
    } catch (error) {
        console.error('Delete error:', error);
        showError('Failed to delete file: ' + error.message);
    }
}

// Dialog functions
function showRenameDialog(currentName, fileItem) {
    const newName = prompt('Enter new filename:', currentName);
    if (newName && newName !== currentName && newName.trim()) {
        renameMediaFile(currentName, newName.trim(), fileItem);
    }
}

function showDeleteDialog(filename, fileItem) {
    if (confirm(`Are you sure you want to delete "${filename}"?`)) {
        deleteMediaFile(filename, fileItem);
    }
}

// Initialize library UI
export function initializeLibraryUI() {
    const searchInput = document.getElementById('media-search-input');
    const sortSelect = document.getElementById('media-sort-select');
    const gridViewBtn = document.getElementById('media-grid-view-btn');
    const listViewBtn = document.getElementById('media-list-view-btn');
    const gridSizeSlider = document.getElementById('media-grid-size');

    // Search and sort functionality
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            filterAndSortMediaFiles();
        });
    }

    if (sortSelect) {
        sortSelect.addEventListener('change', () => {
            filterAndSortMediaFiles();
        });
    }

    // View controls
    if (gridViewBtn) {
        gridViewBtn.addEventListener('click', () => {
            setViewMode('grid');
        });
    }

    if (listViewBtn) {
        listViewBtn.addEventListener('click', () => {
            setViewMode('list');
        });
    }

    if (gridSizeSlider) {
        gridSizeSlider.addEventListener('input', (e) => {
            setCurrentGridSize(parseInt(e.target.value));
            if (getCurrentViewMode() === 'grid') {
                updateGridSize();
            }
        });
    }
}

// Import functions from other modules (will be set by orchestrator)
let loadMediaOnDemand, loadMediaIntoPlayer, addToQueue, getCurrentViewMode, getCurrentGridSize, setViewMode, setCurrentGridSize, updateGridSize, getSelectedFileItem, clearSelection, stopPlayback;

export function setLibraryDependencies(deps) {
    ({ loadMediaOnDemand, loadMediaIntoPlayer, addToQueue, getCurrentViewMode, getCurrentGridSize, setViewMode, setCurrentGridSize, updateGridSize, getSelectedFileItem, clearSelection, stopPlayback } = deps);
}