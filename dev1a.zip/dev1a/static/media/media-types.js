// Media format detection, validation, and utilities

// Supported media formats
export const SUPPORTED_VIDEO_FORMATS = ['mp4', 'webm', 'avi', 'mov'];
export const SUPPORTED_AUDIO_FORMATS = ['mp3', 'wav', 'ogg'];
export const SUPPORTED_IMAGE_FORMATS = ['png', 'jpg', 'jpeg', 'gif', 'webp', 'jfif'];

// MIME type mappings
export const MIME_TYPES = {
    'mp4': 'video/mp4',
    'webm': 'video/webm',
    'avi': 'video/x-msvideo',
    'mov': 'video/quicktime',
    'mp3': 'audio/mpeg',
    'wav': 'audio/wav',
    'ogg': 'audio/ogg',
    'png': 'image/png',
    'jpg': 'image/jpeg',
    'jpeg': 'image/jpeg',
    'gif': 'image/gif',
    'webp': 'image/webp',
    'jfif': 'image/jpeg'
};

// File icon mappings
export const FILE_ICONS = {
    'pdf': 'fa-file-pdf',
    'doc': 'fa-file-word',
    'docx': 'fa-file-word',
    'txt': 'fa-file-alt',
    'md': 'fa-file-code',
    'png': 'fa-file-image',
    'jpg': 'fa-file-image',
    'jpeg': 'fa-file-image',
    'gif': 'fa-file-image',
    'webp': 'fa-file-image',
    'jfif': 'fa-file-image',
    'mp4': 'fa-file-video',
    'webm': 'fa-file-video',
    'avi': 'fa-file-video',
    'mov': 'fa-file-video',
    'mp3': 'fa-file-audio',
    'wav': 'fa-file-audio',
    'ogg': 'fa-file-audio'
};

// Get file extension
export function getFileExtension(filename) {
    if (!filename || typeof filename !== 'string') {
        return '';
    }
    return filename.split('.').pop().toLowerCase();
}

// Check if file is a supported video format
export function isVideoFile(filename) {
    const ext = getFileExtension(filename);
    return SUPPORTED_VIDEO_FORMATS.includes(ext);
}

// Check if file is a supported audio format
export function isAudioFile(filename) {
    const ext = getFileExtension(filename);
    return SUPPORTED_AUDIO_FORMATS.includes(ext);
}

// Check if file is a supported media format (video or audio)
export function isMediaFile(filename) {
    return isVideoFile(filename) || isAudioFile(filename);
}

// Check if file is a supported image format
export function isImageFile(filename) {
    const ext = getFileExtension(filename);
    return SUPPORTED_IMAGE_FORMATS.includes(ext);
}

// Get MIME type for file
export function getMimeType(filename) {
    const ext = getFileExtension(filename);
    return MIME_TYPES[ext] || 'application/octet-stream';
}

// Get icon class for file
export function getFileIcon(filename) {
    const ext = getFileExtension(filename);
    return FILE_ICONS[ext] || 'fa-file';
}

// Validate file for upload
export function validateMediaFile(file) {
    if (!file) {
        throw new Error('No file provided');
    }

    const ext = getFileExtension(file.name);
    if (!isMediaFile(file.name)) {
        throw new Error(`Unsupported file format: ${ext}`);
    }

    // Check file size (max 500MB)
    const maxSize = 500 * 1024 * 1024;
    if (file.size > maxSize) {
        throw new Error('File too large. Maximum size is 500MB.');
    }

    return true;
}

// Format file size for display
export function formatFileSize(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}