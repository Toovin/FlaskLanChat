// Media player controls and state management

import { showError } from '../core/ui-utils.js';
import { isVideoFile, isAudioFile } from './media-types.js';

// Player state
let selectedFileItem = null;
let currentViewMode = 'grid'; // 'grid' or 'list'
let currentGridSize = 200; // pixels

// Queue functions (will be set by orchestrator)
let playNextTrack, playPreviousTrack;

// Get player elements
function getPlayerElements() {
    return {
        videoPlayer: document.getElementById('cinema-player-video'),
        audioPlayer: document.getElementById('cinema-player-audio'),
        placeholder: document.querySelector('.player-placeholder'),
        playPauseBtn: document.getElementById('play-pause-btn'),
        volumeSlider: document.getElementById('volume-slider')
    };
}

// Load media into player
export function loadMediaIntoPlayer(url, name) {
    const { videoPlayer, audioPlayer, placeholder } = getPlayerElements();

    // Determine file type
    const isVideo = isVideoFile(name);
    const isAudio = isAudioFile(name);

    if (!isVideo && !isAudio) {
        showError('Unsupported file format for playback');
        return;
    }

    // Set up player
    videoPlayer.style.display = isVideo ? 'block' : 'none';
    audioPlayer.style.display = isAudio ? 'block' : 'none';
    placeholder.style.display = 'none';

    const player = isVideo ? videoPlayer : audioPlayer;
    player.src = url;
    player.load(); // Ensure load

    // Update now playing
    updateNowPlaying(name);
}

// Select media file
export function selectMediaFile(fileItem, url, name) {
    // Remove previous selection
    if (selectedFileItem) {
        selectedFileItem.classList.remove('selected');
    }

    // Select new item
    selectedFileItem = fileItem;
    fileItem.classList.add('selected');

    // Load into player
    loadMediaIntoPlayer(url, name);
}

// Load media on demand
export function loadMediaOnDemand(fileItem, lazyUrl, name) {
    // Remove previous selection
    if (selectedFileItem) {
        selectedFileItem.classList.remove('selected');
    }

    // Select new item
    selectedFileItem = fileItem;
    fileItem.classList.add('selected');

    // Show loading state
    const { videoPlayer, audioPlayer, placeholder } = getPlayerElements();

    videoPlayer.style.display = 'none';
    audioPlayer.style.display = 'none';
    placeholder.style.display = 'block';
    placeholder.textContent = 'Loading...';

    // Load content from lazy URL
    loadMediaIntoPlayer(lazyUrl, name);
}

// Stop playback
export function stopPlayback() {
    const { videoPlayer, audioPlayer, placeholder, playPauseBtn } = getPlayerElements();

    videoPlayer.pause();
    audioPlayer.pause();
    videoPlayer.src = '';
    audioPlayer.src = '';
    videoPlayer.style.display = 'none';
    audioPlayer.style.display = 'none';
    placeholder.style.display = 'block';
    playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';

    // Clear now playing
    updateNowPlaying('No media selected');

    if (selectedFileItem) {
        selectedFileItem.classList.remove('selected');
        selectedFileItem = null;
    }
}

// Update now playing display
export function updateNowPlaying(title) {
    const nowPlayingTitle = document.getElementById('now-playing-title');
    if (nowPlayingTitle) {
        nowPlayingTitle.textContent = title || 'No media selected';
    }
}

// Initialize player controls
export function initializePlayerControls() {
    const { playPauseBtn, prevBtn, nextBtn, stopBtn, volumeSlider, videoPlayer, audioPlayer } = getPlayerElements();

    // Play/pause button
    if (playPauseBtn) {
        playPauseBtn.addEventListener('click', () => {
            const activePlayer = videoPlayer.style.display !== 'none' ? videoPlayer : audioPlayer;
            if (activePlayer.paused) {
                activePlayer.play();
                playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
            } else {
                activePlayer.pause();
                playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
            }
        });
    }

    // Previous/Next buttons
    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            if (playPreviousTrack) {
                const track = playPreviousTrack();
                if (track) {
                    loadMediaIntoPlayer(track.lazy_url, track.name);
                }
            }
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            if (playNextTrack) {
                const track = playNextTrack();
                if (track) {
                    loadMediaIntoPlayer(track.lazy_url, track.name);
                }
            }
        });
    }

    // Stop button
    if (stopBtn) {
        stopBtn.addEventListener('click', () => {
            stopPlayback();
        });
    }

    // Volume control
    if (volumeSlider) {
        volumeSlider.addEventListener('input', (e) => {
            const volume = parseFloat(e.target.value);
            videoPlayer.volume = volume;
            audioPlayer.volume = volume;
        });
    }

    // Update play/pause button on player events
    [videoPlayer, audioPlayer].forEach(player => {
        player.addEventListener('play', () => {
            playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
        });
        player.addEventListener('pause', () => {
            playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
        });
        player.addEventListener('ended', () => {
            playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
            // Auto-play next track
            if (playNextTrack) {
                const track = playNextTrack();
                if (track) {
                    loadMediaIntoPlayer(track.lazy_url, track.name);
                }
            }
        });
    });
}

// View mode management
export function setViewMode(mode) {
    if (mode !== 'grid' && mode !== 'list') return;

    currentViewMode = mode;

    // Update button states
    const gridBtn = document.getElementById('media-grid-view-btn');
    const listBtn = document.getElementById('media-list-view-btn');

    if (gridBtn) gridBtn.classList.toggle('active', mode === 'grid');
    if (listBtn) listBtn.classList.toggle('active', mode === 'list');

    // Re-render files with new view mode will be handled by library
}

export function updateGridSize() {
    if (currentViewMode === 'grid') {
        const gridContainer = document.querySelector('.media-files-grid');
        if (gridContainer) {
            gridContainer.style.gridTemplateColumns = `repeat(auto-fill, minmax(${currentGridSize}px, 1fr))`;
        }
    }
}

export function getCurrentViewMode() {
    return currentViewMode;
}

export function getCurrentGridSize() {
    return currentGridSize;
}

export function setCurrentGridSize(size) {
    currentGridSize = size;
    updateGridSize();
}

// Set queue dependencies
export function setPlayerQueueDependencies(deps) {
    ({ playNextTrack, playPreviousTrack } = deps);
}

// Get selected file item
export function getSelectedFileItem() {
    return selectedFileItem;
}

// Clear selection
export function clearSelection() {
    if (selectedFileItem) {
        selectedFileItem.classList.remove('selected');
        selectedFileItem = null;
    }
}