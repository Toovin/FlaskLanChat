// Media system orchestrator

import { initializeUploadUI, initializeDownloadUI } from './media-upload.js';
import { initializeQueueUI, addToQueue, clearMediaQueue, updateQueueDisplay, playNextTrack, playPreviousTrack, getCurrentTrack, setQueuePlayerDependencies } from './media-queue.js';
import { initializePlayerControls, loadMediaIntoPlayer, loadMediaOnDemand, selectMediaFile, stopPlayback, setViewMode, getCurrentViewMode, getCurrentGridSize, setCurrentGridSize, updateGridSize, setPlayerQueueDependencies, getSelectedFileItem, clearSelection, updateNowPlaying } from './media-player.js';
import { loadMediaFiles, initializeLibraryUI, setLibraryDependencies } from './media-library.js';

// Initialize media system
export function initMedia() {
    console.log('Initializing media system...');

    // Set up inter-module dependencies
    setLibraryDependencies({
        loadMediaOnDemand,
        loadMediaIntoPlayer,
        addToQueue,
        getCurrentViewMode,
        getCurrentGridSize,
        setViewMode,
        setCurrentGridSize,
        updateGridSize,
        getSelectedFileItem,
        clearSelection,
        stopPlayback
    });

    // Set player queue dependencies
    setPlayerQueueDependencies({
        playNextTrack,
        playPreviousTrack
    });

    // Set queue player dependencies
    setQueuePlayerDependencies({
        loadMediaIntoPlayer,
        updateNowPlaying
    });

    // Initialize all UI components
    initializeUploadUI();
    initializeDownloadUI(handleDownloadComplete);
    initializeQueueUI();
    initializePlayerControls();
    initializeLibraryUI();

    // Set up tab switching
    setupTabSwitching();

    console.log('Media system initialized');
}

// Tab switching logic
function setupTabSwitching() {
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const tabName = tab.dataset.tab;
            switchToTab(tabName);
            if (tabName === 'media') {
                loadMediaFiles();
            }
        });
    });

    // Initialize tab display
    const activeTab = document.querySelector('.tab.active');
    if (activeTab) {
        switchToTab(activeTab.dataset.tab);
    }
}

function switchToTab(tabName) {
    // Hide all tab contents
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(content => {
        content.style.display = 'none';
    });

    // Show the selected tab content
    const targetContent = document.getElementById(`tab-content-${tabName}`);
    if (targetContent) {
        targetContent.style.display = 'flex';
    }

    // Update active tab
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        tab.classList.toggle('active', tab.dataset.tab === tabName);
    });
}

// Connect queue to player controls
export function connectQueueToPlayer() {
    // This will be called to set up the connection between queue navigation and player
    // For now, the player controls call playNextTrack/playPreviousTrack from queue
}

// Handle download completion
export function handleDownloadComplete() {
    // Reload media content
    loadMediaFiles();
}

// Handle download error
export function handleDownloadError() {
    // Reset download button state (handled in upload module)
}

// DOM ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initMedia);
} else {
    initMedia();
}