// Media upload handling and progress

import { showError } from '../core/ui-utils.js';
import { validateMediaFile } from './media-types.js';
import { socket } from '../core/setup.js';

// Upload media file
export async function uploadMediaFile(file) {
    try {
        validateMediaFile(file);

        const formData = new FormData();
        formData.append('file', file);

        const response = await fetch('/upload-media', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        const data = await response.json();

        if (data.error) throw new Error(data.error);

        console.log('Media file uploaded successfully:', data.filename);
        return data;
    } catch (error) {
        console.error('Upload error:', error);
        showError('Failed to upload media file: ' + error.message);
        throw error;
    }
}

// Download media from URL
export async function downloadMediaFromUrl(url) {
    if (!url || !url.trim()) {
        throw new Error('Please enter a valid URL');
    }

    const requestBody = { url: url.trim() };

    try {
        const response = await fetch('/download-media', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestBody)
        });

        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        const data = await response.json();

        if (data.error) throw new Error(data.error);

        console.log('Media download initiated:', data.download_id);
        return data;
    } catch (error) {
        console.error('Download error:', error);
        showError('Failed to download media: ' + error.message);
        throw error;
    }
}

// Handle multiple file uploads
export async function handleMultipleUploads(files) {
    const results = [];
    for (const file of files) {
        try {
            const result = await uploadMediaFile(file);
            results.push(result);
        } catch (error) {
            // Continue with other files even if one fails
            console.error('Failed to upload file:', file.name, error);
        }
    }
    return results;
}

// Initialize upload UI elements
export function initializeUploadUI() {
    const mediaUploadButton = document.querySelector('#tab-content-media .upload-btn');
    const mediaUploadInput = document.getElementById('media-upload-input');

    if (mediaUploadButton && mediaUploadInput) {
        mediaUploadButton.addEventListener('click', () => {
            mediaUploadInput.click();
        });

        mediaUploadInput.addEventListener('change', async (event) => {
            const files = event.target.files;
            if (!files || files.length === 0) return;

            await handleMultipleUploads(files);
            // Clear the input
            mediaUploadInput.value = '';
            // Reload media content
            // This will be handled by the orchestrator
        });
    }
}

// Initialize download UI elements
export function initializeDownloadUI(onDownloadComplete) {
    const mediaUrlInput = document.getElementById('media-url-input');
    const mediaDownloadButton = document.querySelector('#tab-content-media .download-btn');
    const toastOnDownloadCheckbox = document.getElementById('toast-on-download');

    // Load toast setting
    if (toastOnDownloadCheckbox) {
        let settingsLoaded = false;

        // Load current setting (only once)
        const loadSettingsOnce = (settings) => {
            if (!settingsLoaded && toastOnDownloadCheckbox) {
                toastOnDownloadCheckbox.checked = settings.toast_on_media_download !== false;
                settingsLoaded = true;
                // Remove listener after initial load
                socket.off('user_settings', loadSettingsOnce);
            }
        };

        socket.on('user_settings', loadSettingsOnce);
        socket.emit('get_user_settings');

        // Save setting when changed
        toastOnDownloadCheckbox.addEventListener('change', (e) => {
            socket.emit('update_user_settings', {
                settings: { toast_on_media_download: e.target.checked }
            });
        });
    }

    if (mediaDownloadButton) {
        mediaDownloadButton.addEventListener('click', async () => {
            const url = mediaUrlInput.value.trim();
            try {
                await downloadMediaFromUrl(url);
                mediaUrlInput.value = '';
                if (onDownloadComplete) onDownloadComplete();
            } catch (error) {
                // Error already shown
            }
        });
    }
}