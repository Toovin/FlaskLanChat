// Media queue management and persistence

import { showError, escapeHtml } from '../core/ui-utils.js';
import { getFileIcon } from './media-types.js';

// Queue state
let mediaQueue = [];
let currentQueueIndex = -1;
let savedPlaylists = {};

// Player functions (will be set by orchestrator)
let loadMediaIntoPlayer, updateNowPlaying;

// Load saved playlists from localStorage
export function loadSavedPlaylists() {
    try {
        const stored = localStorage.getItem('mediaPlaylists');
        if (stored) {
            savedPlaylists = JSON.parse(stored);
        }
    } catch (e) {
        console.error('Error loading saved playlists:', e);
        savedPlaylists = {};
    }
}

// Save playlists to localStorage
function savePlaylistsToStorage() {
    try {
        localStorage.setItem('mediaPlaylists', JSON.stringify(savedPlaylists));
    } catch (e) {
        console.error('Error saving playlists:', e);
    }
}

// Queue operations
export function addToQueue(file) {
    // Check if file is already in queue
    const existingIndex = mediaQueue.findIndex(item => item.name === file.name);
    if (existingIndex === -1) {
        mediaQueue.push(file);
        updateQueueDisplay();
    }
}

export function removeFromQueue(index) {
    if (index >= 0 && index < mediaQueue.length) {
        mediaQueue.splice(index, 1);
        if (currentQueueIndex >= index && currentQueueIndex > 0) {
            currentQueueIndex--;
        } else if (currentQueueIndex >= mediaQueue.length) {
            currentQueueIndex = mediaQueue.length - 1;
        }
        updateQueueDisplay();
    }
}

export function clearMediaQueue() {
    mediaQueue = [];
    currentQueueIndex = -1;
    updateQueueDisplay();
    // Stop playback will be handled by player
}

export function getQueue() {
    return [...mediaQueue];
}

export function getCurrentQueueIndex() {
    return currentQueueIndex;
}

export function setCurrentQueueIndex(index) {
    currentQueueIndex = index;
}

// Playback navigation
export function playNextTrack() {
    if (mediaQueue.length > 0) {
        currentQueueIndex = (currentQueueIndex + 1) % mediaQueue.length;
        return mediaQueue[currentQueueIndex];
    }
    return null;
}

export function playPreviousTrack() {
    if (mediaQueue.length > 0) {
        currentQueueIndex = currentQueueIndex > 0 ? currentQueueIndex - 1 : mediaQueue.length - 1;
        return mediaQueue[currentQueueIndex];
    }
    return null;
}

export function getCurrentTrack() {
    if (currentQueueIndex >= 0 && currentQueueIndex < mediaQueue.length) {
        return mediaQueue[currentQueueIndex];
    }
    return null;
}

// Playlist management
export function saveCurrentPlaylist() {
    if (mediaQueue.length === 0) {
        showError('Queue is empty. Add some media files to save as a playlist.');
        return false;
    }

    const playlistName = prompt('Enter playlist name:');
    if (!playlistName || !playlistName.trim()) {
        return false;
    }

    const name = playlistName.trim();
    if (savedPlaylists[name]) {
        if (!confirm(`Playlist "${name}" already exists. Overwrite?`)) {
            return false;
        }
    }

    // Save current queue as playlist
    savedPlaylists[name] = {
        files: [...mediaQueue],
        created: new Date().toISOString(),
        count: mediaQueue.length
    };

    savePlaylistsToStorage();
    return true;
}

export function loadPlaylist(playlistName) {
    const playlist = savedPlaylists[playlistName];
    if (!playlist) {
        showError('Playlist not found.');
        return false;
    }

    // Load playlist into queue
    mediaQueue = [...playlist.files];
    currentQueueIndex = -1;
    updateQueueDisplay();
    return true;
}

export function deletePlaylist(playlistName) {
    if (!savedPlaylists[playlistName]) {
        showError('Playlist not found.');
        return false;
    }

    if (!confirm(`Are you sure you want to delete playlist "${playlistName}"?`)) {
        return false;
    }

    delete savedPlaylists[playlistName];
    savePlaylistsToStorage();
    return true;
}

export function getSavedPlaylists() {
    return { ...savedPlaylists };
}

// Set player dependencies
export function setQueuePlayerDependencies(deps) {
    ({ loadMediaIntoPlayer, updateNowPlaying } = deps);
}

// UI updates
export function updateQueueDisplay() {
    const queueContainer = document.getElementById('media-queue');
    if (!queueContainer) return;

    queueContainer.innerHTML = '';

    if (mediaQueue.length === 0) {
        queueContainer.innerHTML = '<div class="queue-empty">Queue is empty</div>';
        return;
    }

    mediaQueue.forEach((file, index) => {
        const queueItem = document.createElement('div');
        queueItem.className = `queue-item ${index === currentQueueIndex ? 'playing' : ''}`;

        const removeBtn = document.createElement('button');
        removeBtn.className = 'queue-remove';
        removeBtn.title = 'Remove from queue';
        removeBtn.innerHTML = '<i class="fas fa-times"></i>';
        removeBtn.addEventListener('click', () => removeFromQueue(index));

        queueItem.innerHTML = `
            <i class="fas ${getFileIcon(file.name)}"></i>
            <div class="queue-title">${escapeHtml(file.name)}</div>
        `;
        queueItem.appendChild(removeBtn);

        queueItem.addEventListener('click', (e) => {
            if (!e.target.closest('.queue-remove')) {
                // Play from queue
                setCurrentQueueIndex(index);
                if (loadMediaIntoPlayer) {
                    loadMediaIntoPlayer(file.lazy_url, file.name);
                }
                if (updateNowPlaying) {
                    updateNowPlaying(file.name);
                }
                updateQueueDisplay();
            }
        });

        queueContainer.appendChild(queueItem);
    });
}

// Initialize queue UI
export function initializeQueueUI() {
    const clearQueueBtn = document.getElementById('clear-queue-btn');
    if (clearQueueBtn) {
        clearQueueBtn.addEventListener('click', () => {
            clearMediaQueue();
        });
    }

    // Playlist controls
    const savePlaylistBtn = document.getElementById('save-playlist-btn');
    const loadPlaylistBtn = document.getElementById('load-playlist-btn');
    const loadSelectedPlaylistBtn = document.getElementById('load-selected-playlist-btn');
    const deletePlaylistBtn = document.getElementById('delete-playlist-btn');
    const cancelPlaylistBtn = document.getElementById('cancel-playlist-btn');

    if (savePlaylistBtn) {
        savePlaylistBtn.addEventListener('click', () => {
            saveCurrentPlaylist();
        });
    }

    if (loadPlaylistBtn) {
        loadPlaylistBtn.addEventListener('click', () => {
            showPlaylistSelector();
        });
    }

    if (loadSelectedPlaylistBtn) {
        loadSelectedPlaylistBtn.addEventListener('click', () => {
            loadSelectedPlaylist();
        });
    }

    if (deletePlaylistBtn) {
        deletePlaylistBtn.addEventListener('click', () => {
            deleteSelectedPlaylist();
        });
    }

    if (cancelPlaylistBtn) {
        cancelPlaylistBtn.addEventListener('click', () => {
            hidePlaylistSelector();
        });
    }

    // Load saved playlists on startup
    loadSavedPlaylists();
}

// Playlist selector UI
function showPlaylistSelector() {
    const selector = document.getElementById('playlist-selector');
    const dropdown = document.getElementById('playlist-dropdown');

    if (!selector || !dropdown) return;

    // Populate dropdown with saved playlists
    dropdown.innerHTML = '<option value="">Select playlist...</option>';
    Object.keys(savedPlaylists).forEach(name => {
        const option = document.createElement('option');
        option.value = name;
        option.textContent = `${name} (${savedPlaylists[name].count} files)`;
        dropdown.appendChild(option);
    });

    selector.style.display = 'block';
}

function hidePlaylistSelector() {
    const selector = document.getElementById('playlist-selector');
    if (selector) {
        selector.style.display = 'none';
    }
}

function loadSelectedPlaylist() {
    const dropdown = document.getElementById('playlist-dropdown');
    if (!dropdown || !dropdown.value) {
        showError('Please select a playlist to load.');
        return;
    }

    const playlistName = dropdown.value;
    if (loadPlaylist(playlistName)) {
        hidePlaylistSelector();
        showError(`Playlist "${playlistName}" loaded!`);
    }
}

function deleteSelectedPlaylist() {
    const dropdown = document.getElementById('playlist-dropdown');
    if (!dropdown || !dropdown.value) {
        showError('Please select a playlist to delete.');
        return;
    }

    const playlistName = dropdown.value;
    if (deletePlaylist(playlistName)) {
        hidePlaylistSelector();
        showError(`Playlist "${playlistName}" deleted.`);
    }
}