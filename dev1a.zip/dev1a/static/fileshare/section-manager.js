// Section management for public/server file sections

import { showError } from '../core/ui-utils.js';

/**
 * SectionManager - Handles switching between public and server sections
 */
export class SectionManager {
    constructor() {
        this.currentSection = 'public';
        this.username = window.currentUsername || 'admin';
        this.isAdmin = window.isAdmin || false;

        // DOM elements (will be set by orchestrator)
        this.elements = {};
    }

    /**
     * Set DOM elements reference
     */
    setElements(elements) {
        this.elements = elements;
    }

    /**
     * Initialize section tabs
     */
    initialize() {
        this.setupSectionTabs();
        this.updateSectionUI();
    }

    /**
     * Setup section tab event listeners
     */
    setupSectionTabs() {
        const sectionTabs = this.elements.sectionTabs;
        if (!sectionTabs) return;

        sectionTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                this.switchSection(tab.dataset.section);
            });
        });
    }

    /**
     * Switch to a different section
     */
    switchSection(section) {
        console.log(`[SectionManager] Switching to section: ${section}`);

        if (section !== 'public' && section !== 'server') {
            return;
        }

        // Update active tab
        const sectionTabs = this.elements.sectionTabs;
        if (sectionTabs) {
            sectionTabs.forEach(tab => tab.classList.remove('active'));
            const activeTab = document.querySelector(`.section-tab[data-section="${section}"]`);
            if (activeTab) {
                activeTab.classList.add('active');
            }
        }

        // Update state
        this.currentSection = section;

        // Update UI elements
        this.updateSectionUI();
    }

    /**
     * Update UI elements based on current section
     */
    updateSectionUI() {
        const uploadBtn = this.elements.uploadBtn;
        const fileList = this.elements.fileList;
        const sectionName = this.elements.sectionName;
        const sectionBadge = this.elements.sectionBadge;

        if (this.currentSection === 'public') {
            // Enable upload for public section
            if (uploadBtn) {
                uploadBtn.style.display = 'flex';
                uploadBtn.disabled = false;
            }
            if (fileList) {
                fileList.classList.remove('read-only');
            }
            if (sectionName) {
                sectionName.textContent = 'Public Files';
            }
            if (sectionBadge) {
                sectionBadge.textContent = 'Editable';
                sectionBadge.className = 'section-badge public';
            }
        } else {
            // Disable upload for server section
            if (uploadBtn) {
                uploadBtn.style.display = 'none';
            }
            if (fileList) {
                fileList.classList.add('read-only');
            }
            if (sectionName) {
                sectionName.textContent = 'Server Files';
            }
            if (sectionBadge) {
                sectionBadge.textContent = 'Read-Only';
                sectionBadge.className = 'section-badge server';
            }
        }
    }

    /**
     * Check if current section allows modifications
     */
    canModify() {
        return this.currentSection === 'public';
    }

    /**
     * Check if current section allows uploads
     */
    canUpload() {
        return this.currentSection === 'public';
    }

    /**
     * Get current section
     */
    getCurrentSection() {
        return this.currentSection;
    }

    /**
     * Get section display name
     */
    getSectionDisplayName() {
        return this.currentSection === 'public' ? 'public' : 'server';
    }
}