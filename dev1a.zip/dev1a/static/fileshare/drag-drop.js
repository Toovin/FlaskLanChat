// Drag and drop functionality for file uploads

import { showError } from '../core/ui-utils.js';

/**
 * DragDropManager - Handles drag and drop file uploads
 */
export class DragDropManager {
    constructor() {
        // DOM elements (will be set by orchestrator)
        this.elements = {};

        // Callbacks (will be set by orchestrator)
        this.onFilesDropped = null;
    }

    /**
     * Set DOM elements reference
     */
    setElements(elements) {
        this.elements = elements;
    }

    /**
     * Set callback for when files are dropped
     */
    setOnFilesDropped(callback) {
        this.onFilesDropped = callback;
    }

    /**
     * Initialize drag and drop functionality
     */
    initialize() {
        this.setupDragAndDrop();
    }

    /**
     * Setup drag and drop event listeners
     */
    setupDragAndDrop() {
        const fileList = this.elements.fileList;
        if (!fileList) return;

        // Drag over event
        fileList.addEventListener('dragover', (e) => {
            e.preventDefault();
            if (this.canAcceptDrop()) {
                fileList.classList.add('drag-over');
            }
        });

        // Drag leave event
        fileList.addEventListener('dragleave', (e) => {
            e.preventDefault();
            fileList.classList.remove('drag-over');
        });

        // Drop event
        fileList.addEventListener('drop', (e) => {
            e.preventDefault();
            fileList.classList.remove('drag-over');

            if (!this.canAcceptDrop()) {
                showError('Cannot upload files to this section');
                return;
            }

            const files = Array.from(e.dataTransfer.files);
            if (files.length > 0) {
                this.handleFilesDropped(files);
            }
        });
    }

    /**
     * Check if the current section can accept file drops
     */
    canAcceptDrop() {
        // This will be checked by the section manager
        // For now, assume public section allows drops
        return this.elements.sectionManager?.canUpload() ?? false;
    }

    /**
     * Handle files dropped
     */
    handleFilesDropped(files) {
        console.log('[DragDrop] Files dropped:', Array.from(files).map(f => f.name));

        if (this.onFilesDropped) {
            this.onFilesDropped(files);
        }
    }

    /**
     * Set section manager reference for checking permissions
     */
    setSectionManager(sectionManager) {
        this.elements.sectionManager = sectionManager;
    }
}