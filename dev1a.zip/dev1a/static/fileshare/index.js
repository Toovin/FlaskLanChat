// ============================================================================
// File Share System Orchestrator - Modular File Sharing
// ============================================================================

import { SectionManager } from './section-manager.js';
import { DragDropManager } from './drag-drop.js';
import { FileUploadManager } from './file-upload.js';
import { FileBrowser } from './file-browser.js';

/**
 * FileShareOrchestrator - Main orchestrator for the modular file sharing system
 */
class FileShareOrchestrator {
    constructor() {
        // State management
        this.state = {
            currentSection: 'public', // 'public' or 'server'
            username: window.currentUsername || 'admin',
            isAdmin: window.isAdmin || false
        };

        // DOM element cache
        this.elements = {};

        // Manager instances
        this.sectionManager = null;
        this.dragDropManager = null;
        this.fileUploadManager = null;
        this.fileBrowser = null;

        // Initialize on DOM ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.initialize());
        } else {
            this.initialize();
        }
    }

    /**
     * Initialize the file share system
     */
    initialize() {
        this.cacheElements();
        this.createManagers();
        this.setupManagers();
        this.wireCallbacks();
        this.initializeManagers();
        this.exposeGlobalFunctions();
        this.loadInitialData();
    }

    /**
     * Cache DOM elements for better performance
     */
    cacheElements() {
        this.elements = {
            fileInput: document.getElementById('file-share-upload-input'),
            fileList: document.getElementById('file-list'),
            sectionTabs: document.querySelectorAll('.section-tab'),
            uploadBtn: document.getElementById('file-upload-btn'),
            sectionName: document.getElementById('section-name'),
            sectionBadge: document.getElementById('section-badge'),
            fileCount: document.getElementById('file-count'),
            errorMessage: document.getElementById('error-message'),
            progressContainer: document.getElementById('upload-progress-container'),
            progressFill: document.getElementById('upload-progress-fill'),
            progressStatus: document.getElementById('upload-status'),
            progressFilename: document.getElementById('upload-filename'),
            progressSpeed: document.getElementById('upload-speed'),
            progressEta: document.getElementById('upload-eta')
        };
    }

    /**
     * Create manager instances
     */
    createManagers() {
        this.sectionManager = new SectionManager();
        this.dragDropManager = new DragDropManager();
        this.fileUploadManager = new FileUploadManager();
        this.fileBrowser = new FileBrowser();
    }

    /**
     * Setup managers with DOM elements
     */
    setupManagers() {
        // Set elements for all managers
        const elements = this.elements;
        this.sectionManager.setElements(elements);
        this.dragDropManager.setElements(elements);
        this.fileUploadManager.setElements(elements);
        this.fileBrowser.setElements(elements);

        // Set initial section for managers that need it
        this.fileUploadManager.setCurrentSection(this.state.currentSection);
        this.fileBrowser.setCurrentSection(this.state.currentSection);
    }

    /**
     * Wire up callbacks between managers
     */
    wireCallbacks() {
        // Section manager -> File browser (when section changes)
        this.sectionManager.switchSection = (section) => {
            this.handleSectionSwitch(section);
        };

        // Drag drop -> File upload (when files are dropped)
        this.dragDropManager.setOnFilesDropped((files) => {
            this.fileUploadManager.uploadFiles(files);
        });

        // File upload -> File browser (when upload completes)
        this.fileUploadManager.setOnUploadComplete(() => {
            this.fileBrowser.loadFiles();
        });

        // File browser -> Global functions (for delete/rename actions)
        this.fileBrowser.setOnFileAction((action, data) => {
            this.handleFileAction(action, data);
        });

        // Set section manager reference for drag drop permissions
        this.dragDropManager.setSectionManager(this.sectionManager);
    }

    /**
     * Initialize all managers
     */
    initializeManagers() {
        this.sectionManager.initialize();
        this.dragDropManager.initialize();
        this.fileUploadManager.initialize();
        this.fileBrowser.initialize();
    }

    /**
     * Handle section switching
     */
    handleSectionSwitch(section) {
        console.log(`[Orchestrator] Switching to section: ${section}`);

        // Update state
        this.state.currentSection = section;

        // Update managers
        this.fileUploadManager.setCurrentSection(section);
        this.fileBrowser.setCurrentSection(section);

        // Reload files for new section
        this.fileBrowser.loadFiles();
    }

    /**
     * Handle file actions from browser
     */
    handleFileAction(action, data) {
        switch (action) {
            case 'delete':
                this.fileBrowser.deleteFile(data.filename);
                break;
            case 'rename':
                this.fileBrowser.renameFile(data.filename);
                break;
            default:
                console.warn(`[Orchestrator] Unknown file action: ${action}`);
        }
    }

    /**
     * Expose functions to global scope for HTML onclick handlers
     */
    exposeGlobalFunctions() {
        // Create a single global object for all exposed functions
        window.fileShareManager = {
            deleteFile: (filename) => this.fileBrowser.deleteFile(filename),
            renameFile: (filename) => this.fileBrowser.renameFile(filename),
            openImageModal: (url) => this.fileBrowser.openImageModal(url),
            switchSection: (section) => this.sectionManager.switchSection(section),
            loadFileShareContent: () => this.loadFileShareContent(),
            openTextPreview: (url, filename) => this.openTextPreview(url, filename),
            openVideoModal: (url) => this.openVideoModal(url),
            openAudioModal: (url, filename) => this.openAudioModal(url, filename),
            handleUploadButtonClick: () => this.fileUploadManager.handleUploadButtonClick()
        };

        // Also expose individual functions for backward compatibility
        Object.entries(window.fileShareManager).forEach(([key, value]) => {
            window[key] = value;
        });
    }

    /**
     * Load initial data
     */
    async loadInitialData() {
        try {
            // Set initial section UI (handled by section manager)
            await this.fileBrowser.loadFiles();
        } catch (error) {
            console.error('[Orchestrator] Failed to load initial data:', error);
            // Error handling is done by individual managers
        }
    }

    /**
     * Load file share content (called when tab is activated)
     */
    async loadFileShareContent() {
        console.log('[Orchestrator] Loading file share content');
        await this.fileBrowser.loadFiles();
    }

    /**
     * Open text file preview
     */
    openTextPreview(url, filename) {
        console.log('[Orchestrator] Opening text preview:', filename, url);

        // Create a simple text preview modal
        const modal = document.createElement('div');
        modal.className = 'text-preview-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 2000;
        `;

        const content = document.createElement('div');
        content.style.cssText = `
            background: var(--bg-primary, #ffffff);
            border-radius: 8px;
            padding: 20px;
            max-width: 80%;
            max-height: 80%;
            overflow: auto;
            position: relative;
        `;

        const header = document.createElement('div');
        header.style.cssText = `
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            border-bottom: 1px solid var(--border-color, #ddd);
            padding-bottom: 10px;
        `;

        const title = document.createElement('h3');
        title.textContent = `Preview: ${filename}`;
        title.style.margin = '0';

        const closeBtn = document.createElement('button');
        closeBtn.textContent = '×';
        closeBtn.style.cssText = `
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: var(--text-color, #333);
        `;
        closeBtn.onclick = () => document.body.removeChild(modal);

        header.appendChild(title);
        header.appendChild(closeBtn);

        const textArea = document.createElement('pre');
        textArea.style.cssText = `
            white-space: pre-wrap;
            word-wrap: break-word;
            font-family: monospace;
            font-size: 14px;
            line-height: 1.4;
            max-height: 400px;
            overflow: auto;
        `;

        // Load text content
        fetch(url)
            .then(response => response.text())
            .then(text => {
                textArea.textContent = text;
            })
            .catch(error => {
                textArea.textContent = `Error loading file: ${error.message}`;
                console.error('[Orchestrator] Error loading text file:', error);
            });

        content.appendChild(header);
        content.appendChild(textArea);
        modal.appendChild(content);

        // Close on background click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                document.body.removeChild(modal);
            }
        });

        document.body.appendChild(modal);
    }

    /**
     * Open video modal
     */
    openVideoModal(url) {
        console.log('[Orchestrator] Opening video modal:', url);

        const modal = document.createElement('div');
        modal.className = 'video-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 2000;
        `;

        const video = document.createElement('video');
        video.src = url;
        video.controls = true;
        video.style.cssText = `
            max-width: 90%;
            max-height: 90%;
            border-radius: 8px;
        `;

        modal.appendChild(video);
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                document.body.removeChild(modal);
            }
        });

        document.body.appendChild(modal);
        video.play();
    }

    /**
     * Open audio modal
     */
    openAudioModal(url, filename) {
        console.log('[Orchestrator] Opening audio modal:', filename, url);

        const modal = document.createElement('div');
        modal.className = 'audio-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 2000;
        `;

        const content = document.createElement('div');
        content.style.cssText = `
            background: var(--bg-primary, #ffffff);
            border-radius: 8px;
            padding: 30px;
            text-align: center;
        `;

        const title = document.createElement('h3');
        title.textContent = `Playing: ${filename}`;
        title.style.marginTop = '0';

        const audio = document.createElement('audio');
        audio.src = url;
        audio.controls = true;
        audio.style.margin = '20px 0';

        const closeBtn = document.createElement('button');
        closeBtn.textContent = 'Close';
        closeBtn.style.cssText = `
            background: var(--button-bg, #007bff);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
        `;
        closeBtn.onclick = () => document.body.removeChild(modal);

        content.appendChild(title);
        content.appendChild(audio);
        content.appendChild(closeBtn);
        modal.appendChild(content);

        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                document.body.removeChild(modal);
            }
        });

        document.body.appendChild(modal);
    }
}

// Create and export the orchestrator instance
const fileShareOrchestrator = new FileShareOrchestrator();
export default fileShareOrchestrator;