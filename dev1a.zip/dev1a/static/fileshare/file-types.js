// File type detection, validation, and utilities

// Supported file type categories
export const FILE_TYPE_CATEGORIES = {
    images: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'jfif', 'svg', 'bmp'],
    videos: ['mp4', 'webm', 'avi', 'mov', 'wmv', 'flv', 'mkv'],
    audio: ['mp3', 'wav', 'ogg', 'flac', 'aac'],
    text: ['txt', 'md', 'json', 'xml', 'csv', 'log'],
    code: ['js', 'py', 'html', 'css', 'php', 'java', 'cpp', 'c', 'h'],
    documents: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'],
    archives: ['zip', 'rar', '7z', 'tar', 'gz']
};

// File icon mappings
export const FILE_ICONS = {
    // Documents
    'pdf': 'fa-file-pdf',
    'doc': 'fa-file-word',
    'docx': 'fa-file-word',
    'xls': 'fa-file-excel',
    'xlsx': 'fa-file-excel',
    'ppt': 'fa-file-powerpoint',
    'pptx': 'fa-file-powerpoint',
    'txt': 'fa-file-alt',
    'md': 'fa-file-code',

    // Code
    'js': 'fa-file-code',
    'py': 'fa-file-code',
    'html': 'fa-file-code',
    'css': 'fa-file-code',
    'json': 'fa-file-code',

    // Images
    'png': 'fa-file-image',
    'jpg': 'fa-file-image',
    'jpeg': 'fa-file-image',
    'gif': 'fa-file-image',
    'svg': 'fa-file-image',

    // Videos
    'mp4': 'fa-file-video',
    'webm': 'fa-file-video',
    'avi': 'fa-file-video',
    'mov': 'fa-file-video',

    // Audio
    'mp3': 'fa-file-audio',
    'wav': 'fa-file-audio',
    'ogg': 'fa-file-audio',

    // Archives
    'zip': 'fa-file-archive',
    'rar': 'fa-file-archive',
    '7z': 'fa-file-archive',
    'tar': 'fa-file-archive'
};

/**
 * Get file extension from filename
 */
export function getFileExtension(filename) {
    if (!filename || typeof filename !== 'string') {
        return '';
    }
    return filename.split('.').pop().toLowerCase();
}

/**
 * Get file icon class for a filename
 */
export function getFileIcon(filename) {
    const ext = getFileExtension(filename);
    return FILE_ICONS[ext] || 'fa-file';
}

/**
 * Check if file is an image
 */
export function isImageFile(filename) {
    const ext = getFileExtension(filename);
    return FILE_TYPE_CATEGORIES.images.includes(ext);
}

/**
 * Check if file is a video
 */
export function isVideoFile(filename) {
    const ext = getFileExtension(filename);
    return FILE_TYPE_CATEGORIES.videos.includes(ext);
}

/**
 * Check if file is audio
 */
export function isAudioFile(filename) {
    const ext = getFileExtension(filename);
    return FILE_TYPE_CATEGORIES.audio.includes(ext);
}

/**
 * Check if file is text-based
 */
export function isTextFile(filename) {
    const ext = getFileExtension(filename);
    return FILE_TYPE_CATEGORIES.text.includes(ext) || FILE_TYPE_CATEGORIES.code.includes(ext);
}

/**
 * Check if file is a document
 */
export function isDocumentFile(filename) {
    const ext = getFileExtension(filename);
    return FILE_TYPE_CATEGORIES.documents.includes(ext);
}

/**
 * Check if file is an archive
 */
export function isArchiveFile(filename) {
    const ext = getFileExtension(filename);
    return FILE_TYPE_CATEGORIES.archives.includes(ext);
}

/**
 * Get file type category
 */
export function getFileCategory(filename) {
    const ext = getFileExtension(filename);

    for (const [category, extensions] of Object.entries(FILE_TYPE_CATEGORIES)) {
        if (extensions.includes(ext)) {
            return category;
        }
    }

    return 'other';
}

/**
 * Format file size in human readable format
 */
export function formatFileSize(bytes) {
    if (!bytes || bytes === 0) return '0 B';

    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));

    return (bytes / Math.pow(1024, i)).toFixed(1) + ' ' + sizes[i];
}

/**
 * Format transfer speed
 */
export function formatSpeed(bytesPerSecond) {
    if (!bytesPerSecond || bytesPerSecond === 0) return '0 B/s';

    const sizes = ['B/s', 'KB/s', 'MB/s', 'GB/s'];
    const i = Math.floor(Math.log(bytesPerSecond) / Math.log(1024));

    return (bytesPerSecond / Math.pow(1024, i)).toFixed(1) + ' ' + sizes[i];
}

/**
 * Format time remaining
 */
export function formatTime(seconds) {
    if (!isFinite(seconds) || seconds < 0) return '--:--';

    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);

    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}