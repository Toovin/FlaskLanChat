// File browsing, listing, and management

import { showError } from '../core/ui-utils.js';
import { escapeHtml } from '../core/ui-utils.js';
import { openImageViewer } from '../viewers.js';
import {
    getFileIcon,
    formatFileSize,
    isImageFile,
    isVideoFile,
    isAudioFile,
    isTextFile
} from './file-types.js';

/**
 * FileBrowser - Handles file listing, rendering, and actions
 */
export class FileBrowser {
    constructor() {
        // DOM elements (will be set by orchestrator)
        this.elements = {};

        // Current section and user info
        this.currentSection = 'public';
        this.username = window.currentUsername || 'admin';
        this.isAdmin = window.isAdmin || false;

        // Callbacks
        this.onFileAction = null;
    }

    /**
     * Set DOM elements reference
     */
    setElements(elements) {
        this.elements = elements;
    }

    /**
     * Set current section
     */
    setCurrentSection(section) {
        this.currentSection = section;
    }

    /**
     * Set file action callback
     */
    setOnFileAction(callback) {
        this.onFileAction = callback;
    }

    /**
     * Initialize file browser
     */
    initialize() {
        // Initial load will be handled by the orchestrator
    }

    /**
     * Load files for current section
     */
    async loadFiles() {
        const fileList = this.elements.fileList;
        if (!fileList) return;

        const url = `/files/${this.currentSection}`;
        console.log(`[FileBrowser] Loading files for section: ${this.currentSection}`);

        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error('Failed to fetch files');

            const data = await response.json();
            const files = data.files || [];

            this.renderFileList(files);
            this.updateFileCount(files.length);

        } catch (error) {
            console.error('[FileBrowser] Error loading files:', error);
            this.renderErrorMessage('Failed to load files');
            this.updateFileCount(0);
        }
    }

    /**
     * Render file list
     */
    renderFileList(files) {
        const fileList = this.elements.fileList;
        if (!fileList) return;

        fileList.innerHTML = '';

        if (files.length === 0) {
            this.renderEmptyMessage();
            return;
        }

        files.forEach(file => {
            if (this.validateFile(file)) {
                const fileElement = this.createFileElement(file);
                fileList.appendChild(fileElement);
            }
        });
    }

    /**
     * Validate file object
     */
    validateFile(file) {
        if (!file || !file.filename) {
            console.warn('[FileBrowser] Skipping file with missing filename:', file);
            return false;
        }
        return true;
    }

    /**
     * Render empty files message
     */
    renderEmptyMessage() {
        const sectionNames = {
            'public': 'public',
            'server': 'server'
        };

        this.elements.fileList.innerHTML = `
            <div style="text-align: center; color: var(--text-muted); padding: 20px;">
                No ${sectionNames[this.currentSection]} files available
            </div>
        `;
    }

    /**
     * Render error message
     */
    renderErrorMessage(message) {
        this.elements.fileList.innerHTML =
            `<div style="text-align: center; color: #dc3545; padding: 20px;">${message}</div>`;
    }

    /**
     * Create file element
     */
    createFileElement(file) {
        const element = document.createElement('div');
        element.className = 'file-item';

        const fileInfo = this.getFileInfo(file);
        element.innerHTML = this.getFileHTML(file, fileInfo);

        return element;
    }

    /**
     * Get file information
     */
    getFileInfo(file) {
        const ext = file.filename.split('.').pop().toLowerCase();
        const viewUrl = file.url || file.filepath.replace(/^static[\\\/]/, '').replace(/\\/g, '/');
        const downloadUrl = `/lazy-file/${encodeURIComponent(viewUrl.replace(/^\/static\//, ''))}?download=true`;

        return {
            ext,
            viewUrl,
            downloadUrl,
            icon: getFileIcon(file.filename),
            size: formatFileSize(file.size),
            isImage: isImageFile(file.filename),
            isVideo: isVideoFile(file.filename),
            isAudio: isAudioFile(file.filename),
            isText: isTextFile(file.filename),
            isOwner: file.created_by === this.username,
            canModify: this.currentSection === 'public' && file.created_by === this.username
        };
    }

    /**
     * Get file HTML
     */
    getFileHTML(file, info) {
        const clickAction = this.getFileClickAction(file, info);

        return `
            <div class="file-icon" ${clickAction}>
                <i class="fas ${info.icon}"></i>
            </div>
            <div class="file-info">
                <div class="file-name" ${clickAction}>${escapeHtml(file.filename)}</div>
                <div class="file-details">
                    <span class="file-size">${info.size}</span>
                    <span class="file-date">${file.created_at}</span>
                    ${file.visibility === 'public' ? '<span class="file-visibility">Public</span>' : ''}
                </div>
            </div>
            <div class="file-actions">
                ${this.getFileActionsHTML(file, info)}
            </div>
        `;
    }

    /**
     * Get file click action
     */
    getFileClickAction(file, info) {
        if (info.isImage) {
            return `onclick="openImageModal('${escapeHtml(info.viewUrl)}')"`;
        } else if (info.isVideo) {
            return `onclick="openVideoModal('${escapeHtml(info.viewUrl)}')"`;
        } else if (info.isAudio) {
            return `onclick="openAudioModal('${escapeHtml(info.viewUrl)}', '${escapeHtml(file.filename)}')"`;
        } else if (info.isText) {
            return `onclick="openTextPreview('${escapeHtml(info.viewUrl)}', '${escapeHtml(file.filename)}')"`;
        }
        return `onclick="window.location.href='${escapeHtml(info.downloadUrl)}'"`;
    }

    /**
     * Get file actions HTML
     */
    getFileActionsHTML(file, info) {
        let html = '';

        // Download button (always available)
        html += `
            <a href="${escapeHtml(info.downloadUrl)}" download="${escapeHtml(file.filename)}"
               class="download-btn" title="Download">
                <i class="fas fa-download"></i>
            </a>
        `;

        // Actions for Public section (editable)
        if (this.currentSection === 'public' && info.canModify) {
            html += `
                <button class="rename-btn" onclick="renameFile('${escapeHtml(file.filename)}')" title="Rename">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="delete-btn" onclick="deleteFile('${escapeHtml(file.filename)}')" title="Delete">
                    <i class="fas fa-trash"></i>
                </button>
            `;
        }

        // External link for HTML files in server section
        if (this.currentSection === 'server' && info.ext === 'html') {
            html += `
                <button class="view-btn" onclick="window.open('${escapeHtml(info.viewUrl)}', '_blank')" title="Open in new tab">
                    <i class="fas fa-external-link-alt"></i>
                </button>
            `;
        }

        return html;
    }

    /**
     * Update file count display
     */
    updateFileCount(count) {
        const fileCount = this.elements.fileCount;
        if (fileCount) {
            fileCount.textContent = `${count} file${count !== 1 ? 's' : ''}`;
        }
    }

    /**
     * Delete file
     */
    async deleteFile(filename) {
        if (this.currentSection !== 'public') {
            showError('Cannot delete files from server section');
            return;
        }

        if (!confirm(`Are you sure you want to delete "${filename}"? This action cannot be undone.`)) {
            return;
        }

        try {
            const response = await fetch(`/delete-file/${this.currentSection}/${encodeURIComponent(filename)}`, {
                method: 'DELETE'
            });

            if (!response.ok) throw new Error('Failed to delete file');

            const data = await response.json();
            if (!data.success) {
                throw new Error(data.error || 'Unknown error');
            }

            this.showSuccess(`File "${filename}" deleted successfully`);
            await this.loadFiles(); // This will update the file count

        } catch (error) {
            console.error('[FileBrowser] Error deleting file:', error);
            showError('Failed to delete file: ' + error.message);
        }
    }

    /**
     * Rename file
     */
    async renameFile(filename) {
        if (this.currentSection !== 'public') {
            showError('Cannot rename files in server section');
            return;
        }

        const newFilename = prompt('Enter new filename:', filename);
        if (!newFilename || newFilename.trim() === filename) return;

        const trimmedFilename = newFilename.trim();

        try {
            const response = await fetch(`/rename-file/${this.currentSection}/${encodeURIComponent(filename)}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ new_filename: trimmedFilename })
            });

            if (!response.ok) throw new Error('Failed to rename file');

            const data = await response.json();
            if (!data.success) {
                throw new Error(data.error || 'Unknown error');
            }

            this.showSuccess(`File renamed to "${trimmedFilename}"`);
            await this.loadFiles(); // This will update the file count

        } catch (error) {
            console.error('[FileBrowser] Error renaming file:', error);
            showError('Failed to rename file: ' + error.message);
        }
    }

    /**
     * Show success message
     */
    showSuccess(message) {
        const errorMessage = this.elements.errorMessage;
        if (errorMessage) {
            errorMessage.textContent = message;
            errorMessage.style.background = '#28a745';
            errorMessage.style.display = 'block';

            setTimeout(() => {
                errorMessage.style.display = 'none';
            }, 3000);
        }

        if (window.soundManager) {
            window.soundManager.playSuccess();
        }
    }

    /**
     * Open image modal
     */
    openImageModal(imageUrl) {
        openImageViewer(imageUrl);
    }
}