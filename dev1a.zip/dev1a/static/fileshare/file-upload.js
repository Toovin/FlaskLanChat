// File upload handling and progress tracking

import { showError } from '../core/ui-utils.js';
import { formatSpeed, formatTime } from './file-types.js';

/**
 * FileUploadManager - Handles file uploads with progress tracking
 */
export class FileUploadManager {
    constructor() {
        // DOM elements (will be set by orchestrator)
        this.elements = {};

        // Current section (will be set by section manager)
        this.currentSection = 'public';

        // Callbacks
        this.onUploadComplete = null;
        this.onUploadError = null;
    }

    /**
     * Set DOM elements reference
     */
    setElements(elements) {
        this.elements = elements;
    }

    /**
     * Set current section
     */
    setCurrentSection(section) {
        this.currentSection = section;
    }

    /**
     * Set upload completion callback
     */
    setOnUploadComplete(callback) {
        this.onUploadComplete = callback;
    }

    /**
     * Set upload error callback
     */
    setOnUploadError(callback) {
        this.onUploadError = callback;
    }

    /**
     * Initialize upload functionality
     */
    initialize() {
        this.setupUploadButton();
    }

    /**
     * Setup upload button event listener
     */
    setupUploadButton() {
        const uploadBtn = this.elements.uploadBtn;
        const fileInput = this.elements.fileInput;

        if (uploadBtn && fileInput) {
            uploadBtn.addEventListener('click', () => this.handleUploadButtonClick());
            fileInput.addEventListener('change', (e) => this.handleFileSelection(e));
        }
    }

    /**
     * Handle upload button click
     */
    handleUploadButtonClick() {
        if (this.currentSection !== 'public') {
            showError('Cannot upload files to server section');
            return;
        }

        const fileInput = this.elements.fileInput;
        if (fileInput) {
            fileInput.click();
        }
    }

    /**
     * Handle file selection from input
     */
    handleFileSelection(e) {
        const files = e.target.files;
        if (files.length > 0) {
            console.log('[FileUpload] Files selected for upload:', Array.from(files).map(f => f.name));
            this.uploadFiles(files);
        }
    }

    /**
     * Upload files with progress tracking
     */
    async uploadFiles(files) {
        if (files.length === 0) return;

        if (this.currentSection !== 'public') {
            showError('Cannot upload to server section');
            return;
        }

        // For simplicity, only upload the first file
        const file = files[0];
        const formData = this.buildUploadFormData(file);

        await this.performUpload(formData, 1);
    }

    /**
     * Build upload form data
     */
    buildUploadFormData(file) {
        const formData = new FormData();
        formData.append('file', file, file.name);
        return formData;
    }

    /**
     * Perform file upload with progress tracking
     */
    async performUpload(formData, fileCount) {
        const uploadButton = this.elements.uploadBtn;
        const progressContainer = this.elements.progressContainer;
        const progressFill = this.elements.progressFill;
        const progressStatus = this.elements.progressStatus;
        const progressFilename = this.elements.progressFilename;
        const progressSpeed = this.elements.progressSpeed;
        const progressEta = this.elements.progressEta;

        // Store original button text
        const originalText = uploadButton?.textContent || 'Upload';

        // Update UI for upload in progress
        if (uploadButton) {
            uploadButton.textContent = 'Uploading...';
            uploadButton.disabled = true;
        }

        // Show progress bar
        if (progressContainer) {
            progressContainer.style.display = 'block';
        }

        // Get filename from form data
        const file = formData.get('file');
        if (progressFilename && file) {
            progressFilename.textContent = file.name;
        }

        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            let startTime = Date.now();
            let lastLoaded = 0;
            let lastTime = startTime;

            // Progress handler
            xhr.upload.onprogress = (e) => {
                if (e.lengthComputable) {
                    const percentComplete = (e.loaded / e.total) * 100;

                    // Update progress bar
                    if (progressFill) {
                        progressFill.style.width = percentComplete + '%';
                    }
                    if (progressStatus) {
                        progressStatus.textContent = Math.round(percentComplete) + '%';
                    }

                    // Calculate speed and ETA
                    const currentTime = Date.now();
                    const timeDiff = (currentTime - lastTime) / 1000; // seconds
                    const loadedDiff = e.loaded - lastLoaded;

                    if (timeDiff > 0.5) { // Update every 500ms
                        const speed = loadedDiff / timeDiff; // bytes per second
                        const remaining = e.total - e.loaded;
                        const eta = remaining / speed; // seconds

                        if (progressSpeed) {
                            progressSpeed.textContent = formatSpeed(speed);
                        }
                        if (progressEta) {
                            progressEta.textContent = formatTime(eta);
                        }

                        lastLoaded = e.loaded;
                        lastTime = currentTime;
                    }
                }
            };

            // Load handler
            xhr.onload = () => {
                if (xhr.status >= 200 && xhr.status < 300) {
                    try {
                        const data = JSON.parse(xhr.responseText);
                        console.log(`[FileUpload] Successfully uploaded ${fileCount} files to ${this.currentSection}`);

                        if (this.onUploadComplete) {
                            this.onUploadComplete(data);
                        }

                        resolve(data);
                    } catch (e) {
                        reject(new Error('Invalid response format'));
                    }
                } else {
                    reject(new Error(`HTTP error! Status: ${xhr.status}`));
                }
            };

            // Error handler
            xhr.onerror = () => {
                reject(new Error('Network error during upload'));
            };

            // Setup and send request
            xhr.open('POST', `/upload/${this.currentSection}`);
            xhr.setRequestHeader('Accept', 'application/json');
            xhr.send(formData);
        }).catch((error) => {
            console.error('[FileUpload] Upload error:', error);
            showError('Failed to upload files: ' + error.message);

            if (this.onUploadError) {
                this.onUploadError(error);
            }
        }).finally(() => {
            // Hide progress bar
            if (progressContainer) {
                progressContainer.style.display = 'none';
            }

            // Reset progress elements
            if (progressFill) progressFill.style.width = '0%';
            if (progressStatus) progressStatus.textContent = '0%';
            if (progressSpeed) progressSpeed.textContent = '0 B/s';
            if (progressEta) progressEta.textContent = '--:--';

            // Reset upload button
            if (uploadButton) {
                uploadButton.textContent = originalText;
                uploadButton.disabled = false;
            }

            // Clear file input
            const fileInput = this.elements.fileInput;
            if (fileInput) {
                fileInput.value = '';
            }
        });
    }
}