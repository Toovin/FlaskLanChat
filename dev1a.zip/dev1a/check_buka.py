#!/usr/bin/env python3
import sqlite3

conn = sqlite3.connect('devchat.db')
cursor = conn.cursor()

# Check BUKA character
cursor.execute('SELECT character_name, ai_system_prompt FROM ai_characters WHERE character_name = "BUKA"')
row = cursor.fetchone()
if row:
    print('BUKA character found:')
    print(f'Name: {row[0]}')
    print(f'Prompt length: {len(row[1])} characters')
    print(f'Prompt preview: {row[1][:200]}...')
else:
    print('BUKA character not found')

conn.close()