"""
Type stubs for Flask-SocketIO to resolve type checking issues.
This provides type hints for Flask-SocketIO extensions to the Flask request object.
"""

from typing import Any, Dict, Optional, Union, Callable
from flask import Request as FlaskRequest

class Request(FlaskRequest):
    """Extended Flask request object with SocketIO attributes."""
    sid: str  # Socket.IO session ID

# Re-export common Flask-SocketIO functions with type hints
def emit(event: str, data: Any = None, to: Optional[str] = None, room: Optional[str] = None,
         skip_sid: Optional[str] = None, namespace: Optional[str] = None,
         callback: Optional[Callable] = None) -> None: ...

def join_room(room: str, sid: Optional[str] = None, namespace: Optional[str] = None) -> None: ...

def leave_room(room: str, sid: Optional[str] = None, namespace: Optional[str] = None) -> None: ...

class SocketIO:
    """SocketIO class with basic type hints."""
    def __init__(self, app: Any = None, **kwargs: Any) -> None: ...
    def on(self, event: str, namespace: Optional[str] = None) -> Callable: ...