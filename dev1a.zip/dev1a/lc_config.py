import os

# Server configuration
USE_HTTPS = os.environ.get('FLASKLANCHAT_HTTPS', 'true').lower() == 'true'
SERVER_PORT = int(os.environ.get('FLASKLANCHAT_PORT', '6969'))
CHAT_DB_NAME = os.environ.get('FLASKLANCHAT_DB_NAME', 'devchat.db')
AI_DB_NAME = os.environ.get('FLASKLANCHAT_AI_DB_NAME', 'ai_chat.db')

EXTENSIONS_DIR = 'extensions'
UPLOAD_DIR = 'static/uploads'
THUMBNAILS_DIR = 'static/thumbnails/uploads'
AVATAR_DIR = 'static/uploads/avatars'
DEFAULT_AVATAR_DIR = 'static/default_avatars'
MEDIA_DOWNLOAD_DIR = 'static/media_downloaded'
THUMBNAILS_MEDIA_DOWNLOADED_DIR = 'static/thumbnails/media_downloaded'

# File upload limits (in bytes)
# Set to 0 or None to disable limits
MAX_FILE_SIZE = int(os.environ.get('FLASKLANCHAT_MAX_FILE_SIZE', '0'))  # 50MB default
MAX_TOTAL_UPLOAD_SIZE = int(os.environ.get('FLASKLANCHAT_MAX_TOTAL_UPLOAD_SIZE', '0'))  # 200MB default




