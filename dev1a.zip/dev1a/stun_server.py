#!/usr/bin/env python3
"""
Simple STUN server for LAN WebRTC connections
Implements RFC 5389 STUN protocol
"""

import socket
import struct
import time
import threading
import sys

# STUN message types
STUN_BINDING_REQUEST = 0x0001
STUN_BINDING_RESPONSE = 0x0101

# STUN attributes
STUN_ATTR_MAPPED_ADDRESS = 0x0001
STUN_ATTR_XOR_MAPPED_ADDRESS = 0x0020

class STUNServer:
    def __init__(self, host='0.0.0.0', port=3479):
        self.host = host
        self.port = port
        self.sock = None
        self.running = False

    def start(self):
        """Start the STUN server"""
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock.bind((self.host, self.port))
            self.running = True

            print(f"STUN server started on {self.host}:{self.port}")

            # Start listening thread
            thread = threading.Thread(target=self._listen)
            thread.daemon = True
            thread.start()

        except Exception as e:
            print(f"Failed to start STUN server: {e}")
            sys.exit(1)

    def stop(self):
        """Stop the STUN server"""
        self.running = False
        if self.sock:
            self.sock.close()

    def _listen(self):
        """Listen for STUN requests"""
        while self.running:
            try:
                data, addr = self.sock.recvfrom(1024)
                self._handle_request(data, addr)
            except OSError:
                break
            except Exception as e:
                print(f"Error handling request: {e}")

    def _handle_request(self, data, addr):
        """Handle a STUN binding request"""
        try:
            if len(data) < 20:
                return

            # Parse STUN header
            message_type, message_length, magic_cookie, transaction_id = struct.unpack('>HHL12s', data[:20])

            if message_type != STUN_BINDING_REQUEST:
                return

            print(f"STUN binding request from {addr[0]}:{addr[1]}")

            # Create response
            response = self._create_binding_response(transaction_id, addr)
            self.sock.sendto(response, addr)

        except Exception as e:
            print(f"Error parsing STUN request: {e}")

    def _create_binding_response(self, transaction_id, addr):
        """Create a STUN binding response"""
        # XOR the address with magic cookie for XOR-MAPPED-ADDRESS
        magic_cookie = 0x2112A442
        ip_int = struct.unpack('>L', socket.inet_aton(addr[0]))[0]
        xor_addr = ip_int ^ magic_cookie
        xor_port = (addr[1] ^ (magic_cookie >> 16)) & 0xFFFF

        # Build XOR-MAPPED-ADDRESS attribute
        family = 0x01  # IPv4
        reserved = 0x00
        xor_mapped_attr = struct.pack('>BBHL', family, reserved, xor_port, xor_addr)

        # Attribute header
        attr_type = STUN_ATTR_XOR_MAPPED_ADDRESS
        attr_length = len(xor_mapped_attr)
        attr_header = struct.pack('>HH', attr_type, attr_length)

        # Full attribute
        xor_mapped_full = attr_header + xor_mapped_attr

        # Response header
        message_type = STUN_BINDING_RESPONSE
        message_length = len(xor_mapped_full)
        magic_cookie = 0x2112A442

        header = struct.pack('>HHL12s', message_type, message_length, magic_cookie, transaction_id)

        return header + xor_mapped_full

def main():
    server = STUNServer()
    try:
        server.start()
        print("Press Ctrl+C to stop")
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping STUN server...")
        server.stop()
    except Exception as e:
        print(f"Error: {e}")
        server.stop()
        sys.exit(1)

if __name__ == '__main__':
    main()