#!/usr/bin/env python3
"""
Simple server to serve the LLM API test page
"""
from flask import Flask, send_from_directory
import os

app = Flask(__name__)

@app.route('/')
def index():
    return send_from_directory('.', 'test_llm_api.html')

@app.route('/<path:filename>')
def serve_static(filename):
    return send_from_directory('.', filename)

if __name__ == '__main__':
    print("Starting LLM API Test Page Server...")
    print("Open http://localhost:8080 in your browser")
    print("Make sure the main FlaskLanChat server is running on port 6969")
    app.run(host='0.0.0.0', port=8080, debug=False)