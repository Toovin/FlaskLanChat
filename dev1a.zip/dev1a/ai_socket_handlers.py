"""
New AI Socket Handlers - Clean integration with modular AI system
"""
# def register_new_ai_handlers(socketio, users_db, users):
# def handle_ai_modal_send(data):
# def handle_ai_get_characters():
# def handle_ai_create_character(data):
# def handle_ai_update_character(data):
# def handle_ai_delete_character(data):
# def handle_ai_set_active_character(data):
# def handle_ai_get_active_character():
# def handle_ai_analyze_document(data):
# def handle_ai_analyze_image(data):
# def handle_ai_clear_conversation(data):
# def handle_ai_get_conversations():
# def handle_ai_create_conversation(data):
# def handle_ai_get_conversation_history(data):
# def handle_ai_delete_conversation(data):
# def handle_ai_update_conversation(data):
from flask_socketio import emit
from flask import request
from ai_modal import ai_modal
import base64
import os


def register_new_ai_handlers(socketio, users_db, users):
    """Register the new modular AI socket handlers"""

    @socketio.on('ai_modal_send')
    def handle_ai_modal_send(data):
        """Handle sending messages in the AI modal"""
        print(f"[SERVER] ai_modal_send received data: {data}")

        try:
            user_uuid = users.get(request.sid)
            print(f"[SERVER] User UUID: {user_uuid}")

            if not user_uuid:
                print("[SERVER] User not authenticated")
                emit('ai_error', {'message': 'User not authenticated'}, room=request.sid)
                return

            message = data.get('message', '').strip()
            character_name = data.get('character_name')
            conversation_key = data.get('conversation_key')
            conversation_id = data.get('conversation_id')
            image_data = data.get('image_data')  # Base64 image data

            print(f"[SERVER] Parsed data - message: '{message}', character: {character_name}, conv_key: {conversation_key}, conv_id: {conversation_id}, has_image: {bool(image_data)}")

            if not message and not image_data:
                print("[SERVER] No message or image, returning")
                return

            # Send through modal interface
            print("[SERVER] Calling ai_modal.send_message")
            result = ai_modal.send_message(
                user_uuid=user_uuid,
                message=message,
                character_name=character_name,
                conversation_key=conversation_key,
                conversation_id=conversation_id,
                image_data=image_data
            )

            print(f"[SERVER] ai_modal.send_message result: {result}")

            if result and result.get('success'):
                print("[SERVER] Emitting ai_modal_response")
                emit('ai_modal_response', result, room=request.sid)
            else:
                error_msg = result.get('error', 'Unknown error') if result else 'AI generation failed'
                print(f"[SERVER] Emitting error: {error_msg}")
                emit('ai_error', {'message': error_msg}, room=request.sid)

        except Exception as e:
            print(f"[SERVER] Error in ai_modal_send: {str(e)}")
            import traceback
            traceback.print_exc()
            emit('ai_error', {'message': 'Internal server error'}, room=request.sid)

    @socketio.on('ai_get_characters')
    def handle_ai_get_characters():
        """Get user's AI characters"""
        print(f"[DEBUG] ai_get_characters called")
        try:
            user_uuid = users.get(request.sid)
            print(f"[DEBUG] user_uuid: {user_uuid}")
            if not user_uuid:
                print("[DEBUG] User not authenticated")
                emit('ai_error', {'message': 'User not authenticated'}, room=request.sid)
                return

            print("[DEBUG] Calling ai_modal.get_characters")
            characters = ai_modal.get_characters(user_uuid)
            print(f"[DEBUG] Retrieved {len(characters)} characters")
            for i, char in enumerate(characters[:3]):  # Log first 3 characters
                print(f"[DEBUG] Character {i}: {char.get('character_name')} (type: {char.get('character_type')})")

            print("[DEBUG] Emitting ai_characters_list")
            emit('ai_characters_list', {'characters': characters}, room=request.sid)
            print("[DEBUG] ai_characters_list emitted successfully")

        except Exception as e:
            print(f"[DEBUG] Error getting characters: {str(e)}")
            import traceback
            traceback.print_exc()
            emit('ai_error', {'message': 'Failed to load characters'}, room=request.sid)

    @socketio.on('ai_create_character')
    def handle_ai_create_character(data):
        """Create a new character"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('ai_error', {'message': 'User not authenticated'}, room=request.sid)
                return

            character_data = data.get('character', {})
            if not character_data.get('character_name'):
                emit('ai_error', {'message': 'Character name is required'}, room=request.sid)
                return

            # Check if debug logging is enabled
            from database import get_user_ai_settings
            ai_settings = get_user_ai_settings(user_uuid)
            debug_enabled = ai_settings.get('ai_debug_settings', False)

            if debug_enabled:
                print(f"[AI_SETTINGS_DEBUG] User {user_uuid} creating new character: {character_data.get('character_name')}")
                print(f"[AI_SETTINGS_DEBUG] Character data: {character_data}")

            character_data = data.get('character', {})
            if not character_data.get('character_name'):
                emit('ai_error', {'message': 'Character name is required'}, room=request.sid)
                return

            # Handle avatar upload
            if 'avatar' in character_data:
                try:
                    avatar_data = character_data['avatar']
                    if avatar_data.startswith('data:image/'):
                        # Generate filename and save
                        filename = f"avatar_ai_{user_uuid}_{character_data['character_name']}.png"
                        filepath = os.path.join('static', 'uploads', 'avatars', filename)

                        os.makedirs(os.path.dirname(filepath), exist_ok=True)

                        # Extract base64 data
                        header, base64_data = avatar_data.split(',', 1)
                        image_bytes = base64.b64decode(base64_data)

                        with open(filepath, 'wb') as f:
                            f.write(image_bytes)

                        character_data['avatar_url'] = f'/static/uploads/avatars/{filename}'
                        del character_data['avatar']

                except Exception as e:
                    print(f"Error saving avatar: {str(e)}")
                    emit('ai_error', {'message': 'Failed to save avatar'}, room=request.sid)
                    return

            success = ai_modal.create_character(user_uuid, character_data)
            if success:
                emit('ai_character_created', {'character': character_data}, room=request.sid)
            else:
                emit('ai_error', {'message': 'Failed to create character'}, room=request.sid)

        except Exception as e:
            print(f"Error creating character: {str(e)}")
            emit('ai_error', {'message': 'Failed to create character'}, room=request.sid)

    @socketio.on('ai_update_character')
    def handle_ai_update_character(data):
        """Update an existing character"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('ai_error', {'message': 'User not authenticated'}, room=request.sid)
                return

            character_data = data.get('character', {})
            original_name = data.get('original_name')

            if not character_data.get('character_name'):
                emit('ai_error', {'message': 'Character name is required'}, room=request.sid)
                return

            # For update, we need to update the character with the new data
            success = ai_modal.update_character(user_uuid, original_name, character_data)
            if success:
                emit('ai_character_updated', {'character': character_data, 'success': True}, room=request.sid)
            else:
                emit('ai_error', {'message': 'Failed to update character'}, room=request.sid)

        except Exception as e:
            print(f"Error updating character: {str(e)}")
            emit('ai_error', {'message': 'Failed to update character'}, room=request.sid)

    @socketio.on('ai_delete_character')
    def handle_ai_delete_character(data):
        """Delete a character"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('ai_error', {'message': 'User not authenticated'}, room=request.sid)
                return

            character_name = data.get('character_name')
            if not character_name:
                emit('ai_error', {'message': 'Character name is required'}, room=request.sid)
                return

            success = ai_modal.delete_character(user_uuid, character_name)
            if success:
                emit('ai_character_deleted', {'character_name': character_name}, room=request.sid)
            else:
                emit('ai_error', {'message': 'Failed to delete character'}, room=request.sid)

        except Exception as e:
            print(f"Error deleting character: {str(e)}")
            emit('ai_error', {'message': 'Failed to delete character'}, room=request.sid)

    @socketio.on('ai_set_active_character')
    def handle_ai_set_active_character(data):
        """Set active character"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('ai_error', {'message': 'User not authenticated'}, room=request.sid)
                return

            character_name = data.get('character_name')
            if not character_name:
                emit('ai_error', {'message': 'Character name is required'}, room=request.sid)
                return

            success = ai_modal.set_active_character(user_uuid, character_name)
            if success:
                character = ai_modal.get_active_character(user_uuid)
                emit('ai_active_character_set', {'character': character}, room=request.sid)
            else:
                emit('ai_error', {'message': 'Failed to set active character'}, room=request.sid)

        except Exception as e:
            print(f"Error setting active character: {str(e)}")
            emit('ai_error', {'message': 'Failed to set active character'}, room=request.sid)

    @socketio.on('ai_get_active_character')
    def handle_ai_get_active_character():
        """Get active character"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('ai_error', {'message': 'User not authenticated'}, room=request.sid)
                return

            character = ai_modal.get_active_character(user_uuid)
            emit('ai_active_character_data', {'character': character}, room=request.sid)

        except Exception as e:
            print(f"Error getting active character: {str(e)}")
            emit('ai_error', {'message': 'Failed to get active character'}, room=request.sid)

    @socketio.on('ai_analyze_document')
    def handle_ai_analyze_document(data):
        """Analyze a document"""
        try:
            document_content = data.get('content', '').strip()
            document_type = data.get('type', 'text')

            if not document_content:
                emit('ai_error', {'message': 'Document content is required'}, room=request.sid)
                return

            result = ai_modal.analyze_document(document_content, document_type)
            if result and result.get('success'):
                emit('ai_document_analysis', result, room=request.sid)
            else:
                emit('ai_error', {
                    'message': result.get('error', 'Document analysis failed') if result else 'Analysis failed'
                }, room=request.sid)

        except Exception as e:
            print(f"Error analyzing document: {str(e)}")
            emit('ai_error', {'message': 'Document analysis failed'}, room=request.sid)

    @socketio.on('ai_analyze_image')
    def handle_ai_analyze_image(data):
        """Analyze an image"""
        try:
            image_data = data.get('image_data')
            if not image_data:
                emit('ai_error', {'message': 'Image data is required'}, room=request.sid)
                return

            result = ai_modal.analyze_image(image_data)
            if result and result.get('success'):
                emit('ai_image_analysis', result, room=request.sid)
            else:
                emit('ai_error', {
                    'message': result.get('error', 'Image analysis failed') if result else 'Analysis failed'
                }, room=request.sid)

        except Exception as e:
            print(f"Error analyzing image: {str(e)}")
            emit('ai_error', {'message': 'Image analysis failed'}, room=request.sid)

    @socketio.on('ai_clear_conversation')
    def handle_ai_clear_conversation(data):
        """Clear conversation context"""
        try:
            conversation_key = data.get('conversation_key')
            if not conversation_key:
                emit('ai_error', {'message': 'Conversation key is required'}, room=request.sid)
                return

            success = ai_modal.clear_conversation(conversation_key)
            if success:
                emit('ai_conversation_cleared', {'conversation_key': conversation_key}, room=request.sid)
            else:
                emit('ai_error', {'message': 'Failed to clear conversation'}, room=request.sid)

        except Exception as e:
            print(f"Error clearing conversation: {str(e)}")
            emit('ai_error', {'message': 'Failed to clear conversation'}, room=request.sid)

    @socketio.on('ai_get_conversations')
    def handle_ai_get_conversations():
        """Get conversations for the current user"""
        print(f"[SERVER] ai_get_conversations called")

        try:
            user_uuid = users.get(request.sid)
            print(f"[SERVER] User UUID: {user_uuid}")

            if not user_uuid:
                print("[SERVER] User not authenticated")
                emit('ai_error', {'message': 'User not authenticated'}, room=request.sid)
                return

            from ai_database import ai_database
            # First try to get all conversations to debug
            all_conversations = ai_database.get_user_conversations(user_uuid)
            print(f"[SERVER] Retrieved {len(all_conversations)} total conversations for user")
            if all_conversations:
                sample_info = []
                for c in all_conversations[:3]:
                    title = c.get('title', 'Untitled')
                    conv_type = c.get('conversation_type', 'unknown')
                    conv_id = c.get('id')
                    sample_info.append(f"{title} (type: {conv_type}, id: {conv_id})")
                print(f"[SERVER] Sample conversations: {sample_info}")

            # Include modal, dm, and channel conversations for better UX (channel AI conversations should be manageable too)
            conversations = [c for c in all_conversations if c.get('conversation_type') in ['modal', 'dm', 'channel']]
            print(f"[SERVER] Filtered to {len(conversations)} modal/dm/channel conversations")

            # Enhance conversations with character information and preview
            for conv in conversations:
                # Add character info if available
                character_name = conv.get('character_name')
                if character_name:
                    conv['character_display'] = character_name
                    # Try to get character details for avatar
                    try:
                        character = ai_database.get_character(user_uuid, character_name)
                        if not character:
                            # Try built-in characters
                            character = ai_database.get_character('system-builtin-characters', character_name)
                        if character and character.get('avatar_url'):
                            conv['character_avatar'] = character['avatar_url']
                    except Exception as e:
                        print(f"[SERVER] Error getting character info for {character_name}: {e}")
                else:
                    conv['character_display'] = 'Default AI'

                # Add conversation preview (first user message)
                try:
                    history = ai_database.get_conversation_messages(conv['id'], limit=2)
                    user_messages = [msg for msg in history if msg.get('role') == 'user']
                    if user_messages:
                        preview = user_messages[0]['content'][:50]
                        if len(user_messages[0]['content']) > 50:
                            preview += '...'
                        conv['preview'] = preview
                    else:
                        conv['preview'] = 'Start a new conversation...'
                except Exception as e:
                    print(f"[SERVER] Error getting preview for conversation {conv['id']}: {e}")
                    conv['preview'] = 'Start a new conversation...'

            print(f"[SERVER] Emitting ai_conversations_list with {len(conversations)} conversations")
            emit('ai_conversations_list', {'conversations': conversations}, room=request.sid)

        except Exception as e:
            print(f"[SERVER] Error getting conversations: {str(e)}")
            import traceback
            traceback.print_exc()
            emit('ai_error', {'message': 'Failed to get conversations'}, room=request.sid)

    @socketio.on('ai_create_conversation')
    def handle_ai_create_conversation(data):
        """Create a new conversation"""
        print(f"[SERVER] ai_create_conversation received data: {data}")

        try:
            user_uuid = users.get(request.sid)
            print(f"[SERVER] User UUID: {user_uuid}")

            if not user_uuid:
                print("[SERVER] User not authenticated")
                emit('ai_error', {'message': 'User not authenticated'}, room=request.sid)
                return

            conversation_type = data.get('conversation_type', 'modal')
            channel_id = data.get('channel_id')
            character_name = data.get('character_name')
            title = data.get('title')

            print(f"[SERVER] Creating conversation - type: {conversation_type}, channel: {channel_id}, character: {character_name}, title: {title}")

            from ai_database import ai_database
            conversation_id = ai_database.create_conversation(
                user_uuid=user_uuid,
                conversation_type=conversation_type,
                channel_id=channel_id,
                character_name=character_name,
                title=title
            )

            print(f"[SERVER] Created conversation with ID: {conversation_id}")

            if conversation_id:
                print("[SERVER] Emitting ai_conversation_created")
                emit('ai_conversation_created', {
                    'conversation_id': conversation_id,
                    'success': True
                }, room=request.sid)
            else:
                print("[SERVER] Failed to create conversation")
                emit('ai_conversation_create_error', {'message': 'Failed to create conversation'}, room=request.sid)

        except Exception as e:
            print(f"[SERVER] Error creating conversation: {str(e)}")
            import traceback
            traceback.print_exc()
            emit('ai_conversation_create_error', {'message': 'Failed to create conversation'}, room=request.sid)

    @socketio.on('ai_get_conversation_history')
    def handle_ai_get_conversation_history(data):
        """Get conversation history"""
        print(f"[SERVER] ai_get_conversation_history received data: {data}")

        try:
            user_uuid = users.get(request.sid)
            print(f"[SERVER] User UUID: {user_uuid}")

            if not user_uuid:
                print("[SERVER] User not authenticated")
                emit('ai_error', {'message': 'User not authenticated'}, room=request.sid)
                return

            conversation_id = data.get('conversation_id')
            print(f"[SERVER] Conversation ID: {conversation_id}")

            if not conversation_id:
                print("[SERVER] No conversation ID provided")
                emit('ai_error', {'message': 'Conversation ID required'}, room=request.sid)
                return

            from ai_database import ai_database

            # Verify the conversation belongs to the user
            print(f"[SERVER] Checking conversation ownership for ID: {conversation_id}")
            conversation = ai_database.get_conversation(conversation_id)
            print(f"[SERVER] Conversation found: {conversation}")

            if not conversation or conversation['user_uuid'] != user_uuid:
                print(f"[SERVER] Conversation not found or doesn't belong to user. Found: {conversation}, User: {user_uuid}")
                emit('ai_error', {'message': 'Conversation not found'}, room=request.sid)
                return

            print(f"[SERVER] Getting messages for conversation {conversation_id}")
            messages = ai_database.get_conversation_messages(conversation_id)
            print(f"[SERVER] Retrieved {len(messages)} messages")

            print(f"[SERVER] Emitting ai_conversation_history with {len(messages)} messages")
            emit('ai_conversation_history', {'history': messages}, room=request.sid)

        except Exception as e:
            print(f"[SERVER] Error getting conversation history: {str(e)}")
            import traceback
            traceback.print_exc()
            emit('ai_error', {'message': 'Failed to get conversation history'}, room=request.sid)

    @socketio.on('ai_delete_conversation')
    def handle_ai_delete_conversation(data):
        """Delete a conversation"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('ai_error', {'message': 'User not authenticated'}, room=request.sid)
                return

            conversation_id = data.get('conversation_id')
            if not conversation_id:
                emit('ai_error', {'message': 'Conversation ID required'}, room=request.sid)
                return

            from ai_database import ai_database

            # Verify the conversation belongs to the user
            conversation = ai_database.get_conversation(conversation_id)
            if not conversation or conversation['user_uuid'] != user_uuid:
                emit('ai_error', {'message': 'Conversation not found'}, room=request.sid)
                return

            success = ai_database.delete_conversation(conversation_id)

            if success:
                emit('ai_conversation_deleted', {
                    'conversation_id': conversation_id,
                    'success': True
                }, room=request.sid)
            else:
                emit('ai_error', {'message': 'Failed to delete conversation'}, room=request.sid)

        except Exception as e:
            print(f"Error deleting conversation: {str(e)}")
            emit('ai_error', {'message': 'Failed to delete conversation'}, room=request.sid)

    @socketio.on('ai_clear_all_conversations')
    def handle_ai_clear_all_conversations():
        """Clear all conversations for the current user"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('ai_error', {'message': 'User not authenticated'}, room=request.sid)
                return

            success = ai_modal.clear_all_conversations(user_uuid)

            if success:
                emit('ai_conversations_cleared', {
                    'success': True
                }, room=request.sid)
            else:
                emit('ai_error', {'message': 'Failed to clear all conversations'}, room=request.sid)

        except Exception as e:
            print(f"Error clearing all conversations: {str(e)}")
            emit('ai_error', {'message': 'Failed to clear all conversations'}, room=request.sid)

    @socketio.on('ai_update_conversation')
    def handle_ai_update_conversation(data):
        """Update conversation details"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('ai_error', {'message': 'User not authenticated'}, room=request.sid)
                return

            conversation_id = data.get('conversation_id')
            title = data.get('title')

            if not conversation_id:
                emit('ai_error', {'message': 'Conversation ID required'}, room=request.sid)
                return

            from ai_database import ai_database

            # Verify the conversation belongs to the user
            conversation = ai_database.get_conversation(conversation_id)
            if not conversation or conversation['user_uuid'] != user_uuid:
                emit('ai_error', {'message': 'Conversation not found'}, room=request.sid)
                return

            success = False
            if title is not None:
                success = ai_database.update_conversation_title(conversation_id, title)

            if success:
                emit('ai_conversation_updated', {
                    'conversation_id': conversation_id,
                    'updates': {'title': title}
                }, room=request.sid)
            else:
                emit('ai_error', {'message': 'Failed to update conversation'}, room=request.sid)

        except Exception as e:
            print(f"Error updating conversation: {str(e)}")
            emit('ai_error', {'message': 'Failed to update conversation'}, room=request.sid)

    @socketio.on('ai_get_user_settings')
    def handle_ai_get_user_settings(data=None):
        """Get user's AI settings"""
        print(f"[DEBUG] ai_get_user_settings called")
        try:
            user_uuid = users.get(request.sid)
            print(f"[DEBUG] user_uuid from session: {user_uuid}")
            if not user_uuid:
                # For local LAN development, allow anonymous access
                user_uuid = 'anonymous_user'
                print("WARNING: Using anonymous user for AI settings - authentication bypassed")
                users[request.sid] = user_uuid  # Store for future requests

            from database import get_user_ai_settings
            settings = get_user_ai_settings(user_uuid)
            print(f"[DEBUG] Retrieved AI settings for user {user_uuid}: {settings}")

            # Emit the settings
            emit('ai_settings_loaded', {'settings': settings}, room=request.sid)

        except Exception as e:
            print(f"Error getting AI user settings: {str(e)}")
            import traceback
            traceback.print_exc()
            emit('ai_error', {'message': 'Failed to load AI settings'}, room=request.sid)

    @socketio.on('ai_update_user_settings')
    def handle_ai_update_user_settings(data):
        """Update user's AI settings"""
        print(f"[DEBUG] ai_update_user_settings called with data: {data}")
        try:
            user_uuid = users.get(request.sid)
            print(f"[DEBUG] user_uuid from session: {user_uuid}")
            if not user_uuid:
                # For local LAN development, allow anonymous access
                user_uuid = 'anonymous_user'
                print("WARNING: Using anonymous user for AI settings - authentication bypassed")
                users[request.sid] = user_uuid  # Store for future requests

            settings = data.get('settings', {})
            print(f"[DEBUG] settings to save: {settings}")
            if not settings:
                print("[DEBUG] No settings provided")
                emit('ai_error', {'message': 'No settings provided'}, room=request.sid)
                return

            # Check if debug logging is enabled before update
            from database import get_user_ai_settings
            current_ai_settings = get_user_ai_settings(user_uuid)
            debug_enabled = settings.get('ai_debug_settings', current_ai_settings.get('ai_debug_settings', False))

            if debug_enabled:
                print(f"[AI_SETTINGS_DEBUG] Socket handler: User {user_uuid} updating AI settings via socket")
                print(f"[AI_SETTINGS_DEBUG] Received settings: {settings}")

            print(f"[DEBUG] Calling update_user_ai_settings")
            from database import update_user_ai_settings
            result = update_user_ai_settings(user_uuid, settings)
            print(f"[DEBUG] update_user_ai_settings returned: {result}")

            if debug_enabled:
                print(f"[AI_SETTINGS_DEBUG] Settings update completed successfully")

            # Emit success
            print(f"[DEBUG] Emitting ai_settings_updated")
            emit('ai_settings_updated', {'success': True}, room=request.sid)

        except Exception as e:
            print(f"Error updating AI user settings: {str(e)}")
            import traceback
            traceback.print_exc()
            emit('ai_error', {'message': 'Failed to update AI settings'}, room=request.sid)

    @socketio.on('ai_config_get')
    def handle_ai_config_get():
        """Get AI configuration for settings modal"""
        try:
            from ai_config import ai_config
            # Get AI config summary
            config_summary = ai_config.get_config_summary()

            # Add available models
            available_models = ai_config.get_available_models()
            config_summary['available_models'] = available_models

            # Test endpoint connection
            endpoint_valid = ai_config.validate_endpoint()
            config_summary['endpoint_valid'] = endpoint_valid

            emit('ai_config_data', config_summary, room=request.sid)

        except Exception as e:
            print(f"Error getting AI config: {str(e)}")
            emit('ai_error', {'message': 'Failed to get AI configuration'}, room=request.sid)

    @socketio.on('ai_config_update')
    def handle_ai_config_update(data):
        """Update AI configuration"""
        try:
            from ai_config import ai_config
            # Update config
            ai_config.update_config(**data)

            emit('ai_config_updated', {'success': True}, room=request.sid)

        except Exception as e:
            print(f"Error updating AI config: {str(e)}")
            emit('ai_error', {'message': 'Failed to update AI configuration'}, room=request.sid)

    @socketio.on('ai_get_models')
    def handle_ai_get_models():
        """Get available models from LM Studio"""
        try:
            from ai_config import ai_config
            # Get available models
            available_models = ai_config.get_available_models()
            emit('ai_models_list', {'models': available_models}, room=request.sid)
        except Exception as e:
            print(f"Error getting models: {str(e)}")
            emit('ai_error', {'message': 'Failed to get available models'}, room=request.sid)

    @socketio.on('ai_get_system_settings')
    def handle_ai_get_system_settings():
        """Get system settings"""
        try:
            from database import get_system_settings
            settings = get_system_settings()
            emit('ai_system_settings_data', settings, room=request.sid)
        except Exception as e:
            print(f"Error getting system settings: {str(e)}")
            emit('ai_error', {'message': 'Failed to get system settings'}, room=request.sid)

    @socketio.on('ai_save_system_settings')
    def handle_ai_save_system_settings(data):
        """Save system settings"""
        try:
            settings = data.get('settings', {})
            if not settings:
                emit('ai_error', {'message': 'No settings provided'}, room=request.sid)
                return

            from database import save_system_settings
            success = save_system_settings(settings)
            if success:
                emit('ai_system_settings_saved', {'success': True}, room=request.sid)
            else:
                emit('ai_error', {'message': 'Failed to save system settings'}, room=request.sid)
        except Exception as e:
            print(f"Error saving system settings: {str(e)}")
            emit('ai_error', {'message': 'Failed to save system settings'}, room=request.sid)