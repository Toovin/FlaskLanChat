"""
AI Modal Interface - Clean modal UI for AI chat
"""

from typing import Dict, List, Optional, Any
from ai_engine import ai_engine, StructuredResponse
from ai_characters import character_manager
from ai_context import context_manager


class AIModal:
    """
    Clean AI modal interface that orchestrates all AI functionality
    """

    def __init__(self):
        self.engine = ai_engine
        self.characters = character_manager
        self.context = context_manager

    def send_message(self, user_uuid: str, message: str, character_name: Optional[str] = None,
                     conversation_key: Optional[str] = None, conversation_id: Optional[int] = None,
                     image_data: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Send a message through the AI modal

        Returns structured response data for the frontend
        """
        print(f"[AI_MODAL] send_message called with: user_uuid={user_uuid}, message='{message[:50]}...', character_name={character_name}, conversation_key={conversation_key}, conversation_id={conversation_id}, has_image={bool(image_data)}")

        try:
            # Get username for message formatting
            from database import database_users
            user_name = database_users.get_display_name_by_uuid(user_uuid)

            # Format message with username
            formatted_message = f"User {user_name} said: {message}" if user_name else message

            # Get character settings
            character = None
            system_prompt = None

            model = None
            if character_name:
                print(f"[AI_MODAL] Getting character: {character_name}")
                character = self.characters.get_character(user_uuid, character_name)
                print(f"[AI_MODAL] Character found: {bool(character)}")
                if character:
                    system_prompt = character.get('ai_system_prompt')
                    model = character.get('ai_model')
                    # Use config default if character model is 'default'
                    if model == 'default':
                        model = None

            # Get user AI settings for modal memory and global model fallback
            from database import get_user_ai_settings
            user_ai_settings = get_user_ai_settings(user_uuid)

            # Use global model from settings as fallback if no character model specified
            if model is None:
                global_model = user_ai_settings.get('ai_model')
                if global_model and global_model.strip():
                    model = global_model
                    print(f"[AI_MODAL] Using global model from settings: {model}")

            # Generate conversation key if not provided
            if not conversation_key:
                print("[AI_MODAL] Generating conversation key")
                conversation_key = self.context.get_conversation_key(
                    user_uuid, "modal", character_name=character_name
                )
                print(f"[AI_MODAL] Generated conversation key: {conversation_key}")

            # Get context for inference (respect modal memory settings)
            modal_memory_enabled = user_ai_settings.get('ai_modal_memory_enabled', True)
            modal_memory_limit = user_ai_settings.get('ai_modal_memory_limit', 15) if modal_memory_enabled else 0

            print(f"[AI_MODAL] Getting context for conversation key: {conversation_key} (limit: {modal_memory_limit})")
            context_messages = self.context.get_recent_context(conversation_key, max_messages=modal_memory_limit)
            print(f"[AI_MODAL] Retrieved {len(context_messages)} context messages")

            # Generate AI response

            print("[AI_MODAL] Generating AI response")
            response = self.engine.generate_response(
                prompt=formatted_message,
                system_prompt=system_prompt,
                character_name=character_name,
                context_messages=context_messages,
                model=model,
                image_data=image_data
            )

            print(f"[AI_MODAL] AI response generated: {bool(response)}")
            if response:
                print(f"[AI_MODAL] Response content length: {len(response.content)}")

                # Save to context (inference-only)
                print("[AI_MODAL] Saving to context")
                self.context.add_user_message(conversation_key, formatted_message)
                self.context.add_assistant_message(conversation_key, response.content)

                # Save to conversation database if conversation_id provided
                if conversation_id:
                    print(f"[AI_MODAL] Saving to conversation database, ID: {conversation_id}")
                    from ai_database import ai_database
                    ai_database.save_conversation_message(conversation_id, 'user', formatted_message)
                    ai_database.save_conversation_message(conversation_id, 'assistant', response.content, character_name)
                    # Update conversation timestamp
                    ai_database.update_conversation_timestamp(conversation_id)
                    print("[AI_MODAL] Messages saved to database")

                # Return structured data for frontend
                result = {
                    'success': True,
                    'response': response.content,
                    'character_name': character_name,
                    'conversation_key': conversation_key,
                    'structured_data': response.structured_data,
                    'is_structured': response.is_structured
                }

                # Add character avatar if available
                if character and character.get('avatar_url'):
                    result['avatar_url'] = character['avatar_url']
                    print(f"[AI_MODAL] Added avatar URL: {character['avatar_url']}")

                print(f"[AI_MODAL] Returning success result")
                return result

        except Exception as e:
            print(f"[AI_MODAL] Error in AI modal send_message: {str(e)}")
            import traceback
            traceback.print_exc()
            return {'success': False, 'error': str(e)}

    def get_characters(self, user_uuid: str) -> List[Dict[str, Any]]:
        """Get user's AI characters for the modal"""
        return self.characters.get_user_characters(user_uuid)

    def create_character(self, user_uuid: str, character_data: Dict[str, Any]) -> bool:
        """Create a new character"""
        return self.characters.create_character(user_uuid, character_data) is not None

    def update_character(self, user_uuid: str, character_name: str, updates: Dict[str, Any]) -> bool:
        """Update a character"""
        return self.characters.update_character(user_uuid, character_name, updates)

    def delete_character(self, user_uuid: str, character_name: str) -> bool:
        """Delete a character"""
        return self.characters.delete_character(user_uuid, character_name)

    def set_active_character(self, user_uuid: str, character_name: str) -> bool:
        """Set active character"""
        return self.characters.set_active_character(user_uuid, character_name)

    def get_active_character(self, user_uuid: str) -> Optional[Dict[str, Any]]:
        """Get active character"""
        return self.characters.get_active_character(user_uuid)

    def analyze_document(self, document_content: str, document_type: str) -> Optional[Dict[str, Any]]:
        """Analyze a document"""
        try:
            response = self.engine.analyze_document(document_content, document_type)
            if response:
                return {
                    'success': True,
                    'analysis': response.content,
                    'structured_data': response.structured_data
                }
            return {'success': False, 'error': 'Document analysis failed'}
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def analyze_conversation(self, conversation_key: str, max_messages: int = 20) -> Optional[Dict[str, Any]]:
        """Analyze a conversation"""
        try:
            # Get conversation messages
            context_messages = self.context.build_openai_messages(conversation_key, max_messages)
            if not context_messages:
                return {'success': False, 'error': 'No conversation messages found'}

            response = self.engine.analyze_conversation(context_messages)
            if response:
                return {
                    'success': True,
                    'analysis': response.content,
                    'structured_data': response.structured_data
                }
            return {'success': False, 'error': 'Conversation analysis failed'}
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def plan_tasks(self, task_description: str, context: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Generate a task plan"""
        try:
            response = self.engine.plan_tasks(task_description, context)
            if response:
                return {
                    'success': True,
                    'plan': response.content,
                    'structured_data': response.structured_data
                }
            return {'success': False, 'error': 'Task planning failed'}
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def analyze_image(self, image_data: str) -> Optional[Dict[str, Any]]:
        """Analyze an image"""
        try:
            response = self.engine.analyze_image(image_data)
            if response:
                return {
                    'success': True,
                    'description': response.content,
                    'structured_data': response.structured_data
                }
            return {'success': False, 'error': 'Image analysis failed'}
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def clear_conversation(self, conversation_key: str) -> bool:
        """Clear conversation context"""
        return self.context.clear_context(conversation_key)

    def clear_all_conversations(self, user_uuid: str) -> bool:
        """Clear all conversations for a user"""
        return self.context.clear_all_contexts(user_uuid)


# Global modal instance
ai_modal = AIModal()