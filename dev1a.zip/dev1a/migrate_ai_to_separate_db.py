#!/usr/bin/env python3
"""
ARCHIVED: Migration completed successfully on 2025-10-22
Migration script to move AI data from devchat.db to ai_chat.db
This consolidates all AI data into the separate database for clean separation.

Status: ✅ COMPLETED - AI data successfully migrated to ai_chat.db
Keep for reference only - do not run again.
"""

import sqlite3
import os
from lc_config import CHAT_DB_NAME, AI_DB_NAME

def migrate_ai_data():
    """Migrate AI tables from main database to AI database"""

    print("Starting AI data migration...")
    print(f"Source: {CHAT_DB_NAME}")
    print(f"Target: {AI_DB_NAME}")

    # Check if source database exists
    if not os.path.exists(CHAT_DB_NAME):
        print(f"❌ Source database {CHAT_DB_NAME} not found!")
        return False

    # Connect to both databases
    try:
        main_conn = sqlite3.connect(CHAT_DB_NAME)
        ai_conn = sqlite3.connect(AI_DB_NAME)

        main_cursor = main_conn.cursor()
        ai_cursor = ai_conn.cursor()

        print("Connected to databases successfully")

        # Check if AI tables exist in main database
        main_cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'ai_%'")
        main_ai_tables = [row[0] for row in main_cursor.fetchall()]

        print(f"Found AI tables in main DB: {main_ai_tables}")

        if not main_ai_tables:
            print("⚠️  No AI tables found in main database - nothing to migrate")
            return True

        # Migrate ai_characters table
        if 'ai_characters' in main_ai_tables:
            print("Migrating ai_characters table...")

            # Get all characters from main DB
            main_cursor.execute("SELECT * FROM ai_characters")
            characters = main_cursor.fetchall()

            # Get column names
            main_cursor.execute("PRAGMA table_info(ai_characters)")
            columns = [col[1] for col in main_cursor.fetchall()]

            print(f"Found {len(characters)} characters to migrate")

            # Insert into AI database (skip duplicates)
            for character in characters:
                try:
                    # Create parameterized query
                    placeholders = ','.join(['?' for _ in columns])
                    column_names = ','.join(columns)

                    query = f"INSERT OR IGNORE INTO ai_characters ({column_names}) VALUES ({placeholders})"
                    ai_cursor.execute(query, character)
                except Exception as e:
                    print(f"Error migrating character {character[1] if len(character) > 1 else 'unknown'}: {e}")

            ai_conn.commit()
            print(f"✅ Migrated {len(characters)} characters")

        # Migrate ai_context table
        if 'ai_context' in main_ai_tables:
            print("Migrating ai_context table...")

            # Get all context messages from main DB
            main_cursor.execute("SELECT * FROM ai_context")
            context_messages = main_cursor.fetchall()

            # Get column names
            main_cursor.execute("PRAGMA table_info(ai_context)")
            columns = [col[1] for col in main_cursor.fetchall()]

            print(f"Found {len(context_messages)} context messages to migrate")

            # Insert into AI database (skip duplicates)
            for message in context_messages:
                try:
                    placeholders = ','.join(['?' for _ in columns])
                    column_names = ','.join(columns)

                    query = f"INSERT OR IGNORE INTO ai_context ({column_names}) VALUES ({placeholders})"
                    ai_cursor.execute(query, message)
                except Exception as e:
                    print(f"Error migrating context message: {e}")

            ai_conn.commit()
            print(f"✅ Migrated {len(context_messages)} context messages")

        # Verify migration
        print("\nVerifying migration...")

        # Check characters in AI DB
        ai_cursor.execute("SELECT COUNT(*) FROM ai_characters")
        ai_char_count = ai_cursor.fetchone()[0]
        print(f"Characters in AI DB: {ai_char_count}")

        # Check context in AI DB
        ai_cursor.execute("SELECT COUNT(*) FROM ai_context")
        ai_context_count = ai_cursor.fetchone()[0]
        print(f"Context messages in AI DB: {ai_context_count}")

        # Close connections
        main_conn.close()
        ai_conn.close()

        print("✅ Migration completed successfully!")
        print("\n⚠️  IMPORTANT: Test the application thoroughly before removing old tables")
        print("   The old tables in devchat.db can be removed after verification")

        return True

    except Exception as e:
        print(f"❌ Migration failed: {str(e)}")
        return False

if __name__ == "__main__":
    success = migrate_ai_data()
    exit(0 if success else 1)