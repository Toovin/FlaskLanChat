#!/usr/bin/env python3
"""
Avatar Migration Script

Migrates existing user and AI character avatars to the unified storage location
and updates database URLs accordingly.
"""

import os
import shutil
import sqlite3
import time
from pathlib import Path

# Configuration
DB_PATH = 'devchat.db'
OLD_USER_AVATAR_DIR = 'static/user_avatars'
OLD_AI_AVATAR_DIR = 'static/uploads/character_avatars'
NEW_AVATAR_DIR = 'static/uploads/avatars'

def migrate_files():
    """Move avatar files to new location with new naming convention"""
    print("Starting avatar file migration...")

    # Ensure new directory exists
    os.makedirs(NEW_AVATAR_DIR, exist_ok=True)

    migrated_files = {}

    # Migrate user avatars
    if os.path.exists(OLD_USER_AVATAR_DIR):
        print(f"Migrating user avatars from {OLD_USER_AVATAR_DIR}")
        for filename in os.listdir(OLD_USER_AVATAR_DIR):
            if filename.startswith('.'):
                continue

            old_path = os.path.join(OLD_USER_AVATAR_DIR, filename)
            # Extract UUID from filename (assuming UUID.ext format)
            parts = filename.rsplit('.', 1)
            if len(parts) == 2:
                uuid_part = parts[0]
                ext = parts[1]
                timestamp = str(int(time.time()))
                new_filename = f"avatar_user_{uuid_part}_{timestamp}.{ext}"
                new_path = os.path.join(NEW_AVATAR_DIR, new_filename)

                try:
                    shutil.copy2(old_path, new_path)
                    migrated_files[filename] = new_filename
                    print(f"Migrated {filename} -> {new_filename}")
                except Exception as e:
                    print(f"Failed to migrate {filename}: {e}")

    # Migrate AI avatars
    if os.path.exists(OLD_AI_AVATAR_DIR):
        print(f"Migrating AI avatars from {OLD_AI_AVATAR_DIR}")
        for filename in os.listdir(OLD_AI_AVATAR_DIR):
            if filename.startswith('.'):
                continue

            old_path = os.path.join(OLD_AI_AVATAR_DIR, filename)
            # Parse character_avatar_{user_uuid}_{character_name}.{ext}
            if filename.startswith('character_avatar_'):
                parts = filename.split('_', 3)
                if len(parts) >= 4:
                    user_uuid = parts[2]
                    character_name = parts[3].rsplit('.', 1)[0]
                    ext = parts[3].rsplit('.', 1)[1] if '.' in parts[3] else 'png'
                    timestamp = str(int(time.time()))
                    new_filename = f"avatar_ai_{user_uuid}_{character_name}_{timestamp}.{ext}"
                    new_path = os.path.join(NEW_AVATAR_DIR, new_filename)

                    try:
                        shutil.copy2(old_path, new_path)
                        migrated_files[filename] = new_filename
                        print(f"Migrated {filename} -> {new_filename}")
                    except Exception as e:
                        print(f"Failed to migrate {filename}: {e}")

    return migrated_files

def update_database_urls(migrated_files):
    """Update avatar URLs in database"""
    print("Updating database URLs...")

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Update user avatars
    cursor.execute("SELECT uuid, avatar_url FROM users WHERE avatar_url IS NOT NULL")
    user_rows = cursor.fetchall()

    for uuid, old_url in user_rows:
        if old_url and '/static/user_avatars/' in old_url:
            filename = old_url.split('/')[-1]
            if filename in migrated_files:
                new_filename = migrated_files[filename]
                new_url = f'/static/uploads/avatars/{new_filename}'
                cursor.execute("UPDATE users SET avatar_url = ? WHERE uuid = ?", (new_url, uuid))
                print(f"Updated user {uuid} avatar: {old_url} -> {new_url}")

    # Update AI character avatars
    cursor.execute("SELECT id, avatar_url FROM ai_characters WHERE avatar_url IS NOT NULL")
    ai_rows = cursor.fetchall()

    for char_id, old_url in ai_rows:
        if old_url and '/static/uploads/character_avatars/' in old_url:
            filename = old_url.split('/')[-1]
            if filename in migrated_files:
                new_filename = migrated_files[filename]
                new_url = f'/static/uploads/avatars/{new_filename}'
                cursor.execute("UPDATE ai_characters SET avatar_url = ? WHERE id = ?", (new_url, char_id))
                print(f"Updated AI character {char_id} avatar: {old_url} -> {new_url}")

    conn.commit()
    conn.close()

def main():
    print("Avatar Migration Script")
    print("=" * 50)

    # Check if files exist
    user_count = len([f for f in os.listdir(OLD_USER_AVATAR_DIR) if not f.startswith('.')]) if os.path.exists(OLD_USER_AVATAR_DIR) else 0
    ai_count = len([f for f in os.listdir(OLD_AI_AVATAR_DIR) if not f.startswith('.')]) if os.path.exists(OLD_AI_AVATAR_DIR) else 0

    print(f"Found {user_count} user avatars and {ai_count} AI avatars to migrate")

    if user_count == 0 and ai_count == 0:
        print("No avatars to migrate. Exiting.")
        return

    # Auto-confirm for automated migration
    print("Auto-confirming migration...")

    # Migrate files
    migrated_files = migrate_files()

    # Update database
    update_database_urls(migrated_files)

    print("Migration completed successfully!")
    print(f"Migrated {len(migrated_files)} avatar files")

if __name__ == '__main__':
    main()