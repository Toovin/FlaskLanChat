# ai_handlers.py - Socket.IO event handlers for AI chat integration
from flask_socketio import emit
from flask import request
from ai_database import ai_database
from database import get_user_ai_settings, update_user_ai_settings  # User settings stay in main DB
from database.database_ai import get_channel_context_for_ai
from ai_engine import ai_engine
from ai_config import ai_config
import uuid
import json
import base64
import os
from werkzeug.utils import secure_filename





def get_ai_username():
    """Get the AI assistant username"""
    return "AI Assistant"


def get_ai_user_uuid():
    """Get the AI assistant user UUID"""
    return "ai_assistant_uuid"


def handle_ai_channel_mention_standalone(socketio, users_db, users, data):
    """Standalone version of AI channel mention handler with mode support"""
    try:
        # For standalone calls, we need to simulate the request context
        # This is a simplified version that assumes the data contains user_uuid
        user_uuid = data.get('user_uuid')
        if not user_uuid:
            print("Error: user_uuid not provided in standalone call")
            return

        channel = data.get('channel', '').strip()
        message = data.get('message', '').strip()
        trigger_user = data.get('trigger_user', '')
        character_name = data.get('character_name')
        # New: Support for interaction modes
        interaction_mode = data.get('interaction_mode', 'diverse')  # 'one-off', 'focused', 'diverse'

        if not channel or not message:
            return

        # Check if this is a character impersonation
        character_settings = None
        sender_name = get_ai_username()
        if character_name:
            character = ai_database.get_character(user_uuid, character_name)
            if character:
                character_settings = character
                sender_name = character_name
                print(f"DEBUG: Using character {character_name} for response")
            else:
                print(f"DEBUG: Character {character_name} not found, falling back to default AI")

        # Create or get conversation for this channel and character (separate context per character per channel)
        conversation_title = f'Channel AI Context - {sender_name}' if character_name else 'Channel AI Context'
        conversation_id = ai_database.create_conversation(
            user_uuid, 'channel', channel_id=f"{channel}_{character_name or 'default'}", title=conversation_title
        )

        # Get conversation history for this specific character/channel context
        raw_context = ai_database.get_conversation_messages(conversation_id, limit=16384)

        # Simplified context processing - since conversations are now character-specific,
        # all assistant messages in this conversation are from the current character
        context = []
        for msg in raw_context:
            processed_msg = dict(msg)  # Copy the message

            if msg['role'] == 'assistant':
                # Remove character prefix if present (legacy compatibility)
                content = msg['content']
                if content.startswith('['):
                    bracket_end = content.find(']')
                    if bracket_end > 0:
                        processed_msg['content'] = content[bracket_end + 1:].strip()
                # Keep as assistant since this conversation is character-specific
                processed_msg['role'] = 'assistant'

            context.append(processed_msg)

        # Get user display name for context (needed early for channel context processing)
        from database import database_users
        user_name = database_users.get_display_name_by_uuid(user_uuid)

        # Initialize context variables
        context_text = ""
        context_messages = []  # For ai_engine.py compatibility

        # Get user AI settings
        user_ai_settings = get_user_ai_settings(user_uuid)

        # Handle different interaction modes
        if interaction_mode == 'one-off':
            # Mode 1: One-off interactions - no context at all
            print(f"DEBUG: Using one-off mode - no context")
            context = []
            context_messages = []

        elif interaction_mode == 'focused':
            # Mode 2: Focused agent conversation - only self + agent history
            print(f"DEBUG: Using focused mode - conversation history only")
            # Use only the character-specific conversation history
            context_messages = context  # context already contains conversation history

        else:  # 'diverse' (default)
            # Mode 3: Diverse channel conversation - all messages
            print(f"DEBUG: Using diverse mode - channel + conversation history")

            # Get channel AI settings for fallback
            from database import database_channels
            channel_ai_settings = database_channels.get_channel_ai_settings(channel)

            # Determine channel context limit: use user setting if enabled, otherwise channel setting
            channel_context_limit = 0
            if user_ai_settings and user_ai_settings.get('ai_channel_memory_enabled', False):
                channel_context_limit = user_ai_settings.get('ai_channel_memory_limit', 10)
            elif channel_ai_settings['ai_enabled']:
                channel_context_limit = channel_ai_settings['ai_memory_limit']

            # Include recent channel context for awareness of current conversation
            if channel_context_limit > 0:
                # Include AI messages in context for conversational continuity
                include_ai = True  # Always include AI messages for proper conversation flow
                raw_channel_context = get_channel_context_for_ai(channel, message_limit=channel_context_limit, include_ai_messages=include_ai)
                # Convert to OpenAI format
                channel_context = []
                for msg in raw_channel_context:
                    content = msg['message']

                    if msg.get('is_ai'):
                        # For AI messages in channel context, treat them as assistant messages
                        role = "assistant"

                        # Remove character prefix if present for cleaner context
                        if content.startswith('['):
                            bracket_end = content.find(']')
                            if bracket_end > 0:
                                content = content[bracket_end + 1:].strip()
                    else:
                        role = "user"
                        if user_name:
                            content = f"{user_name}: {content}"

                    channel_context.append({"role": role, "content": content})

                # Combine channel context with conversation history
                context_messages = channel_context + context

                # Format context as JSON for embedding in user message (legacy compatibility)
                context_json = {
                    "recent_messages": [
                        {
                            "timestamp": msg.get('timestamp', ''),
                            "sender": msg.get('sender', 'Unknown'),
                            "message": msg.get('content', ''),
                            "type": "ai" if msg.get('role') == 'assistant' else "user"
                        }
                        for msg in context_messages[-15:]  # Last 15 messages to avoid token limits
                    ]
                }
                import json
                context_text = f"\n\n[CONVERSATION CONTEXT]\n{json.dumps(context_json, indent=2)}"
            else:
                # No channel context, just use conversation history
                context_messages = context


        # For channel AI, use the determined channel context limit
        effective_settings = user_ai_settings.copy() if user_ai_settings else {}
        effective_settings['ai_history_limit'] = channel_context_limit
        # Apply user prepend if set
        user_prepend = user_ai_settings.get('ai_user_prepend', '')
        if user_prepend:
            message = f"{user_prepend}\n\n{message}"

        # Add user name for structured message format
        if user_name:
            effective_settings['user_name'] = user_name

            # Strip @ai trigger from message and format with display name
            if message.startswith('@ai'):
                message = message[3:].strip()
                formatted_message = f"User {user_name} said: {message}" if user_name else message

            # Append context to the user message
            formatted_message += context_text

            # Generate AI response using ai_engine (unified system)
        # Get character system prompt if character is specified
        system_prompt = None
        if character_name:
            character = ai_database.get_character(user_uuid, character_name)
            if not character:
                # Try built-in characters
                character = ai_database.get_character('system-builtin-characters', character_name)
            if character:
                system_prompt = character.get('ai_system_prompt')

        # Extract parameters for ai_engine
        model = effective_settings.get('ai_model')
        temperature = effective_settings.get('ai_temperature')
        max_tokens = effective_settings.get('ai_max_tokens')

        # Generate AI response
        response_obj = ai_engine.generate_response(
            prompt=formatted_message,
            system_prompt=system_prompt,
            character_name=character_name,
            context_messages=context_messages if interaction_mode != 'one-off' else None,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens
        )

        # Extract content from StructuredResponse
        ai_response = response_obj.content if response_obj else None

        if ai_response:
            # Store conversation messages (optional - response ID handles context)
            try:
                model = effective_settings.get('ai_model', 'default') if effective_settings else 'default'
                ai_database.save_conversation_message(conversation_id, "user", formatted_message)

                # Store AI response in conversation history (no character prefix needed since conversations are character-specific)
                ai_database.save_conversation_message(conversation_id, "assistant", ai_response)
            except Exception as e:
                print(f"Error storing channel AI conversation: {str(e)}")

            # Send AI response as a regular channel message
            from .utility_functions import save_and_emit_message

            # Get AI assistant user info (use same UUID for all AI responses)
            ai_user_uuid = get_ai_user_uuid()

            # Create response dict for save_and_emit_message
            response = {
                'message': ai_response,
                'sender': sender_name,
                'is_media': False,
                'ai_generated': True,
                'ai_conversation_id': conversation_id
            }

            # Include character avatar - use custom avatar or default
            if character_settings and character_settings.get('avatar_url'):
                response['avatar_url'] = character_settings['avatar_url']
            else:
                # Use default avatar for characters without custom avatar
                response['avatar_url'] = '/static/default_avatars/smile_1.png'

            # Save and emit the AI response
            save_and_emit_message(response, channel, ai_user_uuid, None, socketio)

    except Exception as e:
        print(f"Error in ai_channel_mention_standalone: {str(e)}")


def register_ai_handlers(socketio, users_db, users):
    """Register AI-related Socket.IO event handlers - LEGACY: Only channel AI, modal handled by new system"""

    # All modal-related handlers disabled - handled by new ai_socket_handlers
    # Only keeping channel AI functionality

    @socketio.on('ai_channel_mention')  # Keep for channel AI functionality
    def handle_ai_channel_mention(data):
        """Handle AI mentions in channel messages with mode support"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                return

            channel = data.get('channel', '').strip()
            message = data.get('message', '').strip()
            trigger_user = data.get('trigger_user', '')
            character_name = data.get('character_name')
            interaction_mode = data.get('interaction_mode', 'diverse')  # Support for different interaction modes

            if not channel or not message:
                return

            # Call the standalone function with the data
            handle_ai_channel_mention_standalone(socketio, users_db, users, {
                'user_uuid': user_uuid,
                'channel': channel,
                'message': message,
                'trigger_user': trigger_user,
                'character_name': character_name,
                'interaction_mode': interaction_mode
            })

        except Exception as e:
            print(f"Error in ai_channel_mention: {str(e)}")

    # @socketio.on('ai_get_characters')  # DISABLED - handled by new ai_socket_handlers
    # def handle_ai_get_characters():
        # """Get user's AI characters"""
        # try:
        #     user_uuid = users.get(request.sid)
        #     if not user_uuid:
        #         emit('error', {'msg': 'User not authenticated'}, room=request.sid)
        #     return

        #     characters = database_ai.get_user_ai_characters(user_uuid)
        #     emit('ai_characters_list', {'characters': characters}, room=request.sid)

        # except Exception as e:
        #     print(f"Error getting AI characters: {str(e)}")
        #     emit('error', {'msg': 'Failed to load characters'}, room=request.sid)

    # @socketio.on('ai_load_character')  # DISABLED - handled by new ai_socket_handlers
    # def handle_ai_load_character(data):
        """Load an AI character"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('error', {'msg': 'User not authenticated'}, room=request.sid)
                return

            character_name = data.get('character_name', '').strip()
            if not character_name:
                emit('error', {'msg': 'Character name is required'}, room=request.sid)
                return

            character = ai_database.get_character(user_uuid, character_name)
            if character:
                emit('ai_character_loaded', {'character': character}, room=request.sid)
            else:
                emit('error', {'msg': 'Character not found'}, room=request.sid)

        except Exception as e:
            print(f"Error loading AI character: {str(e)}")
            emit('error', {'msg': 'Failed to load character'}, room=request.sid)



    @socketio.on('ai_dm_message')  # Keep for DM AI functionality
    def handle_ai_dm_message(data):
        """Handle direct messages to AI"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('error', {'msg': 'User not authenticated'}, room=request.sid)
                return

            message = data.get('message', '').strip()
            ai_user_uuid = get_ai_user_uuid()

            if not message:
                return

            # Add user message to DM database
            from database import add_dm_message
            user_msg_id = add_dm_message(user_uuid, ai_user_uuid, message)

            # Build DM context
            context = []  # For now, no context for DM - can be added later

            # Create or get conversation for DM (persistent per user)
            conversation_id = ai_database.create_conversation(
                user_uuid, 'dm', channel_id=f"dm_{user_uuid}_ai", title=f'DM with AI'
            )

            # Get user AI settings
            user_ai_settings = get_user_ai_settings(user_uuid)

            # Get user display name for context
            from database import database_users
            user_name = database_users.get_display_name_by_uuid(user_uuid)

            # Use user's global context limit for DM conversations
            effective_settings = user_ai_settings.copy() if user_ai_settings else {}
            # Add user name for structured message format
            if user_name:
                effective_settings['user_name'] = user_name

            # Strip @ai trigger from message and format with display name
            if message.startswith('@ai'):
                message = message[3:].strip()
            formatted_message = f"User {user_name} said: {message}" if user_name else message

            # Generate AI response using simple system (response ID handles context)
            # Only pass parameters that the generate_response method accepts
            accepted_params = ['system_prompt', 'model', 'temperature', 'max_tokens', 'conversation_id']
            filtered_settings = {k: v for k, v in effective_settings.items() if k in accepted_params}
            ai_response = generate_ai_response(
                prompt=formatted_message,
                character_name=None,  # No character for DM
                user_uuid=user_uuid,
                conversation_id=conversation_id,
                **filtered_settings
            )

            if ai_response:
                # Add AI response to DM database
                ai_msg_id = add_dm_message(ai_user_uuid, user_uuid, ai_response)



                # Emit DM update to user
                emit('dm_message_update', {
                    'other_uuid': ai_user_uuid,
                    'messages': [{
                        'id': ai_msg_id,
                        'sender_uuid': ai_user_uuid,
                        'recipient_uuid': user_uuid,
                        'message': ai_response,
                        'is_media': 0,
                        'timestamp': 'now',  # Will be formatted by client
                        'read_status': 0,
                        'is_mine': False
                    }]
                }, room=request.sid)

        except Exception as e:
            print(f"Error in ai_dm_message: {str(e)}")
            emit('error', {'msg': 'Failed to send AI DM'}, room=request.sid)

    # @socketio.on('ai_get_conversations')  # DISABLED - handled by new ai_socket_handlers
    # def handle_ai_get_conversations():
        """Get user's AI conversations for modal (only modal and dm types, not channel)"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('error', {'msg': 'User not authenticated'}, room=request.sid)
                return

            # Get all conversations but filter to only show modal/dm types in the AI modal
            # Channel AI conversations are handled separately and not shown in modal
            all_conversations = ai_database.get_user_conversations(user_uuid)
            modal_conversations = [conv for conv in all_conversations
                                   if conv['conversation_type'] in ['modal', 'dm']]

            # Add conversation previews (first user message)
            for conv in modal_conversations:
                try:
                    history = ai_database.get_conversation_messages(conv['id'], limit=2)
                    # Find the first user message
                    user_messages = [msg for msg in history if msg.get('role') == 'user']
                    if user_messages:
                        # Take first 50 characters of the first user message
                        preview = user_messages[0]['content'][:50]
                        if len(user_messages[0]['content']) > 50:
                            preview += '...'
                        conv['preview'] = preview
                    else:
                        conv['preview'] = 'Start a new conversation...'
                except Exception as e:
                    print(f"Error getting preview for conversation {conv['id']}: {e}")
                    conv['preview'] = 'Start a new conversation...'

            emit('ai_conversations_list', {
                'conversations': modal_conversations
            }, room=request.sid)

        except Exception as e:
            print(f"Error getting AI conversations: {str(e)}")
            emit('error', {'msg': 'Failed to load conversations'}, room=request.sid)

    # @socketio.on('ai_create_conversation')  # DISABLED - handled by new ai_socket_handlers
    # def handle_ai_create_conversation(data):
        """Create a new AI conversation"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('error', {'msg': 'User not authenticated'}, room=request.sid)
                return

            title = data.get('title', '').strip() or None
            character_name = data.get('character_name')

            # Create new conversation
            conversation_id = ai_database.create_conversation(user_uuid, 'modal', character_name=character_name, title=title)

            if conversation_id:
                emit('ai_conversation_created', {
                    'conversation_id': conversation_id,
                    'title': title,
                    'character_name': character_name
                }, room=request.sid)
            else:
                emit('error', {'msg': 'Failed to create conversation'}, room=request.sid)

        except Exception as e:
            print(f"Error creating AI conversation: {str(e)}")
            emit('error', {'msg': 'Failed to create conversation'}, room=request.sid)

    # @socketio.on('ai_get_conversation_history')  # DISABLED - handled by new ai_socket_handlers
    # def handle_ai_get_conversation_history(data):
        """Get history for a specific AI conversation"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('error', {'msg': 'User not authenticated'}, room=request.sid)
                return

            conversation_id = data.get('conversation_id')
            if not conversation_id:
                emit('error', {'msg': 'Conversation ID is required'}, room=request.sid)
                return

            # Verify user owns this conversation
            conversation = ai_database.get_conversation(conversation_id)
            if not conversation or conversation['user_uuid'] != user_uuid:
                emit('error', {'msg': 'Conversation not found'}, room=request.sid)
                return

            # Get conversation history
            history = ai_database.get_conversation_messages(conversation_id)

            emit('ai_conversation_history', {
                'conversation_id': conversation_id,
                'history': history
            }, room=request.sid)

        except Exception as e:
            print(f"Error getting AI conversation history: {str(e)}")
            emit('error', {'msg': 'Failed to load conversation history'}, room=request.sid)

    # @socketio.on('ai_delete_conversation')  # DISABLED - handled by new ai_socket_handlers
    # def handle_ai_delete_conversation(data):
        """Delete an AI conversation"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('error', {'msg': 'User not authenticated'}, room=request.sid)
                return

            conversation_id = data.get('conversation_id')
            if not conversation_id:
                emit('error', {'msg': 'Conversation ID is required'}, room=request.sid)
                return

            # Verify user owns this conversation
            conversation = ai_database.get_conversation(conversation_id)
            if not conversation or conversation['user_uuid'] != user_uuid:
                emit('error', {'msg': 'Conversation not found'}, room=request.sid)
                return

            # Delete the conversation
            success = ai_database.delete_conversation(conversation_id)
            if success:
                emit('ai_conversation_deleted', {
                    'conversation_id': conversation_id,
                    'success': True
                }, room=request.sid)
            else:
                emit('error', {'msg': 'Failed to delete conversation'}, room=request.sid)

        except Exception as e:
            print(f"Error deleting AI conversation: {str(e)}")
            emit('error', {'msg': 'Failed to delete conversation'}, room=request.sid)

    # @socketio.on('ai_update_conversation')  # DISABLED - handled by new ai_socket_handlers
    # def handle_ai_update_conversation(data):
        """Update an AI conversation (title, etc.)"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('error', {'msg': 'User not authenticated'}, room=request.sid)
                return

            conversation_id = data.get('conversation_id')
            if not conversation_id:
                emit('error', {'msg': 'Conversation ID is required'}, room=request.sid)
                return

            # Verify user owns this conversation
            conversation = ai_database.get_conversation(conversation_id)
            if not conversation or conversation['user_uuid'] != user_uuid:
                emit('error', {'msg': 'Conversation not found'}, room=request.sid)
                return

            updates = {}
            if 'title' in data:
                title = data['title'].strip() or None
                success = ai_database.update_conversation_title(conversation_id, title)
            else:
                emit('error', {'msg': 'No valid updates provided'}, room=request.sid)
                return

            # Update the conversation
            # success = ai_database.update_conversation_title(conversation_id, updates.get('title'))
            if success:
                emit('ai_conversation_updated', {
                    'conversation_id': conversation_id,
                    'updates': updates
                }, room=request.sid)
            else:
                emit('error', {'msg': 'Failed to update conversation'}, room=request.sid)

        except Exception as e:
            print(f"Error updating AI conversation: {str(e)}")
            emit('error', {'msg': 'Failed to update conversation'}, room=request.sid)

    # @socketio.on('ai_update_user_settings')  # DISABLED - handled by new ai_socket_handlers
    # def handle_ai_update_user_settings(data):
        """Update user's AI settings"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('error', {'msg': 'User not authenticated'}, room=request.sid)
                return

            settings = data.get('settings', {})
            if not settings:
                emit('error', {'msg': 'No settings provided'}, room=request.sid)
                return

            # Update user AI settings
            success = update_user_ai_settings(user_uuid, settings)
            if success:
                emit('ai_settings_updated', {'settings': settings}, room=request.sid)
            else:
                emit('error', {'msg': 'Failed to update AI settings'}, room=request.sid)

        except Exception as e:
            print(f"Error updating AI user settings: {str(e)}")
            emit('error', {'msg': 'Failed to update AI settings'}, room=request.sid)

    # @socketio.on('ai_delete_character')  # DISABLED - handled by new ai_socket_handlers
    # def handle_ai_delete_character(data):
        """Delete an AI character"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('error', {'msg': 'User not authenticated'}, room=request.sid)
                return

            character_name = data.get('character_name', '').strip()
            if not character_name:
                emit('error', {'msg': 'Character name is required'}, room=request.sid)
                return

            # Delete the character
            success = ai_database.delete_character(user_uuid, character_name)
            if success:
                emit('ai_character_deleted', {'character_name': character_name}, room=request.sid)
            else:
                emit('error', {'msg': 'Failed to delete character'}, room=request.sid)

        except Exception as e:
            print(f"Error deleting AI character: {str(e)}")
            emit('error', {'msg': 'Failed to delete character'}, room=request.sid)

    # @socketio.on('ai_create_character')  # DISABLED - handled by new ai_socket_handlers
    # def handle_ai_create_character(data):
        """Create a new user AI character"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('error', {'msg': 'User not authenticated'}, room=request.sid)
                return

            character_data = data.get('character', {})
            if not character_data.get('character_name'):
                emit('ai_character_create_error', {'msg': 'Character name is required'}, room=request.sid)
                return

            # Add user_uuid to character data
            character_data['user_uuid'] = user_uuid

            # Handle avatar upload if present
            if 'avatar' in character_data:
                try:
                    # Ensure avatar data is string (decode if bytes)
                    if isinstance(character_data['avatar'], bytes):
                        character_data['avatar'] = character_data['avatar'].decode('utf-8')

                    # Use the unified upload endpoint

                    # Generate unique filename
                    filename = f"avatar_ai_{user_uuid}_{character_data['character_name']}_{int(uuid.uuid4().hex[:16], 16)}.png"
                    filepath = os.path.join('static', 'uploads', 'avatars', filename)

                    # Ensure directory exists
                    os.makedirs(os.path.dirname(filepath), exist_ok=True)

                    # Save the base64 image
                    if character_data['avatar'].startswith('data:image/'):
                        # Extract base64 data
                        header, base64_data = character_data['avatar'].split(',', 1)
                        image_data = base64.b64decode(base64_data)

                        with open(filepath, 'wb') as f:
                            f.write(image_data)

                        # Update character data with avatar URL
                        character_data['avatar_url'] = f'/static/uploads/avatars/{filename}'
                        del character_data['avatar']  # Remove base64 data

                except Exception as e:
                    print(f"Error saving avatar: {str(e)}")
                    emit('ai_character_create_error', {'msg': 'Failed to save avatar'}, room=request.sid)
                    return

            # Create the character
            character_name = character_data.get('character_name')
            success = ai_database.save_character(user_uuid, character_data)
            if success:
                # Add character_type to the response
                character_data['character_type'] = 'user'
                emit('ai_character_created', {'character': character_data}, room=request.sid)
            else:
                emit('ai_character_create_error', {'msg': 'Failed to create character'}, room=request.sid)

        except Exception as e:
            print(f"Error creating AI character: {str(e)}")
            emit('error', {'msg': 'Failed to create character'}, room=request.sid)

    # @socketio.on('ai_update_character')  # DISABLED - handled by new ai_socket_handlers
    # def handle_ai_update_character(data):
        """Update an existing AI character"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('error', {'msg': 'User not authenticated'}, room=request.sid)
                return

            character_data = data.get('character', {})
            original_name = data.get('original_name', '')

            if not character_data.get('character_name'):
                emit('ai_character_update_error', {'msg': 'Character name is required'}, room=request.sid)
                return

            if not original_name:
                emit('ai_character_update_error', {'msg': 'Original character name is required'}, room=request.sid)
                return

            # Handle avatar upload if present
            if 'avatar' in character_data:
                try:
                    # Ensure avatar data is string (decode if bytes)
                    if isinstance(character_data['avatar'], bytes):
                        character_data['avatar'] = character_data['avatar'].decode('utf-8')

                    # Use the unified upload endpoint

                    # Generate unique filename
                    filename = f"avatar_ai_{user_uuid}_{character_data['character_name']}_{int(uuid.uuid4().hex[:16], 16)}.png"
                    filepath = os.path.join('static', 'uploads', 'avatars', filename)

                    # Ensure directory exists
                    os.makedirs(os.path.dirname(filepath), exist_ok=True)

                    # Save the base64 image
                    if character_data['avatar'].startswith('data:image/'):
                        # Extract base64 data
                        header, base64_data = character_data['avatar'].split(',', 1)
                        image_data = base64.b64decode(base64_data)

                        with open(filepath, 'wb') as f:
                            f.write(image_data)

                        # Update character data with avatar URL
                        character_data['avatar_url'] = f'/static/uploads/avatars/{filename}'
                        del character_data['avatar']  # Remove base64 data

                except Exception as e:
                    print(f"Error saving avatar: {str(e)}")
                    emit('ai_character_update_error', {'msg': 'Failed to save avatar'}, room=request.sid)
                    return

            # Check if this is a built-in character that should be updated universally
            target_uuid = user_uuid
            existing_character = ai_database.get_character(user_uuid, original_name)
            if existing_character and existing_character.get('character_type') == 'builtin':
                # This is a built-in character, update it under the system UUID for universal access
                target_uuid = 'system-builtin-characters'

            # Update the character
            new_character_name = character_data.get('character_name')
            success = ai_database.save_character(target_uuid, character_data)

            if success:
                # If the name changed, we need to handle renaming
                if original_name != new_character_name:
                    # For now, just delete the old character and create new one
                    # This is a simple approach - could be improved with proper rename logic
                    ai_database.delete_character(target_uuid, original_name)

                # Retrieve the updated character from database to ensure we have the correct avatar_url
                updated_character = ai_database.get_character(target_uuid, new_character_name)
                if updated_character:
                    # Add character_type to the response
                    updated_character['character_type'] = 'user' if target_uuid != 'system-builtin-characters' else 'builtin'
                    emit('ai_character_updated', {'character': updated_character}, room=request.sid)
                else:
                    emit('ai_character_update_error', {'msg': 'Failed to retrieve updated character'}, room=request.sid)
            else:
                emit('ai_character_update_error', {'msg': 'Failed to update character'}, room=request.sid)

        except Exception as e:
            print(f"Error updating AI character: {str(e)}")
            emit('error', {'msg': 'Failed to update character'}, room=request.sid)

    # @socketio.on('ai_set_active_character')  # DISABLED - handled by new ai_socket_handlers
    # def handle_ai_set_active_character(data):
        """Set a character as the active character for the user"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('error', {'msg': 'User not authenticated'}, room=request.sid)
                return

            character_name = data.get('character_name', '').strip()
            if not character_name:
                emit('error', {'msg': 'Character name is required'}, room=request.sid)
                return

            success = ai_database.set_active_character(user_uuid, character_name)
            if success:
                # Get the updated active character data
                active_character = ai_database.get_active_character(user_uuid)
                emit('ai_active_character_set', {'character': active_character}, room=request.sid)
            else:
                emit('error', {'msg': 'Failed to set active character'}, room=request.sid)

        except Exception as e:
            print(f"Error setting active character: {str(e)}")
            emit('error', {'msg': 'Failed to set active character'}, room=request.sid)

    # @socketio.on('ai_get_active_character')  # DISABLED - handled by new ai_socket_handlers
    # def handle_ai_get_active_character():
        """Get the currently active character for the user"""
        try:
            user_uuid = users.get(request.sid)
            if not user_uuid:
                emit('error', {'msg': 'User not authenticated'}, room=request.sid)
                return

            active_character = ai_database.get_active_character(user_uuid)
            emit('ai_active_character_data', {'character': active_character}, room=request.sid)

        except Exception as e:
            print(f"Error getting active character: {str(e)}")
            emit('error', {'msg': 'Failed to get active character'}, room=request.sid)