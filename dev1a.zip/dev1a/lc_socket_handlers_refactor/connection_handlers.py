from flask_socketio import emit, join_room, leave_room
from werkzeug.security import check_password_hash
from flask import request, session
from flask_socketio_stubs import Request
from database import save_user, get_user_by_username, check_username_available, update_user_avatar, is_user_admin, get_user_settings, update_user_settings, load_channels, load_media_channels
import uuid
import time
import threading


def register_connection_handlers(socketio, app, users_db, channels, media_channels, users, user_id_to_sid):
    # Track user activity for presence management
    user_last_activity = {}  # user_uuid -> timestamp of last activity

    def cleanup_inactive_users():
        """Periodically clean up users who haven't been active"""
        while True:
            try:
                current_time = time.time()
                inactive_threshold = 120  # 2 minutes of inactivity

                # Find inactive users
                inactive_users = []
                for user_uuid, last_activity in user_last_activity.items():
                    if current_time - last_activity > inactive_threshold:
                        inactive_users.append(user_uuid)

                # Remove inactive users
                for user_uuid in inactive_users:
                    if user_uuid in user_id_to_sid:
                        # Remove from tracking
                        sid = user_id_to_sid[user_uuid]
                        if sid in users:
                            del users[sid]
                        del user_id_to_sid[user_uuid]
                        del user_last_activity[user_uuid]
                        print(f"Removed inactive user: {user_uuid}")

                # Update online users list if any users were removed
                if inactive_users:
                    online_users = []
                    for user_uuid in user_id_to_sid.keys():
                        user_data = users_db.get(user_uuid, {})
                        display_name = user_data.get('display_name') or user_data.get('username') or user_uuid
                        online_users.append(display_name)
                    socketio.emit('update_online_users', {'online_users': online_users})
                    print(f"Updated online users after cleanup: {online_users}")

            except Exception as e:
                print(f"Error in cleanup_inactive_users: {e}")

            time.sleep(60)  # Check every minute

    # Start cleanup thread
    cleanup_thread = threading.Thread(target=cleanup_inactive_users, daemon=True)
    cleanup_thread.start()
    @socketio.on('connect')
    def handle_connect(auth=None):
        if 'user_uuid' in session:
            user_uuid = session['user_uuid']
            # Store the user association and add to online list
            users[request.sid] = user_uuid
            user_id_to_sid[user_uuid] = request.sid
            # Track user activity
            user_last_activity[user_uuid] = time.time()
            # print(f"Restored user {user_uuid} for sid {request.sid}")

            # Send current user's UUID to client
            emit('current_user', {'uuid': user_uuid})

        # Send current channels and media channels to the client
        emit('update_channels', {'channels': channels})
        emit('update_media_channels', {'channels': media_channels})

        # Send users database to client for username lookups
        emit('update_users', {'users': users_db})
        online_users = []
        for user_uuid in user_id_to_sid.keys():
            user_data = users_db.get(user_uuid, {})
            display_name = user_data.get('display_name') or user_data.get('username') or user_uuid
            online_users.append(display_name)
        socketio.emit('update_online_users', {'online_users': online_users})

        # Send current image generation status to new client
        try:
            from extensions.sd_integration import current_generation_status
            if current_generation_status['active']:
                emit('image_generation_progress', {
                    'generation_id': current_generation_status['generation_id'],
                    'progress': 0,
                    'status': 'busy',
                    'channel': current_generation_status['channel'],
                    'sender': current_generation_status['sender']
                })
                print(f"Sent current generation status to new client: busy")
        except ImportError:
            pass  # SD integration not available
        except Exception as e:
            print(f"Error in handle_connect: {e}")
            import traceback
            traceback.print_exc()

    @socketio.on('request_webrtc_config')
    def handle_request_webrtc_config():
        client_ip = request.remote_addr
        # print(f"WebRTC config requested from {client_ip}")

        # For LAN use only - include STUN server at the server's accessible IP
        ice_servers = []

        # Get the server's IP that the client connected to
        server_ip = request.host.split(':')[0]
        # Assume STUN server is running on the server and accessible at this IP
        ice_servers.append({'urls': f'stun:{server_ip}:3479'})
        # print(f"STUN server configured at {server_ip}:3479")

        emit('webrtc_config', {
            'iceServers': ice_servers
        })

    @socketio.on('check_username_availability')
    def handle_check_username_availability(data):
        username = data.get('username', '').strip()
        if not username:
            emit('username_availability_result', {'available': False, 'message': 'Username is required'})
            return

        try:
            available = check_username_available(username)
            emit('username_availability_result', {
                'available': available,
                'message': 'Username is available' if available else 'Username is already taken'
            })
        except Exception as e:
            emit('username_availability_result', {'available': False, 'message': f'Error checking availability: {str(e)}'})

    @socketio.on('register_user_with_password')
    def handle_register(data):
        username = data.get('username', '').strip()
        password = data.get('password', '').strip()
        avatar_url = data.get('avatar_url')
        display_name = data.get('display_name')
        custom_status = data.get('custom_status')
        if not username or not password:
            emit('register_error', {'msg': 'Username and password are required'})
            return
        if len(username) < 3 or len(password) < 6:
            emit('register_error', {'msg': 'Username must be at least 3 characters and password at least 6 characters'})
            return
        try:
            user_uuid = str(uuid.uuid4())
            password_hash = save_user(user_uuid, username, password, avatar_url, display_name, custom_status)
            users_db[user_uuid] = {
                'username': username,
                'password_hash': password_hash,
                'avatar_url': avatar_url,
                'display_name': display_name,
                'custom_status': custom_status
            }
            # Remove old sid for this user if exists (though new user shouldn't have)
            if user_uuid in user_id_to_sid:
                old_sid = user_id_to_sid[user_uuid]
                if old_sid in users:
                    del users[old_sid]
            users[request.sid] = user_uuid
            user_id_to_sid[user_uuid] = request.sid
            # Track user activity
            user_last_activity[user_uuid] = time.time()
            session['user_uuid'] = user_uuid
            session.modified = True
            emit('user_registered', {
                'uuid': user_uuid,
                'is_admin': is_user_admin(user_uuid)
            })
            socketio.emit('update_users', {
                'users': users_db
            })
            # Send online users
            online_users = []
            for user_uuid in user_id_to_sid.keys():
                user_data = users_db.get(user_uuid, {})
                display_name = user_data.get('display_name') or user_data.get('username') or user_uuid
                online_users.append(display_name)
            socketio.emit('update_online_users', {'online_users': online_users})
            socketio.emit('update_channels', {'channels': channels})
            socketio.emit('update_media_channels', {'channels': media_channels})
        except ValueError as e:
            emit('register_error', {'msg': str(e)})
        except Exception as e:
            emit('register_error', {'msg': f'Registration failed: {str(e)}'})

    @socketio.on('login_user')
    def handle_login(data):
        username = data.get('username', '').strip()
        password = data.get('password', '').strip()
        avatar_url = data.get('avatar_url')
        user = get_user_by_username(username)
        if not user or not check_password_hash(user['password_hash'], password):
            emit('login_error', {'msg': 'Invalid username or password'})
            return
        user_uuid = user['uuid']
        # Remove old sid for this user if exists
        if user_uuid in user_id_to_sid:
            old_sid = user_id_to_sid[user_uuid]
            if old_sid in users:
                del users[old_sid]
        users[request.sid] = user_uuid
        user_id_to_sid[user_uuid] = request.sid
        # Track user activity
        user_last_activity[user_uuid] = time.time()
        session['user_uuid'] = user_uuid
        session.modified = True
        # Force session save
        try:
            session.save()
        except:
            pass
        if avatar_url:
            update_user_avatar(user['uuid'], avatar_url)
            users_db[user['uuid']]['avatar_url'] = avatar_url
        emit('user_registered', {
            'uuid': user['uuid'],
            'is_admin': is_user_admin(user['uuid'])
        })
        socketio.emit('update_users', {
            'users': users_db
        })
        # Send online users
        online_users = []
        for user_uuid in user_id_to_sid.keys():
            user_data = users_db.get(user_uuid, {})
            display_name = user_data.get('display_name') or user_data.get('username') or user_uuid
            online_users.append(display_name)
            print(f"Online user: {user_uuid} -> {display_name}")
        print(f"Sending online users: {online_users}")
        socketio.emit('update_online_users', {'online_users': online_users})
        socketio.emit('update_channels', {'channels': channels})

    @socketio.on('update_avatar')
    def handle_update_avatar(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return
        avatar_url = data.get('avatar_url')
        if not avatar_url:
            emit('error', {'msg': 'No avatar URL provided'})
            return
        update_user_avatar(user_uuid, avatar_url)
        users_db[user_uuid]['avatar_url'] = avatar_url
        socketio.emit('update_users', {
            'users': {users_db[user_uuid]['username']: users_db[user_uuid] for user_uuid in users.values() if user_uuid in users_db}
        })

    @socketio.on('disconnect')
    def handle_disconnect():
        user_uuid = users.pop(request.sid, None)
        if user_uuid:
            # Remove from user_id_to_sid
            if user_uuid in user_id_to_sid and user_id_to_sid[user_uuid] == request.sid:
                del user_id_to_sid[user_uuid]
            # Remove from activity tracking
            if user_uuid in user_last_activity:
                del user_last_activity[user_uuid]
        socketio.emit('update_users', {
            'users': users_db
        })
        # Send updated online users
        online_users = []
        for user_uuid in user_id_to_sid.keys():
            user_data = users_db.get(user_uuid, {})
            display_name = user_data.get('display_name') or user_data.get('username') or user_uuid
            online_users.append(display_name)
        socketio.emit('update_online_users', {'online_users': online_users})

    @socketio.on('ping')
    def handle_ping():
        """Respond to client ping with pong for latency measurement"""
        emit('pong')

    @socketio.on('user_heartbeat')
    def handle_user_heartbeat():
        """Handle user heartbeat to indicate activity"""
        user_uuid = users.get(request.sid)
        if user_uuid:
            user_last_activity[user_uuid] = time.time()

    @socketio.on('get_user_settings')
    def handle_get_user_settings():
        user_uuid = users.get(request.sid)
        if not user_uuid:
            return

        try:
            settings = get_user_settings(user_uuid)
            emit('user_settings', settings)
        except Exception as e:
            emit('error', {'msg': f'Failed to load user settings: {str(e)}'})

    @socketio.on('update_user_settings')
    def handle_update_user_settings(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return

        settings = data.get('settings', {})
        if not settings:
            emit('error', {'msg': 'No settings provided'})
            return

        try:
            update_user_settings(user_uuid, settings)
            # Reload and emit updated settings
            updated_settings = get_user_settings(user_uuid)
            if updated_settings:
                emit('user_settings', updated_settings)
                emit('settings_updated', {'success': True})

                # If avatar_url, display_name, or custom_status was updated, sync to users_db and notify all clients
                settings_updated = False
                if 'avatar_url' in settings:
                    users_db[user_uuid]['avatar_url'] = settings['avatar_url']
                    settings_updated = True
                if 'display_name' in settings:
                    users_db[user_uuid]['display_name'] = settings['display_name']
                    settings_updated = True
                if 'custom_status' in settings:
                    users_db[user_uuid]['custom_status'] = settings['custom_status']
                    settings_updated = True
                if 'toast_on_media_download' in settings:
                    users_db[user_uuid]['toast_on_media_download'] = settings['toast_on_media_download']
                    settings_updated = True

                if settings_updated:
                    socketio.emit('update_users', {
                        'users': users_db
                    })
            else:
                emit('settings_updated', {'success': False, 'msg': 'Failed to reload settings'})
        except Exception as e:
            emit('settings_updated', {'success': False, 'msg': f'Failed to update settings: {str(e)}'})