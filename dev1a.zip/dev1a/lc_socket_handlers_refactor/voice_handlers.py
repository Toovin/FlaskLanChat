from flask_socketio import emit, join_room, leave_room
from flask import request
import time
import threading


def register_voice_handlers(socketio, app, users, user_id_to_sid, rooms, room_video_states, room_chat_history, room_mute_states, room_last_activity, call_states, call_lock, users_db, typing_users):
    def get_user_id_from_sid(sid):
        """Get user_id from sid - voice connections use same auth as main connections"""
        return users.get(sid)

    def cleanup_stale_voice_participants():
        """Clean up participants who have disconnected without properly leaving rooms"""
        current_time = time.time()
        stale_threshold = 60  # 60 seconds of inactivity

        for room_name, participants in list(rooms.items()):
            if room_name not in room_last_activity:
                continue

            # Check if room has been inactive for too long
            if current_time - room_last_activity[room_name] > stale_threshold:
                # Check which participants are still connected in main system
                active_participants = set()
                for user_id in participants:
                    # Check if user is still connected in main system
                    if user_id in user_id_to_sid:  # User still has active main connection
                        active_participants.add(user_id)

                # Remove stale participants
                stale_participants = participants - active_participants
                if stale_participants:
                    # print(f"Removing stale participants from room {room_name}: {stale_participants}")
                    for user_id in stale_participants:
                        participants.discard(user_id)
                        # Notify remaining participants
                        socketio.emit('user-left', {'userId': user_id, 'room': room_name}, room=room_name)

                    # Update participants list for remaining users
                    if participants:
                        updated_participants = [{'id': uid, 'name': users_db.get(uid, {}).get('username', uid)} for uid in participants]
                        socketio.emit('room-participants', {'participants': updated_participants, 'room': room_name}, room=room_name)

                    # Broadcast updated voice members to ALL clients after cleanup
                    broadcast_voice_members()

                # Clean up empty rooms
                if not participants:
                    # print(f"Cleaning up empty room: {room_name}")
                    del rooms[room_name]
                    if room_name in room_video_states:
                        del room_video_states[room_name]
                    if room_name in room_chat_history:
                        del room_chat_history[room_name]
                    if room_name in room_mute_states:
                        del room_mute_states[room_name]
                    if room_name in room_last_activity:
                        del room_last_activity[room_name]

    # Start periodic cleanup
    def start_voice_cleanup():
        def cleanup_loop():
            while True:
                try:
                    with app.app_context():
                        cleanup_stale_voice_participants()
                except Exception as e:
                    # print(f"Error in voice cleanup: {e}")
                    pass
                time.sleep(15)

        cleanup_thread = threading.Thread(target=cleanup_loop, daemon=True)
        cleanup_thread.start()

    # Periodic cleanup for stale calls
    def cleanup_stale_calls():
        while True:
            current_time = time.time()
            to_delete = []
            for call_id, info in call_states.items():
                if 'timestamp' in info and current_time - info['timestamp'] > 300:  # 5 min
                    if info['state'] != 'ended':
                        info['state'] = 'ended'
                        # Notify both if online
                        caller_sid = user_id_to_sid.get(info['caller'])
                        callee_sid = user_id_to_sid.get(info['callee'])
                        if caller_sid:
                            emit('call_ended', {'call_id': call_id, 'ended_by': 'system', 'reason': 'timeout'}, to=caller_sid)
                        if callee_sid:
                            emit('call_ended', {'call_id': call_id, 'ended_by': 'system', 'reason': 'timeout'}, to=callee_sid)
                    to_delete.append(call_id)

            for call_id in to_delete:
                del call_states[call_id]

            time.sleep(60)  # Check every minute

    cleanup_call_thread = threading.Thread(target=cleanup_stale_calls, daemon=True)
    cleanup_call_thread.start()

    @socketio.on('join-room')
    def handle_join_room(data):
        room = data.get('room')
        user_name = data.get('userName', request.sid)  # Use sid as fallback

        if not room:
            return

        # Get authenticated user from main connection system
        authenticated_user = users.get(request.sid)
        if not authenticated_user:
            print(f"[VOICE] Rejecting join-room: user not authenticated for sid {request.sid}")
            return

        # Use authenticated user instead of provided userName
        user_name = authenticated_user

        if room not in rooms:
            rooms[room] = set()
            room_video_states[room] = {}
            room_chat_history[room] = []
            room_mute_states[room] = {}  # Initialize mute states for new room

        rooms[room].add(user_name)
        # Don't modify global user_id_to_sid - voice connections use same sid as main connection
        room_last_activity[room] = time.time()  # Update activity timestamp
        join_room(room)

        print(f"[VOICE] User {user_name} joined room {room}")

        # Send room state to the new user (matching reference voice server API)
        # Include all participants including the current user
        participants = [{'id': uid, 'name': users_db.get(uid, {}).get('username', uid)} for uid in rooms[room]]
        chat_history = room_chat_history.get(room, [])[-100:]  # Last 100 messages
        video_state = room_video_states.get(room, {})

        emit('room-participants', {
            'participants': participants,
            'chatHistory': chat_history,
            'videoState': video_state,
            'room': room
        })

        # Notify others in the room
        emit('user-joined', {'userId': user_name, 'room': room}, room=room, skip_sid=request.sid)

        # Broadcast updated voice members to ALL clients
        broadcast_voice_members()

        # DON'T broadcast global online users - that's managed by connection handlers

    @socketio.on('leave-room')
    def handle_leave_room(data):
        room = data.get('room')
        user_name = data.get('userName', request.sid)

        # Get authenticated user from main connection system
        authenticated_user = users.get(request.sid)
        if authenticated_user:
            user_name = authenticated_user

        if room in rooms and user_name in rooms[room]:
            rooms[room].remove(user_name)
            leave_room(room)

            # Clean up video state for this user
            if room in room_video_states and user_name in room_video_states[room]:
                del room_video_states[room][user_name]

            print(f"[VOICE] User {user_name} left room {room}")

            # Notify others
            emit('user-left', {'userId': user_name, 'room': room}, room=room)

            # Send updated participants list to remaining members
            participants = [{'id': uid, 'name': users_db.get(uid, {}).get('username', uid)} for uid in rooms[room]]
            socketio.emit('room-participants', {'participants': participants, 'room': room}, room=room)

            # Broadcast updated voice members to ALL clients
            broadcast_voice_members()

            # DON'T broadcast global online users - that's managed by connection handlers

            # Clean up empty rooms
            if not rooms[room]:
                del rooms[room]
                if room in room_video_states:
                    del room_video_states[room]
                if room in room_chat_history:
                    del room_chat_history[room]
                if room in room_mute_states:
                    del room_mute_states[room]

    @socketio.on('signal')
    def handle_signal(data):
        # print(f"Received signal from {request.sid}: targetUserId={data.get('targetUserId')}, signal type={data.get('signal', {}).get('type')}")
        # print(f"Current users dict: {users}")
        # print(f"Current user_id_to_sid dict: {user_id_to_sid}")
        target_user_id = data.get('targetUserId')
        signal = data.get('signal')

        if not target_user_id or not signal:
            # print(f"Invalid signal data: target_user_id={target_user_id}, signal={signal}")
            return

        # Get sender user_id from main connection system
        sender_user_id = get_user_id_from_sid(request.sid)
        if not sender_user_id:
            print(f"[VOICE] No authenticated user found for sid {request.sid}")
            return

        # Find the target's sid
        target_sid = user_id_to_sid.get(target_user_id)
        # print(f"Target user {target_user_id} -> sid {target_sid} (from user_id_to_sid)")

        if not target_sid:
            # Fallback to searching users dict
            for sid, user_id in users.items():
                if user_id == target_user_id:
                    target_sid = sid
                    break
            # print(f"Target user {target_user_id} -> sid {target_sid} (from users dict search)")

        if target_sid:
            pass  # print(f"Forwarding signal from {sender_user_id} to {target_user_id} via sid {target_sid}")
            emit('signal', {
                'from': sender_user_id,
                'signal': signal
            }, to=target_sid)
        else:
            pass  # print(f"Could not find target sid for user {target_user_id}")

    @socketio.on('stream-update')
    def handle_stream_update(data):
        """Unified handler for stream updates (start/stop media types)"""
        room = data.get('room')
        media_type = data.get('mediaType')  # 'audio', 'video', 'screenshare'
        action = data.get('action')  # 'start' or 'stop'
        video_type = data.get('videoType', 'webcam')  # for video streams

        # Find user_id
        user_id = None
        for uid, sid in user_id_to_sid.items():
            if sid == request.sid:
                user_id = uid
                break
        if not user_id:
            user_id = users.get(request.sid, request.sid)

        if not media_type or not action:
            # print(f"Invalid stream-update data: {data}")
            return

        # Find user's room if not provided
        if not room:
            user_sid = request.sid
            user_name = None
            for uname, sid in user_id_to_sid.items():
                if sid == user_sid:
                    user_name = uname
                    break
            if user_name:
                for r, participants in rooms.items():
                    if user_name in participants:
                        room = r
                        break

        if not room:
            # print(f"Warning: stream-update called but user {user_id} is not in any room")
            return

        # Update room state
        if room not in room_video_states:
            room_video_states[room] = {}

        if action == 'start':
            if media_type == 'video':
                room_video_states[room][user_id] = {'type': video_type, 'sharing': True}
            elif media_type in ['audio', 'screenshare']:
                # For audio and screenshare, just mark as active
                if user_id not in room_video_states[room]:
                    room_video_states[room][user_id] = {'sharing': True}
                room_video_states[room][user_id][f'{media_type}_active'] = True

            # Emit the appropriate event based on media type
            event_data = {'userId': user_id}
            if media_type == 'video':
                event_data['type'] = video_type
            emit(f'{media_type}-start', event_data, room=room, skip_sid=request.sid)

        elif action == 'stop':
            if media_type == 'video':
                if user_id in room_video_states[room]:
                    room_video_states[room][user_id]['sharing'] = False
            elif media_type in ['audio', 'screenshare']:
                if user_id in room_video_states[room]:
                    room_video_states[room][user_id][f'{media_type}_active'] = False

            emit(f'{media_type}-stop', {'userId': user_id}, room=room, skip_sid=request.sid)

        # print(f"Stream update: user {user_id} {action}ed {media_type} in room {room}")

        # Broadcast updated voice members to ALL clients when media state changes
        broadcast_voice_members()

    # Keep backward compatibility with old handlers
    @socketio.on('voice-start')
    def handle_voice_start():
        handle_stream_update({'mediaType': 'audio', 'action': 'start'})

    @socketio.on('voice-stop')
    def handle_voice_stop():
        handle_stream_update({'mediaType': 'audio', 'action': 'stop'})

    @socketio.on('video-start')
    def handle_video_start(data=None):
        video_type = (data.get('type') if data else None) or 'webcam'
        handle_stream_update({'mediaType': 'video', 'action': 'start', 'videoType': video_type})

    @socketio.on('video-stop')
    def handle_video_stop(data=None):
        handle_stream_update({'mediaType': 'video', 'action': 'stop'})

    @socketio.on('screenshare-start')
    def handle_screenshare_start(data=None):
        handle_stream_update({'mediaType': 'screenshare', 'action': 'start'})

    @socketio.on('screenshare-stop')
    def handle_screenshare_stop(data=None):
        handle_stream_update({'mediaType': 'screenshare', 'action': 'stop'})

    @socketio.on('audio-status')
    def handle_audio_status(data):
        room = data.get('room')
        # Find user_id from either voice connections or regular connections
        user_id = None
        for uid, sid in user_id_to_sid.items():
            if sid == request.sid:
                user_id = uid
                break
        if not user_id:
            user_id = users.get(request.sid, request.sid)
        enabled = data.get('enabled', True)
        emit('audio-status', {'userId': user_id, 'enabled': enabled}, room=room, skip_sid=request.sid)

    @socketio.on('mute')
    def handle_mute():
        # Find user's room and user_id
        user_sid = request.sid
        room = None
        user_name = None

        for uname, sid in user_id_to_sid.items():
            if sid == user_sid:
                user_name = uname
                break

        if user_name:
            for r, participants in rooms.items():
                if user_name in participants:
                    room = r
                    break

        user_id = user_name or users.get(request.sid, request.sid)

        if room:
            # Update mute state
            if room not in room_mute_states:
                room_mute_states[room] = {}
            room_mute_states[room][user_id] = True

            emit('mute', {'userId': user_id}, room=room, skip_sid=request.sid)
            # print(f"User {user_id} muted in room {room}")

            # Broadcast updated voice members to ALL clients
            broadcast_voice_members()

    @socketio.on('unmute')
    def handle_unmute():
        # Find user's room and user_id
        user_sid = request.sid
        room = None
        user_name = None

        for uname, sid in user_id_to_sid.items():
            if sid == user_sid:
                user_name = uname
                break

        if user_name:
            for r, participants in rooms.items():
                if user_name in participants:
                    room = r
                    break

        user_id = user_name or users.get(request.sid, request.sid)

        if room:
            # Update mute state
            if room not in room_mute_states:
                room_mute_states[room] = {}
            room_mute_states[room][user_id] = False

            emit('unmute', {'userId': user_id}, room=room, skip_sid=request.sid)
            # print(f"User {user_id} unmuted in room {room}")

            # Broadcast updated voice members to ALL clients
            broadcast_voice_members()

    @socketio.on('voice-disconnect')
    def handle_voice_disconnect(data):
        room = data.get('room')
        # Find user_id from either voice connections or regular connections
        user_id = None
        for uid, sid in user_id_to_sid.items():
            if sid == request.sid:
                user_id = uid
                break
        if not user_id:
            user_id = users.get(request.sid, request.sid)
        disconnected = data.get('disconnected', False)
        socketio.emit('voice-disconnect', {'userId': user_id, 'disconnected': disconnected}, room=room, skip_sid=request.sid)

        # If user is disconnecting from voice, remove them from the room
        if disconnected and room in rooms and user_id in rooms[room]:
            rooms[room].discard(user_id)
            # print(f"User {user_id} voice-disconnected from room {room}")

            # Broadcast updated voice members
            broadcast_voice_members()

    @socketio.on('voice-heartbeat')
    def handle_voice_heartbeat(data):
        room = data.get('room')
        if room in room_last_activity:
            room_last_activity[room] = time.time()

    @socketio.on('chat-message')
    def handle_chat_message(data):
        room = data.get('room')
        user_id = users.get(request.sid, request.sid)
        message_data = data.get('message', {})

        # Add to room chat history
        if room not in room_chat_history:
            room_chat_history[room] = []
        room_chat_history[room].append(message_data)

        # Keep only last 100 messages
        if len(room_chat_history[room]) > 100:
            room_chat_history[room] = room_chat_history[room][-100:]

        # Broadcast to room
        emit('chat-message', {'message': message_data}, room=room)

    @socketio.on('sound-board')
    def handle_sound_board(data):
        room = data.get('room')
        sound_name = data.get('soundName', '')
        emit('sound-board', {'soundName': sound_name}, room=room)

    @socketio.on('request-video')
    def handle_request_video(data):
        room = data.get('room')
        target_user_id = data.get('targetUserId')
        user_id = users.get(request.sid, request.sid)

        if target_user_id and room in rooms and target_user_id in rooms[room]:
            target_sid = user_id_to_sid.get(target_user_id)
            if target_sid:
                emit('video-request', {'fromUserId': user_id}, to=target_sid)

    @socketio.on('test_event')
    def handle_test_event(data):
        # print(f"Test event received: {data}")
        emit('test_response', {'msg': 'Test successful'})

    @socketio.on('get_active_calls')
    def handle_get_active_calls():
        user_uuid = users.get(request.sid)
        if user_uuid:
            active_calls = [info for info in call_states.values() if info['state'] != 'ended' and (info['caller'] == user_uuid or info['callee'] == user_uuid)]
            emit('active_calls', {'calls': active_calls})

    def broadcast_voice_members():
        """Broadcast current voice members to ALL connected clients"""
        voice_members = {}

        # print(f"[DEBUG] Broadcasting voice members. Current rooms: {list(rooms.keys())}")

        # Collect all voice rooms and their participants (exclude private rooms)
        for room_name, participants in rooms.items():
            if room_name.startswith('private-'):
                continue  # Skip private rooms
            # print(f"[DEBUG] Room {room_name} has participants: {list(participants)}")
            if participants:  # Only include non-empty rooms
                room_members = []
                for user_id in participants:
                    # Get user info
                    user_info = users_db.get(user_id, {})
                    username = user_info.get('username', user_id)
                    display_name = user_info.get('display_name', username)

                    # Get media states for this user in this room
                    media_states = room_video_states.get(room_name, {}).get(user_id, {})
                    mute_state = room_mute_states.get(room_name, {}).get(user_id, False)

                    member_data = {
                        'id': user_id,
                        'name': display_name,
                        'username': username,
                        'room': room_name,
                        'audio_active': media_states.get('audio_active', False),
                        'video_active': media_states.get('sharing', False) if media_states.get('type') == 'webcam' else False,
                        'screenshare_active': media_states.get('audio_active', False) if media_states.get('type') == 'screenshare' else False,
                        'muted': mute_state
                    }
                    room_members.append(member_data)

                if room_members:
                    voice_members[room_name] = room_members

        # print(f"[DEBUG] Broadcasting voice_members: {voice_members}")

        # Broadcast to ALL connected clients
        socketio.emit('voice-members-update', {'voice_members': voice_members})

    # Start the voice cleanup thread
    start_voice_cleanup()