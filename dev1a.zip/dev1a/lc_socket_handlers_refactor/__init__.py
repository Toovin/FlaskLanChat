from .connection_handlers import register_connection_handlers
from .messaging_handlers import register_messaging_handlers
from .voice_handlers import register_voice_handlers
from .channel_handlers import register_channel_handlers
from .user_notes_handlers import register_user_notes_handlers
from .call_handlers import register_call_handlers
from ai_socket_handlers import register_new_ai_handlers

import threading


def register_socket_handlers(socketio_instance, app, users_db, channels, media_channels, command_processor):
    # Initialize global state variables (matching original)
    global socketio
    socketio = socketio_instance
    users = {}  # sid -> user_uuid
    rooms = {}  # room_name -> set of user_ids
    user_id_to_sid = {}  # user_id -> sid
    room_last_activity = {}  # room_name -> timestamp of last activity
    call_states = {}  # call_id -> call info
    call_lock = threading.Lock()  # Prevent simultaneous call initiates

    # Global room state management for voice server compatibility
    room_video_states = {}  # room_name -> {user_id: {'type': 'webcam'|'screen', 'sharing': bool}}
    room_chat_history = {}  # room_name -> list of chat messages (last 100)
    room_mute_states = {}  # room_name -> {user_id: bool} - True if muted, False if unmuted

    # Import typing_users and processed_requests from utility_functions
    from .utility_functions import typing_users, processed_requests

    # Register all handler modules
    register_connection_handlers(socketio, app, users_db, channels, media_channels, users, user_id_to_sid)
    register_messaging_handlers(socketio, users_db, command_processor, users, typing_users)
    register_voice_handlers(socketio, app, users, user_id_to_sid, rooms, room_video_states, room_chat_history, room_mute_states, room_last_activity, call_states, call_lock, users_db, typing_users)
    register_channel_handlers(socketio, users_db, channels, media_channels, users)
    register_user_notes_handlers(socketio, users_db, users)
    register_call_handlers(socketio, users_db, users, call_states, call_lock)
    register_new_ai_handlers(socketio, users_db, users)