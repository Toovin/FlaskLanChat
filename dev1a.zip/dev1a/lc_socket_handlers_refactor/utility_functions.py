import sqlite3
import time
import json
from database import get_standard_timestamp

# Global variables that were in the original file
typing_users = {}  # Added for handling multiple typing people!
processed_requests = {}  # Track processed request IDs with timestamps for cleanup


def cleanup_processed_requests():
    """Clean up old processed request IDs to prevent memory leaks"""
    current_time = time.time()
    # Remove requests older than 5 minutes
    expired_requests = [req_id for req_id, timestamp in processed_requests.items()
                       if current_time - timestamp > 300]  # 300 seconds = 5 minutes
    for req_id in expired_requests:
        del processed_requests[req_id]
    if expired_requests:
        pass  # print(f"Cleaned up {len(expired_requests)} expired request IDs")


def save_and_emit_message(response, channel, sender, replied_to, socketio):
    """Unified function to save message to database and emit to channel"""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        timestamp = get_standard_timestamp()
        message_content = response.get('message', '')
        if not isinstance(message_content, str):
            message_content = str(message_content)

        # Handle AI context marker (invisible marker for AI context control)
        ai_context_marker = response.get('ai_context_marker')
        if ai_context_marker:
            # Prepend marker to message content (will be invisible in UI if handled properly)
            message_content = f"{ai_context_marker} {message_content}"

        # Handle generation_id and auto_share for image messages
        generation_id = response.get('generation_id')
        auto_share = response.get('auto_share', True)

        # Handle reply context
        replied_sender = None
        replied_text = None
        if replied_to:
            # Fetch the original message to store reply context
            c_reply = conn.cursor()
            c_reply.execute("SELECT sender, message FROM messages WHERE id = ?", (replied_to,))
            reply_row = c_reply.fetchone()
            if reply_row:
                replied_sender = reply_row[0]
                replied_text = reply_row[1]
                if replied_text and len(replied_text) > 100:  # Truncate long messages
                    replied_text = replied_text[:100] + '...'

        # Handle AI generated flag
        ai_generated = response.get('ai_generated', False)
        ai_conversation_id = response.get('ai_conversation_id')

        c.execute("INSERT INTO messages (channel, sender, message, is_media, timestamp, replied_to, replied_sender, replied_text, image_url, thumbnail_url, generation_id, auto_share, ai_generated, ai_conversation_id, avatar_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                  (channel, response.get('sender', sender), message_content, response.get('is_media', False), timestamp, replied_to, replied_sender, replied_text, response.get('image_url'), response.get('thumbnail_url'), generation_id, auto_share, ai_generated, ai_conversation_id, response.get('avatar_url')))
        message_id = c.lastrowid
        conn.commit()
        conn.close()

        # print(f"Saved message ID {message_id} for {response.get('sender', sender)} in channel {channel}")

        socketio.emit('receive_message', {
            'id': message_id,
            'channel': channel,
            'sender': response.get('sender', sender),
            'message': message_content,
            'is_media': response.get('is_media', False),
            'image_url': response.get('image_url'),
            'thumbnail_url': response.get('thumbnail_url'),
            'avatar_url': response.get('avatar_url'),
            'timestamp': timestamp,
            'replied_to': replied_to,
            'replied_sender': replied_sender,
            'replied_text': replied_text,
            'replies_count': 0,
            'reactions': [],
            'generation_id': generation_id,
            'auto_share': auto_share,
            'ai_generated': ai_generated,
            'ai_conversation_id': ai_conversation_id
        }, room=channel)

    except Exception as e:
        # print(f"Error saving and emitting message: {str(e)}")
        socketio.emit('error', {'msg': f'Failed to save message: {str(e)}'}, room=socketio.request.sid)


def validate_media_response(response):
    """
    Validate a media response to ensure it contains valid image_url and thumbnail_url or attachments.
    Returns True if valid, False otherwise.
    """
    if not response.get('is_media', False):
        # Non-media messages don't need validation
        return True

    valid_extensions = ['png', 'jpg', 'jpeg', 'gif', 'webp', 'mp4', 'webm', 'avi', 'mov']
    if 'image_url' in response and 'thumbnail_url' in response:
        image_url = response.get('image_url')
        thumbnail_url = response.get('thumbnail_url')
        # Allow thumbnail_url to be None for videos and other files without thumbnails
        is_valid = (image_url and
                    isinstance(image_url, str) and
                    image_url.strip() and
                    image_url.split('.')[-1].lower() in valid_extensions and
                    (thumbnail_url is None or
                     (isinstance(thumbnail_url, str) and thumbnail_url.strip())))
        if not is_valid:
            pass  # print(f"Invalid media response: image_url={image_url}, thumbnail_url={thumbnail_url}")
        return is_valid
    elif 'message' in response and isinstance(response['message'], str):
        try:
            import json
            parsed = json.loads(response['message'])
            attachments = parsed.get('attachments', [])
            is_valid = all(
                isinstance(att, dict) and
                'url' in att and
                isinstance(att['url'], str) and
                att['url'].strip() and
                att['url'].split('.')[-1].lower() in valid_extensions and
                # Allow thumbnail_url to be None or a valid string
                ('thumbnail_url' not in att or
                 att['thumbnail_url'] is None or
                 (isinstance(att['thumbnail_url'], str) and att['thumbnail_url'].strip()))
                for att in attachments
            )
            if not is_valid:
                pass  # print(f"Invalid attachments in media response: {attachments}")
            return is_valid
        except json.JSONDecodeError:
            # print(f"Invalid JSON in media response message: {response['message']}")
            return False
    # print(f"Invalid media response format: {response}")
    return False