from flask_socketio import emit, socketio
from flask import request
from flask_socketio_stubs import Request
from database import load_messages, add_reaction, remove_reaction, get_reactions, delete_message, add_dm_message, load_dm_messages, get_dm_conversations, mark_dm_messages_read, get_system_display_name, get_user_ai_settings
from ai_database import ai_database
from lc_socket_handlers_refactor.utility_functions import save_and_emit_message, validate_media_response, cleanup_processed_requests, processed_requests
import sqlite3
import uuid
import json
import threading
import time


def register_messaging_handlers(socketio, users_db, command_processor, users, typing_users):
    @socketio.on('send_message')
    def handle_send_message(data):
        request_id = data.get('request_id', str(uuid.uuid4()))
        # print(f"Received send_message with request_id: {request_id}, data: {data}")

        # Clean up old processed requests periodically
        cleanup_processed_requests()

        if request_id in processed_requests:
            # print(f"Skipping duplicate request: {request_id}")
            return
        processed_requests[request_id] = time.time()
        # print(f"Processing send_message with request_id: {request_id}")
        channel = data['channel'].strip()
        message = data['message'].strip()
        user_uuid = users.get(request.sid)
        sender = users_db[user_uuid]['username'] if user_uuid and user_uuid in users_db else 'Anonymous'
        is_media = data.get('is_media', 0)
        replied_to = data.get('reply_to')
        form_data = data.get('form_data', {})
        initial_prompt = data.get('initial_prompt')
        if not message:
            # print("Empty message, ignoring")
            return
        # Use initial_prompt as args if provided (for !image command with prompt)
        args = form_data if form_data else (initial_prompt if initial_prompt else None)
        response = command_processor.process_command(message, user_uuid, sender, channel, args)
        if response:
            if 'modal_data' in response:
                # print(f"Emitting show_modal for {sender} in channel {channel}")
                emit('show_modal', {
                    'modal_data': response['modal_data'],
                    'channel': channel
                }, room=request.sid)
                return
            elif 'modal_result' in response:
                # Handle modal results (for image generation)
                # print(f"Handling modal result for {sender} in channel {channel}")
                modal_result = response['modal_result']
                emit('image_generation_result', modal_result, room=request.sid)

                # If there's also a message to save, handle it
                if 'message' in response:
                    if not validate_media_response(response):
                        # print(f"Invalid media response from command: {response}")
                        emit('error', {'msg': 'Invalid media data from command'}, room=request.sid)
                        return
                    save_and_emit_message(response, channel, sender, replied_to, socketio)
                    return
            else:
                # Regular command response with message
                if not validate_media_response(response):
                    # print(f"Invalid media response from command: {response}")
                    emit('error', {'msg': 'Invalid media data from command'}, room=request.sid)
                    return
                save_and_emit_message(response, channel, sender, replied_to, socketio)
                return

         # Handle regular messages (not from commands)
        # Extract image_url and thumbnail_url from message content if it's a media message with attachments
        image_url = None
        thumbnail_url = None
        if is_media and message:
            try:
                import json
                parsed = json.loads(message)
                if isinstance(parsed, dict) and 'attachments' in parsed and isinstance(parsed['attachments'], list) and len(parsed['attachments']) > 0:
                    attachment = parsed['attachments'][0]  # For single uploads, take the first attachment
                    if isinstance(attachment, dict):
                        image_url = attachment.get('url')
                        thumbnail_url = attachment.get('thumbnail_url')
            except (json.JSONDecodeError, KeyError, TypeError):
                # If parsing fails, keep URLs as None
                pass

        # Create a response dict for the unified save function
        regular_response = {
            'sender': sender,
            'message': message,
            'is_media': is_media,
            'image_url': image_url,
            'thumbnail_url': thumbnail_url
        }

        save_and_emit_message(regular_response, channel, sender, replied_to, socketio)

        # Check for AI mentions in channel messages (impersonation mode)
        import re
        mention_match = re.match(r'^@(\w+)', message.strip())
        if mention_match:
            mentioned_name = mention_match.group(1).lower()
            character_name = None

            if mentioned_name in ['ai', 'assistant']:
                # Check for character name in the message content after @ai
                message_after_mention = message.strip()[len('@' + mentioned_name):].strip()
                # Look for a character name (first word after @ai)
                words = message_after_mention.split()
                if words:
                    potential_character = words[0]
                    # Check if it's a valid character name
                    if ai_database.get_character(user_uuid, potential_character):
                        character_name = potential_character
                    else:
                        # Check for selected active character
                        user_ai_settings = get_user_ai_settings(user_uuid)
                        if user_ai_settings:
                            character_name = user_ai_settings.get('ai_active_character')
                            # If no active character is set, use default
                            if not character_name:
                                character_name = 'Helpful Assistant'
                else:
                    # No words after @ai, use active character
                    user_ai_settings = get_user_ai_settings(user_uuid)
                    if user_ai_settings:
                        character_name = user_ai_settings.get('ai_active_character')
                        # If no active character is set, use default
                        if not character_name:
                            character_name = 'Helpful Assistant'
            elif ai_database.get_character(user_uuid, mentioned_name.title()):
                character_name = mentioned_name.title()

            if mentioned_name in ['ai', 'assistant'] or character_name:
                # Determine interaction mode from message content
                interaction_mode = 'diverse'  # Default to diverse mode
                lower_message = message.lower()
                if '--one-off' in lower_message or '--once' in lower_message:
                    interaction_mode = 'one-off'
                    message = message.replace('--one-off', '').replace('--once', '').strip()
                elif '--focused' in lower_message:
                    interaction_mode = 'focused'
                    message = message.replace('--focused', '').strip()
                # Remove extra spaces that might result from flag removal
                message = ' '.join(message.split())

                # Trigger AI response asynchronously to avoid blocking
                import threading
                def handle_ai_mention():
                    try:
                        from .ai_handlers import handle_ai_channel_mention_standalone
                        handle_ai_channel_mention_standalone(socketio, users_db, users, {
                            'user_uuid': user_uuid,
                            'channel': channel,
                            'message': message,
                            'trigger_user': sender,
                            'character_name': character_name,
                            'interaction_mode': interaction_mode
                        })
                    except Exception as e:
                        print(f"Error handling AI mention: {str(e)}")

                ai_thread = threading.Thread(target=handle_ai_mention)
                ai_thread.daemon = True
                ai_thread.start()

    @socketio.on('load_more_messages')
    def handle_load_more_messages(data):
        channel = data.get('channel')
        before_message_id = data.get('before_message_id')
        if not channel or not before_message_id:
            emit('error', {'msg': 'User not authenticated, missing channel, or missing message ID'})
            return
        try:
            conn = sqlite3.connect('devchat.db')
            c = conn.cursor()
            c.execute("SELECT timestamp FROM messages WHERE id = ? AND channel = ?", (before_message_id, channel))
            row = c.fetchone()
            if not row:
                emit('error', {'msg': 'Message not found'})
                conn.close()
                return
            before_timestamp = row[0]
            c.execute("""SELECT m.id, m.sender, m.message, m.is_media, m.timestamp, m.replied_to,
                              m.image_url, m.thumbnail_url, m.avatar_url,
                              (SELECT COUNT(*) FROM messages r WHERE r.replied_to = m.id) as replies_count
                       FROM messages m WHERE m.channel = ? AND m.timestamp < ? ORDER BY m.timestamp DESC LIMIT 50""",
                      (channel, before_timestamp))
            messages = [
                {
                    'id': row[0],
                    'sender': row[1],
                    'message': row[2],
                    'is_media': row[3],
                    'timestamp': row[4],
                    'replied_to': row[5],
                    'image_url': row[6],
                    'thumbnail_url': row[7],
                    'avatar_url': row[8],
                    'replies_count': row[9],
                    'reactions': get_reactions(row[0])
                }
                for row in c.fetchall()
            ]
            conn.close()
            emit('channel_history', {
                'channel': channel,
                'messages': messages[::-1],
                'is_load_more': True
            })
        except Exception as e:
            emit('error', {'msg': f'Failed to load more messages: {str(e)}'})

    @socketio.on('get_reactions')
    def handle_get_reactions(data):
        try:
            message_id = int(data['message_id'])
        except (ValueError, TypeError):
            print(f"Invalid message_id received: {data.get('message_id')} (type: {type(data.get('message_id'))})")
            emit('error', {'msg': 'Invalid message ID format'})
            return

        channel = data['channel']
        user_uuid = users.get(request.sid)
        if not user_uuid or not message_id or not channel:
            emit('error', {'msg': 'User not authenticated, missing message ID, or missing channel'})
            return
        try:
            reactions = get_reactions(message_id)
            emit('receive_reactions', {
                'message_id': message_id,
                'reactions': reactions,
                'channel': channel
            })
        except Exception as e:
            emit('error', {'msg': f'Failed to fetch reactions: {str(e)}'})

    @socketio.on('add_reaction')
    def handle_add_reaction(data):
        try:
            message_id = int(data['message_id'])
        except (ValueError, TypeError):
            print(f"Invalid message_id received in add_reaction: {data.get('message_id')} (type: {type(data.get('message_id'))})")
            emit('error', {'msg': 'Invalid message ID format'})
            return

        user_uuid = users.get(request.sid)
        emoji = data['emoji']
        channel = data.get('channel')
        if not user_uuid or not message_id or not channel:
            emit('error', {'msg': 'User not authenticated, missing message ID, or missing channel'})
            return
        try:
            add_reaction(message_id, user_uuid, emoji)
            reactions = get_reactions(message_id)
            socketio.emit('receive_reactions', {
                'message_id': message_id,
                'reactions': reactions,
                'channel': channel
            }, room=channel)
        except Exception as e:
            emit('error', {'msg': f'Failed to add reaction: {str(e)}'})

    @socketio.on('remove_reaction')
    def handle_remove_reaction(data):
        try:
            message_id = int(data['message_id'])
        except (ValueError, TypeError):
            print(f"Invalid message_id received in remove_reaction: {data.get('message_id')} (type: {type(data.get('message_id'))})")
            emit('error', {'msg': 'Invalid message ID format'})
            return

        user_uuid = users.get(request.sid)
        emoji = data['emoji']
        channel = data.get('channel')
        if not user_uuid or not message_id or not channel:
            emit('error', {'msg': 'User not authenticated, missing message ID, or missing channel'})
            return
        try:
            remove_reaction(message_id, user_uuid, emoji)
            reactions = get_reactions(message_id)
            socketio.emit('receive_reactions', {
                'message_id': message_id,
                'reactions': reactions,
                'channel': channel
            }, room=channel)
        except Exception as e:
            emit('error', {'msg': f'Failed to remove reaction: {str(e)}'})

    @socketio.on('delete_message')
    def handle_delete_message(data):
        user_uuid = users.get(request.sid)
        message_id = data.get('message_id')
        channel = data.get('channel')
        if not message_id or not channel:
            emit('error', {'msg': 'Missing message ID or channel'})
            return

        # Get the message to check permissions
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("SELECT sender, message, ai_generated FROM messages WHERE id = ? AND channel = ?", (message_id, channel))
        row = c.fetchone()
        conn.close()
        if not row:
            print(f"DEBUG: Message {message_id} in channel {channel} not found")
            emit('error', {'msg': 'Message not found'})
            return

        sender, message_text, ai_generated = row
        print(f"DEBUG: Retrieved message {message_id}: sender={sender}, ai_generated={ai_generated} (raw type: {type(ai_generated)})")
        # Check if it's a cinema post (sender is media_download system user)
        media_download_sender = get_system_display_name('media_download')
        is_cinema_post = (sender == media_download_sender)
        # Ensure ai_generated is treated as integer
        ai_generated_int = int(ai_generated) if ai_generated is not None else 0
        is_ai_message = bool(ai_generated_int)
        print(f"DEBUG: ai_generated_int={ai_generated_int}, is_ai_message={is_ai_message}")

        # Debug logging
        print(f"DEBUG: message_id={message_id}, sender={sender}, ai_generated={ai_generated} (type: {type(ai_generated)}), is_ai_message={is_ai_message}")

        # Allow delete if user is the sender, it's a cinema post, or it's an AI-generated message
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return

        deleter_username = users_db.get(user_uuid, {}).get('username', 'unknown')
        print(f"User {deleter_username} ({user_uuid}) attempted to delete message {message_id} by {sender}, is_cinema: {is_cinema_post}, is_ai: {is_ai_message}")

        if not is_cinema_post and not is_ai_message and deleter_username != sender:
            emit('error', {'msg': 'You can only delete your own messages, cinema posts, or AI messages'})
            return

        # Delete the message from database
        if not delete_message(message_id):
            emit('error', {'msg': 'Failed to delete message'})
            return

        # Emit to channel that message was deleted
        socketio.emit('message_deleted', {'message_id': message_id, 'channel': channel}, room=channel)

    @socketio.on('start_typing')
    def handle_start_typing(data):
        channel = data.get('channel', '').strip()
        if not channel or request.sid not in users:
            return
        # Use display_name for consistency with what's shown in member list, fallback to username
        display_name = users_db[users[request.sid]].get('display_name') or users_db[users[request.sid]]['username']

        def remove_typing():
            if channel in typing_users and display_name in typing_users[channel]:
                typing_users[channel].remove(display_name)
                if not typing_users[channel]:
                    del typing_users[channel]
                socketio.emit('typing', {'users': list(typing_users.get(channel, set()))}, room=channel)

        if channel not in typing_users:
            typing_users[channel] = set()
        typing_users[channel].add(display_name)

        threading.Timer(3.0, remove_typing).start()

        socketio.emit('typing', {'users': list(typing_users[channel])}, room=channel)

    @socketio.on('share_image_generation')
    def handle_share_image_generation(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return
        generation_id = data.get('generation_id', '').strip()
        images = data.get('images', [])
        metadata = data.get('metadata', {})
        channel = data.get('channel', '').strip()
        sender = users_db[user_uuid]['username'] if user_uuid and user_uuid in users_db else 'Anonymous'
        print(f"Handling share_image_generation: sender={sender}, channel={channel}, images={len(images)}")
        if not generation_id or not images or not channel:
            emit('error', {'msg': 'Missing generation ID, images, or channel'})
            return

        try:
            # Create message content from images - use consistent attachment format
            # Handle both old format (images as simple objects) and new format (images with metadata)
            attachments = []
            for img in images:
                if isinstance(img, dict) and 'metadata' in img:
                    # New format: image has individual metadata
                    attachments.append({
                        'url': img['url'],
                        'thumbnail_url': img.get('thumbnail_url'),
                        'metadata': img['metadata']
                    })
                else:
                    # Old format: simple image object
                    attachments.append({
                        'url': img['url'],
                        'thumbnail_url': img.get('thumbnail_url'),
                        'metadata': metadata  # Use shared metadata
                    })

            message_data = {
                'message': f"Generated {len(images)} image{'s' if len(images) > 1 else ''}",
                'attachments': attachments,
                'metadata': metadata  # Keep for backward compatibility
            }
            message = json.dumps(message_data)
            is_media = True
            image_url = images[0]['url'] if images else None
            thumbnail_url = images[0]['thumbnail_url'] if images else None

            # Validate the message
            message_data = {
                'message': message,
                'is_media': is_media,
                'sender': sender
            }
            if image_url is not None:
                message_data['image_url'] = image_url
            if thumbnail_url is not None:
                message_data['thumbnail_url'] = thumbnail_url
            if not validate_media_response(message_data):
                emit('error', {'msg': 'Invalid image data'})
                return

            # Save the message to database
            conn = sqlite3.connect('devchat.db')
            c = conn.cursor()
            from database import get_standard_timestamp
            timestamp = get_standard_timestamp()
            c.execute("INSERT INTO messages (channel, sender, message, is_media, timestamp, replied_to, replied_sender, replied_text, image_url, thumbnail_url, generation_id, auto_share) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                      (channel, sender, message, is_media, timestamp, None, None, None, image_url, thumbnail_url, generation_id, 1))
            message_id = c.lastrowid
            conn.commit()
            conn.close()

            # Broadcast to channel
            socketio.emit('receive_message', {
                'id': message_id,
                'channel': channel,
                'sender': sender,
                'message': message,
                'is_media': is_media,
                'image_url': image_url,
                'thumbnail_url': thumbnail_url,
                'timestamp': timestamp,
                'replied_to': None,
                'replies_count': 0,
                'reactions': []
            }, room=channel)
            print("Sent receive_message for shared images")

        except Exception as e:
            # print(f"Error sharing generation: {str(e)}")
            emit('error', {'msg': 'Failed to share generation'})

    @socketio.on('share_selected_images')
    def handle_share_selected_images(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return
        images = data.get('images', [])
        channel = data.get('channel', '').strip()
        sender = users_db[user_uuid]['username'] if user_uuid and user_uuid in users_db else 'Anonymous'
        if not images or not channel:
            emit('error', {'msg': 'Missing images or channel'})
            return

        try:
            conn = sqlite3.connect('devchat.db')
            c = conn.cursor()
            from database import get_standard_timestamp
            timestamp = get_standard_timestamp()

            # Create message content with image attachments
            if len(images) == 1:
                message_content = f"Shared image"
                is_media = True
                image_url = images[0]['url']
                thumbnail_url = images[0].get('thumbnail_url')
            else:
                message_text = f"Shared {len(images)} images"
                attachments = []
                for img in images:
                    if isinstance(img, dict) and 'url' in img:
                        attachments.append({
                            'url': img['url'],
                            'thumbnail_url': img.get('thumbnail_url')
                        })

                # Create JSON message with attachments
                message_content = json.dumps({
                    'message': message_text,
                    'attachments': attachments
                })
                is_media = True
                image_url = None
                thumbnail_url = None

            # Save message to database
            c.execute("INSERT INTO messages (channel, sender, message, is_media, timestamp, replied_to, replied_sender, replied_text, image_url, thumbnail_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                      (channel, sender, message_content, is_media, timestamp, None, None, None, image_url, thumbnail_url))
            message_id = c.lastrowid
            conn.commit()
            conn.close()

            # Emit the shared message
            socketio.emit('receive_message', {
                'id': message_id,
                'channel': channel,
                'sender': sender,
                'message': message_content,
                'is_media': True,
                'timestamp': timestamp,
                'replied_to': None,
                'replies_count': 0,
                'reactions': []
            }, room=channel)

        except Exception as e:
            # print(f"Error sharing selected images: {str(e)}")
            emit('error', {'msg': 'Failed to share images'})

    @socketio.on('submit_image_form')
    def handle_submit_image_form(data):
        command = data.get('command', 'image')
        args = data.get('args', {})
        channel = data.get('channel', 'general')
        sender_sid = request.sid
        user_uuid = users.get(sender_sid)

        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return

        sender = users_db[user_uuid]['username'] if user_uuid and user_uuid in users_db else 'Anonymous'

        print(f"Processing submit_image_form from {sender} in channel {channel}")
        print(f"DEBUG: args = {args}")

        # Process the image command with form data
        response = command_processor.process_command('!image', user_uuid, sender, channel, args)
        print(f"DEBUG: response = {response}")

        if response:
            if 'modal_result' in response:
                # Send the result back to the client
                emit('image_generation_result', response['modal_result'], room=sender_sid)
            elif 'message' in response:
                # Handle error messages
                emit('error', {'msg': response['message']}, room=sender_sid)
            else:
                emit('error', {'msg': 'Unknown response from image command'}, room=sender_sid)

    @socketio.on('get_message')
    def handle_get_message(data):
        message_id = data.get('message_id')
        channel = data.get('channel')
        if not message_id or not channel:
            emit('error', {'msg': 'Missing message ID or channel'})
            return
        try:
            conn = sqlite3.connect('devchat.db')
            c = conn.cursor()
            c.execute("SELECT sender, message, is_media, timestamp, replied_to, replied_sender, replied_text FROM messages WHERE id = ? AND channel = ?", (message_id, channel))
            row = c.fetchone()
            conn.close()
            if row:
                emit('message_data', {
                    'message': {
                        'sender': row[0],
                        'message': row[1],
                        'is_media': row[2],
                        'timestamp': row[3],
                        'replied_to': row[4],
                        'replied_sender': row[5],
                        'replied_text': row[6]
                    }
                })
            else:
                emit('error', {'msg': 'Message not found'})
        except Exception as e:
            emit('error', {'msg': f'Failed to fetch message: {str(e)}'})

    @socketio.on('send_dm_message')
    def handle_send_dm_message(data):
        print(f"Received send_dm_message: {data}")
        sender_uuid = users.get(request.sid)
        if not sender_uuid:
            print("Not authenticated")
            emit('error', {'msg': 'Not authenticated'})
            return

        recipient_username = data.get('recipient_username')
        message = data.get('message', '').strip()
        is_media = data.get('is_media', 0)

        if not recipient_username or not message:
            emit('error', {'msg': 'Missing recipient or message'})
            return

        # Get recipient UUID
        from database import get_user_by_username
        recipient = get_user_by_username(recipient_username)
        if not recipient:
            emit('error', {'msg': 'Recipient not found'})
            return

        recipient_uuid = recipient['uuid']

        # Don't allow DMing yourself
        if sender_uuid == recipient_uuid:
            emit('error', {'msg': 'Cannot send DM to yourself'})
            return

        # Check if recipient allows DMs
        if not recipient.get('allow_dms', True):
            emit('error', {'msg': 'User does not accept DMs'})
            return

        # Add message to DB
        message_id = add_dm_message(sender_uuid, recipient_uuid, message, is_media)
        if not message_id:
            emit('error', {'msg': 'Failed to send DM'})
            return

        # Emit to sender
        emit('dm_message_sent', {
            'message_id': message_id,
            'recipient_username': recipient_username
        }, room=request.sid)

        # Emit to recipient if online
        recipient_sid = None
        for sid, uid in users.items():
            if uid == recipient_uuid:
                recipient_sid = sid
                break

        if recipient_sid:
            emit('dm_message_received', {
                'message_id': message_id,
                'sender_username': users_db[sender_uuid]['username'],
                'message': message,
                'is_media': is_media,
                'timestamp': None  # Will be loaded from DB
            }, room=recipient_sid)

    @socketio.on('load_dm_conversations')
    def handle_load_dm_conversations():
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'Not authenticated'})
            return

        conversations = get_dm_conversations(user_uuid)
        emit('dm_conversations_loaded', {'conversations': conversations}, room=request.sid)

    @socketio.on('load_dm_messages')
    def handle_load_dm_messages(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'Not authenticated'})
            return

        other_username = data.get('other_username')
        if not other_username:
            emit('error', {'msg': 'Missing other username'})
            return

        # Get other user UUID
        from database import get_user_by_username
        other_user = get_user_by_username(other_username)
        if not other_user:
            emit('error', {'msg': 'User not found'})
            return

        other_uuid = other_user['uuid']

        # Mark messages as read
        mark_dm_messages_read(user_uuid, other_uuid)

        # Load messages (initial load - last 50)
        messages = load_dm_messages(user_uuid, other_uuid, limit=50)
        emit('dm_messages_loaded', {
            'other_username': other_username,
            'messages': messages,
            'is_load_more': False
        }, room=request.sid)

    @socketio.on('load_more_dm_messages')
    def handle_load_more_dm_messages(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'Not authenticated'})
            return

        other_username = data.get('other_username')
        before_message_id = data.get('before_message_id')
        if not other_username or not before_message_id:
            emit('error', {'msg': 'Missing other username or before_message_id'})
            return

        # Get other user UUID
        from database import get_user_by_username
        other_user = get_user_by_username(other_username)
        if not other_user:
            emit('error', {'msg': 'User not found'})
            return

        other_uuid = other_user['uuid']

        # Load more messages
        messages = load_dm_messages(user_uuid, other_uuid, limit=50, before_message_id=before_message_id)
        emit('dm_messages_loaded', {
            'other_username': other_username,
            'messages': messages,
            'is_load_more': True
        }, room=request.sid)

    @socketio.on('delete_dm_chat_history')
    def handle_delete_dm_chat_history(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'Not authenticated'})
            return

        other_username = data.get('other_username')
        if not other_username:
            emit('error', {'msg': 'Missing other username'})
            return

        # Get other user UUID
        from database import get_user_by_username
        other_user = get_user_by_username(other_username)
        if not other_user:
            emit('error', {'msg': 'User not found'})
            return

        other_uuid = other_user['uuid']

        # Delete all DM messages between these users
        try:
            conn = sqlite3.connect('devchat.db')
            c = conn.cursor()
            c.execute("DELETE FROM dm_messages WHERE (sender_uuid = ? AND recipient_uuid = ?) OR (sender_uuid = ? AND recipient_uuid = ?)",
                     (user_uuid, other_uuid, other_uuid, user_uuid))
            deleted_count = c.rowcount
            conn.commit()
            conn.close()

            # Emit to both users to clear their chat history
            emit('dm_chat_history_deleted', {
                'other_username': other_username,
                'deleted_count': deleted_count
            }, room=request.sid)

            # Also emit to the other user if they're online
            for sid, uid in users.items():
                if uid == other_uuid:
                    emit('dm_chat_history_deleted', {
                        'other_username': users_db[user_uuid]['username'],
                        'deleted_count': deleted_count
                    }, room=sid)
                    break

            print(f"Deleted {deleted_count} DM messages between {users_db[user_uuid]['username']} and {other_username}")

        except Exception as e:
            emit('error', {'msg': f'Failed to delete chat history: {str(e)}'})

    @socketio.on('play_soundboard_sound')
    def handle_play_soundboard_sound(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'Not authenticated'})
            return

        sound_file = data.get('sound_file')
        if not sound_file:
            emit('error', {'msg': 'Missing sound file'})
            return

        # Validate sound file against allowed list
        allowed_sounds = [
            'Bonk.mp3', 'DuckQuack.mp3', 'drumroll_strong_Budum-tsss.mp3',
            'drumroll_tsss.mp3', 'single_ding.mp3', 'sucess_strings.mp3', 'tuba-womp.mp3',
            'synthetic-airhorn.mp3'
        ]

        if sound_file not in allowed_sounds:
            emit('error', {'msg': 'Invalid sound file'})
            return

        username = users_db[user_uuid]['username'] if user_uuid in users_db else 'Anonymous'

        # Broadcast to all connected users
        socketio.emit('soundboard_sound_played', {
            'sound_file': sound_file,
            'played_by': username
        })

        print(f"Soundboard sound '{sound_file}' played by {username}")

    @socketio.on('generate_more')
    def handle_generate_more(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return

        metadata = data.get('metadata', {})
        channel = data.get('channel', '').strip()
        sender = users_db[user_uuid]['username'] if user_uuid and user_uuid in users_db else 'Anonymous'

        if not metadata or not channel:
            emit('error', {'msg': 'Missing metadata or channel'})
            return

        print(f"Handling generate_more: sender={sender}, channel={channel}")

        try:
            # Import the image generation function
            from extensions.sd_integration import generate_image_from_metadata

            # Call the generation function
            result = generate_image_from_metadata(metadata, sender, channel, socketio)

            # If generation was successful, automatically share to chat
            if result and 'modal_result' in result:
                modal_result = result['modal_result']
                images = modal_result.get('images', [])

                if images:
                    # Automatically share the generated images to chat
                    generation_id = modal_result.get('generation_id', str(uuid.uuid4()))
                    share_data = {
                        'generation_id': generation_id,
                        'images': images,
                        'metadata': modal_result.get('metadata', {}),
                        'channel': channel
                    }

                    print(f"Auto-sharing {len(images)} generated images to channel {channel}")
                    # Call the share handler directly
                    handle_share_image_generation(share_data)
                else:
                    emit('error', {'msg': 'No images were generated'})
            else:
                emit('error', {'msg': 'Failed to generate image'})

        except Exception as e:
            print(f"Error in generate_more: {str(e)}")
            emit('error', {'msg': 'Failed to generate more images'})

    @socketio.on('img2img_more')
    def handle_img2img_more(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return

        image_base64 = data.get('image_base64', '')
        metadata = data.get('metadata', {})
        channel = data.get('channel', '').strip()
        sender = users_db[user_uuid]['username'] if user_uuid and user_uuid in users_db else 'Anonymous'

        if not image_base64 or not metadata or not channel:
            emit('error', {'msg': 'Missing image, metadata, or channel'})
            return

        print(f"Handling img2img_more: sender={sender}, channel={channel}")

        try:
            # Import the img2img generation function
            from extensions.sd_integration import generate_img2img_from_metadata

            # Call the img2img generation function
            result = generate_img2img_from_metadata(image_base64, metadata, sender, channel, socketio)

            # If generation was successful, automatically share to chat
            if result and 'modal_result' in result:
                modal_result = result['modal_result']
                images = modal_result.get('images', [])

                if images:
                    # Automatically share the generated images to chat
                    generation_id = modal_result.get('generation_id', str(uuid.uuid4()))
                    share_data = {
                        'generation_id': generation_id,
                        'images': images,
                        'metadata': modal_result.get('metadata', {}),
                        'channel': channel
                    }

                    print(f"Auto-sharing {len(images)} img2img generated images to channel {channel}")
                    # Call the share handler directly
                    handle_share_image_generation(share_data)
                else:
                    emit('error', {'msg': 'No images were generated'})
            else:
                emit('error', {'msg': 'Failed to generate img2img'})

        except Exception as e:
            print(f"Error in img2img_more: {str(e)}")
            emit('error', {'msg': 'Failed to generate img2img'})