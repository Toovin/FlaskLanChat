from flask_socketio import emit, join_room, leave_room
from flask import request
from flask_socketio_stubs import Request
from database import create_channel, update_channel, delete_channel, load_channels, load_media_channels, create_media_channel, delete_media_channel, load_messages
import re


def register_channel_handlers(socketio, users_db, channels, media_channels, users):
    @socketio.on('request_channels')
    def handle_request_channels():
        emit('update_channels', {'channels': load_channels()})
        emit('update_media_channels', {'channels': load_media_channels()})

    @socketio.on('join_channel')
    def handle_join_channel(data):
        channel_id = data['channel'].strip()
        if not any(c.get('id') == channel_id for c in channels):
            emit('error', {'msg': 'Channel does not exist'})
            return
        for old_channel in channels:
            if old_channel['id'] != channel_id:
                leave_room(old_channel['id'])
        join_room(channel_id)
        messages = load_messages(channel_id)[-100:]
        emit('channel_history', {
            'channel': channel_id,
            'messages': [{
                'id': m['id'],
                'sender': m['sender'],
                'message': m['message'],
                'is_media': m['is_media'],
                'timestamp': m['timestamp'],
                'replied_to': m['replied_to'],
                'image_url': m['image_url'],
                'thumbnail_url': m['thumbnail_url'],
                'replies_count': m['replies_count'],
                'reactions': m['reactions']
            } for m in messages],
            'is_load_more': False
        })

    @socketio.on('create_channel')
    def handle_create_channel(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return
        channel_name = data.get('channel', '').strip()
        channel_icon = data.get('icon', '').strip()
        ai_enabled = data.get('ai_enabled', True)
        ai_memory_limit = data.get('ai_memory_limit', 10)
        if not channel_name:
            emit('error', {'msg': 'Channel name is required'})
            return
        # Sanitize channel name (for display, but since name is display, allow spaces?)
        # For now, keep as is, but perhaps sanitize
        import re
        sanitized_name = re.sub(r'[^a-zA-Z0-9-_ ]', '-', channel_name).strip()
        if not sanitized_name or len(sanitized_name) > 50:
            emit('error', {'msg': 'Invalid channel name'})
            return
        import uuid
        channel_id = str(uuid.uuid4())
        try:
            if create_channel(channel_id, sanitized_name, channel_icon if channel_icon else None, ai_enabled, ai_memory_limit):
                # Reload channels and notify all users
                channels.clear()
                channels.extend(load_channels())
                socketio.emit('update_channels', {'channels': channels})
                emit('channel_created', {'channel': channel_id})
            else:
                emit('error', {'msg': 'Channel already exists'})
        except Exception as e:
            emit('error', {'msg': f'Failed to create channel: {str(e)}'})

    @socketio.on('update_channel')
    def handle_update_channel(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return
        channel_id = data.get('id', '').strip()
        new_name = data.get('name', '').strip()
        channel_icon = data.get('icon', '').strip()
        ai_enabled = data.get('ai_enabled')
        ai_memory_limit = data.get('ai_memory_limit')
        if not channel_id or not new_name:
            emit('error', {'msg': 'Channel id and name are required'})
            return
        # Sanitize new channel name
        import re
        sanitized_name = re.sub(r'[^a-zA-Z0-9-_ ]', '-', new_name).strip()
        if not sanitized_name or len(sanitized_name) > 50:
            emit('error', {'msg': 'Invalid channel name'})
            return
        # Check if new name conflicts with existing (except itself)
        existing_channels = load_channels()
        if any(c['name'] == sanitized_name and c['id'] != channel_id for c in existing_channels):
            emit('error', {'msg': 'Channel name already exists'})
            return
        try:
            if update_channel(channel_id, sanitized_name, channel_icon if channel_icon else None, ai_enabled, ai_memory_limit):
                # Reload channels and notify all users
                channels.clear()
                channels.extend(load_channels())
                socketio.emit('update_channels', {'channels': channels})
                emit('channel_updated', {'channel_id': channel_id, 'new_name': sanitized_name})
            else:
                emit('error', {'msg': 'Failed to update channel'})
        except Exception as e:
            emit('error', {'msg': f'Failed to update channel: {str(e)}'})

    @socketio.on('delete_channel')
    def handle_delete_channel(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return
        channel_id = data.get('channel', '').strip()
        if not channel_id:
            emit('error', {'msg': 'Channel id is required'})
            return
        if channel_id == 'general':
            emit('error', {'msg': 'Cannot delete the general channel'})
            return
        try:
            if delete_channel(channel_id):
                # Reload channels and notify all users
                channels.clear()
                channels.extend(load_channels())
                socketio.emit('update_channels', {'channels': channels})
                emit('channel_deleted', {'channel': channel_id})
            else:
                emit('error', {'msg': 'Failed to delete channel'})
        except Exception as e:
            emit('error', {'msg': f'Failed to delete channel: {str(e)}'})

    @socketio.on('create_media_channel')
    def handle_create_media_channel(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return
        channel_name = data.get('channel', '').strip()
        if not channel_name:
            emit('error', {'msg': 'Channel name is required'})
            return
        # Sanitize channel name
        import re
        channel_name = re.sub(r'[^a-zA-Z0-9-_]', '-', channel_name).lower()
        channel_name = re.sub(r'-+', '-', channel_name).strip('-')
        if not channel_name or len(channel_name) > 50:
            emit('error', {'msg': 'Invalid channel name'})
            return
        try:
            if create_media_channel(channel_name):
                # Reload media channels and notify all users
                media_channels.clear()
                media_channels.extend(load_media_channels())
                socketio.emit('update_media_channels', {'channels': media_channels})
                emit('media_channel_created', {'channel': channel_name})
            else:
                emit('error', {'msg': 'Media channel already exists'})
        except Exception as e:
            emit('error', {'msg': f'Failed to create media channel: {str(e)}'})

    @socketio.on('delete_media_channel')
    def handle_delete_media_channel(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return
        channel_name = data.get('channel', '').strip()
        if not channel_name:
            emit('error', {'msg': 'Channel name is required'})
            return
        if channel_name == 'default':
            emit('error', {'msg': 'Cannot delete the default media channel'})
            return
        try:
            if delete_media_channel(channel_name):
                # Reload media channels and notify all users
                media_channels.clear()
                media_channels.extend(load_media_channels())
                socketio.emit('update_media_channels', {'channels': media_channels})
                emit('media_channel_deleted', {'channel': channel_name})
            else:
                emit('error', {'msg': 'Failed to delete media channel'})
        except Exception as e:
            emit('error', {'msg': f'Failed to delete media channel: {str(e)}'})