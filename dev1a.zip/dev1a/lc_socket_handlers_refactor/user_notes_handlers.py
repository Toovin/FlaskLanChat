from flask_socketio import emit
from flask import request
from flask_socketio_stubs import Request


def register_user_notes_handlers(socketio, users_db, users):
    @socketio.on('get_user_notes')
    def handle_get_user_notes(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return

        try:
            from database import get_user_notes
            notes = get_user_notes(user_uuid)
            emit('user_notes_loaded', {'notes': notes})
        except Exception as e:
            emit('error', {'msg': f'Failed to load notes: {str(e)}'})

    @socketio.on('create_user_note')
    def handle_create_user_note(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return

        note_uuid = data.get('note_uuid')
        title = data.get('title', '').strip()
        content = data.get('content', '')

        if not note_uuid or not title:
            emit('error', {'msg': 'Note UUID and title are required'})
            return

        try:
            from database import create_user_note, get_standard_timestamp
            if create_user_note(user_uuid, note_uuid, title, content):
                timestamp = get_standard_timestamp()
                emit('note_created', {
                    'note_uuid': note_uuid,
                    'title': title,
                    'content': content,
                    'created_at': timestamp,
                    'updated_at': timestamp
                })
            else:
                emit('error', {'msg': 'Failed to create note'})
        except Exception as e:
            emit('error', {'msg': f'Failed to create note: {str(e)}'})

    @socketio.on('update_user_note')
    def handle_update_user_note(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return

        note_uuid = data.get('note_uuid')
        title = data.get('title', '').strip()
        content = data.get('content', '')

        if not note_uuid or not title:
            emit('error', {'msg': 'Note UUID and title are required'})
            return

        try:
            from database import update_user_note
            updated_note = update_user_note(note_uuid, title, content)
            if updated_note:
                emit('note_updated', {
                    'note_uuid': updated_note['uuid'],
                    'title': updated_note['title'],
                    'content': updated_note['content'],
                    'updated_at': updated_note['updated_at']
                })
            else:
                emit('error', {'msg': 'Failed to update note'})
        except Exception as e:
            emit('error', {'msg': f'Failed to update note: {str(e)}'})

    @socketio.on('delete_user_note')
    def handle_delete_user_note(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return

        note_uuid = data.get('note_uuid')
        if not note_uuid:
            emit('error', {'msg': 'Note UUID is required'})
            return

        try:
            from database import delete_user_note
            if delete_user_note(note_uuid):
                emit('note_deleted', {'note_uuid': note_uuid})
            else:
                emit('error', {'msg': 'Failed to delete note'})
        except Exception as e:
            emit('error', {'msg': f'Failed to delete note: {str(e)}'})

    @socketio.on('rename_user_note')
    def handle_rename_user_note(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return

        note_uuid = data.get('note_uuid')
        new_title = data.get('new_title', '').strip()

        if not note_uuid or not new_title:
            emit('error', {'msg': 'Note UUID and new title are required'})
            return

        try:
            from database import rename_user_note
            updated_note = rename_user_note(note_uuid, new_title)
            if updated_note:
                emit('note_renamed', {
                    'note_uuid': updated_note['uuid'],
                    'new_title': updated_note['title'],
                    'updated_at': updated_note['updated_at']
                })
            else:
                emit('error', {'msg': 'Failed to rename note'})
        except Exception as e:
            emit('error', {'msg': f'Failed to rename note: {str(e)}'})