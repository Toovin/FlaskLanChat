from flask_socketio import emit
from flask import request
import uuid
import threading


def register_call_handlers(socketio, users_db, users, call_states, call_lock):
    @socketio.on('initiate_call')
    def handle_initiate_call(data):
        caller_uuid = users.get(request.sid)
        if not caller_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return

        target_uuid = data.get('target')
        if not target_uuid or target_uuid not in users_db:
            emit('error', {'msg': 'Invalid target user'})
            return

        # Check if target user is online
        if target_uuid not in users_db:
            emit('error', {'msg': 'User is not online'})
            return

        # Check for existing active calls between these users
        existing_call_id = None
        for cid, info in call_states.items():
            if ((info['caller'] == caller_uuid and info['callee'] == target_uuid) or
                (info['caller'] == target_uuid and info['callee'] == caller_uuid)) and info['state'] != 'ended':
                existing_call_id = cid
                break

        if existing_call_id:
            # Force end the existing call
            existing_info = call_states[existing_call_id]
            existing_info['state'] = 'ended'
            # Notify both parties of forced end
            caller_sid = None
            for sid, uid in users.items():
                if uid == existing_info['caller']:
                    caller_sid = sid
                    break
            callee_sid = None
            for sid, uid in users.items():
                if uid == existing_info['callee']:
                    callee_sid = sid
                    break
            if caller_sid:
                emit('call_ended', {'call_id': existing_call_id, 'ended_by': 'system', 'reason': 'new_call_initiated'}, to=caller_sid)
            if callee_sid:
                emit('call_ended', {'call_id': existing_call_id, 'ended_by': 'system', 'reason': 'new_call_initiated'}, to=callee_sid)
            del call_states[existing_call_id]
            # print(f"Forced end of existing call {existing_call_id} due to new call initiation between {caller_uuid} and {target_uuid}")

        # Create call ID and room name
        call_id = str(uuid.uuid4())
        users_sorted = sorted([caller_uuid, target_uuid])
        room_name = f"private-{users_sorted[0]}-{users_sorted[1]}"

        # Store call state
        call_states[call_id] = {
            'caller': caller_uuid,
            'callee': target_uuid,
            'state': 'ringing',
            'room': room_name,
            'call_id': call_id
        }

        # Send incoming call notification to target user
        target_sid = None
        for sid, uid in users.items():
            if uid == target_uuid:
                target_sid = sid
                break
        caller_info = users_db[caller_uuid]
        emit('incoming_call', {
            'caller': caller_info.get('username', caller_uuid),
            'caller_uuid': caller_uuid,
            'call_id': call_id
        }, to=target_sid)

        # Confirm to caller that call is initiated
        emit('call_initiated', {
            'call_id': call_id,
            'target': target_uuid,
            'room': room_name
        })

        # print(f"Call initiated: {caller_uuid} -> {target_uuid}, call_id: {call_id}")

    @socketio.on('accept_call')
    def handle_accept_call(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return

        call_id = data.get('call_id')
        if not call_id or call_id not in call_states:
            emit('error', {'msg': 'Invalid call ID'})
            return

        call_info = call_states[call_id]
        if call_info['callee'] != user_uuid:
            emit('error', {'msg': 'Not authorized to accept this call'})
            return

        # Update call state to call negotiating
        call_info['state'] = 'call negotiating'

        # Notify both parties
        caller_sid = None
        for sid, uid in users.items():
            if uid == call_info['caller']:
                caller_sid = sid
                break
        callee_sid = None
        for sid, uid in users.items():
            if uid == call_info['callee']:
                callee_sid = sid
                break

        emit('call_accepted', {
            'call_id': call_id,
            'room': call_info['room'],
            'caller_uuid': call_info['caller'],
            'callee_uuid': call_info['callee']
        }, to=caller_sid)

        emit('call_accepted', {
            'call_id': call_id,
            'room': call_info['room'],
            'caller_uuid': call_info['caller'],
            'callee_uuid': call_info['callee']
        }, to=callee_sid)

        # After negotiation period, set to call connected
        def set_call_connected():
            if call_id in call_states and call_states[call_id]['state'] == 'call negotiating':
                call_states[call_id]['state'] = 'call connected'
                if caller_sid:
                    socketio.emit('call_connected', {'call_id': call_id}, to=caller_sid)
                if callee_sid:
                    socketio.emit('call_connected', {'call_id': call_id}, to=callee_sid)

        threading.Timer(3.0, set_call_connected).start()  # 3 seconds for negotiation

        # print(f"Call accepted: {call_id}")

    @socketio.on('decline_call')
    def handle_decline_call(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return

        call_id = data.get('call_id')
        if not call_id or call_id not in call_states:
            emit('error', {'msg': 'Invalid call ID'})
            return

        call_info = call_states[call_id]
        if call_info['callee'] != user_uuid:
            emit('error', {'msg': 'Not authorized to decline this call'})
            return

        # Update call state
        call_info['state'] = 'ended'

        # Notify caller
        caller_sid = None
        for sid, uid in users.items():
            if uid == call_info['caller']:
                caller_sid = sid
                break
        emit('call_declined', {
            'call_id': call_id,
            'callee': users_db[call_info['callee']].get('username', call_info['callee'])
        }, to=caller_sid)

        # Clean up call state
        del call_states[call_id]

        # print(f"Call declined: {call_id}")

    @socketio.on('end_call')
    def handle_end_call(data):
        user_uuid = users.get(request.sid)
        if not user_uuid:
            emit('error', {'msg': 'User not authenticated'})
            return

        call_id = data.get('call_id')
        if not call_id or call_id not in call_states:
            emit('error', {'msg': 'Invalid call ID'})
            return

        call_info = call_states[call_id]
        if call_info['caller'] != user_uuid and call_info['callee'] != user_uuid:
            emit('error', {'msg': 'Not authorized to end this call'})
            return

        # Update call state to call ending
        call_info['state'] = 'call ending'

        # Notify both parties
        caller_sid = None
        for sid, uid in users.items():
            if uid == call_info['caller']:
                caller_sid = sid
                break
        callee_sid = None
        for sid, uid in users.items():
            if uid == call_info['callee']:
                callee_sid = sid
                break

        if caller_sid:
            emit('call_ended', {'call_id': call_id, 'ended_by': user_uuid}, to=caller_sid)
        if callee_sid:
            emit('call_ended', {'call_id': call_id, 'ended_by': user_uuid}, to=callee_sid)

        # Clean up call state
        del call_states[call_id]

        # print(f"Call ended: {call_id}")