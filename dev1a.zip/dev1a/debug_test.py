#!/usr/bin/env python3
import requests
import json

print("Starting test...")

url = 'http://127.0.0.1:1234/v1/responses'
payload = {
    'model': 'auto',
    'input': 'Hello, what is 2+2?',
    'max_output_tokens': 100,
    'temperature': 0.7
}
headers = {'Content-Type': 'application/json'}

print("Making request...")
try:
    response = requests.post(url, json=payload, headers=headers, timeout=30)
    print(f'Status: {response.status_code}')
    print(f'Response: {response.text[:200]}...')
except Exception as e:
    print(f'Error: {e}')
    import traceback
    traceback.print_exc()

print("Test complete.")