import os
import cv2
import numpy as np
from PIL import Image
from lc_routes_refactor.utility_functions import generate_thumbnail

def generate_thumbnails():
    """Generate thumbnails for images in UPLOAD_DIR if they don't exist."""
    upload_path = UPLOAD_DIR
    thumbnails_path = os.path.join('static', 'thumbnails', 'uploads')
    valid_extensions = ['.png', '.jpg', '.jpeg', '.gif', '.webp']

    try:
        os.makedirs(thumbnails_path, exist_ok=True)
        print(f"Ensured thumbnail directory exists: {thumbnails_path}")

        for filename in os.listdir(upload_path):
            if filename.lower().endswith(tuple(valid_extensions)):
                file_path = os.path.join(upload_path, filename)
                if not os.path.isfile(file_path):
                    print(f"Skipping non-file entry: {file_path}")
                    continue
                thumbnail_filename = f"{os.path.splitext(filename)[0]}_thumb.jpg"
                thumbnail_filepath = os.path.join(thumbnails_path, thumbnail_filename)
                if not os.path.exists(thumbnail_filepath):
                    print(f"Generating thumbnail for {filename}")
                    if generate_thumbnail(file_path, thumbnail_filepath):
                        print(f"Generated thumbnail: {thumbnail_filepath}")
                    else:
                        print(f"Failed to generate thumbnail for {filename}")
                else:
                    print(f"Thumbnail already exists: {thumbnail_filepath}")
            else:
                print(f"Skipping non-image file: {filename}")
    except Exception as e:
        print(f"Error processing thumbnails: {str(e)}")

if __name__ == "__main__":
    generate_thumbnails()