import os
from PIL import Image
import cv2
import numpy as np
from lc_routes_refactor.utility_functions import generate_thumbnail

# Configuration constants
UPLOAD_DIR = 'static/uploads'
THUMBNAILS_DIR = 'static/thumbnails/uploads'

# Export for proper importing
__all__ = ['UPLOAD_DIR', 'THUMBNAILS_DIR']

