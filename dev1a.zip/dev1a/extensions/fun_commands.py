def setup(command_processor):
    """Setup function to register commands with the CommandProcessor."""

    def fitb(args, sender, channel):
        """Command: !fitb - Returns a fun message."""
        return {'message': "Fire in the Bowl!! 🔥"}

    def poof(args, sender, channel):
        """Command: !poof - Clears user's AI conversation history and sets a hard stop for channel context."""
        try:
            from database import get_user_by_username
            from ai_database import ai_database

            # Get user
            user = get_user_by_username(sender)
            if not user:
                return {'message': 'User not found'}

            user_uuid = user['uuid']

            # Archive all AI conversations for this user (mark as poofed instead of deleting)
            conversations = ai_database.get_user_conversations(user_uuid)
            archived_count = 0

            for conv in conversations:
                # Update conversation title to indicate it was poofed
                poof_title = f"[POOFED] {conv.get('title', 'Untitled')} - {sender}"
                if ai_database.update_conversation_title(conv['id'], poof_title):
                    archived_count += 1

            # Return a response that includes a hidden marker for context hard stop
            # The marker will be invisible to users but detectable by the AI context loader
            marker_message = "[POOF_RESET_MARKER]"
            visible_message = f"Poof! 💨 Archived {archived_count} AI conversation(s) from your history. Your AI chats have been reset!" if archived_count > 0 else "Poof! 💨 No AI conversations found to archive."

            # Return both visible message and marker separately
            return {
                'message': visible_message,
                'ai_context_marker': marker_message  # Special field for context control
            }

        except Exception as e:
            print(f"Error in poof command: {e}")
            return {'message': 'Error clearing AI history'}

    def roll(args, sender, channel):
        """Command: !roll - Rolls virtual dice with D&D-style notation (e.g., 2d20, 3d6+5, advantage 2d20)."""
        import random

        # Helper function to parse dice string (handles + and - modifiers)
        def parse_dice(dice_str):
            """Parses dice string into components (dice_count, sides, modifier)."""
            dice_str = dice_str.replace(" ", "").lower()

            # Check for modifier (+ or -)
            if '+' in dice_str or '-' in dice_str:
                # Split into dice and modifier
                if '+' in dice_str:
                    parts = dice_str.split('+')
                    dice_part = parts[0]
                    modifier_str = parts[1]
                else:
                    parts = dice_str.split('-')
                    dice_part = parts[0]
                    modifier_str = parts[1]

                # Parse dice part
                try:
                    dice_count, sides = dice_part.split('d')
                    dice_count = int(dice_count)
                    sides = int(sides)
                except (ValueError, IndexError):
                    return None, None, None

                # Parse modifier
                try:
                    modifier = int(modifier_str)
                except ValueError:
                    return None, None, None
                return dice_count, sides, modifier

            else:
                # No modifier
                try:
                    dice_count, sides = dice_str.split('d')
                    dice_count = int(dice_count)
                    sides = int(sides)
                except (ValueError, IndexError):
                    return None, None, None
                return dice_count, sides, 0

        # Split input into tokens
        tokens = args.strip().lower().split()

        # Handle empty input
        if not tokens:
            return {'message': f"{sender} rolled a {random.randint(1, 6)} on a 6-sided die! 🎲"}

        # Check for advantage/disadvantage
        is_advantage = tokens[0] == "advantage"
        is_disadvantage = tokens[0] == "disadvantage"

        # Handle standard rolls (no advantage/disadvantage)
        if not is_advantage and not is_disadvantage:
            dice_str = tokens[0]
            dice_count, sides, modifier = parse_dice(dice_str)

            if dice_count is None or sides is None or modifier is None:
                return {'message': (
                    f"Invalid dice notation. Example: 2d20, 3d6+5. "
                    f"You typed: {dice_str}"
                )}

            # Generate dice rolls
            rolls = [random.randint(1, sides) for _ in range(dice_count)]
            total = sum(rolls) + modifier

            # Format results
            roll_breakdown = "  Result: " + "+".join(str(d) for d in rolls) + " = " + str(total)
            return {'message': (
                f"{sender} rolled a {dice_count}d{sides}...:\n"
                f"{roll_breakdown}\n"
                f"{sender} rolled a {total} total!"
            )}

        # Handle advantage/disadvantage rolls
        else:
            dice_str = tokens[1]
            dice_count, sides, modifier = parse_dice(dice_str)

            if dice_count is None or sides is None or modifier is None:
                return {'message': (
                    f"Invalid dice notation. Example: advantage 2d20, disadvantage 4d6. "
                    f"You typed: {dice_str}"
                )}

            # Generate two separate rolls
            roll1 = [random.randint(1, sides) for _ in range(dice_count)]
            roll2 = [random.randint(1, sides) for _ in range(dice_count)]

            # Calculate totals
            total1 = sum(roll1) + modifier
            total2 = sum(roll2) + modifier

            # Format individual roll breakdowns
            def format_roll(roll, total):
                return f"    #{roll}: ({'+'.join(str(d) for d in roll)}) + {modifier} = {total}"

            # Determine winner
            if is_advantage:
                winner = "highest"
                winner_roll = max(total1, total2)
                winner_index = 1 if total1 > total2 else 2
            else:
                winner = "lowest"
                winner_roll = min(total1, total2)
                winner_index = 1 if total1 < total2 else 2

            # Build output
            output = (
                f"{sender} rolls a {dice_count}d{sides} with {('advantage' if is_advantage else 'disadvantage')}! "
                f"Rolls are...:\n"
                f"{format_roll(roll1, total1)}\n"
                f"{format_roll(roll2, total2)}\n"
                f"{winner} roll #{winner_index} is {winner} with {winner_roll}!"
            )

            return {'message': output}

    def clear_ai(args, sender, channel, socketio_instance):
        """Clear all AI-generated messages from the current channel"""
        try:
            import sqlite3
            from database import get_user_by_username

            # Check if user is admin (optional - allow anyone for now)
            user = get_user_by_username(sender)
            if not user:
                return {'message': 'User not found'}

            # Connect to database and delete AI messages
            conn = sqlite3.connect('devchat.db')
            c = conn.cursor()

            # Get count of AI messages before deletion
            c.execute("SELECT COUNT(*) FROM messages WHERE channel = ? AND ai_generated = 1", (channel,))
            count_before = c.fetchone()[0]

            if count_before == 0:
                conn.close()
                return {'message': f'No AI messages found in #{channel}'}

            # Delete AI messages
            c.execute("DELETE FROM messages WHERE channel = ? AND ai_generated = 1", (channel,))
            deleted_count = c.rowcount
            conn.commit()
            conn.close()

            # Emit update to refresh channel history
            if socketio_instance:
                from database import load_messages
                messages = load_messages(channel)[-100:]
                socketio_instance.emit('channel_history', {
                    'channel': channel,
                    'messages': [{
                        'id': m['id'],
                        'sender': m['sender'],
                        'message': m['message'],
                        'is_media': m['is_media'],
                        'timestamp': m['timestamp'],
                        'replied_to': m['replied_to'],
                        'image_url': m['image_url'],
                        'thumbnail_url': m['thumbnail_url'],
                        'replies_count': m['replies_count'],
                        'reactions': m['reactions']
                    } for m in messages],
                    'is_load_more': False
                }, room=channel)

            return {'message': f'Cleared {deleted_count} AI message(s) from #{channel}'}

        except Exception as e:
            print(f"Error in clear_ai command: {e}")
            return {'message': 'Error clearing AI messages'}

    # Register commands
    command_processor.register_command('fitb', fitb)
    command_processor.register_command('poof', poof)
    command_processor.register_command('roll', roll)
    command_processor.register_command('clearai', clear_ai)
