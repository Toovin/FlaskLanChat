import requests
import base64
import io
from PIL import Image
import os
import json
from datetime import datetime
import re
import hashlib
import uuid
import requests
from lc_routes_refactor.utility_functions import generate_thumbnail
from lc_config import SERVER_PORT, USE_HTTPS

UPLOAD_DIR = 'static/uploads'
THUMBNAILS_DIR = 'static/thumbnails/uploads'

# Global state for current image generation
current_generation_status = {
    'active': False,
    'progress': 0,
    'generation_id': None,
    'channel': None,
    'sender': None
}


def sanitize_filename(text, max_length=30):
    """
    Sanitize text for use as filename by removing/replacing special characters
    that can cause filesystem or command execution issues.
    """
    if not text:
        return "generated_image"

    # Convert to string if not already
    text = str(text)

    # Remove or replace problematic characters
    # Keep only alphanumeric, spaces, hyphens, and underscores
    sanitized = re.sub(r'[^\w\s\-_]', '', text)

    # Replace spaces with underscores
    sanitized = sanitized.replace(' ', '_')

    # Remove multiple consecutive underscores
    sanitized = re.sub(r'_+', '_', sanitized)

    # Remove leading/trailing underscores and whitespace
    sanitized = sanitized.strip('_ \t\n\r')

    # Ensure it's not empty after sanitization
    if not sanitized or sanitized.isspace():
        sanitized = "generated_image"

    # Truncate to max length
    return sanitized[:max_length]


def sanitize_prompt(prompt):
    """
    Sanitize prompt text to ensure it can be safely base64 encoded for metadata storage.
    Keeps all Latin1 characters (0-255) including punctuation, brackets, braces, colons, etc.
    Removes characters outside the Latin1 range that would cause btoa() to fail in JavaScript.
    """
    if not prompt:
        return ""

    # Convert to string if not already
    prompt = str(prompt)

    # Keep only characters in the Latin1 range (0-255)
    # This preserves ASCII punctuation, letters, digits, and common symbols
    sanitized = ''.join(c for c in prompt if ord(c) <= 255)

    return sanitized


def load_samplers(api_url):
    """Fetch samplers from the API with fallback defaults."""
    try:
        response = requests.get(f"{api_url.rstrip('/')}/sdapi/v1/samplers", timeout=10)
        response.raise_for_status()
        samplers = response.json()
        return [
            {
                'value': s['name'],
                'label': s.get('label', s['name']),
                'recommended_scheduler': s.get('options', {}).get('scheduler', None)
            }
            for s in samplers
        ]
    except requests.RequestException as e:
        print(f"Failed to fetch samplers from API: {str(e)}. Using fallback.")
        return [
            {'value': 'Euler', 'label': 'Euler', 'recommended_scheduler': None},
            {'value': 'DPM++ 3M SDE', 'label': 'DPM++ 3M SDE', 'recommended_scheduler': 'exponential'}
        ]


def load_schedulers(api_url):
    """Fetch schedulers from the API with fallback defaults."""
    try:
        response = requests.get(f"{api_url.rstrip('/')}/sdapi/v1/schedulers", timeout=10)
        response.raise_for_status()
        schedulers = response.json()
        return [{'value': s['name'], 'label': s.get('label', s['name'])} for s in schedulers]
    except requests.RequestException as e:
        print(f"Failed to fetch schedulers from API: {str(e)}. Using fallback.")
        return [
            {'value': 'Simple', 'label': 'Simple'},
            {'value': 'exponential', 'label': 'Exponential'}
        ]


def load_models(api_url):
    """Fetch models from the API with fallback defaults."""
    try:
        response = requests.get(f"{api_url.rstrip('/')}/sdapi/v1/sd-models", timeout=10)
        response.raise_for_status()
        models = response.json()
        return [
            {
                'value': m['model_name'],
                'label': m.get('title', m['model_name']),
                'hash': m.get('hash', ''),
                'filename': m.get('filename', '')
            }
            for m in models
        ]
    except requests.RequestException as e:
        print(f"Failed to fetch models from API: {str(e)}. Using fallback.")
        return [
            {'value': 'pixelArtDiffusionXL', 'label': 'pixelArtDiffusionXL.safetensors [7adffa28d4]', 'hash': '7adffa28d4',
             'filename': ''},
            {'value': 'juggernautXL', 'label': 'juggernautXL.safetensors [33e58e8668]', 'hash': '33e58e8668',
             'filename': ''}
        ]


def setup(command_processor):
    """Setup function to register commands with the CommandProcessor."""
    # Load config
    config_path = os.path.join(os.path.dirname(__file__), '..', 'sd_config.json')
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
    except FileNotFoundError:
        raise FileNotFoundError("sd_config.json not found")
    except json.JSONDecodeError:
        raise ValueError("Invalid JSON in sd_config.json")

    # Load samplers, schedulers, and models from API
    base_api_url = config.get('sd_api_url', 'http://127.0.0.1:7860')
    try:
        SAMPLERS = load_samplers(base_api_url)
        SCHEDULERS = load_schedulers(base_api_url)
        MODELS = load_models(base_api_url)
        print(
            f"Successfully loaded {len(SAMPLERS)} samplers, {len(SCHEDULERS)} schedulers, and {len(MODELS)} models from API")
    except Exception as e:
        print(f"Failed to load samplers, schedulers, or models from API: {str(e)}. Using fallbacks.")
        SAMPLERS = [
            {'value': 'Euler', 'label': 'Euler', 'recommended_scheduler': None},
            {'value': 'DPM++ 3M SDE', 'label': 'DPM++ 3M SDE', 'recommended_scheduler': 'exponential'}
        ]
        SCHEDULERS = [
            {'value': 'Simple', 'label': 'Simple'},
            {'value': 'exponential', 'label': 'Exponential'}
        ]
        MODELS = [
            {'value': 'pixelArtDiffusionXL', 'label': 'pixelArtDiffusionXL.safetensors [7adffa28d4]', 'hash': '7adffa28d4',
             'filename': ''},
            {'value': 'juggernautXL', 'label': 'juggernautXL.safetensors [33e58e8668]', 'hash': '33e58e8668',
             'filename': ''}
        ]

    api_url = f"{base_api_url.rstrip('/')}/sdapi/v1/txt2img"
    default_width = config.get('default_width', 1024)
    default_height = config.get('default_height', 1024)
    default_steps = config.get('default_steps', 35)
    default_cfg_scale = config.get('default_cfg_scale', 7)
    default_negative_prompt = config.get('negative_prompt', '')
    default_sampler_name = config.get('sampler_name', 'DPM++ 3M SDE')
    default_scheduler_name = config.get('scheduler_name', 'Simple')
    default_clip_skip = config.get('default_clip_skip', 2)
    default_batch_size = config.get('default_batch_size', 1)

    def image(args, sender, channel, socketio):
        """Command: !image [prompt] - Opens modal with optional prompt prefill, or generates with form data."""
        print(f"Processing !image command from {sender} in channel {channel}")
        if not args or not isinstance(args, dict):
            prompt_prefill = args.strip() if args else ''
            print(f"Opening modal with prompt prefill: '{prompt_prefill}'")

            # Fetch options dynamically to ensure we have the latest available options
            try:
                # Load config to get API URL
                config_path = os.path.join(os.path.dirname(__file__), '..', 'sd_config.json')
                with open(config_path, 'r') as f:
                    config = json.load(f)
                api_url = config.get('sd_api_url', 'http://127.0.0.1:7860')

                current_samplers = load_samplers(api_url)
                current_schedulers = load_schedulers(api_url)
                current_models = load_models(api_url)
                print(
                    f"Fetched {len(current_samplers)} samplers, {len(current_schedulers)} schedulers, and {len(current_models)} models for modal")
            except Exception as e:
                print(f"Failed to fetch current options: {str(e)}, using cached options")
                current_samplers = SAMPLERS
                current_schedulers = SCHEDULERS
                current_models = MODELS

            # Load user preferences
            try:
                from database import get_user_image_preferences, get_user_by_username
                user_info = get_user_by_username(sender)
                if user_info:
                    user_prefs = get_user_image_preferences(user_info['uuid'])
                    print(f"Loaded user preferences for {sender}: model={user_prefs['model_name']}")
                else:
                    raise Exception(f"User {sender} not found")
            except Exception as e:
                print(f"Failed to load user preferences: {str(e)}, using defaults")
                user_prefs = {
                    'model_name': current_models[0]['value'] if current_models else '',
                    'width': default_width,
                    'height': default_height,
                    'steps': default_steps,
                    'cfg_scale': default_cfg_scale,
                    'clip_skip': default_clip_skip,
                    'negative_prompt': default_negative_prompt,
                    'sampler_name': default_sampler_name,
                    'scheduler_name': default_scheduler_name,
                    'batch_size': default_batch_size,
                    'uploaded_image': None
                }

            return {
                'modal_data': {
                    'open_modal': True,
                    'mode': 'txt2img',
                    'prompt': prompt_prefill,
                    'width': user_prefs['width'],
                    'height': user_prefs['height'],
                    'steps': user_prefs['steps'],
                    'cfg_scale': user_prefs['cfg_scale'],
                    'clip_skip': user_prefs['clip_skip'],
                    'negative_prompt': user_prefs['negative_prompt'],
                    'sampler_name': user_prefs['sampler_name'],
                    'scheduler_name': user_prefs['scheduler_name'],
                    'model_name': user_prefs['model_name'],
                    'batch_size': user_prefs['batch_size'],
                    'uploaded_image': user_prefs['uploaded_image'],
                    'sampler_options': current_samplers,
                    'scheduler_options': current_schedulers,
                    'model_options': current_models
                }
            }

        # Handle form submission
        form_data = args
        mode = form_data.get('mode', 'txt2img')
        prompt = form_data.get('prompt', '')
        width = int(form_data.get('width', default_width))
        height = int(form_data.get('height', default_height))
        steps = int(form_data.get('steps', default_steps))
        cfg_scale = float(form_data.get('cfg_scale', default_cfg_scale))
        negative_prompt = form_data.get('negative_prompt', default_negative_prompt)
        sampler_name = form_data.get('sampler_name', default_sampler_name)
        scheduler_name = form_data.get('scheduler_name', default_scheduler_name)
        model_name = form_data.get('model_name', MODELS[0]['value'] if MODELS else '')
        num_images = max(1, min(int(form_data.get('batch_size', default_batch_size)), 8))
        generation_id = form_data.get('generation_id', '')
        auto_share_raw = form_data.get('auto_share', True)
        auto_share = auto_share_raw == 'on' if isinstance(auto_share_raw, str) else bool(auto_share_raw)
        seed = int(form_data.get('seed', -1))
        print(f"DEBUG: Auto-share raw value: {auto_share_raw} (type: {type(auto_share_raw)}), processed: {auto_share}")
        print(f"DEBUG: Using seed: {seed}")

        # Save user preferences
        try:
            from database import save_user_image_preferences, get_user_by_username
            user_info = get_user_by_username(sender)
            if user_info:
                user_uuid = user_info['uuid']
                preferences = {
                    'last_sd_model': model_name,
                    'last_img_width': width,
                    'last_img_height': height,
                    'last_img_steps': steps,
                    'last_img_cfg_scale': cfg_scale,
                    'last_img_clip_skip': int(form_data.get('clip_skip', default_clip_skip)),
                    'last_img_negative_prompt': negative_prompt,
                    'last_img_sampler': sampler_name,
                    'last_img_scheduler': scheduler_name,
                    'last_img_batch_size': num_images
                }
                print(f"DEBUG: Saving user preferences for {sender} (UUID: {user_uuid}): {preferences}")
                save_user_image_preferences(user_uuid, preferences)
                print(f"DEBUG: User preferences saved successfully for {sender}")
            else:
                print(f"Failed to find user {sender} for saving preferences")
        except Exception as e:
            print(f"Failed to save user preferences: {str(e)}")

        if form_data.get('cancel') is True:
            print(f"Cancel requested for !image by {sender}")
            return None

        if not prompt.strip():
            print("Empty prompt provided")
            return {'message': 'Reeeee, prompt is empty! Please provide a description.', 'is_media': False}

        # Determine API endpoint and payload based on mode
        if mode == 'img2img':
            api_url_img = f"{base_api_url.rstrip('/')}/sdapi/v1/img2img"
            clip_skip = int(form_data.get('clip_skip', default_clip_skip))
            denoising_strength = float(form_data.get('denoising_strength', 0.75))

            # Handle init_image - it can be a data URL, file URL, or raw base64
            init_image = form_data.get('init_image')
            print(f"DEBUG: init_image received: {init_image}")
            if not init_image:
                return {'message': 'Reeeee, no input image provided for img2img!', 'is_media': False}

            if init_image.startswith('data:'):
                # Already a data URL
                init_images = [init_image]
            elif init_image.startswith('/static/'):
                # Load image from relative file path
                file_path = os.path.join(os.getcwd(), init_image[1:])
                print(f"DEBUG: Looking for file at: {file_path}")
                print(f"DEBUG: File exists: {os.path.exists(file_path)}")
                if os.path.exists(file_path):
                    print(f"DEBUG: File size: {os.path.getsize(file_path)}")
                    with open(file_path, 'rb') as f:
                        content = f.read()
                    # Detect MIME type (simple check)
                    import mimetypes
                    mime_type, _ = mimetypes.guess_type(file_path)
                    if not mime_type:
                        mime_type = 'image/png'  # fallback
                    init_image_data = f"data:{mime_type};base64,{base64.b64encode(content).decode('utf-8')}"
                    print(f"DEBUG: Created data URL, length: {len(init_image_data)}")
                    init_images = [init_image_data]
                else:
                    # File not found locally, try fetching from server URL
                    protocol = "https" if USE_HTTPS else "http"
                    base_url = f"{protocol}://localhost:{SERVER_PORT}"
                    full_url = base_url + init_image
                    try:
                        response = requests.get(full_url, verify=False)
                        if response.status_code == 200:
                            content = response.content
                            mime_type, _ = mimetypes.guess_type(full_url)
                            if not mime_type:
                                mime_type = 'image/png'
                            init_image_data = f"data:{mime_type};base64,{base64.b64encode(content).decode('utf-8')}"
                            print(f"DEBUG: Fetched and created data URL, length: {len(init_image_data)}")
                            init_images = [init_image_data]
                        else:
                            print(f"DEBUG: File not found at {full_url}")
                            return {'message': f'Init image not found at {full_url}', 'is_media': False}
                    except Exception as e:
                        print(f"DEBUG: Error fetching init image: {str(e)}")
                        return {'message': f'Error fetching init image: {str(e)}', 'is_media': False}
            elif init_image.startswith(('http://', 'https://')) and '/static/' in init_image:
                # Handle full server URLs - extract the static path
                try:
                    from urllib.parse import urlparse
                    parsed_url = urlparse(init_image)
                    # Extract path after /static/
                    static_path = parsed_url.path
                    if static_path.startswith('/static/'):
                        file_path = os.path.join(os.getcwd(), static_path[1:])
                        if os.path.exists(file_path):
                            with open(file_path, 'rb') as f:
                                content = f.read()
                            # Detect MIME type (simple check)
                            import mimetypes
                            mime_type, _ = mimetypes.guess_type(file_path)
                            if not mime_type:
                                mime_type = 'image/png'  # fallback
                            init_image = f"data:{mime_type};base64,{base64.b64encode(content).decode('utf-8')}"
                            init_images = [init_image]
                        else:
                            return {'message': 'Init image file not found on server', 'is_media': False}
                    else:
                        return {'message': 'Invalid static URL format', 'is_media': False}
                except Exception as e:
                    return {'message': f'Error processing server URL: {str(e)}', 'is_media': False}
            else:
                # Raw base64 string (fallback)
                init_images = [f"data:image/png;base64,{init_image}"]

            payload = {
                'prompt': prompt,
                'negative_prompt': negative_prompt,
                'steps': steps,
                'width': width,
                'height': height,
                'cfg_scale': cfg_scale,
                'clip_skip': clip_skip,
                'sampler_name': sampler_name,
                'scheduler': scheduler_name,
                'seed': seed,
                'batch_size': num_images,
                'denoising_strength': denoising_strength,
                'init_images': init_images,
                'resize_mode': 0,  # Just resize
                'override_settings': {
                    'sd_model_checkpoint': model_name
                }
            }
            print(f"Sending img2img request to {api_url_img}: {payload}")
            api_url = api_url_img
        else:
            # txt2img mode
            api_url = f"{base_api_url.rstrip('/')}/sdapi/v1/txt2img"
            clip_skip = int(form_data.get('clip_skip', default_clip_skip))
            payload = {
                'prompt': prompt,
                'negative_prompt': negative_prompt,
                'steps': steps,
                'width': width,
                'height': height,
                'cfg_scale': cfg_scale,
                'clip_skip': clip_skip,
                'sampler_name': sampler_name,
                'scheduler': scheduler_name,
                'seed': seed,
                'batch_size': num_images,
                'override_settings': {
                    'sd_model_checkpoint': model_name
                }
            }
            print(f"Sending txt2img request to {api_url}: {payload}")

        # Initialize global generation status
        current_generation_status.update({
            'active': True,
            'progress': 0,
            'generation_id': generation_id,
            'channel': channel,
            'sender': sender
        })

        # Emit busy status to all clients
        socketio.emit('image_generation_progress', {
            'generation_id': generation_id,
            'progress': 0,
            'status': 'busy',
            'channel': channel,
            'sender': sender
        })

        # Send the API request
        try:
            response = requests.post(api_url, json=payload, timeout=240)
            print(f"API response status: {response.status_code}")
            response.raise_for_status()
            result = response.json()
            print(f"API response keys: {list(result.keys())}")
            if 'info' in result:
                print(f"Info field present: {result['info'][:200]}...")

            num_returned = len(result.get('images', []))
            print(f"API response received: {num_returned} images (requested batch_size: {num_images})")
            if num_returned != num_images:
                print(f"WARNING: API returned {num_returned} images but requested {num_images}")

            # Check for duplicates in API response and filter them out
            image_hashes = set()
            unique_images = []
            for i, img_data in enumerate(result['images']):
                # Use MD5 hash of full image data for accurate duplicate detection
                img_hash = hashlib.md5(img_data.encode('utf-8') if isinstance(img_data, str) else img_data).hexdigest()
                if img_hash not in image_hashes:
                    image_hashes.add(img_hash)
                    unique_images.append(img_data)
                else:
                    print(f"WARNING: Duplicate image detected at index {i} (MD5: {img_hash}), removing")
            result['images'] = unique_images
            print(f"After removing duplicates: {len(result['images'])} unique images")

        except requests.exceptions.RequestException as e:
            print(f"API request failed: {str(e)}")
            if hasattr(e, 'response') and e.response:
                print(f"Response text: {e.response.text}")
            # Reset global state on error
            current_generation_status.update({
                'active': False,
                'progress': 0,
                'generation_id': None,
                'channel': None,
                'sender': None
            })
            # Emit error status to client
            socketio.emit('image_generation_progress', {
                'generation_id': generation_id,
                'progress': 0,
                'status': 'error',
                'channel': channel,
                'sender': sender
            })
            return {'message': f"Reeeee, image generation failed: {str(e)}", 'is_media': False}

        upload_path = UPLOAD_DIR
        thumbnails_path = THUMBNAILS_DIR
        os.makedirs(upload_path, exist_ok=True)
        os.makedirs(thumbnails_path, exist_ok=True)

        if 'images' in result and result['images']:
            # Limit to the requested number of images
            original_count = len(result['images'])
            result['images'] = result['images'][:num_images]
            print(
                f"Processing {len(result['images'])} images from batch (limited from {original_count} to requested {num_images})")
            if len(result['images']) < num_images:
                print(
                    f"WARNING: Only {len(result['images'])} unique images available, less than requested {num_images}")

            # Extract generation metadata from API response
            base_metadata = {}
            print(f"API result keys: {list(result.keys())}")
            info_data = None
            if 'info' in result:
                print(f"Info present in result: {result['info'][:200]}...")  # First 200 chars
                try:
                    info_data = json.loads(result['info'])
                except Exception as e:
                    print(f"Failed to parse generation info: {str(e)}")
            elif 'parameters' in result:
                print("Using parameters as info_data")
                info_data = result['parameters']
            else:
                print("No 'info' or 'parameters' key in API result, using request payload")
                info_data = payload  # Fallback to request payload

            if info_data:
                base_metadata = {
                    'seed': info_data.get('seed'),
                    'subseed': info_data.get('subseed'),
                    'model': info_data.get('sd_model_name'),
                    'prompt': sanitize_prompt(info_data.get('prompt')),
                    'negative_prompt': sanitize_prompt(info_data.get('negative_prompt')),
                    'steps': info_data.get('steps'),
                    'sampler': info_data.get('sampler_name'),
                    'scheduler': scheduler_name,  # Fallback to request data
                    'cfg_scale': info_data.get('cfg_scale'),
                    'width': info_data.get('width'),
                    'height': info_data.get('height'),
                    'clip_skip': info_data.get('clip_skip'),
                    'denoising_strength': info_data.get('denoising_strength')
                }
                print(f"Extracted base generation metadata: {base_metadata}")

            if num_images == 1:
                # Single image - use existing format for backward compatibility
                image_data = result['images'][0]
                image_bytes = base64.b64decode(image_data)
                image = Image.open(io.BytesIO(image_bytes))

                # Use sanitized prompt-based name with timestamp
                base_name = sanitize_filename(prompt)
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                filename = f"{base_name}_{timestamp}.jpg"
                file_path = os.path.join(upload_path, filename)
                counter = 1
                while os.path.exists(file_path):
                    filename = f"{base_name}_{timestamp}_{counter}.jpg"
                    file_path = os.path.join(upload_path, filename)
                    counter += 1

                # Save image
                image.save(file_path, format='JPEG', quality=85)
                print(f"Image saved: {file_path}")
                image_url = f"/static/uploads/{filename}".replace('\\', '/')

                # Generate thumbnail
                thumbnail_filename = f"{os.path.splitext(filename)[0]}_thumb.jpg"
                thumbnail_filepath = os.path.join(thumbnails_path, thumbnail_filename)
                thumbnail_url = None
                if generate_thumbnail(file_path, thumbnail_filepath):
                    thumbnail_url = f"/static/thumbnails/uploads/{thumbnail_filename}".replace('\\', '/')
                    if not os.path.exists(thumbnail_filepath):
                        print(f"Thumbnail file not found after generation: {thumbnail_filepath}")
                        thumbnail_url = image_url
                else:
                    print(f"Thumbnail generation failed for {filename}")
                    thumbnail_url = image_url  # Fallback to full image

                print("Generated single image")
                # Reset global generation status since generation is complete
                current_generation_status.update({
                    'active': False,
                    'progress': 0,
                    'generation_id': None,
                    'channel': None,
                    'sender': None
                })
                # Emit idle status to all clients
                socketio.emit('image_generation_progress', {
                    'generation_id': generation_id,
                    'progress': 100,
                    'status': 'idle',
                    'channel': channel,
                    'sender': sender
                })
                # Create per-image metadata for single image
                images_with_metadata = [{'url': image_url, 'thumbnail_url': thumbnail_url, 'metadata': base_metadata}]
                result = {
                    'modal_result': {
                        'images': images_with_metadata,
                        'generation_id': generation_id,
                        'auto_share': auto_share,
                        'metadata': base_metadata
                    }
                }
                # For auto_share, the client will handle sharing the carousel
                return result
            else:
                # Multiple images - create carousel format
                attachments = []
                base_name = sanitize_filename(prompt, 25)
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

                for i, image_data in enumerate(result['images']):
                    image_bytes = base64.b64decode(image_data)
                    image = Image.open(io.BytesIO(image_bytes))

                    # Create unique filename for each image
                    filename = f"{base_name}_{timestamp}_{i + 1}.jpg"
                    file_path = os.path.join(upload_path, filename)
                    counter = 1
                    while os.path.exists(file_path):
                        filename = f"{base_name}_{timestamp}_{i + 1}_{counter}.jpg"
                        file_path = os.path.join(upload_path, filename)
                        counter += 1

                    # Save image
                    image.save(file_path, format='JPEG', quality=85)
                    print(f"Image {i + 1}/{num_images} saved: {file_path}")
                    image_url = f"/static/uploads/{filename}".replace('\\', '/')

                    # Generate thumbnail
                    thumbnail_filename = f"{os.path.splitext(filename)[0]}_thumb.jpg"
                    thumbnail_filepath = os.path.join(thumbnails_path, thumbnail_filename)
                    thumbnail_url = None
                    if generate_thumbnail(file_path, thumbnail_filepath):
                        thumbnail_url = f"/static/thumbnails/uploads/{thumbnail_filename}".replace('\\', '/')
                        if not os.path.exists(thumbnail_filepath):
                            print(f"Thumbnail file not found after generation: {thumbnail_filepath}")
                            thumbnail_url = image_url
                    else:
                        print(f"Thumbnail generation failed for {filename}")
                        thumbnail_url = image_url  # Fallback to full image

                    attachments.append({
                        'url': image_url,
                        'thumbnail_url': thumbnail_url
                    })

                print(f"Generated batch of {num_images} images")
                # Reset global generation status since generation is complete
                current_generation_status.update({
                    'active': False,
                    'progress': 0,
                    'generation_id': None,
                    'channel': None,
                    'sender': None
                })
                # Emit idle status to all clients
                socketio.emit('image_generation_progress', {
                    'generation_id': generation_id,
                    'progress': 100,
                    'status': 'idle',
                    'channel': channel,
                    'sender': sender
                })


                # Create per-image metadata for batch generations
                images_with_metadata = []
                base_seed = base_metadata.get('seed', -1)
                for i, att in enumerate(attachments):
                    image_metadata = base_metadata.copy()
                    # For batch generations, increment seed for each image after the first
                    if len(attachments) > 1 and base_seed != -1:
                        image_metadata['seed'] = base_seed + i
                    images_with_metadata.append({
                        'url': att['url'],
                        'thumbnail_url': att['thumbnail_url'],
                        'metadata': image_metadata
                    })

                result = {
                    'modal_result': {
                        'images': images_with_metadata,
                        'generation_id': generation_id,
                        'auto_share': auto_share,
                        'metadata': base_metadata  # Keep base metadata for backward compatibility
                    }
                }
                # For auto_share, the client will handle sharing the carousel
                return result

        else:
            print("No image data returned from API")
            return {'message': 'Reeeee, no image data returned from API!', 'is_media': False}

    # Create a closure that captures socketio
    def image_with_socketio(args, sender, channel):
        return image(args, sender, channel, command_processor.socketio)

    command_processor.register_command('image', image_with_socketio)


def generate_image_from_metadata(metadata, sender, channel, socketio):
    """Generate images using metadata from a previous generation."""
    print(f"generate_image_from_metadata called with metadata: {metadata}")

    # Load config
    config_path = os.path.join(os.path.dirname(__file__), '..', 'sd_config.json')
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {'message': 'Configuration error', 'is_media': False}

    base_api_url = config.get('sd_api_url', 'http://127.0.0.1:7860')
    api_url = f"{base_api_url.rstrip('/')}/sdapi/v1/txt2img"

    # Extract parameters from metadata
    prompt = metadata.get('prompt', '')
    negative_prompt = metadata.get('negative_prompt', '')
    width = metadata.get('width', 1024)
    height = metadata.get('height', 1024)
    steps = metadata.get('steps', 33)
    cfg_scale = metadata.get('cfg_scale', 7)
    clip_skip = metadata.get('clip_skip', 2)
    sampler_name = metadata.get('sampler', 'DPM++ 3M SDE')
    scheduler_name = metadata.get('scheduler', 'Simple')
    model_name = metadata.get('model', '')
    seed = -1  # Always use random seed for variations
    batch_size = metadata.get('batch_size', 1)

    # Generate unique generation ID
    generation_id = str(uuid.uuid4())

    payload = {
        'prompt': prompt,
        'negative_prompt': negative_prompt,
        'steps': steps,
        'width': width,
        'height': height,
        'cfg_scale': cfg_scale,
        'clip_skip': clip_skip,
        'sampler_name': sampler_name,
        'scheduler': scheduler_name,
        'seed': seed,
        'batch_size': batch_size,
        'override_settings': {
            'sd_model_checkpoint': model_name
        }
    }

    print(f"Sending generate_more txt2img request: {payload}")

    # Initialize global generation status
    current_generation_status.update({
        'active': True,
        'progress': 0,
        'generation_id': generation_id,
        'channel': channel,
        'sender': sender
    })

    # Emit busy status
    socketio.emit('image_generation_progress', {
        'generation_id': generation_id,
        'progress': 0,
        'status': 'busy',
        'channel': channel,
        'sender': sender
    })

    try:
        response = requests.post(api_url, json=payload, timeout=240)
        response.raise_for_status()
        result = response.json()

        # Process the result similar to the main image function
        # This is a simplified version - in practice, you'd want to reuse the existing processing logic
        images = result.get('images', [])
        if not images:
            return {'message': 'No images generated', 'is_media': False}

        # Save images and create metadata (simplified)
        attachments = []
        info_data = {}
        if 'info' in result and result['info']:
            try:
                info_data = json.loads(result['info'])
                print(f"Parsed info data: seed={info_data.get('seed', 'N/A')}")
            except json.JSONDecodeError as e:
                print(f"Failed to parse info JSON: {e}")
                info_data = {}

        base_metadata = {
            'seed': info_data.get('seed', seed),
            'model': model_name,
            'prompt': prompt,
            'negative_prompt': negative_prompt,
            'steps': steps,
            'sampler': sampler_name,
            'scheduler': scheduler_name,
            'cfg_scale': cfg_scale,
            'width': width,
            'height': height,
            'clip_skip': clip_skip
        }

        for i, img_data in enumerate(images):
            # Save image logic here (similar to main function)
            image_bytes = base64.b64decode(img_data)
            image = Image.open(io.BytesIO(image_bytes))

            base_name = sanitize_filename(prompt)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"{base_name}_{timestamp}_{i}.jpg"
            file_path = os.path.join(UPLOAD_DIR, filename)

            image.save(file_path, format='JPEG', quality=85)
            image_url = f"/static/uploads/{filename}".replace('\\', '/')

            # Generate thumbnail
            thumbnail_filename = f"{os.path.splitext(filename)[0]}_thumb.jpg"
            thumbnail_filepath = os.path.join(THUMBNAILS_DIR, thumbnail_filename)
            thumbnail_url = image_url
            if generate_thumbnail(file_path, thumbnail_filepath):
                thumbnail_url = f"/static/thumbnails/uploads/{thumbnail_filename}".replace('\\', '/')

            attachments.append({
                'url': image_url,
                'thumbnail_url': thumbnail_url,
                'metadata': base_metadata.copy()
            })

        # Reset generation status
        current_generation_status.update({
            'active': False,
            'progress': 0,
            'generation_id': None,
            'channel': None,
            'sender': None
        })

        socketio.emit('image_generation_progress', {
            'generation_id': generation_id,
            'progress': 100,
            'status': 'idle',
            'channel': channel,
            'sender': sender
        })

        return {
            'modal_result': {
                'images': attachments,
                'generation_id': generation_id,
                'auto_share': False,  # Don't auto-share for generate more
                'metadata': base_metadata
            }
        }

    except Exception as e:
        print(f"Error in generate_image_from_metadata: {str(e)}")
        current_generation_status.update({
            'active': False,
            'progress': 0,
            'generation_id': None,
            'channel': None,
            'sender': None
        })
        return {'message': f'Generation failed: {str(e)}', 'is_media': False}


def generate_img2img_from_metadata(image_base64, metadata, sender, channel, socketio):
    """Generate img2img using metadata and base64 image."""
    print(f"generate_img2img_from_metadata called")

    # Load config
    config_path = os.path.join(os.path.dirname(__file__), '..', 'sd_config.json')
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {'message': 'Configuration error', 'is_media': False}

    base_api_url = config.get('sd_api_url', 'http://127.0.0.1:7860')
    api_url = f"{base_api_url.rstrip('/')}/sdapi/v1/img2img"

    # Extract parameters from metadata
    prompt = metadata.get('prompt', '')
    negative_prompt = metadata.get('negative_prompt', '')
    width = metadata.get('width', 1024)
    height = metadata.get('height', 1024)
    steps = metadata.get('steps', 33)
    cfg_scale = metadata.get('cfg_scale', 7)
    clip_skip = metadata.get('clip_skip', 2)
    sampler_name = metadata.get('sampler', 'DPM++ 3M SDE')
    scheduler_name = metadata.get('scheduler', 'Simple')
    model_name = metadata.get('model', '')
    seed = -1  # Always use random seed for variations
    # Handle null denoising_strength from txt2img metadata
    denoising_strength = metadata.get('denoising_strength')
    if denoising_strength is None:
        denoising_strength = 0.75
    batch_size = metadata.get('batch_size', 1)

    # Generate unique generation ID
    generation_id = str(uuid.uuid4())

    # Extract base64 data from data URL if present
    if image_base64.startswith('data:'):
        # Format: data:image/jpeg;base64,BASE64DATA
        base64_data = image_base64.split(',')[1]
    else:
        base64_data = image_base64

    payload = {
        'prompt': prompt,
        'negative_prompt': negative_prompt,
        'steps': steps,
        'width': width,
        'height': height,
        'cfg_scale': cfg_scale,
        'clip_skip': clip_skip,
        'sampler_name': sampler_name,
        'scheduler': scheduler_name,
        'seed': seed,
        'batch_size': batch_size,
        'denoising_strength': denoising_strength,
        'init_images': [base64_data],
        'resize_mode': 0,
        'override_settings': {
            'sd_model_checkpoint': model_name
        }
    }

    print(f"Sending img2img_more request to {api_url}")
    print(f"Payload keys: {list(payload.keys())}")
    print(f"Init images length: {len(payload['init_images'][0]) if payload['init_images'] else 0}")
    print(f"Denoising strength: {payload['denoising_strength']}")

    # Initialize global generation status
    current_generation_status.update({
        'active': True,
        'progress': 0,
        'generation_id': generation_id,
        'channel': channel,
        'sender': sender
    })

    # Emit busy status
    socketio.emit('image_generation_progress', {
        'generation_id': generation_id,
        'progress': 0,
        'status': 'busy',
        'channel': channel,
        'sender': sender
    })

    try:
        response = requests.post(api_url, json=payload, timeout=240)
        response.raise_for_status()
        result = response.json()

        # Process the result (similar to txt2img)
        images = result.get('images', [])
        print(f"Img2img API response received: {len(images)} images")
        if not images:
            print("No images in img2img API response")
            return {'message': 'No images generated', 'is_media': False}

        # Save images and create metadata
        attachments = []
        info_data = {}
        if 'info' in result and result['info']:
            try:
                info_data = json.loads(result['info'])
                print(f"Parsed info data: seed={info_data.get('seed', 'N/A')}")
            except json.JSONDecodeError as e:
                print(f"Failed to parse info JSON: {e}")
                info_data = {}

        base_metadata = {
            'seed': info_data.get('seed', seed),
            'model': model_name,
            'prompt': prompt,
            'negative_prompt': negative_prompt,
            'steps': steps,
            'sampler': sampler_name,
            'scheduler': scheduler_name,
            'cfg_scale': cfg_scale,
            'width': width,
            'height': height,
            'clip_skip': clip_skip,
            'denoising_strength': denoising_strength
        }

        for i, img_data in enumerate(images):
            image_bytes = base64.b64decode(img_data)
            image = Image.open(io.BytesIO(image_bytes))

            base_name = sanitize_filename(prompt)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"{base_name}_img2img_{timestamp}_{i}.jpg"
            file_path = os.path.join(UPLOAD_DIR, filename)

            image.save(file_path, format='JPEG', quality=85)
            image_url = f"/static/uploads/{filename}".replace('\\', '/')

            # Generate thumbnail
            thumbnail_filename = f"{os.path.splitext(filename)[0]}_thumb.jpg"
            thumbnail_filepath = os.path.join(THUMBNAILS_DIR, thumbnail_filename)
            thumbnail_url = image_url
            if generate_thumbnail(file_path, thumbnail_filepath):
                thumbnail_url = f"/static/thumbnails/uploads/{thumbnail_filename}".replace('\\', '/')

            attachments.append({
                'url': image_url,
                'thumbnail_url': thumbnail_url,
                'metadata': base_metadata.copy()
            })

        # Reset generation status
        current_generation_status.update({
            'active': False,
            'progress': 0,
            'generation_id': None,
            'channel': None,
            'sender': None
        })

        socketio.emit('image_generation_progress', {
            'generation_id': generation_id,
            'progress': 100,
            'status': 'idle',
            'channel': channel,
            'sender': sender
        })

        return {
            'modal_result': {
                'images': attachments,
                'generation_id': generation_id,
                'auto_share': False,
                'metadata': base_metadata
            }
        }

    except Exception as e:
        print(f"Error in generate_img2img_from_metadata: {str(e)}")
        current_generation_status.update({
            'active': False,
            'progress': 0,
            'generation_id': None,
            'channel': None,
            'sender': None
        })
        return {'message': f'Img2img generation failed: {str(e)}', 'is_media': False}