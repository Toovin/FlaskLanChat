"""
Main Server Database Manager
Handles all database operations for the main FlaskLanChat server (devchat.db).
"""

from .database_manager import DatabaseManager
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import uuid
from typing import Optional, Dict, Any, List


class MainDatabaseManager(DatabaseManager):
    """Database manager for the main server database (devchat.db)."""

    def __init__(self):
        super().__init__('devchat.db')

    def initialize_database(self):
        """Initialize the main database with required tables."""
        print("Initializing main database...")

        # Create users table
        if not self.table_exists('users'):
            self.execute_query('''
                CREATE TABLE users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    avatar TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
        else:
            # Add avatar column if it doesn't exist
            self.add_column_if_not_exists('users', 'avatar', 'avatar TEXT')
            self.add_column_if_not_exists('users', 'last_seen', 'last_seen TIMESTAMP')
            self.add_column_if_not_exists('users', 'cursor_size', 'cursor_size INTEGER DEFAULT 0')

        # Create channels table
        if not self.table_exists('channels'):
            self.execute_query('''
                CREATE TABLE channels (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT UNIQUE NOT NULL,
                    description TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
        else:
            # Ensure all required columns exist
            self.add_column_if_not_exists('channels', 'description', 'TEXT')
            self.add_column_if_not_exists('channels', 'created_at', 'TIMESTAMP')

        # Create messages table
        if not self.table_exists('messages'):
            self.execute_query('''
                CREATE TABLE messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    channel TEXT NOT NULL,
                    sender TEXT NOT NULL,
                    message TEXT NOT NULL,
                    is_media BOOLEAN DEFAULT 0,
                    image_url TEXT,
                    thumbnail_url TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    replied_to INTEGER,
                    FOREIGN KEY (replied_to) REFERENCES messages(id)
                )
            ''')

        # Create reactions table
        if not self.table_exists('reactions'):
            self.execute_query('''
                CREATE TABLE reactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    message_id INTEGER NOT NULL,
                    user_id TEXT NOT NULL,
                    reaction TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
                    UNIQUE(message_id, user_id, reaction)
                )
            ''')

        # Create folders table
        if not self.table_exists('folders'):
            self.execute_query('''
                CREATE TABLE folders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    path TEXT UNIQUE NOT NULL,
                    parent_id INTEGER,
                    created_by TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (parent_id) REFERENCES folders(id) ON DELETE CASCADE
                )
            ''')

        # Create file_folders table
        if not self.table_exists('file_folders'):
            self.execute_query('''
                CREATE TABLE file_folders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    filename TEXT NOT NULL,
                    filepath TEXT NOT NULL,
                    folder_id INTEGER,
                    uploaded_by TEXT,
                    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (folder_id) REFERENCES folders(id) ON DELETE CASCADE
                )
            ''')

        # Create indexes for better performance
        indexes = [
            ('idx_messages_channel_timestamp', 'messages', ['channel', 'timestamp']),
            ('idx_messages_sender', 'messages', 'sender'),
            ('idx_reactions_message_id', 'reactions', 'message_id'),
            ('idx_folders_path', 'folders', 'path'),
            ('idx_file_folders_folder_id', 'file_folders', 'folder_id'),
        ]
        self.create_indexes(indexes)

        # Insert default 'general' channel if it doesn't exist
        self._ensure_default_channel()

        print("Main database initialized successfully!")

    def _ensure_default_channel(self):
        """Ensure the default 'general' channel exists."""
        # First ensure the channels table exists
        if not self.table_exists('channels'):
            print("Warning: Channels table doesn't exist, cannot create default channel")
            return

        try:
            result = self.execute_query(
                "SELECT id FROM channels WHERE name = ?",
                ('general',),
                fetch=True
            )

            if not result:
                self.execute_query(
                    "INSERT INTO channels (name, description) VALUES (?, ?)",
                    ('general', 'General discussion channel')
                )
                print("Created default 'general' channel")
        except Exception as e:
            print(f"Error ensuring default channel exists: {e}")

    # User management methods
    def create_user(self, username: str, password: str, avatar: str = None) -> bool:
        """Create a new user."""
        try:
            password_hash = generate_password_hash(password)
            self.execute_query(
                "INSERT INTO users (username, password_hash, avatar) VALUES (?, ?, ?)",
                (username, password_hash, avatar)
            )
            return True
        except Exception as e:
            print(f"Error creating user: {e}")
            return False

    def authenticate_user(self, username: str, password: str) -> Optional[Dict[str, Any]]:
        """Authenticate a user and return user data if successful."""
        result = self.execute_query(
            "SELECT * FROM users WHERE username = ?",
            (username,),
            fetch=True
        )

        if result and check_password_hash(result[0]['password_hash'], password):
            return dict(result[0])
        return {}

    def get_user_by_username(self, username: str) -> Optional[Dict[str, Any]]:
        """Get user data by username."""
        result = self.execute_query(
            "SELECT * FROM users WHERE username = ?",
            (username,),
            fetch=True
        )
        return dict(result[0]) if result else None

    def update_user_avatar(self, username: str, avatar: str) -> bool:
        """Update user's avatar."""
        try:
            self.execute_query(
                "UPDATE users SET avatar = ? WHERE username = ?",
                (avatar, username)
            )
            return True
        except Exception as e:
            print(f"Error updating avatar: {e}")
            return False

    def update_user_last_seen(self, username: str) -> bool:
        """Update user's last seen timestamp."""
        try:
            self.execute_query(
                "UPDATE users SET last_seen = CURRENT_TIMESTAMP WHERE username = ?",
                (username,)
            )
            return True
        except Exception as e:
            print(f"Error updating last seen: {e}")
            return False

    # Message management methods
    def save_message(self, channel: str, sender: str, message: str,
                    is_media: bool = False, image_url: Optional[str] = None,
                    thumbnail_url: Optional[str] = None, replied_to: Optional[int] = None) -> Optional[int]:
        """Save a message and return its ID."""
        result = self.execute_query(
            """INSERT INTO messages (channel, sender, message, is_media, image_url, thumbnail_url, replied_to)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (channel, sender, message, is_media, image_url, thumbnail_url, replied_to),
            fetch=True
        )
        return result[0]['id'] if result else None

    def get_messages(self, channel: str, limit: int = 100) -> list:
        """Get recent messages from a channel."""
        return self.execute_query(
            """SELECT m.*, GROUP_CONCAT(r.reaction || ':' || r.user_id) as reactions
               FROM messages m
               LEFT JOIN reactions r ON m.id = r.message_id
               WHERE m.channel = ?
               GROUP BY m.id
               ORDER BY m.timestamp DESC
               LIMIT ?""",
            (channel, limit),
            fetch=True
        ) or []

    def get_message_by_id(self, message_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific message by ID."""
        result = self.execute_query(
            "SELECT * FROM messages WHERE id = ?",
            (message_id,),
            fetch=True
        )
        return dict(result[0]) if result else None

    # Channel management methods
    def create_channel(self, name: str, description: str = None) -> bool:
        """Create a new channel."""
        try:
            self.execute_query(
                "INSERT INTO channels (name, description) VALUES (?, ?)",
                (name, description)
            )
            return True
        except Exception as e:
            print(f"Error creating channel: {e}")
            return False

    def get_channels(self) -> list:
        """Get all channels."""
        return self.execute_query(
            "SELECT * FROM channels ORDER BY name",
            fetch=True
        ) or []

    def delete_channel(self, name: str) -> bool:
        """Delete a channel."""
        try:
            self.execute_query("DELETE FROM channels WHERE name = ?", (name,))
            return True
        except Exception as e:
            print(f"Error deleting channel: {e}")
            return False

    # Reaction management methods
    def add_reaction(self, message_id: int, user_id: str, reaction: str) -> bool:
        """Add a reaction to a message."""
        try:
            self.execute_query(
                "INSERT OR IGNORE INTO reactions (message_id, user_id, reaction) VALUES (?, ?, ?)",
                (message_id, user_id, reaction)
            )
            return True
        except Exception as e:
            print(f"Error adding reaction: {e}")
            return False

    def remove_reaction(self, message_id: int, user_id: str, reaction: str) -> bool:
        """Remove a reaction from a message."""
        try:
            self.execute_query(
                "DELETE FROM reactions WHERE message_id = ? AND user_id = ? AND reaction = ?",
                (message_id, user_id, reaction)
            )
            return True
        except Exception as e:
            print(f"Error removing reaction: {e}")
            return False

    def get_reactions(self, message_id: int) -> list:
        """Get all reactions for a message."""
        return self.execute_query(
            "SELECT * FROM reactions WHERE message_id = ? ORDER BY created_at",
            (message_id,),
            fetch=True
        ) or []

    # Folder management methods
    def create_folder(self, name: str, parent_id: Optional[int] = None, created_by: Optional[str] = None) -> Optional[int]:
        """Create a new folder and return its ID."""
        # Build path
        if parent_id:
            parent_result = self.execute_query(
                "SELECT path FROM folders WHERE id = ?",
                (parent_id,),
                fetch=True
            )
            if parent_result:
                parent_path = parent_result[0]['path']
                path = f"{parent_path}/{name}"
            else:
                raise ValueError("Parent folder not found")
        else:
            path = f"/{name}"

        result = self.execute_query(
            "INSERT INTO folders (name, path, parent_id, created_by) VALUES (?, ?, ?, ?)",
            (name, path, parent_id, created_by),
            fetch=True
        )
        return result[0]['id'] if result else None

    def get_folder_structure(self) -> list:
        """Get the complete folder structure."""
        return self.execute_query(
            "SELECT * FROM folders ORDER BY path",
            fetch=True
        ) or []

    def get_folder_by_id(self, folder_id: int) -> Optional[Dict[str, Any]]:
        """Get folder information by ID."""
        result = self.execute_query(
            "SELECT * FROM folders WHERE id = ?",
            (folder_id,),
            fetch=True
        )
        return dict(result[0]) if result else None

    def delete_folder(self, folder_id: int) -> bool:
        """Delete a folder and all its contents."""
        try:
            self.execute_query("DELETE FROM folders WHERE id = ?", (folder_id,))
            return True
        except Exception as e:
            print(f"Error deleting folder: {e}")
            return False

    def rename_folder(self, folder_id: int, new_name: str) -> bool:
        """Rename a folder."""
        try:
            # Get current folder info
            folder_info = self.get_folder_by_id(folder_id)
            if not folder_info:
                return False

            # Update folder name and path
            old_path = folder_info['path']
            path_parts = old_path.split('/')
            path_parts[-1] = new_name
            new_path = '/'.join(path_parts)

            self.execute_query(
                "UPDATE folders SET name = ?, path = ? WHERE id = ?",
                (new_name, new_path, folder_id)
            )

            # Update paths for all subfolders
            old_path_prefix = old_path + '/'
            new_path_prefix = new_path + '/'
            self.execute_query(
                "UPDATE folders SET path = REPLACE(path, ?, ?) WHERE path LIKE ?",
                (old_path_prefix, new_path_prefix, old_path_prefix + '%')
            )

            return True
        except Exception as e:
            print(f"Error renaming folder: {e}")
            return False

    # File management methods
    def add_file_to_folder(self, filename: str, filepath: str, folder_id: Optional[int] = None,
                          uploaded_by: Optional[str] = None) -> Optional[int]:
        """Add a file to a folder."""
        result = self.execute_query(
            "INSERT INTO file_folders (filename, filepath, folder_id, uploaded_by) VALUES (?, ?, ?, ?)",
            (filename, filepath, folder_id, uploaded_by),
            fetch=True
        )
        return result[0]['id'] if result else None

    def get_files_in_folder(self, folder_id: int) -> list:
        """Get all files in a folder."""
        return self.execute_query(
            "SELECT * FROM file_folders WHERE folder_id = ? ORDER BY uploaded_at DESC",
            (folder_id,),
            fetch=True
        ) or []

    def delete_file_from_folder(self, file_id: int) -> bool:
        """Delete a file from a folder."""
        try:
            self.execute_query("DELETE FROM file_folders WHERE id = ?", (file_id,))
            return True
        except Exception as e:
            print(f"Error deleting file: {e}")
            return False

    # User settings methods
    def update_user_settings(self, username: str, settings: dict) -> bool:
        """Update user settings."""
        # For now, we'll store settings as JSON in the users table
        # In a production system, you'd want a separate settings table
        try:
            import json
            settings_json = json.dumps(settings)
            self.execute_query(
                "UPDATE users SET settings = ? WHERE username = ?",
                (settings_json, username)
            )
            return True
        except Exception as e:
            print(f"Error updating user settings: {e}")
            return False

    def get_user_settings(self, username: str) -> dict:
        """Get user settings."""
        try:
            result = self.execute_query(
                "SELECT settings FROM users WHERE username = ?",
                (username,),
                fetch=True
            )
            if result and result[0]['settings']:
                import json
                return json.loads(result[0]['settings'])
            return {}
        except Exception as e:
            print(f"Error getting user settings: {e}")
            return {}


# Global instance for easy access
main_db = MainDatabaseManager()