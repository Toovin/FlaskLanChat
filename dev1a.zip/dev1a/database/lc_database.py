import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import uuid
import os
import json
import shutil
from lc_config import CHAT_DB_NAME


def get_standard_timestamp():
    """Get a standard timestamp string for database storage"""
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def init_db():
    db_path = CHAT_DB_NAME
    try:
        # Check if database file is accessible
        if not os.path.exists(db_path):
            print(f"Creating new database file: {db_path}")
        else:
            print(f"Using existing database file: {db_path}")

        conn = sqlite3.connect(db_path)
        c = conn.cursor()

        # Check if messages table exists
        c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='messages'")
        table_exists = c.fetchone()
        if table_exists:
            print("Messages table exists, checking for missing columns")
            c.execute("PRAGMA table_info(messages)")
            columns = [col[1] for col in c.fetchall()]

            # Check for replied_to column
            if 'replied_to' not in columns:
                print("Adding replied_to column to messages table")
                c.execute("ALTER TABLE messages ADD COLUMN replied_to INTEGER")
                c.execute("UPDATE messages SET replied_to = NULL")
                conn.commit()

            # Check for image_url column
            if 'image_url' not in columns:
                print("Adding image_url column to messages table")
                c.execute("ALTER TABLE messages ADD COLUMN image_url TEXT")
                conn.commit()

            # Check for thumbnail_url column
            if 'thumbnail_url' not in columns:
                print("Adding thumbnail_url column to messages table")
                c.execute("ALTER TABLE messages ADD COLUMN thumbnail_url TEXT")
                conn.commit()

            # Check for generation_id column
            if 'generation_id' not in columns:
                print("Adding generation_id column to messages table")
                c.execute("ALTER TABLE messages ADD COLUMN generation_id TEXT")
                conn.commit()

            # Check for auto_share column
            if 'auto_share' not in columns:
                print("Adding auto_share column to messages table")
                c.execute("ALTER TABLE messages ADD COLUMN auto_share INTEGER DEFAULT 1")
                conn.commit()

            # Check for replied_sender column
            if 'replied_sender' not in columns:
                print("Adding replied_sender column to messages table")
                c.execute("ALTER TABLE messages ADD COLUMN replied_sender TEXT")
                conn.commit()

            # Check for replied_text column
            if 'replied_text' not in columns:
                print("Adding replied_text column to messages table")
                c.execute("ALTER TABLE messages ADD COLUMN replied_text TEXT")
                conn.commit()
        else:
            print("Creating messages table")
            c.execute('''CREATE TABLE messages (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 channel TEXT,
                 sender TEXT,
                 message TEXT,
                 is_media INTEGER,
                 timestamp TEXT,
                 replied_to INTEGER,
                 replied_sender TEXT,
                 replied_text TEXT,
                 image_url TEXT,
                 thumbnail_url TEXT,
                 generation_id TEXT,
                 auto_share INTEGER DEFAULT 1,
                 FOREIGN KEY (replied_to) REFERENCES messages(id) ON DELETE SET NULL
             )''')
            conn.commit()

        # Create other tables
        print("Creating users table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS users (
            uuid TEXT PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            avatar_url TEXT,
            display_name TEXT,
            status TEXT DEFAULT 'online',
            custom_status TEXT,
            theme TEXT DEFAULT 'dobo',
            compact_mode INTEGER DEFAULT 0,
            show_timestamps INTEGER DEFAULT 1,
            allow_dms INTEGER DEFAULT 1,
            show_online_status INTEGER DEFAULT 1,
            typing_indicators INTEGER DEFAULT 1
        )''')

        # Check if new columns exist and add them if they don't
        c.execute("PRAGMA table_info(users)")
        columns = [col[1] for col in c.fetchall()]

        new_columns = [
            ('display_name', 'TEXT'),
            ('status', 'TEXT DEFAULT "online"'),
            ('custom_status', 'TEXT'),
            ('theme', 'TEXT DEFAULT "dobo"'),
            ('font', 'TEXT DEFAULT "system"'),
            ('font_scale', 'REAL DEFAULT 1.0'),
            ('compact_mode', 'INTEGER DEFAULT 0'),
            ('show_timestamps', 'INTEGER DEFAULT 1'),
            ('animated_bg', 'TEXT DEFAULT "none"'),
            ('cursor_effect', 'TEXT DEFAULT "orbiting"'),
            ('particle_style', 'TEXT DEFAULT "theme"'),
            ('particle_size', 'REAL DEFAULT 1.0'),

            ('cursor_main', 'TEXT DEFAULT "default"'),
            ('cursor_particle', 'TEXT DEFAULT "default"'),
            ('cursor_glow', 'INTEGER DEFAULT 0'),
            ('cursor_size', 'INTEGER DEFAULT 64'),
            ('allow_dms', 'INTEGER DEFAULT 1'),
            ('show_online_status', 'INTEGER DEFAULT 1'),
            ('typing_indicators', 'INTEGER DEFAULT 1'),

             ('auto_hide_particles', 'INTEGER DEFAULT 1'),
             ('auto_hide_timeout', 'INTEGER DEFAULT 10'),
             ('mic_volume', 'REAL DEFAULT 1.0'),
             ('receive_volume', 'REAL DEFAULT 1.0'),
             ('mute', 'INTEGER DEFAULT 0'),
            ('toast_on_media_download', 'INTEGER DEFAULT 1'),
            ('is_admin', 'INTEGER DEFAULT 0'),
            # Image generation preferences
            ('last_sd_model', 'TEXT DEFAULT ""'),
            ('last_img_width', 'INTEGER DEFAULT 1024'),
            ('last_img_height', 'INTEGER DEFAULT 1024'),
            ('last_img_steps', 'INTEGER DEFAULT 35'),
            ('last_img_cfg_scale', 'REAL DEFAULT 7.0'),
            ('last_img_clip_skip', 'INTEGER DEFAULT 2'),
            ('last_img_negative_prompt', 'TEXT'),
            ('last_img_sampler', 'TEXT DEFAULT "DPM++ 3M SDE"'),
            ('last_img_scheduler', 'TEXT DEFAULT "simple"'),
            ('last_img_batch_size', 'INTEGER DEFAULT 1'),
            ('last_uploaded_image', 'TEXT')
        ]

        for col_name, col_type in new_columns:
            if col_name not in columns:
                print(f"Adding {col_name} column to users table")
                c.execute(f"ALTER TABLE users ADD COLUMN {col_name} {col_type}")
                conn.commit()

        print("Creating channels table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS channels (
            id TEXT PRIMARY KEY,
            name TEXT UNIQUE,
            icon TEXT DEFAULT NULL
        )''')

        # Add icon column if not exists (for migration)
        try:
            c.execute("ALTER TABLE channels ADD COLUMN icon TEXT DEFAULT NULL")
        except sqlite3.OperationalError:
            pass  # Column already exists

        # Add AI settings columns if not exists (for migration)
        try:
            c.execute("ALTER TABLE channels ADD COLUMN ai_enabled INTEGER DEFAULT 1")
            print("Added ai_enabled column to channels table")
        except sqlite3.OperationalError:
            pass  # Column already exists

        try:
            c.execute("ALTER TABLE channels ADD COLUMN ai_memory_limit INTEGER DEFAULT 10")
            print("Added ai_memory_limit column to channels table")
        except sqlite3.OperationalError:
            pass  # Column already exists

        try:
            c.execute("ALTER TABLE channels ADD COLUMN ai_model TEXT DEFAULT 'default'")
            print("Added ai_model column to channels table")
        except sqlite3.OperationalError:
            pass  # Column already exists

        try:
            c.execute("ALTER TABLE channels ADD COLUMN ai_temperature REAL DEFAULT 0.7")
            print("Added ai_temperature column to channels table")
        except sqlite3.OperationalError:
            pass  # Column already exists

        print("Creating folders table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS folders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            parent_id INTEGER,
            path TEXT NOT NULL,
            created_at TEXT NOT NULL,
            created_by TEXT,
            FOREIGN KEY (parent_id) REFERENCES folders(id) ON DELETE CASCADE
        )''')

        print("Creating file_folders table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS file_folders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            folder_id INTEGER,
            filepath TEXT NOT NULL,
            size INTEGER,
            created_at TEXT NOT NULL,
            created_by TEXT,
            thumbnail_url TEXT,
            visibility TEXT DEFAULT 'private',
            shared_by TEXT,
            ownership TEXT DEFAULT 'user',
            FOREIGN KEY (folder_id) REFERENCES folders(id) ON DELETE CASCADE
        )''')

        # Add new columns if they don't exist
        c.execute("PRAGMA table_info(file_folders)")
        columns = [col[1] for col in c.fetchall()]
        if 'thumbnail_url' not in columns:
            print("Adding thumbnail_url column to file_folders table")
            c.execute("ALTER TABLE file_folders ADD COLUMN thumbnail_url TEXT")
            conn.commit()
        if 'visibility' not in columns:
            print("Adding visibility column to file_folders table")
            c.execute("ALTER TABLE file_folders ADD COLUMN visibility TEXT DEFAULT 'private'")
            conn.commit()
        if 'shared_by' not in columns:
            print("Adding shared_by column to file_folders table")
            c.execute("ALTER TABLE file_folders ADD COLUMN shared_by TEXT")
            conn.commit()
        if 'ownership' not in columns:
            print("Adding ownership column to file_folders table")
            c.execute("ALTER TABLE file_folders ADD COLUMN ownership TEXT DEFAULT 'user'")
            conn.commit()

        # Create root folder if it doesn't exist
        c.execute("SELECT id FROM folders WHERE parent_id IS NULL AND name = 'Share'")
        root_folder = c.fetchone()
        if not root_folder:
            print("Creating root 'Share' folder")
            c.execute('''INSERT INTO folders (name, parent_id, path, created_at, created_by)
                        VALUES (?, ?, ?, ?, ?)''',
                     ('Share', None, 'file_share_system', datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'system'))
            root_folder_id = c.lastrowid

            # Create default subfolder
            print("Creating default 'Subfolder' under root")
            c.execute('''INSERT INTO folders (name, parent_id, path, created_at, created_by)
                        VALUES (?, ?, ?, ?, ?)''',
                     ('Subfolder', root_folder_id, 'file_share_system/Subfolder', datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'system'))
        else:
            root_folder_id = root_folder[0]
            # Check if Subfolder exists, create if not
            c.execute("SELECT id FROM folders WHERE parent_id = ? AND name = 'Subfolder'", (root_folder_id,))
            if not c.fetchone():
                print("Creating default 'Subfolder' under root")
                c.execute('''INSERT INTO folders (name, parent_id, path, created_at, created_by)
                            VALUES (?, ?, ?, ?, ?)''',
                         ('Subfolder', root_folder_id, 'file_share_system/Subfolder', datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'system'))

        print("Creating reactions table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS reactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message_id INTEGER,
            user_uuid TEXT,
            emoji TEXT,
            FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
            FOREIGN KEY (user_uuid) REFERENCES users(uuid)
        )''')

        print("Cleaning up duplicate reactions")
        c.execute('''
            DELETE FROM reactions
            WHERE id NOT IN (
                SELECT MAX(id)
                FROM reactions
                GROUP BY message_id, user_uuid, emoji
            )
        ''')

        print("Creating unique index for reactions")
        c.execute(
            '''CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_reaction ON reactions (message_id, user_uuid, emoji)''')

        print("Inserting default 'general' channel")
        c.execute("INSERT OR IGNORE INTO channels (id, name, icon) VALUES ('general', 'general', 'fas fa-circle')")

        print("Creating media_channels table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS media_channels (
            name TEXT PRIMARY KEY
        )''')

        print("Inserting default 'default' media channel")
        c.execute("INSERT OR IGNORE INTO media_channels (name) VALUES ('default')")

        print("Creating system_users table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS system_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT UNIQUE NOT NULL,
            display_name TEXT NOT NULL
        )''')

        print("Creating system_settings table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS system_settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )''')

        # Insert default system users
        default_system_users = [
            ('media_download', 'Media Download'),
            ('file_share', 'File Share'),
            ('cinema', 'Cinema'),
            ('voice', 'Voice'),
            ('system', 'System')
        ]
        c.executemany("INSERT OR IGNORE INTO system_users (category, display_name) VALUES (?, ?)", default_system_users)

        print("Creating user_notes table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS user_notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uuid TEXT NOT NULL UNIQUE,
            user_uuid TEXT NOT NULL,
            title TEXT NOT NULL,
            content TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (user_uuid) REFERENCES users(uuid) ON DELETE CASCADE
        )''')

        # Create index for faster queries
        c.execute('''CREATE INDEX IF NOT EXISTS idx_user_notes_user_uuid ON user_notes (user_uuid)''')
        c.execute('''CREATE INDEX IF NOT EXISTS idx_user_notes_updated_at ON user_notes (updated_at DESC)''')

        print("Creating user_settings table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS user_settings (
            user_uuid TEXT PRIMARY KEY,
            settings TEXT NOT NULL,
            FOREIGN KEY (user_uuid) REFERENCES users(uuid) ON DELETE CASCADE
        )''')

        print("Creating dm_messages table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS dm_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender_uuid TEXT,
            recipient_uuid TEXT,
            message TEXT,
            is_media INTEGER DEFAULT 0,
            timestamp TEXT,
            read_status INTEGER DEFAULT 0,
            FOREIGN KEY (sender_uuid) REFERENCES users(uuid),
            FOREIGN KEY (recipient_uuid) REFERENCES users(uuid)
        )''')

        conn.commit()
        # Migrate avatar URLs from old path to new user_avatars path
        try:
            c.execute("UPDATE users SET avatar_url = REPLACE(avatar_url, '/static/avatars/', '/static/user_avatars/') WHERE avatar_url LIKE '/static/avatars/%'")
            migrated_count = c.rowcount
            if migrated_count > 0:
                print(f"Migrated {migrated_count} user avatar URLs to new user_avatars path")
            conn.commit()
        except Exception as e:
            print(f"Error during avatar URL migration: {str(e)}")

        # Ensure user folders exist
        ensure_user_folders()

        print("Database initialization completed successfully")
    except Exception as e:
        print(f"Error during database initialization: {str(e)}")
        raise
    finally:
        conn.close()


def load_users():
    users_db = {}
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("""SELECT uuid, username, password_hash, avatar_url, display_name, status,
                        custom_status, theme, font, font_scale, compact_mode, show_timestamps, animated_bg, cursor_effect, particle_style, cursor_main, cursor_particle, cursor_glow, cursor_size, allow_dms,
                        show_online_status, typing_indicators, toast_on_media_download FROM users""")
        for row in c.fetchall():
            # Validate theme
            theme = row[7] or 'dobo'
            valid_themes = ['dobo', 'retro-green', 'blue', 'ice-blue', 'hpos10i', 'cabo', 'dark', 'purple', 'pika-yellow', 'nature', 'light', 'minimal', 'gray', 'classic']
            if theme not in valid_themes:
                theme = 'dobo'  # Default to dobo for invalid themes

            users_db[row[0]] = {
                'username': row[1],
                'password_hash': row[2],
                'avatar_url': row[3],
                'display_name': row[4],
                'status': row[5] or 'online',
                'custom_status': row[6],
                'theme': theme,
                'font': row[8] or 'system',
                'font_scale': row[9] or 1.0,
                'compact_mode': bool(row[10]),
                'show_timestamps': bool(row[11]) if row[11] is not None else True,
                'animated_bg': row[12] or 'none',
                'cursor_effect': row[13] or 'orbiting',
                'particle_style': row[14] or 'theme',

                'cursor_main': row[15] or 'default',
                'cursor_particle': row[16] or 'default',
                'cursor_glow': bool(row[17]) if row[17] is not None else False,
                'cursor_size': int(row[18]) if row[18] is not None else 64,
                'allow_dms': bool(row[19]) if row[19] is not None else True,
                'show_online_status': bool(row[20]) if row[20] is not None else True,
                'typing_indicators': bool(row[21]) if row[21] is not None else True,
                'toast_on_media_download': bool(row[22]) if row[22] is not None else True
            }
        conn.close()

        # Load updated avatar_url, display_name, and custom_status from user_settings if available
        for user_uuid, user_data in users_db.items():
            settings = get_user_settings(user_uuid)
            if settings:
                if settings.get('avatar_url'):
                    user_data['avatar_url'] = settings['avatar_url']
                if settings.get('display_name'):
                    user_data['display_name'] = settings['display_name']
                if settings.get('custom_status'):
                    user_data['custom_status'] = settings['custom_status']
                print(f"Loaded settings for user {user_data.get('username', user_uuid)}: avatar={settings.get('avatar_url')}, display_name={settings.get('display_name')}")

        print(f"Loaded {len(users_db)} users from database")
        return users_db
    except Exception as e:
        print(f"Error loading users: {str(e)}")
        raise


def save_user(uuid, username, password, avatar_url=None, display_name=None, custom_status=None, is_admin=False):
    password_hash = generate_password_hash(password)
    try:
        conn = sqlite3.connect(CHAT_DB_NAME)
        c = conn.cursor()
        c.execute("INSERT INTO users (uuid, username, password_hash, avatar_url, display_name, custom_status, is_admin) VALUES (?, ?, ?, ?, ?, ?, ?)",
                  (uuid, username, password_hash, avatar_url, display_name, custom_status, 1 if is_admin else 0))
        conn.commit()
        print(f"Saved user: {username}")

        # Create user folder
        folder_path = f'file_share_system/{username}'
        if not get_folder_by_path(folder_path):
            c.execute("INSERT INTO folders (name, path, created_at, created_by) VALUES (?, ?, ?, ?)",
                      (username, folder_path, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), username))
            conn.commit()
            # Create the filesystem directory
            os.makedirs(os.path.join('static', folder_path), exist_ok=True)
            print(f"Created folder for new user: {username}")

        return password_hash
    except sqlite3.IntegrityError as e:
        if "UNIQUE constraint failed" in str(e):
            raise ValueError("Username already taken")
        raise e
    except Exception as e:
        print(f"Error saving user {username}: {str(e)}")
        raise
    finally:
        conn.close()


def update_user_avatar(uuid, avatar_url):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("UPDATE users SET avatar_url = ? WHERE uuid = ?", (avatar_url, uuid))
        conn.commit()
        print(f"Updated avatar for user UUID: {uuid}")
    except Exception as e:
        print(f"Error updating avatar for user UUID {uuid}: {str(e)}")
        raise
    finally:
        conn.close()


def check_username_available(username):
    """Check if a username is available (not taken by existing user)."""
    try:
        conn = sqlite3.connect(CHAT_DB_NAME)
        c = conn.cursor()
        c.execute("SELECT COUNT(*) FROM users WHERE username = ?", (username,))
        count = c.fetchone()[0]
        conn.close()
        available = count == 0
        print(f"Username '{username}' availability check: {'available' if available else 'taken'}")
        return available
    except Exception as e:
        print(f"Error checking username availability for {username}: {str(e)}")
        raise


def get_user_by_username(username):
    try:
        conn = sqlite3.connect(CHAT_DB_NAME)
        c = conn.cursor()
        c.execute("""SELECT uuid, username, password_hash, avatar_url, display_name, status,
                        custom_status, theme, font, font_scale, compact_mode, show_timestamps, animated_bg, cursor_effect, cursor_main, cursor_particle, cursor_glow, cursor_size, allow_dms,
                        show_online_status, typing_indicators, is_admin FROM users WHERE username = ?""", (username,))
        row = c.fetchone()
        conn.close()
        if row:
            print(f"Retrieved user: {username}")
            # Validate theme
            theme = row[7] or 'dobo'
            valid_themes = ['dobo', 'retro-green', 'blue', 'ice-blue', 'hpos10i', 'cabo', 'dark', 'purple', 'pika-yellow', 'nature', 'light', 'minimal', 'gray', 'classic']
            if theme not in valid_themes:
                theme = 'dobo'  # Default to dobo for invalid themes

            return {
                'uuid': row[0],
                'username': row[1],
                'password_hash': row[2],
                'avatar_url': row[3],
                'display_name': row[4],
                'status': row[5] or 'online',
                'custom_status': row[6],
                'theme': theme,
                'font': row[8] or 'system',
                'font_scale': row[9] or 1.0,
                'compact_mode': bool(row[10]),
                'show_timestamps': bool(row[11]) if row[11] is not None else True,
                'animated_bg': row[12] or 'none',
                'cursor_effect': row[13] or 'orbiting',
                'cursor_main': row[14] or 'default',
                'cursor_particle': row[15] or 'default',
                'cursor_glow': bool(row[16]) if row[16] is not None else False,
                'cursor_size': int(row[17]) if row[17] is not None else 64,
                'allow_dms': bool(row[18]) if row[18] is not None else True,
                'show_online_status': bool(row[19]) if row[19] is not None else True,
                'typing_indicators': bool(row[20]) if row[20] is not None else True,
                'is_admin': bool(row[21]) if row[21] is not None else False
            }
        print(f"User not found: {username}")
        return None
    except Exception as e:
        print(f"Error retrieving user {username}: {str(e)}")
        raise


def get_username_by_uuid(user_uuid):
    """Get username by user UUID"""
    try:
        conn = sqlite3.connect(CHAT_DB_NAME)
        c = conn.cursor()
        c.execute("SELECT username FROM users WHERE uuid = ?", (user_uuid,))
        row = c.fetchone()
        conn.close()
        if row:
            return row[0]
        return None
    except Exception as e:
        print(f"Error retrieving username for UUID {user_uuid}: {str(e)}")
        return None


def is_user_admin(user_uuid):
    """Check if a user is an admin"""
    try:
        conn = sqlite3.connect(CHAT_DB_NAME)
        c = conn.cursor()
        c.execute("SELECT is_admin FROM users WHERE uuid = ?", (user_uuid,))
        row = c.fetchone()
        conn.close()
        return bool(row[0]) if row else False
    except Exception as e:
        print(f"Error checking admin status for {user_uuid}: {str(e)}")
        return False


def load_channels():
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("SELECT name FROM channels")
        channels = [row[0] for row in c.fetchall()]
        conn.close()
        print(f"Loaded {len(channels)} channels from database")
        return channels
    except Exception as e:
        print(f"Error loading channels: {str(e)}")
        raise

def create_channel(name):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("INSERT OR IGNORE INTO channels (name) VALUES (?)", (name,))
        success = c.rowcount > 0
        conn.commit()
        conn.close()
        return success
    except Exception as e:
        print(f"Error creating channel: {str(e)}")
        return False

def delete_channel(name):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("DELETE FROM channels WHERE name = ?", (name,))
        success = c.rowcount > 0
        conn.commit()
        conn.close()
        return success
    except Exception as e:
        print(f"Error deleting channel: {str(e)}")
        return False

def load_media_channels():
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("SELECT name FROM media_channels")
        channels = [row[0] for row in c.fetchall()]
        conn.close()
        print(f"Loaded {len(channels)} media channels from database")
        return channels
    except Exception as e:
        print(f"Error loading media channels: {str(e)}")
        raise

def create_media_channel(name):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("INSERT OR IGNORE INTO media_channels (name) VALUES (?)", (name,))
        success = c.rowcount > 0
        conn.commit()
        conn.close()
        return success
    except Exception as e:
        print(f"Error creating media channel: {str(e)}")
        return False

def delete_media_channel(name):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("DELETE FROM media_channels WHERE name = ?", (name,))
        success = c.rowcount > 0
        conn.commit()
        conn.close()
        return success
    except Exception as e:
        print(f"Error deleting media channel: {str(e)}")
        return False

def load_messages(channel, limit=None):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        if limit:
            # Use a subquery to get the most recent messages in correct order
            c.execute(
                """SELECT m.id, m.sender, m.message, m.is_media, m.timestamp, m.replied_to,
                            m.replied_sender, m.replied_text, m.image_url, m.thumbnail_url,
                            (SELECT COUNT(*) FROM messages r WHERE r.replied_to = m.id) as replies_count
                     FROM messages m
                     WHERE m.channel = ? AND m.id IN (
                         SELECT id FROM messages
                         WHERE channel = ?
                         ORDER BY timestamp DESC
                         LIMIT ?
                     )
                     ORDER BY m.timestamp ASC""",
                (channel, channel, limit))
        else:
            c.execute(
                """SELECT m.id, m.sender, m.message, m.is_media, m.timestamp, m.replied_to,
                            m.replied_sender, m.replied_text, m.image_url, m.thumbnail_url,
                            (SELECT COUNT(*) FROM messages r WHERE r.replied_to = m.id) as replies_count
                     FROM messages m WHERE m.channel = ? ORDER BY m.timestamp ASC""",
                (channel,))

        messages = [
            {
                'id': row[0],
                'sender': row[1],
                'message': row[2],
                'is_media': row[3],
                'timestamp': row[4],
                'replied_to': row[5],
                'replied_sender': row[6],
                'replied_text': row[7],
                'image_url': row[8],
                'thumbnail_url': row[9],
                'replies_count': row[10],
                'reactions': get_reactions(row[0])
            }
            for row in c.fetchall()
        ]

        conn.close()
        print(f"Loaded {len(messages)} messages for channel: {channel}")
        return messages
    except Exception as e:
        print(f"Error loading messages for channel {channel}: {str(e)}")
        raise


def add_reaction(message_id, user_uuid, emoji):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("INSERT OR IGNORE INTO reactions (message_id, user_uuid, emoji) VALUES (?, ?, ?)",
                  (message_id, user_uuid, emoji))
        conn.commit()
        print(f"Added reaction {emoji} to message ID {message_id} by user UUID {user_uuid}")
    except Exception as e:
        print(f"Error adding reaction to message ID {message_id}: {str(e)}")
        raise
    finally:
        conn.close()


def remove_reaction(message_id, user_uuid, emoji):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("DELETE FROM reactions WHERE message_id = ? AND user_uuid = ? AND emoji = ?",
                  (message_id, user_uuid, emoji))
        conn.commit()
        print(f"Removed reaction {emoji} from message ID {message_id} by user UUID {user_uuid}")
    except Exception as e:
        print(f"Error removing reaction from message ID {message_id}: {str(e)}")
        raise
    finally:
        conn.close()


def get_reactions(message_id):
    try:
        conn = sqlite3.connect(CHAT_DB_NAME)
        c = conn.cursor()
        c.execute("SELECT user_uuid, emoji FROM reactions WHERE message_id = ?", (message_id,))
        rows = c.fetchall()
        conn.close()
        return [{'user_uuid': row[0], 'emoji': row[1]} for row in rows]
    except Exception as e:
        print(f"Error getting reactions for message {message_id}: {str(e)}")
        return []


def delete_message(message_id):
    """Delete a message by ID (admin only)"""
    try:
        conn = sqlite3.connect(CHAT_DB_NAME)
        c = conn.cursor()
        c.execute("DELETE FROM messages WHERE id = ?", (message_id,))
        c.execute("DELETE FROM reactions WHERE message_id = ?", (message_id,))
        conn.commit()
        conn.close()
        print(f"Deleted message {message_id}")
        return True
    except Exception as e:
        print(f"Error deleting message {message_id}: {str(e)}")
        return False
    finally:
        conn.close()

def create_user_note(user_uuid, note_uuid, title, content):
    """Create a new note for a user."""
    conn = sqlite3.connect('devchat.db')
    c = conn.cursor()
    try:
        timestamp = get_standard_timestamp()
        c.execute('''INSERT INTO user_notes (uuid, user_uuid, title, content, created_at, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?)''',
                  (note_uuid, user_uuid, title, content, timestamp, timestamp))
        conn.commit()
        print(f"Created note {note_uuid} for user {user_uuid}")
        return True
    except Exception as e:
        print(f"Error creating user note: {str(e)}")
        return False
    finally:
        conn.close()

def update_user_note(note_uuid, title, content):
    """Update an existing note and return the updated note data."""
    conn = sqlite3.connect('devchat.db')
    c = conn.cursor()
    try:
        timestamp = get_standard_timestamp()
        c.execute('''UPDATE user_notes
                     SET title = ?, content = ?, updated_at = ?
                     WHERE uuid = ?''',
                  (title, content, timestamp, note_uuid))

        # Fetch the updated note data
        c.execute('''SELECT uuid, title, content, created_at, updated_at
                     FROM user_notes WHERE uuid = ?''', (note_uuid,))
        row = c.fetchone()

        conn.commit()

        if row:
            updated_note = {
                'uuid': row[0],
                'title': row[1],
                'content': row[2],
                'created_at': row[3],
                'updated_at': row[4]
            }
            print(f"Updated note {note_uuid}")
            return updated_note
        else:
            print(f"Note {note_uuid} not found after update")
            return None
    except Exception as e:
        print(f"Error updating user note: {str(e)}")
        return None
    finally:
        conn.close()

def delete_user_note(note_uuid):
    """Delete a note by UUID."""
    conn = sqlite3.connect('devchat.db')
    c = conn.cursor()
    try:
        c.execute('DELETE FROM user_notes WHERE uuid = ?', (note_uuid,))
        conn.commit()
        print(f"Deleted note {note_uuid}")
        return True
    except Exception as e:
        print(f"Error deleting user note: {str(e)}")
        return False
    finally:
        conn.close()

def rename_user_note(note_uuid, new_title):
    """Rename a note and return the updated note data."""
    conn = sqlite3.connect('devchat.db')
    c = conn.cursor()
    try:
        timestamp = get_standard_timestamp()
        c.execute('''UPDATE user_notes
                     SET title = ?, updated_at = ?
                     WHERE uuid = ?''',
                  (new_title, timestamp, note_uuid))

        # Fetch the updated note data
        c.execute('''SELECT uuid, title, content, created_at, updated_at
                     FROM user_notes WHERE uuid = ?''', (note_uuid,))
        row = c.fetchone()

        conn.commit()

        if row:
            updated_note = {
                'uuid': row[0],
                'title': row[1],
                'content': row[2],
                'created_at': row[3],
                'updated_at': row[4]
            }
            print(f"Renamed note {note_uuid} to '{new_title}'")
            return updated_note
        else:
            print(f"Note {note_uuid} not found after rename")
            return None
    except Exception as e:
        print(f"Error renaming user note: {str(e)}")
        return None
    finally:
        conn.close()

def get_user_notes(user_uuid):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("SELECT uuid, title, content, created_at, updated_at FROM user_notes WHERE user_uuid = ? ORDER BY updated_at DESC", (user_uuid,))
        rows = c.fetchall()
        conn.close()

        notes = []
        for row in rows:
            notes.append({
                'uuid': row[0],
                'title': row[1],
                'content': row[2],
                'created_at': row[3],
                'updated_at': row[4]
            })
        return notes
    except Exception as e:
        print(f"Error getting user notes: {str(e)}")
        return []

def update_user_settings(user_uuid, settings):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        settings_json = json.dumps(settings)
        c.execute("INSERT OR REPLACE INTO user_settings (user_uuid, settings) VALUES (?, ?)", (user_uuid, settings_json))

        # Also update users table if avatar_url, display_name, or custom_status are being updated
        update_fields = []
        update_values = []
        if 'avatar_url' in settings:
            update_fields.append("avatar_url = ?")
            update_values.append(settings['avatar_url'])
        if 'display_name' in settings:
            update_fields.append("display_name = ?")
            update_values.append(settings['display_name'])
        if 'custom_status' in settings:
            update_fields.append("custom_status = ?")
            update_values.append(settings['custom_status'])
        if 'font' in settings:
            update_fields.append("font = ?")
            update_values.append(settings['font'])
        if 'font_scale' in settings:
            update_fields.append("font_scale = ?")
            update_values.append(settings['font_scale'])
        if 'toast_on_media_download' in settings:
            update_fields.append("toast_on_media_download = ?")
            update_values.append(int(settings['toast_on_media_download']))
        if 'theme' in settings:
            update_fields.append("theme = ?")
            update_values.append(settings['theme'])
        if 'animated_bg' in settings:
            update_fields.append("animated_bg = ?")
            update_values.append(settings['animated_bg'])
        if 'cursor_effect' in settings:
            update_fields.append("cursor_effect = ?")
            update_values.append(settings['cursor_effect'])
        if 'cursor_main' in settings:
            update_fields.append("cursor_main = ?")
            update_values.append(settings['cursor_main'])
        if 'cursor_particle' in settings:
            update_fields.append("cursor_particle = ?")
            update_values.append(settings['cursor_particle'])
        if 'cursor_glow' in settings:
            update_fields.append("cursor_glow = ?")
            update_values.append(int(settings['cursor_glow']))
        if 'cursor_size' in settings:
            update_fields.append("cursor_size = ?")
            update_values.append(int(settings['cursor_size']))
        if 'particle_style' in settings:
            update_fields.append("particle_style = ?")
            update_values.append(settings['particle_style'])
        if 'particle_size' in settings:
            update_fields.append("particle_size = ?")
            update_values.append(float(settings['particle_size']))
        if 'auto_hide_particles' in settings:
            update_fields.append("auto_hide_particles = ?")
            update_values.append(int(settings['auto_hide_particles']))
        if 'auto_hide_timeout' in settings:
            update_fields.append("auto_hide_timeout = ?")
            update_values.append(int(settings['auto_hide_timeout']))
        if 'mic_volume' in settings:
            update_fields.append("mic_volume = ?")
            update_values.append(float(settings['mic_volume']))
        if 'receive_volume' in settings:
            update_fields.append("receive_volume = ?")
            update_values.append(float(settings['receive_volume']))
        if 'mute' in settings:
            update_fields.append("mute = ?")
            update_values.append(int(settings['mute']))

        if update_fields:
            update_values.append(user_uuid)
            c.execute(f"UPDATE users SET {', '.join(update_fields)} WHERE uuid = ?", update_values)

        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error updating user settings: {str(e)}")
        return False

def get_user_settings(user_uuid):
    # Default settings for new users
    default_settings = {
        'display_name': '',
        'status': 'online',
        'custom_status': '',
        'theme': 'dobo',
        'font': 'system',
        'font_scale': 1.0,
        'compact_mode': False,
        'show_timestamps': True,
        'animated_bg': 'none',
        'cursor_effect': 'orbiting',
        'particle_style': 'theme',
        'particle_size': 1.0,
        'cursor_main': 'default',
        'cursor_particle': 'default',
        'cursor_glow': False,
        'cursor_size': 64,
        'allow_dms': True,
        'show_online_status': True,
        'typing_indicators': True,
        'avatar_url': None,
        'auto_hide_particles': True,
        'auto_hide_timeout': 10,
        'mic_volume': 1.0,
        'receive_volume': 1.0,
        'mute': False,
        'toast_on_media_download': True
    }

    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        # Get user settings from user_settings table
        c.execute("SELECT settings FROM user_settings WHERE user_uuid = ?", (user_uuid,))
        user_settings_row = c.fetchone()

        # Get user-specific settings from users table
        c.execute("""SELECT display_name, custom_status, theme, font, font_scale, compact_mode,
                        show_timestamps, animated_bg, cursor_effect, particle_style, cursor_main,
                        cursor_particle, cursor_glow, cursor_size, allow_dms, show_online_status,
                        typing_indicators, avatar_url, toast_on_media_download, auto_hide_particles,
                        auto_hide_timeout, mic_volume, receive_volume, mute
                      FROM users WHERE uuid = ?""", (user_uuid,))
        user_row = c.fetchone()

        conn.close()

        # Start with default settings
        settings = default_settings.copy()

        # Merge user settings from user_settings table
        if user_settings_row:
            user_settings = json.loads(user_settings_row[0])
            settings.update(user_settings)

        # Override with user-specific settings from users table
        if user_row:
            settings.update({
                'display_name': user_row[0] or '',
                'custom_status': user_row[1] or '',
                'theme': user_row[2] or 'dobo',
                'font': user_row[3] or 'system',
                'font_scale': float(user_row[4]) if user_row[4] is not None else 1.0,
                'compact_mode': bool(user_row[5]),
                'show_timestamps': bool(user_row[6]) if user_row[6] is not None else True,
                'animated_bg': user_row[7] or 'none',
                'cursor_effect': user_row[8] or 'orbiting',
                'particle_style': user_row[9] or 'theme',
                'cursor_main': user_row[10] or 'default',
                'cursor_particle': user_row[11] or 'default',
                'cursor_glow': bool(user_row[12]) if user_row[12] is not None else False,
                'cursor_size': int(user_row[13]) if user_row[13] is not None else 64,
                'allow_dms': bool(user_row[14]) if user_row[14] is not None else True,
                'show_online_status': bool(user_row[15]) if user_row[15] is not None else True,
                'typing_indicators': bool(user_row[16]) if user_row[16] is not None else True,
                'avatar_url': user_row[17],
                'toast_on_media_download': bool(user_row[18]) if user_row[18] is not None else True,
                'auto_hide_particles': bool(user_row[19]) if user_row[19] is not None else True,
                'auto_hide_timeout': int(user_row[20]) if user_row[20] is not None else 10,
                'mic_volume': float(user_row[21]) if user_row[21] is not None else 1.0,
                'receive_volume': float(user_row[22]) if user_row[22] is not None else 1.0,
                'mute': bool(user_row[23]) if user_row[23] is not None else False
            })

        return settings
    except Exception as e:
        print(f"Error getting user settings: {str(e)}")
        return default_settings

def create_folder(name, parent_id, created_by):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        timestamp = get_standard_timestamp()
        if parent_id:
            c.execute("SELECT path FROM folders WHERE id = ?", (parent_id,))
            parent_row = c.fetchone()
            if not parent_row:
                conn.close()
                return None
            parent_path = parent_row[0]
            path = f"{parent_path}/{name}"
        else:
            path = f"file_share_system/{name}"
        c.execute("INSERT INTO folders (name, parent_id, path, created_at, created_by) VALUES (?, ?, ?, ?, ?)", (name, parent_id, path, timestamp, created_by))
        folder_id = c.lastrowid
        conn.commit()
        conn.close()
        return folder_id
    except Exception as e:
        print(f"Error creating folder: {str(e)}")
        return None

def get_folder_structure():
    """Get the complete folder structure as a hierarchical tree."""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        def build_tree(parent_id=None):
            c.execute("SELECT id, name, path, created_at, created_by FROM folders WHERE parent_id IS ? ORDER BY name", (parent_id,))
        folders = []
        for row in c.fetchall():
            folder = {
                'id': row[0],
                'name': row[1],
                'path': row[2],
                'created_at': row[3],
                'created_by': row[4],
                'children': []  # For now, keep it simple
            }
            folders.append(folder)

        # Also include the Public folder
        public_folder = get_folder_by_path('file_share_system/Public_Folder')
        if public_folder:
            folders.append({
                'id': public_folder['id'],
                'name': public_folder['name'],
                'path': public_folder['path'],
                'created_at': public_folder['created_at'],
                'created_by': public_folder['created_by'],
                'children': []
            })

        conn.close()
        return folders

        root_folders = build_tree()
        conn.close()
        return root_folders
    except Exception as e:
        print(f"Error getting folder structure: {str(e)}")
        return []

def get_folder_by_id(folder_id):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("SELECT id, name, parent_id, path, created_at, created_by FROM folders WHERE id = ?", (folder_id,))
        row = c.fetchone()
        conn.close()
        if row:
            return {
                'id': row[0],
                'name': row[1],
                'parent_id': row[2],
                'path': row[3],
                'created_at': row[4],
                'created_by': row[5]
            }
        return None
    except Exception as e:
        print(f"Error getting folder by id: {str(e)}")
        return None

def get_folder_by_path(path):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("SELECT id, name, parent_id, path, created_at, created_by FROM folders WHERE path = ?", (path,))
        row = c.fetchone()
        conn.close()
        if row:
            return {
                'id': row[0],
                'name': row[1],
                'parent_id': row[2],
                'path': row[3],
                'created_at': row[4],
                'created_by': row[5]
            }
        return None
    except Exception as e:
        print(f"Error getting folder by path: {str(e)}")
        return None

def ensure_user_folders():
    """Ensure each user has a personal folder."""
    try:
        print("Ensuring user folders exist...")
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        # Get all usernames
        c.execute("SELECT username FROM users")
        users = c.fetchall()
        print(f"Found {len(users)} users")

        for (username,) in users:
            folder_path = f'file_share_system/{username}'
            if not get_folder_by_path(folder_path):
                # Create the folder
                c.execute("INSERT INTO folders (name, path, created_at, created_by) VALUES (?, ?, ?, ?)",
                          (username, folder_path, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), username))
                # Create the filesystem directory
                os.makedirs(os.path.join('static', folder_path), exist_ok=True)
                print(f"Created folder for user: {username}")
            else:
                # Ensure filesystem directory exists
                os.makedirs(os.path.join('static', folder_path), exist_ok=True)
                print(f"Folder already exists for user: {username}")

        conn.commit()
        conn.close()
        print("User folders ensured.")
    except Exception as e:
        print(f"Error ensuring user folders: {str(e)}")

def get_user_folder_structure(user):
    """Get folder structure for a specific user's private folders."""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        def build_user_tree(parent_id=None):
            if parent_id is None:
                # Root level - get folders created by user or system root
                 c.execute("""
                     SELECT id, name, path, created_at, created_by
                     FROM folders
                     WHERE parent_id IS NULL AND (created_by = ? OR name = 'Share')
                     ORDER BY CASE WHEN name = 'Share' THEN 0 ELSE 1 END, name
                 """, (user,))
            else:
                # Child folders - only user's folders
                c.execute("""
                    SELECT id, name, path, created_at, created_by
                    FROM folders
                    WHERE parent_id = ? AND created_by = ?
                    ORDER BY name
                """, (parent_id, user))

            folders = []
            for row in c.fetchall():
                folder = {
                    'id': row[0],
                    'name': row[1],
                    'path': row[2],
                    'created_at': row[3],
                    'created_by': row[4],
                    'children': build_user_tree(row[0])
                }
                folders.append(folder)
            return folders

        root_folders = build_user_tree()
        conn.close()
        return root_folders
    except Exception as e:
        print(f"Error getting user folder structure: {str(e)}")
        return []

def get_public_folder_structure():
    """Get folder structure containing public files."""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        # Get folders that have public files
        c.execute("""
            SELECT DISTINCT f.id, f.name, f.path, f.created_at, f.created_by
            FROM folders f
            INNER JOIN file_folders ff ON f.id = ff.folder_id
            WHERE ff.visibility = 'public' AND ff.ownership = 'user'
            ORDER BY f.name
        """)

        folders = []
        for row in c.fetchall():
            folder = {
                'id': row[0],
                'name': row[1],
                'path': row[2],
                'created_at': row[3],
                'created_by': row[4],
                'children': []  # For now, keep it simple
            }
            folders.append(folder)

        conn.close()
        return folders
    except Exception as e:
        print(f"Error getting public folder structure: {str(e)}")
        return []

def get_system_folder_structure():
    """Get folder structure for system files."""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        # Get folders that have system files
        c.execute("""
            SELECT DISTINCT f.id, f.name, f.path, f.created_at, f.created_by
            FROM folders f
            INNER JOIN file_folders ff ON f.id = ff.folder_id
            WHERE ff.ownership = 'system'
            ORDER BY f.name
        """)

        folders = []
        for row in c.fetchall():
            folder = {
                'id': row[0],
                'name': row[1],
                'path': row[2],
                'created_at': row[3],
                'created_by': row[4],
                'children': []  # For now, keep it simple
            }
            folders.append(folder)

        conn.close()
        return folders
    except Exception as e:
        print(f"Error getting system folder structure: {str(e)}")
        return []

def delete_folder(folder_id):
    """Delete a folder and all its contents from database and filesystem."""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        # Get folder info before deletion
        c.execute("SELECT path FROM folders WHERE id = ?", (folder_id,))
        row = c.fetchone()
        if not row:
            conn.close()
            return False

        folder_path = row[0]

        # Delete folder from database (CASCADE will delete files and subfolders)
        c.execute("DELETE FROM folders WHERE id = ?", (folder_id,))
        conn.commit()
        conn.close()

        # Remove filesystem directory and all contents
        full_path = os.path.join('static', folder_path)
        if os.path.exists(full_path):
            shutil.rmtree(full_path)
            print(f"Removed folder directory: {full_path}")

        print(f"Deleted folder {folder_id} and path {folder_path}")
        return True
    except Exception as e:
        print(f"Error deleting folder {folder_id}: {str(e)}")
        return False

def get_files_in_folder(folder_id, user=None, visibility_filter=None):
    """Get files in folder with optional filtering by user and visibility."""
    conn = None
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        # Handle folder_id = 0 as root folder
        if folder_id == 0:
            # Get the root folder ID (the 'Share' folder)
            root_query = "SELECT id FROM folders WHERE parent_id IS NULL AND name = 'Share'"
            c.execute(root_query)
            root_result = c.fetchone()
            if root_result:
                root_folder_id = root_result[0]
                query = """
                    SELECT id, filename, filepath, size, created_at, created_by, thumbnail_url,
                           visibility, shared_by, ownership
                    FROM file_folders
                    WHERE folder_id = ?
                """
                params = [root_folder_id]
            else:
                # Fallback: if no root folder, get files with NULL folder_id
                query = """
                    SELECT id, filename, filepath, size, created_at, created_by, thumbnail_url,
                           visibility, shared_by, ownership
                    FROM file_folders
                    WHERE folder_id IS NULL
                """
                params = []
        else:
            query = """
                SELECT id, filename, filepath, size, created_at, created_by, thumbnail_url,
                       visibility, shared_by, ownership
                FROM file_folders
                WHERE folder_id = ?
            """
            params = [folder_id]

        # Add visibility filtering
        if visibility_filter:
            if visibility_filter == 'public':
                # Public: show files shared by any user (visibility='public' and ownership='user')
                query += " AND visibility = 'public' AND ownership = 'user'"
            elif visibility_filter == 'private':
                # Private: show only user's own files that are not shared (visibility='private')
                query += " AND visibility = 'private' AND created_by = ? AND ownership = 'user'"
                params.append(user)
            elif visibility_filter == 'system':
                # System: show system-owned files
                query += " AND ownership = 'system'"

        query += " ORDER BY created_at DESC"

        c.execute(query, params)
        rows = c.fetchall()

        files = []
        for row in rows:
            files.append({
                'id': row[0],
                'filename': row[1],
                'filepath': row[2],
                'size': row[3],
                'created_at': row[4],
                'created_by': row[5],
                'thumbnail_url': row[6],
                'visibility': row[7] or 'private',
                'shared_by': row[8],
                'ownership': row[9] or 'user'
            })
        return files
    except Exception as e:
        print(f"Error getting files in folder: {str(e)}")
        return []
    finally:
        if conn:
            conn.close()

def add_file_to_folder(filename, folder_id, filepath, size, created_by, thumbnail_url=None, visibility='private', ownership='user'):
    """Add a file to a folder with sharing options."""
    conn = None
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("""
            INSERT INTO file_folders (filename, folder_id, filepath, size, created_at, created_by, thumbnail_url, visibility, ownership)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (filename, folder_id, filepath, size, datetime.now().isoformat(), created_by, thumbnail_url, visibility, ownership))
        file_id = c.lastrowid
        conn.commit()
        return file_id
    except Exception as e:
        print(f"Error adding file to folder: {str(e)}")
        if conn:
            conn.rollback()
        return None
    finally:
        if conn:
            conn.close()

def update_file_visibility(file_id, visibility, shared_by=None):
    """Update file visibility and sharing info."""
    conn = None
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("""
            UPDATE file_folders
            SET visibility = ?, shared_by = ?
            WHERE id = ?
        """, (visibility, shared_by, file_id))
        conn.commit()
        return True
    except Exception as e:
        print(f"Error updating file visibility: {str(e)}")
        if conn:
            conn.rollback()
        return False
    finally:
        if conn:
            conn.close()

def delete_file_from_folder(file_id):
    """Delete a file from a folder."""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("DELETE FROM file_folders WHERE id = ?", (file_id,))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error deleting file from folder: {str(e)}")
        return False

def rename_folder(folder_id, new_name):
    """Rename a folder in the database."""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        # Update the folder name
        c.execute("UPDATE folders SET name = ? WHERE id = ?", (new_name, folder_id))
        success = c.rowcount > 0
        conn.commit()
        conn.close()

        if success:
            print(f"Renamed folder {folder_id} to '{new_name}'")
        return success
    except Exception as e:
        print(f"Error renaming folder {folder_id}: {str(e)}")
        return False

def get_system_display_name(category):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("SELECT display_name FROM system_users WHERE category = ?", (category,))
        row = c.fetchone()
        conn.close()
        return row[0] if row else category
    except Exception as e:
        print(f"Error getting system display name: {str(e)}")
        return category


def get_user_image_preferences(user_uuid):
    """Get user's image generation preferences"""
    try:
        conn = sqlite3.connect(CHAT_DB_NAME)
        c = conn.cursor()
        c.execute("""SELECT last_sd_model, last_img_width, last_img_height, last_img_steps,
                            last_img_cfg_scale, last_img_clip_skip, last_img_negative_prompt,
                            last_img_sampler, last_img_scheduler, last_img_batch_size, last_uploaded_image
                     FROM users WHERE uuid = ?""", (user_uuid,))
        row = c.fetchone()
        conn.close()

        if row:
            return {
                'model_name': row[0] or '',
                'width': row[1] or 1024,
                'height': row[2] or 1024,
                'steps': row[3] or 33,
                'cfg_scale': row[4] or 7.0,
                'clip_skip': row[5] or 2,
                'negative_prompt': row[6] or '',
                'sampler_name': row[7] or 'DPM++ 3M SDE',
                'scheduler_name': row[8] or 'simple',
                'batch_size': row[9] or 1,
                'uploaded_image': row[10]
            }
        else:
            # User not found, return defaults
            return {
                'model_name': '',
                'width': 1024,
                'height': 1024,
                'steps': 33,
                'cfg_scale': 7.0,
                'clip_skip': 2,
                'negative_prompt': '',
                'sampler_name': 'DPM++ 3M SDE',
                'scheduler_name': 'simple',
                'batch_size': 1,
                'uploaded_image': None
            }
    except Exception as e:
        print(f"Error getting user image preferences for {user_uuid}: {str(e)}")
        # Return defaults on error
        return {
            'model_name': '',
            'width': 1024,
            'height': 1024,
            'steps': 33,
            'cfg_scale': 7.0,
            'clip_skip': 2,
            'negative_prompt': '',
            'sampler_name': 'DPM++ 3M SDE',
            'scheduler_name': 'simple',
            'batch_size': 1,
            'uploaded_image': None
        }


def save_user_image_preferences(user_uuid, preferences):
    """Save user's image generation preferences"""
    try:
        conn = sqlite3.connect(CHAT_DB_NAME)
        c = conn.cursor()
        c.execute("""UPDATE users SET
                        last_sd_model = ?,
                        last_img_width = ?,
                        last_img_height = ?,
                        last_img_steps = ?,
                        last_img_cfg_scale = ?,
                        last_img_clip_skip = ?,
                        last_img_negative_prompt = ?,
                        last_img_sampler = ?,
                        last_img_scheduler = ?,
                        last_img_batch_size = ?,
                        last_uploaded_image = ?
                     WHERE uuid = ?""",
                   (preferences.get('last_sd_model', ''),
                   preferences.get('last_img_width', 1024),
                   preferences.get('last_img_height', 1024),
                   preferences.get('last_img_steps', 33),
                   preferences.get('last_img_cfg_scale', 7.0),
                   preferences.get('last_img_clip_skip', 2),
                   preferences.get('last_img_negative_prompt', ''),
                   preferences.get('last_img_sampler', 'DPM++ 3M SDE'),
                   preferences.get('last_img_scheduler', 'simple'),
                   preferences.get('last_img_batch_size', 1),
                   preferences.get('last_uploaded_image'),
                   user_uuid))
        conn.commit()
        conn.close()
        print(f"Saved image preferences for user {user_uuid}")
        return True
    except Exception as e:
        print(f"Error saving user image preferences for {user_uuid}: {str(e)}")
        return False

# ============================================================================
# Simplified File Share Database Functions - Public and Server Sections
# ============================================================================

def get_public_files(user):
    """Get all public files (user-owned files in Public_Folder)"""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        c.execute("""
            SELECT id, filename, filepath, size, created_at, created_by, thumbnail_url
            FROM file_folders
            WHERE filepath LIKE 'file_share_system/Public_Folder/%'
            AND created_by = ?
            ORDER BY created_at DESC
        """, (user,))

        files = []
        for row in c.fetchall():
            files.append({
                'id': row[0],
                'filename': row[1],
                'filepath': row[2],
                'size': row[3],
                'created_at': row[4],
                'created_by': row[5],
                'thumbnail_url': row[6]
            })

        conn.close()
        return files
    except Exception as e:
        print(f"Error getting public files for user {user}: {str(e)}")
        return []

def get_server_files():
    """Get all server files (read-only system files)"""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        c.execute("""
            SELECT id, filename, filepath, size, created_at, created_by, thumbnail_url
            FROM file_folders
            WHERE filepath LIKE 'file_share_system/system_shared_files/%'
            ORDER BY created_at DESC
        """)

        files = []
        for row in c.fetchall():
            files.append({
                'id': row[0],
                'filename': row[1],
                'filepath': row[2],
                'size': row[3],
                'created_at': row[4],
                'created_by': row[5],
                'thumbnail_url': row[6]
            })

        conn.close()
        return files
    except Exception as e:
        print(f"Error getting server files: {str(e)}")
        return []

def add_file_to_public(filename, filepath, size, created_by, thumbnail_url=None):
    """Add a file to the public section"""
    try:
        from datetime import datetime
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        created_at = datetime.now().isoformat()

        c.execute("""
            INSERT INTO file_folders (filename, filepath, size, created_at, created_by, thumbnail_url, visibility, ownership)
            VALUES (?, ?, ?, ?, ?, ?, 'public', 'user')
        """, (filename, filepath, size, created_at, created_by, thumbnail_url))

        file_id = c.lastrowid
        conn.commit()
        conn.close()

        print(f"Added public file: {filename} by {created_by}")
        return file_id
    except Exception as e:
        print(f"Error adding public file {filename}: {str(e)}")
        return None

def delete_file_from_public(filename, user):
    """Delete a file from the public section (only if user owns it)"""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        c.execute("""
            DELETE FROM file_folders
            WHERE filename = ? AND created_by = ? AND filepath LIKE 'file_share_system/Public_Folder/%'
        """, (filename, user))

        success = c.rowcount > 0
        conn.commit()
        conn.close()

        if success:
            print(f"Deleted public file: {filename} by {user}")
        return success
    except Exception as e:
        print(f"Error deleting public file {filename}: {str(e)}")
        return False

def rename_file_in_public(old_filename, new_filename, user):
    """Rename a file in the public section (only if user owns it)"""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        # Update filename and filepath
        new_filepath = f'file_share_system/Public_Folder/{new_filename}'

        c.execute("""
            UPDATE file_folders
            SET filename = ?, filepath = ?
            WHERE filename = ? AND created_by = ? AND filepath LIKE 'file_share_system/Public_Folder/%'
        """, (new_filename, new_filepath, old_filename, user))

        success = c.rowcount > 0
        conn.commit()
        conn.close()

        if success:
            print(f"Renamed public file: {old_filename} -> {new_filename} by {user}")
        return success
    except Exception as e:
        print(f"Error renaming public file {old_filename}: {str(e)}")
        return False

