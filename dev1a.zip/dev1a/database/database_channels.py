# database_channels.py - Channel management database functions
import sqlite3
from .database_manager import DatabaseManager

# Global database manager instance
db_manager = DatabaseManager('devchat.db')


def load_channels():
    """Load all channels from database."""
    try:
        query = "SELECT id, name, icon, ai_enabled, ai_memory_limit FROM channels"
        result = db_manager.execute_query(query, fetch=True)
        channels = [{
            'id': row['id'],
            'name': row['name'],
            'icon': row['icon'] if row['icon'] and row['icon'] != '#' else 'fas fa-circle',
            'ai_enabled': bool(row['ai_enabled']) if row['ai_enabled'] is not None else True,
            'ai_memory_limit': row['ai_memory_limit'] if row['ai_memory_limit'] is not None else 10
        } for row in (result or [])]
        print(f"Loaded {len(channels)} channels from database")
        return channels
    except Exception as e:
        print(f"Error loading channels: {str(e)}")
        raise


def create_channel(channel_id, name, icon=None, ai_enabled=True, ai_memory_limit=10):
    """Create a new channel."""
    try:
        query = "INSERT OR IGNORE INTO channels (id, name, icon, ai_enabled, ai_memory_limit) VALUES (?, ?, ?, ?, ?)"
        params = (channel_id, name, icon, int(ai_enabled), ai_memory_limit)
        db_manager.execute_query(query, params)
        # Note: rowcount not available in DatabaseManager, assume success for INSERT OR IGNORE
        return True
    except Exception as e:
        print(f"Error creating channel: {str(e)}")
        return False


def update_channel(channel_id, name, icon=None, ai_enabled=None, ai_memory_limit=None):
    """Update a channel's name, icon, and AI settings."""
    try:
        # Build dynamic update query
        update_fields = ["name = ?"]
        params = [name]

        if icon is not None:
            update_fields.append("icon = ?")
            params.append(icon)

        if ai_enabled is not None:
            update_fields.append("ai_enabled = ?")
            params.append(int(ai_enabled))

        if ai_memory_limit is not None:
            update_fields.append("ai_memory_limit = ?")
            params.append(ai_memory_limit)

        params.append(channel_id)

        query = f"UPDATE channels SET {', '.join(update_fields)} WHERE id = ?"
        db_manager.execute_query(query, params)
        return True
    except Exception as e:
        print(f"Error updating channel: {str(e)}")
        return False

def delete_channel(channel_id):
    """Delete a channel."""
    try:
        query = "DELETE FROM channels WHERE id = ?"
        params = (channel_id,)
        db_manager.execute_query(query, params)
        return True
    except Exception as e:
        print(f"Error deleting channel: {str(e)}")
        return False


def get_channel_ai_settings(channel_id):
    """Get AI settings for a specific channel."""
    try:
        query = "SELECT ai_enabled, ai_memory_limit FROM channels WHERE id = ?"
        params = (channel_id,)
        result = db_manager.execute_query(query, params, fetch=True)
        if result and len(result) > 0:
            row = result[0]
            return {
                'ai_enabled': bool(row['ai_enabled']) if row['ai_enabled'] is not None else True,
                'ai_memory_limit': row['ai_memory_limit'] if row['ai_memory_limit'] is not None else 10
            }
        return {'ai_enabled': True, 'ai_memory_limit': 10}  # Defaults
    except Exception as e:
        print(f"Error getting channel AI settings: {str(e)}")
        return {'ai_enabled': True, 'ai_memory_limit': 10}


def load_media_channels():
    """Load all media channels from database."""
    try:
        query = "SELECT name FROM media_channels"
        result = db_manager.execute_query(query, fetch=True)
        channels = [row['name'] for row in (result or [])]
        print(f"Loaded {len(channels)} media channels from database")
        return channels
    except Exception as e:
        print(f"Error loading media channels: {str(e)}")
        raise


def create_media_channel(name):
    """Create a new media channel."""
    try:
        query = "INSERT OR IGNORE INTO media_channels (name) VALUES (?)"
        params = (name,)
        db_manager.execute_query(query, params)
        return True
    except Exception as e:
        print(f"Error creating media channel: {str(e)}")
        return False


def delete_media_channel(name):
    """Delete a media channel."""
    try:
        query = "DELETE FROM media_channels WHERE name = ?"
        params = (name,)
        db_manager.execute_query(query, params)
        return True
    except Exception as e:
        print(f"Error deleting media channel: {str(e)}")
        return False