"""
Base Database Manager Class
Provides common database operations and connection management.
"""

import sqlite3
import os
from typing import Optional, Any, List, Dict
from contextlib import contextmanager


class DatabaseManager:
    """Base class for database management operations."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        print(f"DEBUG: DatabaseManager initialized with path: {db_path}")
        self._ensure_db_directory()

    def _ensure_db_directory(self):
        """Ensure the database directory exists."""
        db_dir = os.path.dirname(self.db_path)
        if db_dir and not os.path.exists(db_dir):
            os.makedirs(db_dir, exist_ok=True)

    @contextmanager
    def get_connection(self):
        """Context manager for database connections."""
        conn = None
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row  # Enable column access by name
            yield conn
        except Exception as e:
            if conn:
                conn.rollback()
            raise e
        finally:
            if conn:
                conn.close()

    def execute_query(self, query: str, params: tuple = (), fetch: bool = False) -> Any:
        """Execute a query and optionally return results."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)

            if fetch:
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                return [dict(zip(columns, row)) for row in cursor.fetchall()]

            conn.commit()
            return cursor

    def execute_many(self, query: str, params_list: List[tuple]) -> None:
        """Execute multiple queries with different parameters."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.executemany(query, params_list)
            conn.commit()

    def table_exists(self, table_name: str) -> bool:
        """Check if a table exists in the database."""
        result = self.execute_query(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
            (table_name,),
            fetch=True
        )
        return len(result or []) > 0

    def get_table_columns(self, table_name: str) -> List[str]:
        """Get column names for a table."""
        result = self.execute_query(f"PRAGMA table_info({table_name})", fetch=True)
        return [row['name'] for row in (result or [])] if result else []

    def add_column_if_not_exists(self, table_name: str, column_name: str, column_definition: str) -> None:
        """Add a column to a table if it doesn't already exist."""
        columns = self.get_table_columns(table_name)
        if column_name not in columns:
            # If column_definition already includes the column name, use it as-is
            # Otherwise, construct the full definition
            if column_definition.startswith(column_name + ' ') or column_definition.startswith(column_name + '\t'):
                full_definition = column_definition
            else:
                full_definition = f"{column_name} {column_definition}"
            self.execute_query(f"ALTER TABLE {table_name} ADD COLUMN {full_definition}")

    def create_indexes(self, indexes: List[tuple]) -> None:
        """Create multiple indexes. Each tuple should be (index_name, table_name, columns)."""
        for index_name, table_name, columns in indexes:
            if isinstance(columns, str):
                columns = [columns]

            # Check if index already exists
            result = self.execute_query(
                "SELECT name FROM sqlite_master WHERE type='index' AND name=?",
                (index_name,),
                fetch=True
            )

            if not result:
                column_str = ', '.join(columns)
                self.execute_query(f"CREATE INDEX {index_name} ON {table_name}({column_str})")

    def get_row_count(self, table_name: str) -> int:
        """Get the number of rows in a table."""
        result = self.execute_query(f"SELECT COUNT(*) as count FROM {table_name}", fetch=True)
        return result[0]['count'] if result else 0

    def vacuum(self) -> None:
        """Optimize the database by reclaiming unused space."""
        self.execute_query("VACUUM")

    def backup_database(self, backup_path: str) -> None:
        """Create a backup of the database."""
        with self.get_connection() as conn:
            with sqlite3.connect(backup_path) as backup_conn:
                conn.backup(backup_conn)

    def get_database_info(self) -> Dict[str, Any]:
        """Get information about the database."""
        info = {
            'path': self.db_path,
            'size': os.path.getsize(self.db_path) if os.path.exists(self.db_path) else 0,
            'tables': []
        }

        # Get all tables
        tables = self.execute_query(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'",
            fetch=True
        )

        for table in (tables or []):
            table_name = table['name']
            table_info = {
                'name': table_name,
                'columns': self.get_table_columns(table_name),
                'row_count': self.get_row_count(table_name)
            }
            info['tables'].append(table_info)

        return info