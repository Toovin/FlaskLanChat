# database_folders.py - Folder management database functions
import sqlite3
from datetime import datetime
import os
import shutil


def create_folder(name, parent_id, created_by):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        if parent_id:
            c.execute("SELECT path FROM folders WHERE id = ?", (parent_id,))
            parent_row = c.fetchone()
            if not parent_row:
                conn.close()
                return None
            parent_path = parent_row[0]
            path = f"{parent_path}/{name}"
        else:
            path = f"file_share_system/{name}"
        c.execute("INSERT INTO folders (name, parent_id, path, created_at, created_by) VALUES (?, ?, ?, ?, ?)", (name, parent_id, path, timestamp, created_by))
        folder_id = c.lastrowid
        conn.commit()
        conn.close()
        return folder_id
    except Exception as e:
        print(f"Error creating folder: {str(e)}")
        return None


def get_folder_structure():
    """Get the complete folder structure as a hierarchical tree."""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        def build_tree(parent_id=None):
            c.execute("SELECT id, name, path, created_at, created_by FROM folders WHERE parent_id IS ? ORDER BY name", (parent_id,))
        folders = []
        for row in c.fetchall():
            folder = {
                'id': row[0],
                'name': row[1],
                'path': row[2],
                'created_at': row[3],
                'created_by': row[4],
                'children': []  # For now, keep it simple
            }
            folders.append(folder)

        # Also include the Public folder
        public_folder = get_folder_by_path('file_share_system/Public_Folder')
        if public_folder:
            folders.append({
                'id': public_folder['id'],
                'name': public_folder['name'],
                'path': public_folder['path'],
                'created_at': public_folder['created_at'],
                'created_by': public_folder['created_by'],
                'children': []
            })

        conn.close()
        return folders

        root_folders = build_tree()
        conn.close()
        return root_folders
    except Exception as e:
        print(f"Error getting folder structure: {str(e)}")
        return []


def get_folder_by_id(folder_id):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("SELECT id, name, parent_id, path, created_at, created_by FROM folders WHERE id = ?", (folder_id,))
        row = c.fetchone()
        conn.close()
        if row:
            return {
                'id': row[0],
                'name': row[1],
                'parent_id': row[2],
                'path': row[3],
                'created_at': row[4],
                'created_by': row[5]
            }
        return None
    except Exception as e:
        print(f"Error getting folder by id: {str(e)}")
        return None


def get_folder_by_path(path):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("SELECT id, name, parent_id, path, created_at, created_by FROM folders WHERE path = ?", (path,))
        row = c.fetchone()
        conn.close()
        if row:
            return {
                'id': row[0],
                'name': row[1],
                'parent_id': row[2],
                'path': row[3],
                'created_at': row[4],
                'created_by': row[5]
            }
        return None
    except Exception as e:
        print(f"Error getting folder by path: {str(e)}")
        return None


def ensure_user_folders():
    """Ensure each user has a personal folder."""
    try:
        print("Ensuring user folders exist...")
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        # Get all usernames
        c.execute("SELECT username FROM users")
        users = c.fetchall()
        print(f"Found {len(users)} users")

        for (username,) in users:
            folder_path = f'file_share_system/{username}'
            if not get_folder_by_path(folder_path):
                # Create the folder
                c.execute("INSERT INTO folders (name, path, created_at, created_by) VALUES (?, ?, ?, ?)",
                          (username, folder_path, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), username))
                # Create the filesystem directory
                os.makedirs(os.path.join('static', folder_path), exist_ok=True)
                print(f"Created folder for user: {username}")
            else:
                # Ensure filesystem directory exists
                os.makedirs(os.path.join('static', folder_path), exist_ok=True)
                print(f"Folder already exists for user: {username}")

        conn.commit()
        conn.close()
        print("User folders ensured.")
    except Exception as e:
        print(f"Error ensuring user folders: {str(e)}")


def get_user_folder_structure(user):
    """Get folder structure for a specific user's private folders."""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        def build_user_tree(parent_id=None):
            if parent_id is None:
                # Root level - get folders created by user or system root
                  c.execute("""
                      SELECT id, name, path, created_at, created_by
                      FROM folders
                      WHERE parent_id IS NULL AND (created_by = ? OR name = 'Share')
                      ORDER BY CASE WHEN name = 'Share' THEN 0 ELSE 1 END, name
                  """, (user,))
            else:
                # Child folders - only user's folders
                c.execute("""
                    SELECT id, name, path, created_at, created_by
                    FROM folders
                    WHERE parent_id = ? AND created_by = ?
                    ORDER BY name
                """, (parent_id, user))

            folders = []
            for row in c.fetchall():
                folder = {
                    'id': row[0],
                    'name': row[1],
                    'path': row[2],
                    'created_at': row[3],
                    'created_by': row[4],
                    'children': build_user_tree(row[0])
                }
                folders.append(folder)
            return folders

        root_folders = build_user_tree()
        conn.close()
        return root_folders
    except Exception as e:
        print(f"Error getting user folder structure: {str(e)}")
        return []


def get_public_folder_structure():
    """Get folder structure containing public files."""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        # Get folders that have public files
        c.execute("""
            SELECT DISTINCT f.id, f.name, f.path, f.created_at, f.created_by
            FROM folders f
            INNER JOIN file_folders ff ON f.id = ff.folder_id
            WHERE ff.visibility = 'public' AND ff.ownership = 'user'
            ORDER BY f.name
        """)

        folders = []
        for row in c.fetchall():
            folder = {
                'id': row[0],
                'name': row[1],
                'path': row[2],
                'created_at': row[3],
                'created_by': row[4],
                'children': []  # For now, keep it simple
            }
            folders.append(folder)

        conn.close()
        return folders
    except Exception as e:
        print(f"Error getting public folder structure: {str(e)}")
        return []


def get_system_folder_structure():
    """Get folder structure for system files."""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        # Get folders that have system files
        c.execute("""
            SELECT DISTINCT f.id, f.name, f.path, f.created_at, f.created_by
            FROM folders f
            INNER JOIN file_folders ff ON f.id = ff.folder_id
            WHERE ff.ownership = 'system'
            ORDER BY f.name
        """)

        folders = []
        for row in c.fetchall():
            folder = {
                'id': row[0],
                'name': row[1],
                'path': row[2],
                'created_at': row[3],
                'created_by': row[4],
                'children': []  # For now, keep it simple
            }
            folders.append(folder)

        conn.close()
        return folders
    except Exception as e:
        print(f"Error getting system folder structure: {str(e)}")
        return []


def delete_folder(folder_id):
    """Delete a folder and all its contents from database and filesystem."""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        # Get folder info before deletion
        c.execute("SELECT path FROM folders WHERE id = ?", (folder_id,))
        row = c.fetchone()
        if not row:
            conn.close()
            return False

        folder_path = row[0]

        # Delete folder from database (CASCADE will delete files and subfolders)
        c.execute("DELETE FROM folders WHERE id = ?", (folder_id,))
        conn.commit()
        conn.close()

        # Remove filesystem directory and all contents
        full_path = os.path.join('static', folder_path)
        if os.path.exists(full_path):
            shutil.rmtree(full_path)
            print(f"Removed folder directory: {full_path}")

        print(f"Deleted folder {folder_id} and path {folder_path}")
        return True
    except Exception as e:
        print(f"Error deleting folder {folder_id}: {str(e)}")
        return False


def rename_folder(folder_id, new_name):
    """Rename a folder in the database."""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        # Update the folder name
        c.execute("UPDATE folders SET name = ? WHERE id = ?", (new_name, folder_id))
        success = c.rowcount > 0
        conn.commit()
        conn.close()

        if success:
            print(f"Renamed folder {folder_id} to '{new_name}'")
        return success
    except Exception as e:
        print(f"Error renaming folder {folder_id}: {str(e)}")
        return False