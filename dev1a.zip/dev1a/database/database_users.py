# database_users.py - User management database functions
import sqlite3
from werkzeug.security import generate_password_hash
from datetime import datetime
import os
from typing import Dict, Any, Optional, List
from lc_config import CHAT_DB_NAME
from .database_settings import get_user_settings
from .database_folders import get_folder_by_path
from .database_manager import DatabaseManager

# Global database manager instance
db_manager = DatabaseManager(CHAT_DB_NAME)


def _transform_user_data(row):
    """Transform raw database row dict into user data dict with business logic."""
    # Validate theme
    theme = row.get('theme') or 'dobo'
    valid_themes = ['dobo', 'retro-green', 'blue', 'ice-blue', 'hpos10i', 'cabo', 'dark', 'purple', 'pika-yellow', 'nature', 'light', 'minimal', 'gray', 'classic']
    if theme not in valid_themes:
        theme = 'dobo'  # Default to dobo for invalid themes

    user_data = {
        'uuid': row.get('uuid'),
        'username': row.get('username'),
        'password_hash': row.get('password_hash'),
        'avatar_url': row.get('avatar_url'),
        'display_name': row.get('display_name'),
        'status': row.get('status') or 'online',
        'custom_status': row.get('custom_status'),
        'theme': theme,
        'font': row.get('font') or 'system',
        'font_scale': row.get('font_scale') or 1.0,
        'compact_mode': bool(row.get('compact_mode')),
        'show_timestamps': bool(row.get('show_timestamps')) if row.get('show_timestamps') is not None else True,
        'animated_bg': row.get('animated_bg') or 'none',
        'cursor_effect': row.get('cursor_effect') or 'orbiting',
        'particle_style': row.get('particle_style') or 'theme',
        'cursor_main': row.get('cursor_main') or 'default',
        'cursor_particle': row.get('cursor_particle') or 'default',
        'allow_dms': bool(row.get('allow_dms')) if row.get('allow_dms') is not None else True,
        'show_online_status': bool(row.get('show_online_status')) if row.get('show_online_status') is not None else True,
        'typing_indicators': bool(row.get('typing_indicators')) if row.get('typing_indicators') is not None else True,
        'toast_on_media_download': bool(row.get('toast_on_media_download')) if row.get('toast_on_media_download') is not None else True,
        'is_admin': bool(row.get('is_admin')) if row.get('is_admin') is not None else False
    }
    return user_data


def _load_user_settings(users_db):
    """Load and merge user settings into users_db."""
    for user_uuid, user_data in users_db.items():
        settings = get_user_settings(user_uuid)
        if settings:
            if settings.get('avatar_url'):
                user_data['avatar_url'] = settings['avatar_url']
            if settings.get('display_name'):
                user_data['display_name'] = settings['display_name']
            if settings.get('custom_status'):
                user_data['custom_status'] = settings['custom_status']
            print(f"Loaded settings for user {user_data.get('username', user_uuid)}: avatar={settings.get('avatar_url')}, display_name={settings.get('display_name')}")


def load_users() -> Dict[str, Any]:
    """Load all users from database with business logic applied."""
    users_db = {}
    try:
        query = """SELECT uuid, username, password_hash, avatar_url, display_name, status,
                   custom_status, theme, font, font_scale, compact_mode, show_timestamps,
                   animated_bg, cursor_effect, particle_style, cursor_main, cursor_particle,
                   allow_dms, show_online_status, typing_indicators, toast_on_media_download, is_admin
                   FROM users"""
        result = db_manager.execute_query(query, fetch=True)

        if result:
            for row in result:
                # Transform raw data with business logic
                user_data = _transform_user_data(row)
                users_db[row['uuid']] = user_data

        # Load and merge user settings
        _load_user_settings(users_db)

        print(f"Loaded {len(users_db)} users from database")
        return users_db
    except Exception as e:
        print(f"Error loading users: {str(e)}")
        raise


def _create_user_folder(username):
    """Create user folder in database and filesystem."""
    folder_path = f'file_share_system/{username}'
    if not get_folder_by_path(folder_path):
        query = "INSERT INTO folders (name, path, created_at, created_by) VALUES (?, ?, ?, ?)"
        params = (username, folder_path, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), username)
        db_manager.execute_query(query, params)
        # Create the filesystem directory
        os.makedirs(os.path.join('static', folder_path), exist_ok=True)
        print(f"Created folder for new user: {username}")


def save_user(uuid: str, username: str, password: str, avatar_url: Optional[str] = None, display_name: Optional[str] = None, custom_status: Optional[str] = None, is_admin: bool = False) -> bool:
    """Save a new user to database with business logic."""
    password_hash = generate_password_hash(password)
    try:
        query = "INSERT INTO users (uuid, username, password_hash, avatar_url, display_name, custom_status, is_admin) VALUES (?, ?, ?, ?, ?, ?, ?)"
        params = (uuid, username, password_hash, avatar_url, display_name, custom_status, 1 if is_admin else 0)
        db_manager.execute_query(query, params)
        print(f"Saved user: {username}")

        # Create user folder (business logic)
        _create_user_folder(username)

        return password_hash
    except sqlite3.IntegrityError as e:
        if "UNIQUE constraint failed" in str(e):
            raise ValueError("Username already taken")
        raise e
    except Exception as e:
        print(f"Error saving user {username}: {str(e)}")
        raise


def update_user_avatar(uuid, avatar_url):
    """Update user's avatar URL."""
    try:
        query = "UPDATE users SET avatar_url = ? WHERE uuid = ?"
        params = (avatar_url, uuid)
        db_manager.execute_query(query, params)
        print(f"Updated avatar for user UUID: {uuid}")
    except Exception as e:
        print(f"Error updating avatar for user UUID {uuid}: {str(e)}")
        raise


def check_username_available(username):
    """Check if a username is available (not taken by existing user)."""
    try:
        query = "SELECT COUNT(*) FROM users WHERE username = ?"
        params = (username,)
        result = db_manager.execute_query(query, params, fetch=True)
        count = result[0]['COUNT(*)'] if result else 0
        available = count == 0
        print(f"Username '{username}' availability check: {'available' if available else 'taken'}")
        return available
    except Exception as e:
        print(f"Error checking username availability for {username}: {str(e)}")
        raise


def get_user_by_username(username: str) -> Optional[Dict[str, Any]]:
    """Get user data by username with business logic applied."""
    try:
        query = """SELECT uuid, username, password_hash, avatar_url, display_name, status,
                   custom_status, theme, font, font_scale, compact_mode, show_timestamps,
                   animated_bg, cursor_effect, particle_style, cursor_main, cursor_particle,
                   allow_dms, show_online_status, typing_indicators, is_admin
                   FROM users WHERE username = ?"""
        params = (username,)
        result = db_manager.execute_query(query, params, fetch=True)

        if result:
            row = result[0]
            print(f"Retrieved user: {username}")
            # Transform with business logic
            user_data = _transform_user_data(row)
            return user_data
        print(f"User not found: {username}")
        return None
    except Exception as e:
        print(f"Error retrieving user {username}: {str(e)}")
        raise


def get_username_by_uuid(user_uuid):
    """Get username by user UUID"""
    try:
        query = "SELECT username FROM users WHERE uuid = ?"
        params = (user_uuid,)
        result = db_manager.execute_query(query, params, fetch=True)
        if result:
            return result[0]['username']
        return None
    except Exception as e:
        print(f"Error retrieving username for UUID {user_uuid}: {str(e)}")
        return None


def get_display_name_by_uuid(user_uuid):
    """Get display name by user UUID"""
    try:
        print(f"DEBUG: get_display_name_by_uuid called for {user_uuid}")
        query = "SELECT display_name, username FROM users WHERE uuid = ?"
        params = (user_uuid,)
        result = db_manager.execute_query(query, params, fetch=True)
        print(f"DEBUG: result = {result}")
        if result:
            display_name = result[0]['display_name'] or result[0]['username']
            print(f"DEBUG: returning display_name = {repr(display_name)}")
            return display_name
        print("DEBUG: no result, returning None")
        return None
    except Exception as e:
        print(f"Error retrieving display name for UUID {user_uuid}: {str(e)}")
        return None


def is_user_admin(user_uuid):
    """Check if a user is an admin"""
    try:
        query = "SELECT is_admin FROM users WHERE uuid = ?"
        params = (user_uuid,)
        result = db_manager.execute_query(query, params, fetch=True)
        if result:
            return bool(result[0]['is_admin'])
        return False
    except Exception as e:
        print(f"Error checking admin status for {user_uuid}: {str(e)}")
        return False


def _get_default_image_preferences():
    """Get default image generation preferences."""
    return {
        'model_name': '',
        'width': 1024,
        'height': 1024,
        'steps': 33,
        'cfg_scale': 7.0,
        'clip_skip': 2,
        'negative_prompt': '',
        'sampler_name': 'DPM++ 3M SDE',
        'scheduler_name': 'simple',
        'batch_size': 1,
        'uploaded_image': None
    }


def get_user_image_preferences(user_uuid):
    """Get user's image generation preferences with defaults."""
    try:
        query = """SELECT last_sd_model, last_img_width, last_img_height, last_img_steps,
                   last_img_cfg_scale, last_img_clip_skip, last_img_negative_prompt,
                   last_img_sampler, last_img_scheduler, last_img_batch_size, last_uploaded_image
                   FROM users WHERE uuid = ?"""
        params = (user_uuid,)
        result = db_manager.execute_query(query, params, fetch=True)

        if result:
            row = result[0]
            return {
                'model_name': row['last_sd_model'] or '',
                'width': row['last_img_width'] or 1024,
                'height': row['last_img_height'] or 1024,
                'steps': row['last_img_steps'] or 33,
                'cfg_scale': row['last_img_cfg_scale'] or 7.0,
                'clip_skip': row['last_img_clip_skip'] or 2,
                'negative_prompt': row['last_img_negative_prompt'] or '',
                'sampler_name': row['last_img_sampler'] or 'DPM++ 3M SDE',
                'scheduler_name': row['last_img_scheduler'] or 'simple',
                'batch_size': row['last_img_batch_size'] or 1,
                'uploaded_image': row['last_uploaded_image']
            }
        else:
            # User not found, return defaults
            return _get_default_image_preferences()
    except Exception as e:
        print(f"Error getting user image preferences for {user_uuid}: {str(e)}")
        # Return defaults on error
        return _get_default_image_preferences()


def save_user_image_preferences(user_uuid, preferences):
    """Save user's image generation preferences"""
    try:
        query = """UPDATE users SET
                   last_sd_model = ?,
                   last_img_width = ?,
                   last_img_height = ?,
                   last_img_steps = ?,
                   last_img_cfg_scale = ?,
                   last_img_clip_skip = ?,
                   last_img_negative_prompt = ?,
                   last_img_sampler = ?,
                   last_img_scheduler = ?,
                   last_img_batch_size = ?,
                   last_uploaded_image = ?
                   WHERE uuid = ?"""
        params = (preferences.get('last_sd_model', ''),
                  preferences.get('last_img_width', 1024),
                  preferences.get('last_img_height', 1024),
                  preferences.get('last_img_steps', 33),
                  preferences.get('last_img_cfg_scale', 7.0),
                  preferences.get('last_img_clip_skip', 2),
                  preferences.get('last_img_negative_prompt', ''),
                  preferences.get('last_img_sampler', 'DPM++ 3M SDE'),
                  preferences.get('last_img_scheduler', 'simple'),
                  preferences.get('last_img_batch_size', 1),
                  preferences.get('last_uploaded_image'),
                  user_uuid)
        db_manager.execute_query(query, params)
        print(f"Saved image preferences for user {user_uuid}")
        return True
    except Exception as e:
        print(f"Error saving user image preferences for {user_uuid}: {str(e)}")
        return False