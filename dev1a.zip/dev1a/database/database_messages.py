# database_messages.py - Message management database functions
import sqlite3
from lc_config import CHAT_DB_NAME
from .database_manager import DatabaseManager

# Global database manager instance
db_manager = DatabaseManager(CHAT_DB_NAME)


def load_messages(channel, limit=50):
    """Load messages for a channel with optional limit."""
    try:
        if limit:
            # Use a subquery to get the most recent messages in correct order
            query = """SELECT m.id, m.sender, m.message, m.is_media, m.timestamp, m.replied_to,
                       m.replied_sender, m.replied_text, m.image_url, m.thumbnail_url, m.avatar_url,
                       m.generation_id, m.auto_share, m.ai_generated, m.ai_conversation_id, m.ai_model,
                       (SELECT COUNT(*) FROM messages r WHERE r.replied_to = m.id) as replies_count
                       FROM messages m
                       WHERE m.channel = ? AND m.id IN (
                           SELECT id FROM messages
                           WHERE channel = ?
                           ORDER BY timestamp DESC
                           LIMIT ?
                       )
                       ORDER BY m.timestamp ASC"""
            params = (channel, channel, limit)
        else:
            query = """SELECT m.id, m.sender, m.message, m.is_media, m.timestamp, m.replied_to,
                       m.replied_sender, m.replied_text, m.image_url, m.thumbnail_url, m.avatar_url,
                       m.generation_id, m.auto_share, m.ai_generated, m.ai_conversation_id, m.ai_model,
                       (SELECT COUNT(*) FROM messages r WHERE r.replied_to = m.id) as replies_count
                       FROM messages m WHERE m.channel = ? ORDER BY m.timestamp ASC"""
            params = (channel,)

        result = db_manager.execute_query(query, params, fetch=True)

        messages = []
        if result:
            for row in result:
                messages.append({
                    'id': row['id'],
                    'sender': row['sender'],
                    'message': row['message'],
                    'is_media': row['is_media'],
                    'timestamp': row['timestamp'],
                    'replied_to': row['replied_to'],
                    'replied_sender': row['replied_sender'],
                    'replied_text': row['replied_text'],
                    'image_url': row['image_url'],
                    'thumbnail_url': row['thumbnail_url'],
                    'avatar_url': row['avatar_url'],
                    'generation_id': row['generation_id'],
                    'auto_share': row['auto_share'],
                    'ai_generated': row['ai_generated'],
                    'ai_conversation_id': row['ai_conversation_id'],
                    'ai_model': row['ai_model'],
                    'replies_count': row['replies_count'],
                    'reactions': get_reactions(row['id'])
                })

        print(f"Loaded {len(messages)} messages for channel: {channel}")
        return messages
    except Exception as e:
        print(f"Error loading messages for channel {channel}: {str(e)}")
        raise


def add_reaction(message_id, user_uuid, emoji):
    """Add a reaction to a message."""
    try:
        query = "INSERT OR IGNORE INTO reactions (message_id, user_uuid, emoji) VALUES (?, ?, ?)"
        params = (message_id, user_uuid, emoji)
        db_manager.execute_query(query, params)
        print(f"Added reaction {emoji} to message ID {message_id} by user UUID {user_uuid}")
    except Exception as e:
        print(f"Error adding reaction to message ID {message_id}: {str(e)}")
        raise


def remove_reaction(message_id, user_uuid, emoji):
    """Remove a reaction from a message."""
    try:
        query = "DELETE FROM reactions WHERE message_id = ? AND user_uuid = ? AND emoji = ?"
        params = (message_id, user_uuid, emoji)
        db_manager.execute_query(query, params)
        print(f"Removed reaction {emoji} from message ID {message_id} by user UUID {user_uuid}")
    except Exception as e:
        print(f"Error removing reaction from message ID {message_id}: {str(e)}")
        raise


def get_reactions(message_id):
    """Get all reactions for a message."""
    try:
        query = "SELECT user_uuid, emoji FROM reactions WHERE message_id = ?"
        params = (message_id,)
        result = db_manager.execute_query(query, params, fetch=True)
        if result:
            return [{'user_uuid': row['user_uuid'], 'emoji': row['emoji']} for row in result]
        return []
    except Exception as e:
        print(f"Error getting reactions for message {message_id}: {str(e)}")
        return []


def delete_message(message_id):
    """Delete a message by ID (admin only)"""
    try:
        # Delete reactions first
        query1 = "DELETE FROM reactions WHERE message_id = ?"
        params1 = (message_id,)
        db_manager.execute_query(query1, params1)

        # Delete message
        query2 = "DELETE FROM messages WHERE id = ?"
        params2 = (message_id,)
        db_manager.execute_query(query2, params2)

        print(f"Deleted message {message_id}")
        return True
    except Exception as e:
        print(f"Error deleting message {message_id}: {str(e)}")
        return False


def delete_dm_message(message_id):
    """Delete a DM message by ID"""
    try:
        # Delete message
        query = "DELETE FROM dm_messages WHERE id = ?"
        params = (message_id,)
        db_manager.execute_query(query, params)

        print(f"Deleted DM message {message_id}")
        return True
    except Exception as e:
        print(f"Error deleting DM message {message_id}: {str(e)}")
        return False


def add_dm_message(sender_uuid, recipient_uuid, message, is_media=0):
    """Add a DM message to the database"""
    print(f"Adding DM message: sender={sender_uuid}, recipient={recipient_uuid}, message={message}")
    try:
        query = """INSERT INTO dm_messages (sender_uuid, recipient_uuid, message, is_media, timestamp, read_status)
                   VALUES (?, ?, ?, ?, datetime('now'), 0)"""
        params = (sender_uuid, recipient_uuid, message, is_media)
        result = db_manager.execute_query(query, params)
        print(f"DM message added with ID: {result.lastrowid if result else None}")
        return result.lastrowid if result else None
    except Exception as e:
        print(f"Error adding DM message: {str(e)}")
        return None


def load_dm_messages(user_uuid, other_uuid, limit=50, before_message_id=None):
    """Load DM messages between two users"""
    try:
        if before_message_id:
            # Get timestamp of the before_message_id
            timestamp_query = "SELECT timestamp FROM dm_messages WHERE id = ?"
            timestamp_result = db_manager.execute_query(timestamp_query, (before_message_id,), fetch=True)
            if not timestamp_result:
                return []
            before_timestamp = timestamp_result[0]['timestamp']

            query = """SELECT id, sender_uuid, recipient_uuid, message, is_media, timestamp, read_status
                       FROM dm_messages
                       WHERE ((sender_uuid = ? AND recipient_uuid = ?) OR (sender_uuid = ? AND recipient_uuid = ?))
                       AND timestamp < ?
                       ORDER BY timestamp DESC
                       LIMIT ?"""
            params = (user_uuid, other_uuid, other_uuid, user_uuid, before_timestamp, limit)
        else:
            query = """SELECT id, sender_uuid, recipient_uuid, message, is_media, timestamp, read_status
                       FROM dm_messages
                       WHERE (sender_uuid = ? AND recipient_uuid = ?) OR (sender_uuid = ? AND recipient_uuid = ?)
                       ORDER BY timestamp DESC
                       LIMIT ?"""
            params = (user_uuid, other_uuid, other_uuid, user_uuid, limit)

        result = db_manager.execute_query(query, params, fetch=True)

        messages = []
        if result:
            for row in result:
                messages.append({
                    'id': row['id'],
                    'sender_uuid': row['sender_uuid'],
                    'recipient_uuid': row['recipient_uuid'],
                    'message': row['message'],
                    'is_media': row['is_media'],
                    'timestamp': row['timestamp'],
                    'read_status': row['read_status'],
                    'is_mine': row['sender_uuid'] == user_uuid
                })
        # Reverse to get chronological order
        messages.reverse()
        return messages
    except Exception as e:
        print(f"Error loading DM messages: {str(e)}")
        return []


def get_dm_conversations(user_uuid):
    """Get list of DM conversations for a user"""
    try:
        query = """SELECT DISTINCT
                       CASE
                           WHEN dm.sender_uuid = ? THEN dm.recipient_uuid
                           ELSE dm.sender_uuid
                       END as other_uuid,
                       u.username,
                       u.avatar_url,
                       u.display_name,
                       dm.message as last_message,
                       dm.timestamp as last_timestamp,
                       (SELECT COUNT(*) FROM dm_messages d2
                        WHERE d2.recipient_uuid = ? AND d2.sender_uuid =
                            CASE
                                WHEN dm.sender_uuid = ? THEN dm.recipient_uuid
                                ELSE dm.sender_uuid
                            END
                        AND d2.read_status = 0) as unread_count
                   FROM dm_messages dm
                   JOIN users u ON u.uuid = CASE
                       WHEN dm.sender_uuid = ? THEN dm.recipient_uuid
                       ELSE dm.sender_uuid
                   END
                   WHERE dm.sender_uuid = ? OR dm.recipient_uuid = ?
                   ORDER BY dm.timestamp DESC"""
        params = (user_uuid, user_uuid, user_uuid, user_uuid, user_uuid, user_uuid)
        result = db_manager.execute_query(query, params, fetch=True)

        conversations = []
        seen_users = set()
        if result:
            for row in result:
                other_uuid = row['other_uuid']
                if other_uuid not in seen_users:
                    conversations.append({
                        'user_uuid': other_uuid,
                        'username': row['username'],
                        'avatar_url': row['avatar_url'],
                        'display_name': row['display_name'],
                        'last_message': row['last_message'],
                        'last_timestamp': row['last_timestamp'],
                        'unread_count': row['unread_count'] or 0
                    })
                    seen_users.add(other_uuid)
        return conversations
    except Exception as e:
        print(f"Error getting DM conversations: {str(e)}")
        return []


def mark_dm_messages_read(user_uuid, other_uuid):
    """Mark DM messages as read"""
    try:
        query = """UPDATE dm_messages SET read_status = 1
                   WHERE sender_uuid = ? AND recipient_uuid = ? AND read_status = 0"""
        params = (other_uuid, user_uuid)
        db_manager.execute_query(query, params)
        return True
    except Exception as e:
        print(f"Error marking DM messages as read: {str(e)}")
        return False