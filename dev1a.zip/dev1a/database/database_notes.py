# database_notes.py - User notes database functions
import sqlite3
from .lc_database import get_standard_timestamp
from .database_manager import DatabaseManager

# Global database manager instance
db_manager = DatabaseManager('devchat.db')


def _create_note_dict(row):
    """Create note dictionary from database row."""
    return {
        'uuid': row['uuid'],
        'title': row['title'],
        'content': row['content'],
        'created_at': row['created_at'],
        'updated_at': row['updated_at']
    }


def create_user_note(user_uuid, note_uuid, title, content):
    """Create a new note for a user."""
    try:
        timestamp = get_standard_timestamp()
        query = '''INSERT INTO user_notes (uuid, user_uuid, title, content, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?)'''
        params = (note_uuid, user_uuid, title, content, timestamp, timestamp)
        db_manager.execute_query(query, params)
        print(f"Created note {note_uuid} for user {user_uuid}")
        return True
    except Exception as e:
        print(f"Error creating user note: {str(e)}")
        return False


def update_user_note(note_uuid, title, content):
    """Update an existing note and return the updated note data."""
    try:
        timestamp = get_standard_timestamp()
        # Update the note
        query1 = '''UPDATE user_notes SET title = ?, content = ?, updated_at = ? WHERE uuid = ?'''
        params1 = (title, content, timestamp, note_uuid)
        db_manager.execute_query(query1, params1)

        # Fetch the updated note data
        query2 = '''SELECT uuid, title, content, created_at, updated_at FROM user_notes WHERE uuid = ?'''
        params2 = (note_uuid,)
        result = db_manager.execute_query(query2, params2, fetch=True)

        if result:
            updated_note = _create_note_dict(result[0])
            print(f"Updated note {note_uuid}")
            return updated_note
        else:
            print(f"Note {note_uuid} not found after update")
            return None
    except Exception as e:
        print(f"Error updating user note: {str(e)}")
        return None


def delete_user_note(note_uuid):
    """Delete a note by UUID."""
    try:
        query = 'DELETE FROM user_notes WHERE uuid = ?'
        params = (note_uuid,)
        db_manager.execute_query(query, params)
        print(f"Deleted note {note_uuid}")
        return True
    except Exception as e:
        print(f"Error deleting user note: {str(e)}")
        return False


def rename_user_note(note_uuid, new_title):
    """Rename a note and return the updated note data."""
    try:
        timestamp = get_standard_timestamp()
        # Update the title
        query1 = '''UPDATE user_notes SET title = ?, updated_at = ? WHERE uuid = ?'''
        params1 = (new_title, timestamp, note_uuid)
        db_manager.execute_query(query1, params1)

        # Fetch the updated note data
        query2 = '''SELECT uuid, title, content, created_at, updated_at FROM user_notes WHERE uuid = ?'''
        params2 = (note_uuid,)
        result = db_manager.execute_query(query2, params2, fetch=True)

        if result:
            updated_note = _create_note_dict(result[0])
            print(f"Renamed note {note_uuid} to '{new_title}'")
            return updated_note
        else:
            print(f"Note {note_uuid} not found after rename")
            return None
    except Exception as e:
        print(f"Error renaming user note: {str(e)}")
        return None


def get_user_notes(user_uuid):
    """Get all notes for a user."""
    try:
        query = "SELECT uuid, title, content, created_at, updated_at FROM user_notes WHERE user_uuid = ? ORDER BY updated_at DESC"
        params = (user_uuid,)
        result = db_manager.execute_query(query, params, fetch=True)

        notes = []
        if result:
            for row in result:
                notes.append(_create_note_dict(row))
        return notes
    except Exception as e:
        print(f"Error getting user notes: {str(e)}")
        return []