"""
Database package for FlaskLanChat
Contains all database-related modules and functions.
"""

from .database_manager import DatabaseManager
from .database_users import (
    load_users, save_user, update_user_avatar, check_username_available,
    get_user_by_username, get_username_by_uuid, is_user_admin,
    get_user_image_preferences, save_user_image_preferences
)
from .database_messages import (
    load_messages, add_reaction, remove_reaction, get_reactions,
    delete_message, add_dm_message, load_dm_messages,
    get_dm_conversations, mark_dm_messages_read
)
from .database_channels import load_channels, create_channel, update_channel, delete_channel, get_channel_ai_settings
from .database_settings import update_user_settings, get_user_settings, get_user_ai_settings, update_user_ai_settings, get_system_settings, save_system_settings
from .database_notes import (
    create_user_note, update_user_note, delete_user_note,
    rename_user_note, get_user_notes
)
from .database_ai import (
    get_channel_context_for_ai, mark_message_as_ai_generated
)
from ai_database import ai_database
from .database_files import (
    get_files_in_folder, add_file_to_folder, update_file_visibility,
    delete_file_from_folder, get_public_files, get_server_files,
    add_file_to_public, delete_file_from_public, rename_file_in_public
)
from .database_folders import (
    create_folder, get_folder_structure, get_folder_by_id,
    get_folder_by_path, ensure_user_folders, get_user_folder_structure,
    get_public_folder_structure, get_system_folder_structure, delete_folder,
    rename_folder
)
from .lc_database import (
    get_standard_timestamp, init_db, load_media_channels, create_media_channel,
    delete_media_channel, get_system_display_name
)
from .main_db_manager import MainDatabaseManager

__all__ = [
    'DatabaseManager',
    'load_users', 'save_user', 'update_user_avatar', 'check_username_available',
    'get_user_by_username', 'get_username_by_uuid', 'is_user_admin',
    'get_user_image_preferences', 'save_user_image_preferences',
    'load_messages', 'add_reaction', 'remove_reaction', 'get_reactions',
    'delete_message', 'add_dm_message', 'load_dm_messages',
    'get_dm_conversations', 'mark_dm_messages_read',
     'load_channels', 'create_channel', 'update_channel', 'delete_channel', 'get_channel_ai_settings',
      'update_user_settings', 'get_user_settings', 'get_user_ai_settings', 'update_user_ai_settings', 'get_system_settings', 'save_system_settings',
    'create_user_note', 'update_user_note', 'delete_user_note',
    'rename_user_note', 'get_user_notes',
    'get_files_in_folder', 'add_file_to_folder', 'update_file_visibility',
    'delete_file_from_folder', 'get_public_files', 'get_server_files',
    'add_file_to_public', 'delete_file_from_public', 'rename_file_in_public',
    'create_folder', 'get_folder_structure', 'get_folder_by_id',
    'get_folder_by_path', 'ensure_user_folders', 'get_user_folder_structure',
    'get_public_folder_structure', 'get_system_folder_structure', 'delete_folder',
    'rename_folder',
    'get_standard_timestamp', 'init_db', 'load_media_channels', 'create_media_channel',
    'delete_media_channel', 'get_system_display_name',
    'MainDatabaseManager',
     'get_channel_context_for_ai', 'mark_message_as_ai_generated'
]