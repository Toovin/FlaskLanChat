# database_ai.py - AI chat database functions
import sqlite3
from lc_config import CHAT_DB_NAME
from .database_manager import DatabaseManager

# Debug flag - will be checked at runtime to avoid circular imports
DEBUG = False

# Global database manager instance
db_manager = DatabaseManager(CHAT_DB_NAME)


def init_ai_tables():
    """Initialize AI-specific database tables"""
    try:
        print("Initializing AI database tables...")

        # Create AI conversations table
        print("Creating ai_conversations table...")
        db_manager.execute_query('''CREATE TABLE IF NOT EXISTS ai_conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_uuid TEXT NOT NULL,
            conversation_type TEXT NOT NULL,
            channel_id TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            title TEXT,
            last_response_id TEXT,
            FOREIGN KEY (user_uuid) REFERENCES users(uuid) ON DELETE CASCADE
        )''')

        # Create AI messages table
        print("Creating ai_messages table...")
        db_manager.execute_query('''CREATE TABLE IF NOT EXISTS ai_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            conversation_id INTEGER NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            token_count INTEGER,
            model_used TEXT,
            lm_response_id TEXT,
            FOREIGN KEY (conversation_id) REFERENCES ai_conversations(id) ON DELETE CASCADE
        )''')

        # Create AI characters table
        print("Creating ai_characters table...")
        db_manager.execute_query('''CREATE TABLE IF NOT EXISTS ai_characters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_uuid TEXT NOT NULL,
            character_name TEXT NOT NULL,
            character_description TEXT,
            avatar_url TEXT,
            ai_temperature REAL,
            ai_max_tokens INTEGER,
            ai_context_window INTEGER,
            ai_history_limit INTEGER,
            ai_model TEXT,
            ai_system_prompt TEXT,
            ai_custom_instructions TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (user_uuid) REFERENCES users(uuid) ON DELETE CASCADE,
            UNIQUE(user_uuid, character_name)
        )''')

        # Add avatar_url column if it doesn't exist (for migration)
        try:
            db_manager.execute_query("ALTER TABLE ai_characters ADD COLUMN avatar_url TEXT")
            print("Added avatar_url column to ai_characters table")
        except Exception as e:
            # Column might already exist
            pass

        # Remove ai_persona column if it exists (legacy cleanup)
        try:
            db_manager.execute_query("ALTER TABLE ai_characters DROP COLUMN ai_persona")
            print("Dropped legacy ai_persona column from ai_characters table")
        except Exception as e:
            # Column might not exist or already dropped
            pass

        # Add AI metadata columns to messages table
        print("Adding AI columns to messages table...")
        _add_ai_columns_to_table('messages')

        # Add AI metadata columns to dm_messages table
        print("Adding AI columns to dm_messages table...")
        _add_ai_columns_to_table('dm_messages')

        # Add LM Studio response ID columns for API-side context management
        print("Adding LM Studio response ID columns...")
        _add_lm_response_columns()

        print("AI database tables initialized successfully")

    except Exception as e:
        print(f"Error initializing AI tables: {str(e)}")
        raise
        raise


def _add_ai_columns_to_table(table_name):
    """Add AI-related columns to existing tables"""
    try:
        # Check existing columns
        result = db_manager.execute_query(f"PRAGMA table_info({table_name})", fetch=True)
        columns = [row['name'] for row in result] if result else []

        # Add ai_generated column
        if 'ai_generated' not in columns:
            db_manager.execute_query(f"ALTER TABLE {table_name} ADD COLUMN ai_generated INTEGER DEFAULT 0")

        # Add ai_conversation_id column
        if 'ai_conversation_id' not in columns:
            db_manager.execute_query(f"ALTER TABLE {table_name} ADD COLUMN ai_conversation_id INTEGER")

        # Add ai_model column
        if 'ai_model' not in columns:
            db_manager.execute_query(f"ALTER TABLE {table_name} ADD COLUMN ai_model TEXT")

        print(f"AI columns added to {table_name} table")
    except Exception as e:
        print(f"Error adding AI columns to {table_name}: {str(e)}")


def _add_lm_response_columns():
    """Add LM Studio response ID columns for API-side context management"""
    try:
        # Check existing columns in ai_messages table
        result = db_manager.execute_query("PRAGMA table_info(ai_messages)", fetch=True)
        ai_messages_columns = [row['name'] for row in result] if result else []

        # Add lm_response_id column to ai_messages if it doesn't exist
        if 'lm_response_id' not in ai_messages_columns:
            db_manager.execute_query("ALTER TABLE ai_messages ADD COLUMN lm_response_id TEXT")
            print("Added lm_response_id column to ai_messages table")

        # Check existing columns in ai_conversations table
        result = db_manager.execute_query("PRAGMA table_info(ai_conversations)", fetch=True)
        ai_conversations_columns = [row['name'] for row in result] if result else []

        # Add last_response_id column to ai_conversations if it doesn't exist
        if 'last_response_id' not in ai_conversations_columns:
            db_manager.execute_query("ALTER TABLE ai_conversations ADD COLUMN last_response_id TEXT")
            print("Added last_response_id column to ai_conversations table")

        print("LM Studio response ID columns added successfully")
    except Exception as e:
        print(f"Error adding LM Studio response ID columns: {str(e)}")


def create_ai_conversation(user_uuid, conversation_type, channel_id=None, title=None):
    """Create a new AI conversation or return existing for channel/DM contexts"""
    try:
        from datetime import datetime
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # For channel and DM conversations, check if one already exists
        if conversation_type in ['channel', 'dm'] and channel_id:
            existing = db_manager.execute_query(
                "SELECT id FROM ai_conversations WHERE conversation_type = ? AND channel_id = ?",
                (conversation_type, channel_id), fetch=True
            )
            if existing:
                # Update timestamp and return existing
                db_manager.execute_query(
                    "UPDATE ai_conversations SET updated_at = ? WHERE id = ?",
                    (timestamp, existing[0]['id'])
                )
                return existing[0]['id']

        # Create new conversation
        query = """INSERT INTO ai_conversations
                    (user_uuid, conversation_type, channel_id, created_at, updated_at, title, last_response_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?)"""
        params = (user_uuid, conversation_type, channel_id, timestamp, timestamp, title, None)
        result = db_manager.execute_query(query, params)
        return result.lastrowid if result else None
    except Exception as e:
        print(f"Error creating AI conversation: {str(e)}")
        return None


def add_ai_message(conversation_id, role, content, model_used=None, token_count=None, lm_response_id=None):
    """Add a message to an AI conversation"""
    try:
        from datetime import datetime
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # Check for debug flag at runtime to avoid circular imports
        try:
            from ai_config import DEBUG as AI_DEBUG
            if AI_DEBUG and lm_response_id:
                print(f"[DATABASE_AI] Storing LM response ID {lm_response_id} for conversation {conversation_id}")
        except ImportError:
            pass

        query = """INSERT INTO ai_messages
                    (conversation_id, role, content, timestamp, token_count, model_used, lm_response_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?)"""
        params = (conversation_id, role, content, timestamp, token_count, model_used, lm_response_id)
        result = db_manager.execute_query(query, params)

        # Update conversation timestamp
        update_query = "UPDATE ai_conversations SET updated_at = ? WHERE id = ?"
        db_manager.execute_query(update_query, (timestamp, conversation_id))

        return result.lastrowid if result else None
    except Exception as e:
        print(f"Error adding AI message: {str(e)}")
        return None


def update_conversation_last_response_id(conversation_id, response_id):
    """Update the last response ID for a conversation (for API-side context management)"""
    try:
        # Check for debug flag at runtime to avoid circular imports
        try:
            from ai_config import DEBUG as AI_DEBUG
            if AI_DEBUG:
                print(f"[DATABASE_AI] Updating conversation {conversation_id} last response ID to: {response_id}")
        except ImportError:
            pass
        query = "UPDATE ai_conversations SET last_response_id = ? WHERE id = ?"
        params = (response_id, conversation_id)
        db_manager.execute_query(query, params)
        return True
    except Exception as e:
        print(f"Error updating conversation last response ID: {str(e)}")
        return False


def get_conversation_last_response_id(conversation_id):
    """Get the last response ID for a conversation"""
    try:
        query = "SELECT last_response_id FROM ai_conversations WHERE id = ?"
        params = (conversation_id,)
        result = db_manager.execute_query(query, params, fetch=True)
        response_id = None
        if result and result[0]['last_response_id']:
            response_id = result[0]['last_response_id']
        # Check for debug flag at runtime to avoid circular imports
        try:
            from ai_config import DEBUG as AI_DEBUG
            if AI_DEBUG:
                print(f"[DATABASE_AI] Retrieved last response ID for conversation {conversation_id}: {response_id}")
        except ImportError:
            pass
        return response_id
    except Exception as e:
        print(f"Error getting conversation last response ID: {str(e)}")
        return None


def get_ai_conversation_history(conversation_id, limit=50):
    """Get message history for an AI conversation"""
    try:
        query = """SELECT role, content, timestamp, token_count, model_used
                   FROM ai_messages
                   WHERE conversation_id = ?
                   ORDER BY timestamp ASC
                   LIMIT ?"""
        params = (conversation_id, limit)
        result = db_manager.execute_query(query, params, fetch=True)

        messages = []
        if result:
            for row in result:
                messages.append({
                    'role': row['role'],
                    'content': row['content'],
                    'timestamp': row['timestamp'],
                    'token_count': row['token_count'],
                    'model_used': row['model_used']
                })
        return messages
    except Exception as e:
        print(f"Error getting AI conversation history: {str(e)}")
        return []


def get_user_ai_conversations(user_uuid, conversation_type=None, limit=20):
    """Get AI conversations for a user"""
    try:
        if conversation_type:
            query = """SELECT id, conversation_type, channel_id, created_at, updated_at, title
                       FROM ai_conversations
                       WHERE user_uuid = ? AND conversation_type = ?
                       ORDER BY updated_at DESC
                       LIMIT ?"""
            params = (user_uuid, conversation_type, limit)
        else:
            query = """SELECT id, conversation_type, channel_id, created_at, updated_at, title
                       FROM ai_conversations
                       WHERE user_uuid = ?
                       ORDER BY updated_at DESC
                       LIMIT ?"""
            params = (user_uuid, limit)

        result = db_manager.execute_query(query, params, fetch=True)

        conversations = []
        if result:
            for row in result:
                conversations.append({
                    'id': row['id'],
                    'conversation_type': row['conversation_type'],
                    'channel_id': row['channel_id'],
                    'created_at': row['created_at'],
                    'updated_at': row['updated_at'],
                    'title': row['title']
                })
        return conversations
    except Exception as e:
        print(f"Error getting user AI conversations: {str(e)}")
        return []


def get_channel_context_for_ai(channel_id, message_limit=10, include_ai_messages=True):
    """Get recent channel messages for AI context, optionally including AI-generated messages for character banter.
    Respects !poof commands as hard stops - only messages after the most recent !poof are included."""
    try:
        import sqlite3
        # Use direct connection like other database functions
        conn = sqlite3.connect(CHAT_DB_NAME)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        # Include AI messages if requested (for character-to-character interactions)
        ai_filter = "" if include_ai_messages else "AND m.ai_generated = 0"

        # Get more messages than requested to ensure we can find a !poof if it exists
        extended_limit = min(message_limit * 3, 100)  # Cap at 100 to avoid excessive queries

        query = f"""SELECT m.sender, m.message, m.timestamp, u.display_name, u.username, m.ai_generated
                    FROM messages m
                    LEFT JOIN users u ON m.sender = u.uuid
                    WHERE m.channel = ? {ai_filter} AND m.is_media = 0
                    ORDER BY m.timestamp DESC
                    LIMIT ?"""
        params = (channel_id, extended_limit)

        cursor.execute(query, params)
        result = cursor.fetchall()

        # Convert to dict format (still in reverse chronological order)
        all_messages = []
        if result:
            for row in result:
                all_messages.append({
                    'sender': row['sender'],
                    'message': row['message'],
                    'timestamp': row['timestamp'],
                    'display_name': row['display_name'],
                    'username': row['username'],
                    'is_ai': bool(row['ai_generated'])
                })

        # Find the most recent !poof marker
        poof_index = -1
        for i, msg in enumerate(all_messages):
            if '[POOF_RESET_MARKER]' in msg['message']:
                poof_index = i
                break

        # If we found a !poof marker, only include messages after it
        if poof_index >= 0:
            # Take messages after the !poof, up to the message limit
            messages = all_messages[:poof_index][:message_limit]
            print(f"DEBUG: Found !poof marker at position {poof_index}, using {len(messages)} messages after it")
        else:
            # No !poof found, use the most recent messages as before
            messages = all_messages[:message_limit]

        conn.close()

        print(f"DEBUG: Returning {len(messages)} messages for AI context")
        if messages:
            print(f"DEBUG: Most recent message: {messages[0]['message'][:50]}...")

        return messages

    except Exception as e:
        print(f"Error getting channel context for AI: {str(e)}")
        return []


def mark_message_as_ai_generated(message_id, conversation_id=None, model=None, is_dm=False):
    """Mark a message as AI-generated"""
    try:
        table = 'dm_messages' if is_dm else 'messages'
        query = f"UPDATE {table} SET ai_generated = 1, ai_conversation_id = ?, ai_model = ? WHERE id = ?"
        params = (conversation_id, model, message_id)
        db_manager.execute_query(query, params)
        return True
    except Exception as e:
        print(f"Error marking message as AI generated: {str(e)}")
        return False


def delete_ai_conversation(conversation_id):
    """Delete an AI conversation and all its messages"""
    try:
        # Messages will be deleted automatically due to CASCADE constraint
        query = "DELETE FROM ai_conversations WHERE id = ?"
        params = (conversation_id,)
        db_manager.execute_query(query, params)
        return True
    except Exception as e:
        print(f"Error deleting AI conversation: {str(e)}")
        return False


def get_user_ai_settings(user_uuid):
    """Get user's AI settings, with defaults"""
    try:
        from database import get_user_settings
        settings = get_user_settings(user_uuid)

        # Default AI settings
        default_ai_settings = {
            'ai_active_character': 'Helpful Assistant',
            'ai_temperature': 0.7,
            'ai_max_tokens': 2048,
            'ai_context_window': 4096,
            'ai_history_limit': 50,  # Global context limit for modal/DM conversations
            'ai_model': 'default',
            'ai_system_prompt': 'You are a helpful AI assistant in a chat application. Be friendly and engaging.',
            'ai_custom_instructions': '',
            'ai_context_management_mode': 'client',  # Default to client-side for backward compatibility
            'ai_api_debug': False,  # Enable detailed API logging
            'ai_channel_memory_enabled': True,  # Enable channel memory by default
            'ai_channel_memory_limit': 10  # Channel-specific context limit
        }

        # Merge with user settings (user settings take precedence)
        ai_settings = default_ai_settings.copy()
        ai_settings.update(settings.get('ai_settings', {}))

        return ai_settings
    except Exception as e:
        print(f"Error getting user AI settings: {str(e)}")
        return default_ai_settings


def update_user_ai_settings(user_uuid, ai_settings):
    """Update user's AI settings"""
    try:
        from database import get_user_settings, update_user_settings

        current_settings = get_user_settings(user_uuid)
        # Merge with existing AI settings instead of replacing
        existing_ai_settings = current_settings.get('ai_settings', {})
        existing_ai_settings.update(ai_settings)
        current_settings['ai_settings'] = existing_ai_settings
        update_user_settings(user_uuid, current_settings)

        return True
    except Exception as e:
        print(f"Error updating user AI settings: {str(e)}")
        return False


def save_ai_character(user_uuid, character_name, character_data):
    """Save an AI character preset - handles both create and update"""
    try:
        import datetime
        now = datetime.datetime.now().isoformat()

        # For updates, preserve existing avatar_url if not provided
        existing_avatar = None
        if character_data.get('avatar_url') is None:
            # Check if character exists and get current avatar
            existing = db_manager.execute_query(
                "SELECT avatar_url FROM ai_characters WHERE user_uuid = ? AND character_name = ?",
                (user_uuid, character_name), fetch=True
            )
            if existing:
                existing_avatar = existing[0]['avatar_url']

        # Map frontend field names to database field names for consistency
        db_data = {
            'character_description': character_data.get('character_description', ''),
            'avatar_url': character_data.get('avatar_url') or existing_avatar or '/static/default_avatars/smile_1.png',
            'ai_temperature': character_data.get('ai_temperature', 0.7),
            'ai_max_tokens': character_data.get('ai_max_tokens', 2048),
            'ai_context_window': character_data.get('ai_context_window', 4096),
            'ai_history_limit': character_data.get('ai_history_limit', 50),
            'ai_model': character_data.get('ai_model', 'default'),
            'ai_system_prompt': character_data.get('ai_system_prompt', ''),
            'ai_custom_instructions': character_data.get('ai_custom_instructions', '')
        }

        # Check if character already exists
        existing = db_manager.execute_query(
            "SELECT id FROM ai_characters WHERE user_uuid = ? AND character_name = ?",
            (user_uuid, character_name), fetch=True
        )

        if existing:
            # Update existing character
            query = """
                UPDATE ai_characters SET
                    character_description = ?, avatar_url = ?, ai_temperature = ?,
                    ai_max_tokens = ?, ai_context_window = ?, ai_history_limit = ?,
                    ai_model = ?, ai_system_prompt = ?, ai_custom_instructions = ?,
                    updated_at = ?
                WHERE user_uuid = ? AND character_name = ?
            """
            params = (
                db_data['character_description'],
                db_data['avatar_url'],
                db_data['ai_temperature'],
                db_data['ai_max_tokens'],
                db_data['ai_context_window'],
                db_data['ai_history_limit'],
                db_data['ai_model'],
                db_data['ai_system_prompt'],
                db_data['ai_custom_instructions'],
                now, user_uuid, character_name
            )
        else:
            # Create new character
            query = """
                INSERT INTO ai_characters
                (user_uuid, character_name, character_description, avatar_url, ai_temperature,
                 ai_max_tokens, ai_context_window, ai_history_limit, ai_model, ai_system_prompt,
                 ai_custom_instructions, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """
            params = (
                user_uuid, character_name,
                db_data['character_description'],
                db_data['avatar_url'],
                db_data['ai_temperature'],
                db_data['ai_max_tokens'],
                db_data['ai_context_window'],
                db_data['ai_history_limit'],
                db_data['ai_model'],
                db_data['ai_system_prompt'],
                db_data['ai_custom_instructions'],
                now, now
            )

        result = db_manager.execute_query(query, params)
        return result.lastrowid if result and not existing else True
    except Exception as e:
        error_msg = str(e)
        print(f"Error saving AI character: {error_msg}")
        return False


def get_user_ai_characters(user_uuid):
    """Get all AI characters for a user (both built-in and user-created)"""
    try:
        # Get user-created characters
        user_query = """
            SELECT character_name, character_description, avatar_url, ai_temperature,
                   ai_max_tokens, ai_context_window, ai_history_limit, ai_model,
                   ai_system_prompt, ai_custom_instructions, created_at, updated_at, 'user' as character_type
            FROM ai_characters
            WHERE user_uuid = ?
            ORDER BY character_name
        """
        user_result = db_manager.execute_query(user_query, (user_uuid,), fetch=True)

        # Get built-in characters (system characters)
        builtin_query = """
            SELECT character_name, character_description, avatar_url, ai_temperature,
                   ai_max_tokens, ai_context_window, ai_history_limit, ai_model,
                   ai_system_prompt, ai_custom_instructions, created_at, updated_at, 'builtin' as character_type
            FROM ai_characters
            WHERE user_uuid = 'system-builtin-characters'
            ORDER BY character_name
        """
        builtin_result = db_manager.execute_query(builtin_query, fetch=True)

        characters = []
        character_dict = {}  # Use dict to prevent duplicates by name

        # Add built-in characters first
        if builtin_result:
            for row in builtin_result:
                char_name = row['character_name']
                character_dict[char_name] = {
                    'character_name': char_name,
                    'character_description': row['character_description'],
                    'avatar_url': row['avatar_url'],
                    'ai_temperature': row['ai_temperature'],
                    'ai_max_tokens': row['ai_max_tokens'],
                    'ai_context_window': row['ai_context_window'],
                    'ai_history_limit': row['ai_history_limit'],
                    'ai_model': row['ai_model'],
                    'ai_system_prompt': row['ai_system_prompt'],
                    'ai_custom_instructions': row['ai_custom_instructions'],
                    'created_at': row['created_at'],
                    'updated_at': row['updated_at'],
                    'character_type': row['character_type']
                }

        # Add user-created characters (these take precedence over built-in ones)
        if user_result:
            for row in user_result:
                char_name = row['character_name']
                character_dict[char_name] = {
                    'character_name': char_name,
                    'character_description': row['character_description'],
                    'avatar_url': row['avatar_url'],
                    'ai_temperature': row['ai_temperature'],
                    'ai_max_tokens': row['ai_max_tokens'],
                    'ai_context_window': row['ai_context_window'],
                    'ai_history_limit': row['ai_history_limit'],
                    'ai_model': row['ai_model'],
                    'ai_system_prompt': row['ai_system_prompt'],
                    'ai_custom_instructions': row['ai_custom_instructions'],
                    'created_at': row['created_at'],
                    'updated_at': row['updated_at'],
                    'character_type': row['character_type']
                }

        # Convert dict to list
        characters = list(character_dict.values())

        return characters
    except Exception as e:
        print(f"Error getting user AI characters: {str(e)}")
        return []


def get_ai_character(user_uuid, character_name):
    """Get a specific AI character (checks both user and built-in characters)"""
    try:
        # First try to find user-specific character
        query = """
            SELECT character_name, character_description, avatar_url, ai_temperature,
                   ai_max_tokens, ai_context_window, ai_history_limit, ai_model,
                   ai_system_prompt, ai_custom_instructions
            FROM ai_characters
            WHERE user_uuid = ? AND character_name = ?
        """
        result = db_manager.execute_query(query, (user_uuid, character_name), fetch=True)
        if result and len(result) > 0:
            row = result[0]
            return {
                'character_name': row['character_name'],
                'character_description': row['character_description'],
                'avatar_url': row['avatar_url'],
                'ai_temperature': row['ai_temperature'],
                'ai_max_tokens': row['ai_max_tokens'],
                'ai_context_window': row['ai_context_window'],
                'ai_history_limit': row['ai_history_limit'],
                'ai_model': row['ai_model'],
                'ai_system_prompt': row['ai_system_prompt'],
                'ai_custom_instructions': row['ai_custom_instructions']
            }

        # If not found, try built-in characters
        builtin_query = """
            SELECT character_name, character_description, avatar_url, ai_temperature,
                   ai_max_tokens, ai_context_window, ai_history_limit, ai_model,
                   ai_system_prompt, ai_custom_instructions
            FROM ai_characters
            WHERE user_uuid = 'system-builtin-characters' AND character_name = ?
        """
        builtin_result = db_manager.execute_query(builtin_query, (character_name,), fetch=True)
        if builtin_result and len(builtin_result) > 0:
            row = builtin_result[0]
            return {
                'character_name': row['character_name'],
                'character_description': row['character_description'],
                'avatar_url': row['avatar_url'],
                'ai_temperature': row['ai_temperature'],
                'ai_max_tokens': row['ai_max_tokens'],
                'ai_context_window': row['ai_context_window'],
                'ai_history_limit': row['ai_history_limit'],
                'ai_model': row['ai_model'],
                'ai_system_prompt': row['ai_system_prompt'],
                'ai_custom_instructions': row['ai_custom_instructions']
            }

        # If not found in built-ins, try any user's characters (for shared characters)
        global_query = """
            SELECT character_name, character_description, avatar_url, ai_temperature,
                   ai_max_tokens, ai_context_window, ai_history_limit, ai_model,
                   ai_system_prompt, ai_custom_instructions
            FROM ai_characters
            WHERE character_name = ? AND user_uuid != 'system-builtin-characters'
            ORDER BY updated_at DESC
            LIMIT 1
        """
        global_result = db_manager.execute_query(global_query, (character_name,), fetch=True)
        if global_result and len(global_result) > 0:
            row = global_result[0]
            return {
                'character_name': row['character_name'],
                'character_description': row['character_description'],
                'avatar_url': row['avatar_url'],
                'ai_temperature': row['ai_temperature'],
                'ai_max_tokens': row['ai_max_tokens'],
                'ai_context_window': row['ai_context_window'],
                'ai_history_limit': row['ai_history_limit'],
                'ai_model': row['ai_model'],
                'ai_system_prompt': row['ai_system_prompt'],
                'ai_custom_instructions': row['ai_custom_instructions']
            }

        return None
    except Exception as e:
        print(f"Error getting AI character: {str(e)}")
        return None


def create_user_ai_character(character_data):
    """Create a new user AI character"""
    try:
        user_uuid = character_data.get('user_uuid')
        name = character_data.get('name', '').strip()
        description = character_data.get('description', '').strip()
        system_prompt = character_data.get('ai_system_prompt', '').strip()
        custom_instructions = character_data.get('ai_custom_instructions', '').strip()
        avatar_url = character_data.get('avatar_url', '/static/default_avatars/smile_1.png')

        if not user_uuid or not name:
            return None

        # Check if character name already exists for this user
        check_query = "SELECT id FROM ai_characters WHERE user_uuid = ? AND character_name = ?"
        existing = db_manager.execute_query(check_query, (user_uuid, name), fetch=True)
        if existing and len(existing) > 0:
            return None  # Character name already exists

        # Insert new character
        insert_query = """
            INSERT INTO ai_characters (user_uuid, character_name, character_description, avatar_url,
                                     ai_temperature, ai_max_tokens, ai_context_window, ai_history_limit,
                                     ai_model, ai_system_prompt, ai_custom_instructions, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
        """

        # Use defaults for numeric fields
        temperature = character_data.get('ai_temperature', 0.7)
        max_tokens = character_data.get('ai_max_tokens', 2048)
        context_window = character_data.get('ai_context_window', 4096)
        history_limit = character_data.get('ai_history_limit', 50)
        model = character_data.get('ai_model', 'default')

        result = db_manager.execute_query(insert_query, (
            user_uuid, name, description, avatar_url,
            temperature, max_tokens, context_window, history_limit,
            model, system_prompt, custom_instructions
        ))

        return result.lastrowid if result else None

    except Exception as e:
        print(f"Error creating user AI character: {str(e)}")
        return None


def delete_ai_character(user_uuid, character_name):
    """Delete an AI character"""
    try:
        query = "DELETE FROM ai_characters WHERE user_uuid = ? AND character_name = ?"
        db_manager.execute_query(query, (user_uuid, character_name))
        return True
    except Exception as e:
        print(f"Error deleting AI character: {str(e)}")
        return False


def update_character_avatar(character_name, avatar_url, user_uuid=None):
    """Update a character's avatar URL"""
    try:
        # For user-created characters
        if user_uuid:
            query = "UPDATE ai_characters SET avatar_url = ? WHERE user_uuid = ? AND character_name = ?"
            db_manager.execute_query(query, (avatar_url, user_uuid, character_name))
        else:
            # For built-in characters (allow any user to customize)
            query = "UPDATE ai_characters SET avatar_url = ? WHERE user_uuid = 'system-builtin-characters' AND character_name = ?"
            db_manager.execute_query(query, (avatar_url, character_name))
        return True
    except Exception as e:
        print(f"Error updating character avatar: {str(e)}")
        return False