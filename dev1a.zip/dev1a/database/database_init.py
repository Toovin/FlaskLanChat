# database_init.py - Database initialization and setup functions
import sqlite3
from datetime import datetime
import os
from lc_config import CHAT_DB_NAME


def get_standard_timestamp():
    """Get a standard timestamp string for database storage"""
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def init_db():
    db_path = CHAT_DB_NAME
    try:
        # Check if database file is accessible
        if not os.path.exists(db_path):
            print(f"Creating new database file: {db_path}")
        else:
            print(f"Using existing database file: {db_path}")

        conn = sqlite3.connect(db_path)
        c = conn.cursor()

        # Check if messages table exists
        c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='messages'")
        table_exists = c.fetchone()
        if table_exists:
            print("Messages table exists, checking for missing columns")
            c.execute("PRAGMA table_info(messages)")
            columns = [col[1] for col in c.fetchall()]

            # Check for replied_to column
            if 'replied_to' not in columns:
                print("Adding replied_to column to messages table")
                c.execute("ALTER TABLE messages ADD COLUMN replied_to INTEGER")
                c.execute("UPDATE messages SET replied_to = NULL")
                conn.commit()

            # Check for image_url column
            if 'image_url' not in columns:
                print("Adding image_url column to messages table")
                c.execute("ALTER TABLE messages ADD COLUMN image_url TEXT")
                conn.commit()

            # Check for thumbnail_url column
            if 'thumbnail_url' not in columns:
                print("Adding thumbnail_url column to messages table")
                c.execute("ALTER TABLE messages ADD COLUMN thumbnail_url TEXT")
                conn.commit()

            # Check for generation_id column
            if 'generation_id' not in columns:
                print("Adding generation_id column to messages table")
                c.execute("ALTER TABLE messages ADD COLUMN generation_id TEXT")
                conn.commit()

            # Check for auto_share column
            if 'auto_share' not in columns:
                print("Adding auto_share column to messages table")
                c.execute("ALTER TABLE messages ADD COLUMN auto_share INTEGER DEFAULT 1")
                conn.commit()

            # Check for replied_sender column
            if 'replied_sender' not in columns:
                print("Adding replied_sender column to messages table")
                c.execute("ALTER TABLE messages ADD COLUMN replied_sender TEXT")
                conn.commit()

            # Check for replied_text column
            if 'replied_text' not in columns:
                print("Adding replied_text column to messages table")
                c.execute("ALTER TABLE messages ADD COLUMN replied_text TEXT")
                conn.commit()

            # Check for avatar_url column
            if 'avatar_url' not in columns:
                print("Adding avatar_url column to messages table")
                c.execute("ALTER TABLE messages ADD COLUMN avatar_url TEXT")
                conn.commit()
        else:
            print("Creating messages table")
            c.execute('''CREATE TABLE messages (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  channel TEXT,
                  sender TEXT,
                  message TEXT,
                  is_media INTEGER,
                  timestamp TEXT,
                  replied_to INTEGER,
                  replied_sender TEXT,
                  replied_text TEXT,
                  image_url TEXT,
                  thumbnail_url TEXT,
                  avatar_url TEXT,
                  generation_id TEXT,
                  auto_share INTEGER DEFAULT 1,
                  FOREIGN KEY (replied_to) REFERENCES messages(id) ON DELETE SET NULL
               )''')
            conn.commit()

            # Add avatar_url column to messages table if it doesn't exist
            try:
                c.execute("ALTER TABLE messages ADD COLUMN avatar_url TEXT")
                conn.commit()
                print("Added avatar_url column to messages table")
            except sqlite3.OperationalError:
                # Column might already exist
                pass

        # Create other tables
        print("Creating users table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS users (
             uuid TEXT PRIMARY KEY,
             username TEXT UNIQUE,
             password_hash TEXT,
             avatar_url TEXT,
             display_name TEXT,
             custom_status TEXT,
             is_admin INTEGER DEFAULT 0
         )''')
        conn.commit()

        # Check for missing image preference columns in users table
        c.execute("PRAGMA table_info(users)")
        columns = [col[1] for col in c.fetchall()]

        image_pref_columns = [
            'last_sd_model', 'last_img_width', 'last_img_height', 'last_img_steps',
            'last_img_cfg_scale', 'last_img_clip_skip', 'last_img_negative_prompt',
            'last_img_sampler', 'last_img_scheduler', 'last_img_batch_size', 'last_uploaded_image'
        ]

        for col in image_pref_columns:
            if col not in columns:
                print(f"Adding {col} column to users table")
                if col == 'last_uploaded_image':
                    c.execute(f"ALTER TABLE users ADD COLUMN {col} TEXT")
                else:
                    c.execute(f"ALTER TABLE users ADD COLUMN {col} TEXT")
                conn.commit()

        # Check for missing user preference columns in users table
        user_pref_columns = [
            ('status', 'TEXT DEFAULT \'online\''),
            ('theme', 'TEXT DEFAULT \'dobo\''),
            ('font', 'TEXT DEFAULT \'system\''),
            ('font_scale', 'REAL DEFAULT 1.0'),
            ('compact_mode', 'INTEGER DEFAULT 0'),
            ('show_timestamps', 'INTEGER DEFAULT 1'),
            ('animated_bg', 'TEXT DEFAULT \'none\''),
            ('cursor_effect', 'TEXT DEFAULT \'orbiting\''),
            ('particle_style', 'TEXT DEFAULT \'theme\''),
            ('cursor_main', 'TEXT DEFAULT \'default\''),
            ('cursor_particle', 'TEXT DEFAULT \'default\''),
            ('allow_dms', 'INTEGER DEFAULT 1'),
            ('show_online_status', 'INTEGER DEFAULT 1'),
            ('typing_indicators', 'INTEGER DEFAULT 1'),
            ('toast_on_media_download', 'INTEGER DEFAULT 1')
        ]

        for col_name, col_def in user_pref_columns:
            if col_name not in columns:
                print(f"Adding {col_name} column to users table")
                try:
                    c.execute(f"ALTER TABLE users ADD COLUMN {col_name} {col_def}")
                    conn.commit()
                except sqlite3.OperationalError as e:
                    print(f"Error adding {col_name} column: {e}")

        print("Creating channels table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS channels (
             id TEXT PRIMARY KEY,
             name TEXT UNIQUE,
             icon TEXT DEFAULT NULL
         )''')

        # Add icon column if not exists (for migration)
        try:
            c.execute("ALTER TABLE channels ADD COLUMN icon TEXT DEFAULT NULL")
        except sqlite3.OperationalError:
            pass  # Column already exists

        conn.commit()

        # Add AI settings columns if not exists (for migration) - run after table creation
        print("Adding AI columns to channels table...")
        try:
            c.execute("ALTER TABLE channels ADD COLUMN ai_enabled INTEGER DEFAULT 1")
            print("Added ai_enabled column")
        except sqlite3.OperationalError as e:
            print(f"ai_enabled column already exists: {e}")

        try:
            c.execute("ALTER TABLE channels ADD COLUMN ai_memory_limit INTEGER DEFAULT 10")
            print("Added ai_memory_limit column")
        except sqlite3.OperationalError as e:
            print(f"ai_memory_limit column already exists: {e}")

        try:
            c.execute("ALTER TABLE channels ADD COLUMN ai_model TEXT DEFAULT 'default'")
            print("Added ai_model column")
        except sqlite3.OperationalError as e:
            print(f"ai_model column already exists: {e}")

        try:
            c.execute("ALTER TABLE channels ADD COLUMN ai_temperature REAL DEFAULT 0.7")
            print("Added ai_temperature column")
        except sqlite3.OperationalError as e:
            print(f"ai_temperature column already exists: {e}")

        conn.commit()
        print("AI columns migration completed")

        conn.commit()

        print("Creating media_channels table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS media_channels (
             id INTEGER PRIMARY KEY AUTOINCREMENT,
             name TEXT UNIQUE
         )''')
        conn.commit()

        print("Creating user_settings table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS user_settings (
             user_uuid TEXT PRIMARY KEY,
             settings TEXT,
             FOREIGN KEY (user_uuid) REFERENCES users(uuid) ON DELETE CASCADE
         )''')
        conn.commit()

        print("Creating user_notes table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS user_notes (
             uuid TEXT PRIMARY KEY,
             user_uuid TEXT,
             title TEXT,
             content TEXT,
             created_at TEXT,
             updated_at TEXT,
             FOREIGN KEY (user_uuid) REFERENCES users(uuid) ON DELETE CASCADE
         )''')
        conn.commit()

        print("Creating folders table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS folders (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL,
              parent_id INTEGER,
              path TEXT NOT NULL,
              created_at TEXT NOT NULL,
              created_by TEXT,
              FOREIGN KEY (parent_id) REFERENCES folders(id) ON DELETE CASCADE
          )''')
        conn.commit()

        print("Creating file_folders table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS file_folders (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              filename TEXT NOT NULL,
              folder_id INTEGER,
              filepath TEXT NOT NULL,
              size INTEGER,
              created_at TEXT NOT NULL,
              created_by TEXT,
              thumbnail_url TEXT,
              visibility TEXT DEFAULT 'private',
              shared_by TEXT,
              ownership TEXT DEFAULT 'user',
              FOREIGN KEY (folder_id) REFERENCES folders(id) ON DELETE CASCADE
          )''')

        # Add new columns if they don't exist
        c.execute("PRAGMA table_info(file_folders)")
        columns = [col[1] for col in c.fetchall()]
        if 'thumbnail_url' not in columns:
            print("Adding thumbnail_url column to file_folders table")
            c.execute("ALTER TABLE file_folders ADD COLUMN thumbnail_url TEXT")
            conn.commit()
        if 'visibility' not in columns:
            print("Adding visibility column to file_folders table")
            c.execute("ALTER TABLE file_folders ADD COLUMN visibility TEXT DEFAULT 'private'")
            conn.commit()
        if 'shared_by' not in columns:
            print("Adding shared_by column to file_folders table")
            c.execute("ALTER TABLE file_folders ADD COLUMN shared_by TEXT")
            conn.commit()
        if 'ownership' not in columns:
            print("Adding ownership column to file_folders table")
            c.execute("ALTER TABLE file_folders ADD COLUMN ownership TEXT DEFAULT 'user'")
            conn.commit()

        # Create root folder if it doesn't exist
        c.execute("SELECT id FROM folders WHERE parent_id IS NULL AND name = 'Share'")
        root_folder = c.fetchone()
        if not root_folder:
            print("Creating root 'Share' folder")
            c.execute('''INSERT INTO folders (name, parent_id, path, created_at, created_by)
                         VALUES (?, ?, ?, ?, ?)''',
                      ('Share', None, 'file_share_system', get_standard_timestamp(), 'system'))
            root_folder_id = c.lastrowid

            # Create default subfolder
            print("Creating default 'Subfolder' under root")
            c.execute('''INSERT INTO folders (name, parent_id, path, created_at, created_by)
                         VALUES (?, ?, ?, ?, ?)''',
                      ('Subfolder', root_folder_id, 'file_share_system/Subfolder', get_standard_timestamp(), 'system'))
        else:
            root_folder_id = root_folder[0]
            # Check if Subfolder exists, create if not
            c.execute("SELECT id FROM folders WHERE parent_id = ? AND name = 'Subfolder'", (root_folder_id,))
            if not c.fetchone():
                print("Creating default 'Subfolder' under root")
                c.execute('''INSERT INTO folders (name, parent_id, path, created_at, created_by)
                             VALUES (?, ?, ?, ?, ?)''',
                          ('Subfolder', root_folder_id, 'file_share_system/Subfolder', get_standard_timestamp(), 'system'))

        print("Creating reactions table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS reactions (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              message_id INTEGER,
              user_uuid TEXT,
              emoji TEXT,
              FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
              FOREIGN KEY (user_uuid) REFERENCES users(uuid)
          )''')

        print("Cleaning up duplicate reactions")
        c.execute('''
            DELETE FROM reactions
            WHERE id NOT IN (
                SELECT MAX(id)
                FROM reactions
                GROUP BY message_id, user_uuid, emoji
            )
        ''')

        print("Creating unique index for reactions")
        c.execute(
            '''CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_reaction ON reactions (message_id, user_uuid, emoji)''')

        print("Creating dm_messages table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS dm_messages (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              sender_uuid TEXT,
              recipient_uuid TEXT,
              message TEXT,
              is_media INTEGER DEFAULT 0,
              timestamp TEXT,
              read_status INTEGER DEFAULT 0,
              FOREIGN KEY (sender_uuid) REFERENCES users(uuid),
              FOREIGN KEY (recipient_uuid) REFERENCES users(uuid)
          )''')

        print("Inserting default 'general' channel")
        c.execute("INSERT OR IGNORE INTO channels (id, name, icon) VALUES ('general', 'general', 'fas fa-circle')")

        print("Inserting default 'default' media channel")
        c.execute("INSERT OR IGNORE INTO media_channels (name) VALUES ('default')")

        print("Creating system_users table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS system_users (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              category TEXT UNIQUE NOT NULL,
              display_name TEXT NOT NULL
          )''')

        print("Creating system_settings table if not exists")
        c.execute('''CREATE TABLE IF NOT EXISTS system_settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )''')

        # Insert default system users
        default_system_users = [
            ('media_download', 'Media Download'),
            ('file_share', 'File Share'),
            ('cinema', 'Cinema'),
            ('voice', 'Voice'),
            ('system', 'System'),
            ('ai_assistant', 'AI Assistant')  # Add AI assistant as system user
        ]
        c.executemany("INSERT OR IGNORE INTO system_users (category, display_name) VALUES (?, ?)", default_system_users)

        conn.commit()

        # Initialize AI-specific tables (legacy - in main database)
        from .database_ai import init_ai_tables
        init_ai_tables()

        # Initialize separate AI database
        from ai_database import ai_database
        ai_database.init_tables()
        # Note: Data migration was completed in previous overhaul
        # Migrate avatar URLs from old path to new user_avatars path
        try:
            c.execute("UPDATE users SET avatar_url = REPLACE(avatar_url, '/static/avatars/', '/static/user_avatars/') WHERE avatar_url LIKE '/static/avatars/%'")
            migrated_count = c.rowcount
            if migrated_count > 0:
                print(f"Migrated {migrated_count} user avatar URLs to new user_avatars path")
            conn.commit()
        except Exception as e:
            print(f"Error during avatar URL migration: {str(e)}")

        # Ensure user folders exist
        ensure_user_folders()

        print("Database initialization completed successfully")
        conn.close()
        print("Database initialization complete")

    except Exception as e:
        print(f"Error initializing database: {e}")
        raise


def ensure_user_folders():
    """Ensure each user has a personal folder."""
    try:
        print("Ensuring user folders exist...")
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        # Get all usernames
        c.execute("SELECT username FROM users")
        users = c.fetchall()
        print(f"Found {len(users)} users")

        for (username,) in users:
            folder_path = f'file_share_system/{username}'
            if not get_folder_by_path(folder_path):
                # Create the folder
                c.execute("INSERT INTO folders (name, path, created_at, created_by) VALUES (?, ?, ?, ?)",
                          (username, folder_path, get_standard_timestamp(), username))
                # Create the filesystem directory
                os.makedirs(os.path.join('static', folder_path), exist_ok=True)
                print(f"Created folder for user: {username}")
            else:
                # Ensure filesystem directory exists
                os.makedirs(os.path.join('static', folder_path), exist_ok=True)
                print(f"Folder already exists for user: {username}")

        conn.commit()
        conn.close()
        print("User folders ensured.")
    except Exception as e:
        print(f"Error ensuring user folders: {str(e)}")


def get_folder_by_path(path):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("SELECT id, name, parent_id, path, created_at, created_by FROM folders WHERE path = ?", (path,))
        row = c.fetchone()
        conn.close()
        if row:
            return {
                'id': row[0],
                'name': row[1],
                'parent_id': row[2],
                'path': row[3],
                'created_at': row[4],
                'created_by': row[5]
            }
        return None
    except Exception as e:
        print(f"Error getting folder by path: {str(e)}")
        return None


def get_system_display_name(category):
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("SELECT display_name FROM system_users WHERE category = ?", (category,))
        row = c.fetchone()
        conn.close()
        return row[0] if row else category
    except Exception as e:
        print(f"Error getting system display name: {str(e)}")
        return category