# database_settings.py - User settings database functions
import sqlite3
import json
from .database_manager import DatabaseManager

# Global database manager instance
db_manager = DatabaseManager('devchat.db')


def _get_update_fields(settings):
    """Get fields to update in users table based on settings."""
    update_fields = []
    update_values = []
    if 'avatar_url' in settings:
        update_fields.append("avatar_url = ?")
        update_values.append(settings['avatar_url'])
    if 'display_name' in settings:
        update_fields.append("display_name = ?")
        update_values.append(settings['display_name'])
    if 'custom_status' in settings:
        update_fields.append("custom_status = ?")
        update_values.append(settings['custom_status'])
    if 'font' in settings:
        update_fields.append("font = ?")
        update_values.append(settings['font'])
    if 'font_scale' in settings and settings['font_scale'] is not None:
        update_fields.append("font_scale = ?")
        update_values.append(float(settings['font_scale']))
    if 'toast_on_media_download' in settings:
        update_fields.append("toast_on_media_download = ?")
        update_values.append(int(settings['toast_on_media_download']))
    if 'theme' in settings:
        update_fields.append("theme = ?")
        update_values.append(settings['theme'])
    if 'animated_bg' in settings:
        update_fields.append("animated_bg = ?")
        update_values.append(settings['animated_bg'])
    # Add cursor and particle settings to users table updates
    if 'cursor_main' in settings:
        update_fields.append("cursor_main = ?")
        update_values.append(settings['cursor_main'])
    if 'cursor_particle' in settings:
        update_fields.append("cursor_particle = ?")
        update_values.append(settings['cursor_particle'])
    if 'cursor_effect' in settings:
        update_fields.append("cursor_effect = ?")
        update_values.append(settings['cursor_effect'])
    if 'particle_style' in settings:
        update_fields.append("particle_style = ?")
        update_values.append(settings['particle_style'])
    if 'cursor_size' in settings:
        update_fields.append("cursor_size = ?")
        update_values.append(int(settings['cursor_size']))
    if 'cursor_glow' in settings:
        update_fields.append("cursor_glow = ?")
        update_values.append(int(settings['cursor_glow']))
    if 'particle_size' in settings:
        update_fields.append("particle_size = ?")
        update_values.append(float(settings['particle_size']))
    if 'auto_hide_particles' in settings:
        update_fields.append("auto_hide_particles = ?")
        update_values.append(int(settings['auto_hide_particles']))
    if 'auto_hide_timeout' in settings:
        update_fields.append("auto_hide_timeout = ?")
        update_values.append(int(settings['auto_hide_timeout']))
    return update_fields, update_values


def update_user_settings(user_uuid, settings):
    """Update user settings in database."""
    print(f"[DEBUG] update_user_settings called for user_uuid: {user_uuid}")
    try:
        # Save to user_settings table
        settings_json = json.dumps(settings)
        print(f"[DEBUG] settings_json: {settings_json}")
        query1 = "INSERT OR REPLACE INTO user_settings (user_uuid, settings) VALUES (?, ?)"
        params1 = (user_uuid, settings_json)
        print(f"[DEBUG] Executing query1: {query1} with params: {params1}")
        db_manager.execute_query(query1, params1)

        # Update users table fields if needed
        update_fields, update_values = _get_update_fields(settings)
        if update_fields:
            update_values.append(user_uuid)
            query2 = f"UPDATE users SET {', '.join(update_fields)} WHERE uuid = ?"
            print(f"[DEBUG] Executing query2: {query2} with params: {update_values}")
            db_manager.execute_query(query2, tuple(update_values))

        print(f"[DEBUG] update_user_settings completed successfully")
        return True
    except Exception as e:
        print(f"Error updating user settings: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def _get_default_settings():
    """Get default settings for new users."""
    return {
        'display_name': '',
        'status': 'online',
        'custom_status': '',
        'theme': 'dobo',
        'font': 'system',
        'font_scale': 1.0,
        'compact_mode': False,
        'show_timestamps': True,
        'animated_bg': 'none',
        'cursor_effect': 'orbiting',
        'particle_style': 'theme',
        'particle_size': 1.0,
        'cursor_main': 'default',
        'cursor_particle': 'default',
        'cursor_glow': False,
        'cursor_size': 64,
        'allow_dms': True,
        'show_online_status': True,  # Placeholder for online status privacy until implemented
        'typing_indicators': True,
        'avatar_url': None,
        'auto_hide_particles': False,  # Disabled by default so particles are visible immediately
        'auto_hide_timeout': 30,  # Increased timeout for better UX
        'mic_volume': 1.0,
        'receive_volume': 1.0,
        'mute': False,
        'toast_on_media_download': True,
        'sound_effects': True,
        'annoying_hover_sounds': False,
        'soundboard_sounds': True,
        'soundboard_volume': 1.0
    }


def _merge_user_table_settings(settings, user_row):
    """Merge settings from users table."""
    if user_row:
        # Only override with users table values if they are not None and not default values
        # This prevents users table defaults from overriding user_settings JSON values
        if user_row['display_name'] is not None:
            settings['display_name'] = user_row['display_name'] or ''
        if user_row['custom_status'] is not None:
            settings['custom_status'] = user_row['custom_status'] or ''
        if user_row['theme'] is not None and user_row['theme'] != 'dobo':
            settings['theme'] = user_row['theme']
        if user_row['font'] is not None and user_row['font'] != 'system':
            settings['font'] = user_row['font']
        # Font scale: only use users table value if it's not NULL and not the default 1.0
        if user_row['font_scale'] is not None and float(user_row['font_scale']) != 1.0:
            settings['font_scale'] = float(user_row['font_scale'])
        if user_row['compact_mode'] is not None:
            settings['compact_mode'] = bool(user_row['compact_mode'])
        if user_row['show_timestamps'] is not None:
            settings['show_timestamps'] = bool(user_row['show_timestamps'])
        if user_row['animated_bg'] is not None and user_row['animated_bg'] != 'none':
            settings['animated_bg'] = user_row['animated_bg']
        if user_row['cursor_effect'] is not None and user_row['cursor_effect'] != 'orbiting':
            settings['cursor_effect'] = user_row['cursor_effect']
        if user_row['particle_style'] is not None and user_row['particle_style'] != 'theme':
            settings['particle_style'] = user_row['particle_style']
        if user_row['cursor_main'] is not None and user_row['cursor_main'] != 'default':
            settings['cursor_main'] = user_row['cursor_main']
        if user_row['cursor_particle'] is not None and user_row['cursor_particle'] != 'default':
            settings['cursor_particle'] = user_row['cursor_particle']
        if user_row['cursor_size'] is not None:
            settings['cursor_size'] = int(user_row['cursor_size'])
        if user_row['cursor_glow'] is not None:
            settings['cursor_glow'] = bool(user_row['cursor_glow'])
        if user_row['particle_size'] is not None:
            settings['particle_size'] = float(user_row['particle_size'])
        if user_row['auto_hide_particles'] is not None:
            settings['auto_hide_particles'] = bool(user_row['auto_hide_particles'])
        if user_row['auto_hide_timeout'] is not None:
            settings['auto_hide_timeout'] = int(user_row['auto_hide_timeout'])
        if user_row['allow_dms'] is not None:
            settings['allow_dms'] = bool(user_row['allow_dms'])
        if user_row['show_online_status'] is not None:
            settings['show_online_status'] = bool(user_row['show_online_status'])
        if user_row['typing_indicators'] is not None:
            settings['typing_indicators'] = bool(user_row['typing_indicators'])
        if user_row['avatar_url'] is not None:
            settings['avatar_url'] = user_row['avatar_url']
        if user_row['toast_on_media_download'] is not None:
            settings['toast_on_media_download'] = bool(user_row['toast_on_media_download'])


def get_user_settings(user_uuid):
    """Get merged user settings from both tables."""
    default_settings = _get_default_settings()

    try:
        # Get user settings from user_settings table
        query1 = "SELECT settings FROM user_settings WHERE user_uuid = ?"
        params1 = (user_uuid,)
        user_settings_result = db_manager.execute_query(query1, params1, fetch=True)

        # Get user-specific settings from users table
        query2 = """SELECT display_name, custom_status, theme, font, font_scale, compact_mode,
                    show_timestamps, animated_bg, cursor_effect, particle_style, cursor_main,
                    cursor_particle, cursor_size, cursor_glow, particle_size, auto_hide_particles,
                    auto_hide_timeout, allow_dms, show_online_status, typing_indicators,
                    avatar_url, toast_on_media_download
                    FROM users WHERE uuid = ?"""
        params2 = (user_uuid,)
        user_result = db_manager.execute_query(query2, params2, fetch=True)

        # Start with default settings
        settings = default_settings.copy()

        # Merge user settings from user_settings table
        if user_settings_result:
            user_settings = json.loads(user_settings_result[0]['settings'])
            settings.update(user_settings)

        # Override with user-specific settings from users table
        if user_result:
            _merge_user_table_settings(settings, user_result[0])

        return settings
    except Exception as e:
        print(f"Error getting user settings: {str(e)}")
        return default_settings


def get_user_ai_settings(user_uuid):
    """Get user's AI settings, with defaults"""
    try:
        settings = get_user_settings(user_uuid)

        # Default AI settings
        default_ai_settings = {
            'ai_active_character': 'Helpful Assistant',
            'ai_temperature': 0.7,
            'ai_max_tokens': 2048,
            'ai_context_window': 4096,
            'ai_history_limit': 50,  # Global context limit for modal/DM conversations
            'ai_model': 'default',
            'ai_system_prompt': 'You are a helpful AI assistant in a chat application. Be friendly and engaging.',
            'ai_custom_instructions': '',
            'ai_context_management_mode': 'client',  # Default to client-side for backward compatibility
            'ai_api_debug': False,  # Enable detailed API logging
            'ai_debug_settings': False,  # Enable settings change logging
            'ai_channel_memory_enabled': True,  # Enable channel memory by default
            'ai_channel_memory_limit': 10,  # Channel-specific context limit
            'ai_modal_memory_enabled': True,  # Enable modal memory by default
            'ai_modal_memory_limit': 15,  # Number of messages for modal context
            'ai_system_prepend': '',  # Text to prepend to system prompts
            'ai_user_prepend': ''  # Text to prepend to user messages
        }

        # Merge with user settings (user settings take precedence)
        ai_settings = default_ai_settings.copy()
        ai_settings.update(settings.get('ai_settings', {}))

        return ai_settings
    except Exception as e:
        print(f"Error getting user AI settings: {str(e)}")
        return default_ai_settings


def update_user_ai_settings(user_uuid, ai_settings):
    """Update user's AI settings"""
    print(f"[DEBUG] update_user_ai_settings called for user_uuid: {user_uuid}")
    try:
        current_settings = get_user_settings(user_uuid)
        print(f"[DEBUG] current_settings: {current_settings}")
        old_ai_settings = current_settings.get('ai_settings', {})

        # Check if debug logging is enabled
        debug_enabled = ai_settings.get('ai_debug_settings', old_ai_settings.get('ai_debug_settings', False))

        if debug_enabled:
            print(f"[AI_SETTINGS_DEBUG] User {user_uuid} updating AI settings:")
            print(f"[AI_SETTINGS_DEBUG] Old settings: {old_ai_settings}")
            print(f"[AI_SETTINGS_DEBUG] New settings: {ai_settings}")

            # Show what changed
            changes = {}
            for key, new_value in ai_settings.items():
                old_value = old_ai_settings.get(key, 'NOT_SET')
                if old_value != new_value:
                    changes[key] = {'old': old_value, 'new': new_value}

            if changes:
                print(f"[AI_SETTINGS_DEBUG] Changes detected: {changes}")
            else:
                print(f"[AI_SETTINGS_DEBUG] No changes detected")

        # Merge with existing AI settings instead of replacing
        existing_ai_settings = current_settings.get('ai_settings', {})
        existing_ai_settings.update(ai_settings)
        current_settings['ai_settings'] = existing_ai_settings
        print(f"[DEBUG] About to call update_user_settings with: {current_settings}")
        result = update_user_settings(user_uuid, current_settings)
        print(f"[DEBUG] update_user_settings returned: {result}")

        return True
    except Exception as e:
        print(f"Error updating user AI settings: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def get_system_settings():
    """Get global system settings"""
    try:
        conn = sqlite3.connect('devchat.db')
        cursor = conn.cursor()

        cursor.execute("SELECT key, value FROM system_settings")
        rows = cursor.fetchall()
        conn.close()

        # Start with defaults
        settings = {
            'debug_mode': False,
            'max_users': 100,
            'ai_endpoint_url': 'http://localhost:1234'
        }

        # Override with stored values
        for key, value in rows:
            if key == 'debug_mode':
                settings[key] = value.lower() == 'true'
            elif key == 'max_users':
                settings[key] = int(value)
            else:
                settings[key] = value

        return settings
    except Exception as e:
        print(f"Error getting system settings: {str(e)}")
        return {
            'debug_mode': False,
            'max_users': 100,
            'ai_endpoint_url': 'http://localhost:1234'
        }


def save_system_settings(settings):
    """Save global system settings"""
    try:
        conn = sqlite3.connect('devchat.db')
        cursor = conn.cursor()

        for key, value in settings.items():
            cursor.execute("""
                INSERT OR REPLACE INTO system_settings (key, value)
                VALUES (?, ?)
            """, (key, str(value)))

        conn.commit()
        conn.close()
        print(f"Saving system settings: {settings}")
        return True
    except Exception as e:
        print(f"Error saving system settings: {str(e)}")
        return False