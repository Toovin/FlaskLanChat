# database_files.py - File management database functions
import sqlite3
from datetime import datetime
from .database_manager import DatabaseManager

# Global database manager instance
db_manager = DatabaseManager('devchat.db')


def get_files_in_folder(folder_id, user=None, visibility_filter=None):
    """Get files in folder with optional filtering by user and visibility."""
    conn = None
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        # Handle folder_id = 0 as root folder
        if folder_id == 0:
            # Get the root folder ID (the 'Share' folder)
            root_query = "SELECT id FROM folders WHERE parent_id IS NULL AND name = 'Share'"
            c.execute(root_query)
            root_result = c.fetchone()
            if root_result:
                root_folder_id = root_result[0]
                query = """
                    SELECT id, filename, filepath, size, created_at, created_by, thumbnail_url,
                           visibility, shared_by, ownership
                    FROM file_folders
                    WHERE folder_id = ?
                """
                params = [root_folder_id]
            else:
                # Fallback: if no root folder, get files with NULL folder_id
                query = """
                    SELECT id, filename, filepath, size, created_at, created_by, thumbnail_url,
                           visibility, shared_by, ownership
                    FROM file_folders
                    WHERE folder_id IS NULL
                """
                params = []
        else:
            query = """
                SELECT id, filename, filepath, size, created_at, created_by, thumbnail_url,
                       visibility, shared_by, ownership
                FROM file_folders
                WHERE folder_id = ?
            """
            params = [folder_id]

        # Add visibility filtering
        if visibility_filter:
            if visibility_filter == 'public':
                # Public: show files shared by any user (visibility='public' and ownership='user')
                query += " AND visibility = 'public' AND ownership = 'user'"
            elif visibility_filter == 'private':
                # Private: show only user's own files that are not shared (visibility='private')
                query += " AND visibility = 'private' AND created_by = ? AND ownership = 'user'"
                params.append(user)
            elif visibility_filter == 'system':
                # System: show system-owned files
                query += " AND ownership = 'system'"

        query += " ORDER BY created_at DESC"

        c.execute(query, params)
        rows = c.fetchall()

        files = []
        for row in rows:
            files.append({
                'id': row[0],
                'filename': row[1],
                'filepath': row[2],
                'size': row[3],
                'created_at': row[4],
                'created_by': row[5],
                'thumbnail_url': row[6],
                'visibility': row[7] or 'private',
                'shared_by': row[8],
                'ownership': row[9] or 'user'
            })
        return files
    except Exception as e:
        print(f"Error getting files in folder: {str(e)}")
        return []
    finally:
        if conn:
            conn.close()


def add_file_to_folder(filename, folder_id, filepath, size, created_by, thumbnail_url=None, visibility='private', ownership='user'):
    """Add a file to a folder with sharing options."""
    conn = None
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("""
            INSERT INTO file_folders (filename, folder_id, filepath, size, created_at, created_by, thumbnail_url, visibility, ownership)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (filename, folder_id, filepath, size, datetime.now().isoformat(), created_by, thumbnail_url, visibility, ownership))
        file_id = c.lastrowid
        conn.commit()
        return file_id
    except Exception as e:
        print(f"Error adding file to folder: {str(e)}")
        if conn:
            conn.rollback()
        return None
    finally:
        if conn:
            conn.close()


def update_file_visibility(file_id, visibility, shared_by=None):
    """Update file visibility and sharing info."""
    conn = None
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("""
            UPDATE file_folders
            SET visibility = ?, shared_by = ?
            WHERE id = ?
        """, (visibility, shared_by, file_id))
        conn.commit()
        return True
    except Exception as e:
        print(f"Error updating file visibility: {str(e)}")
        if conn:
            conn.rollback()
        return False
    finally:
        if conn:
            conn.close()


def delete_file_from_folder(file_id):
    """Delete a file from a folder."""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()
        c.execute("DELETE FROM file_folders WHERE id = ?", (file_id,))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error deleting file from folder: {str(e)}")
        return False


def get_public_files(user):
    """Get all public files (user-owned files in Public_Folder)"""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        c.execute("""
            SELECT id, filename, filepath, size, created_at, created_by, thumbnail_url
            FROM file_folders
            WHERE filepath LIKE 'file_share_system/Public_Folder/%'
            AND created_by = ?
            ORDER BY created_at DESC
        """, (user,))

        files = []
        for row in c.fetchall():
            files.append({
                'id': row[0],
                'filename': row[1],
                'filepath': row[2],
                'size': row[3],
                'created_at': row[4],
                'created_by': row[5],
                'thumbnail_url': row[6]
            })

        conn.close()
        return files
    except Exception as e:
        print(f"Error getting public files for user {user}: {str(e)}")
        return []


def get_server_files():
    """Get all server files (read-only system files)"""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        c.execute("""
            SELECT id, filename, filepath, size, created_at, created_by, thumbnail_url
            FROM file_folders
            WHERE filepath LIKE 'file_share_system/system_shared_files/%'
            ORDER BY created_at DESC
        """)

        files = []
        for row in c.fetchall():
            files.append({
                'id': row[0],
                'filename': row[1],
                'filepath': row[2],
                'size': row[3],
                'created_at': row[4],
                'created_by': row[5],
                'thumbnail_url': row[6]
            })

        conn.close()
        return files
    except Exception as e:
        print(f"Error getting server files: {str(e)}")
        return []


def add_file_to_public(filename, filepath, size, created_by, thumbnail_url=None):
    """Add a file to the public section"""
    try:
        from datetime import datetime
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        created_at = datetime.now().isoformat()

        c.execute("""
            INSERT INTO file_folders (filename, filepath, size, created_at, created_by, thumbnail_url, visibility, ownership)
            VALUES (?, ?, ?, ?, ?, ?, 'public', 'user')
        """, (filename, filepath, size, created_at, created_by, thumbnail_url))

        file_id = c.lastrowid
        conn.commit()
        conn.close()

        print(f"Added public file: {filename} by {created_by}")
        return file_id
    except Exception as e:
        print(f"Error adding public file {filename}: {str(e)}")
        return None


def delete_file_from_public(filename, user):
    """Delete a file from the public section (only if user owns it)"""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        c.execute("""
            DELETE FROM file_folders
            WHERE filename = ? AND created_by = ? AND filepath LIKE 'file_share_system/Public_Folder/%'
        """, (filename, user))

        success = c.rowcount > 0
        conn.commit()
        conn.close()

        if success:
            print(f"Deleted public file: {filename} by {user}")
        return success
    except Exception as e:
        print(f"Error deleting public file {filename}: {str(e)}")
        return False


def rename_file_in_public(old_filename, new_filename, user):
    """Rename a file in the public section (only if user owns it)"""
    try:
        conn = sqlite3.connect('devchat.db')
        c = conn.cursor()

        # Update filename and filepath
        new_filepath = f'file_share_system/Public_Folder/{new_filename}'

        c.execute("""
            UPDATE file_folders
            SET filename = ?, filepath = ?
            WHERE filename = ? AND created_by = ? AND filepath LIKE 'file_share_system/Public_Folder/%'
        """, (new_filename, new_filepath, old_filename, user))

        success = c.rowcount > 0
        conn.commit()
        conn.close()

        if success:
            print(f"Renamed public file: {old_filename} -> {new_filename} by {user}")
        return success
    except Exception as e:
        print(f"Error renaming public file {old_filename}: {str(e)}")
        return False